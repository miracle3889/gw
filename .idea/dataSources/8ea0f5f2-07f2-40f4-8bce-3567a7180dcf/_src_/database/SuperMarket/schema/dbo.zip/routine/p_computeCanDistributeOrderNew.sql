CREATE   PROCEDURE  p_computeCanDistributeOrderNew
AS
	
	/*update tb_order set orderstatus=3,visaTime=getDate(),visaRemark='ZIDO' where isPayment=1 and magazineCodeS='cft' and orderstatus in(1,20) and isdelete<>1 
	and id in(select orderId from tb_orderSaleProduct where saleProductId=21315)	
	and id not in(
	select a.id from tb_order a
	inner join tb_orderSaleProduct b on a.id=b.orderId and  saleProductId<>21315
	 where isPayment=1 and magazineCodeS='cft' and orderstatus in(1,20) and isdelete<>1 	
	)*/

	DECLARE @orderId int
	DECLARE @productId int
	DECLARE @doManId int
	DECLARE @magSourceRemark varchar(50)
	delete from erp..tb_canDistributeOrder 
	DELETE FROM erp..tb_tempWorkOrder --清空临时表
	DELETE FROM erp..tb_notCanDistributeProduct --清空缺货表
	DELETE FROM erp..tb_canDistributeOrderTemp
	

	INSERT INTO  erp..tb_tempWorkOrder(orderId,doManId,magSourceRemark) 
	
	SELECT   ID,memberId,magSourceRemark FROM tb_order WHERE orderstatus=1 and isdelete<>1 and isUpdate=0   
	and magSourceRemark='taobao' and id not in(select orderId from  tb_needUpdateProductCode)  --and  orderCode in('SD1112120173','SD1112164676')
	and memberId<>73650   --and createTime<='2011-12-17'  ---剔除淘宝订单   
	--and memberId  in(SELECT memberId  FROM tb_taobaoMember where taobaoNickName in(select nickName from tb_lockNick))
	--and createTime<='2011-11-25 20:00:00'
	--order by   paymentDate 
	order by   createTime 

	INSERT INTO  erp..tb_tempWorkOrder(orderId,doManId,magSourceRemark) 
	
	SELECT  ID,memberId,magSourceRemark FROM tb_order WHERE orderstatus=1 and isdelete<>1 and isUpdate=0  
	 and isnull(magSourceRemark,'')<>'taobao'   and payType=1 and   memberId  in(7327,691356,873561,884612,1736)


	INSERT INTO  erp..tb_tempWorkOrder(orderId,doManId,magSourceRemark) 
	
	SELECT  ID,memberId,magSourceRemark FROM tb_order WHERE orderstatus=1 and isdelete<>1 and isUpdate=0  
	 and isnull(magSourceRemark,'')<>'taobao'   and payType<>1 
	
	
	--and   id in(select id from  tb_temp_payType1)
	--and memberId<>73650  ---剔除淘宝订单
	--and id not in(select orderId from tb_preOrder)--预售商品暂不配货
	--order by  case when paytype=1 then 0 else 1 end  ,id desc
	
	--去当前等待配货状态中订单
	delete from tb_tempSaleProduct
	delete from erp..tb_shelfProductCountTemp
	
	insert into erp..tb_shelfProductCountTemp   select  *  from erp..tb_shelfProductCount 
	where   shelfCode not in('X0000','Y0000','A0000')  and productCount>0   --and shelfCode not like  'T____'  -- ---剔除淘宝货架
	and shelfCode not in(select code from erp..tb_GoodsShelf where isLock=1)-- and   productCode not in(select * from tb_someOne)
	
	delete from erp..tb_distributeProductShelfTemp

	insert into erp..tb_distributeProductShelfTemp	
	select x.*  from erp..tb_distributeProductShelf x			
       	 inner join erp..tb_Distribute y on x.distributeId=y.id  and y.isTransfer=0  
	
	--where y.id not in ---去除淘宝未完成取货
	--(
	--	select y.id from erp..tb_Distribute y 
	--	inner join  erp..tb_orderDistribute z on z.distributeId=y.id  and y.isTransfer=0   and z.memberId=73650
	--)


	insert into tb_tempSaleProduct(orderId,productShelfCode,buyCount,productId,stockId)

	SELECT  a.orderId,c.productShelfCode,sum(a.buyCount) as buyCount,c.productId,c.id  FROM tb_orderSaleProduct a
	inner join  ERP..tb_tempWorkOrder  x on x.orderId=a.orderId
	--INNER JOIN tb_saleProduct b ON a.saleProductId=b.id  
	INNER JOIN erp..tb_productStock c ON a.productId=c.productId and a.colorId=c.colorId and a.metricsId=c.metricsId where a.buyCount>0
	
	group by  a.orderId,c.productShelfCode,c.productId,c.id


	update tb_orderSaleProduct set stockPrice=b.stockPriceReal from 
	tb_orderSaleProduct a,erp..tb_product b where a.productId=b.id and   a.stockPrice=0 and a.orderId in(select orderId from erp..tb_tempWorkOrder)
	and b.stockPriceReal>0 
		
	--核算订单是否缺货
	DECLARE authors_cursor CURSOR FOR
		select orderId,doManId,magSourceRemark from  ERP..tb_tempWorkOrder     order by orderByClass
		--order by  case  when magSourceRemark='taobao' then 0  else 1 end 
	OPEN authors_cursor
	FETCH NEXT FROM authors_cursor 
	INTO @orderId,@doManId,@magSourceRemark
	WHILE @@FETCH_STATUS = 0
	BEGIN
		DECLARE @outTypeCount INT --缺货商品种类
		DECLARE @stockId INT
		DECLARE @outCount INT

		DECLARE @buyCount INT --订单中数量
		DECLARE @shelCount INT --货架中数量
		DECLARE @inOrderCount INT --可配货订单中数量
		DECLARE @inOrderCount2  INT --可配货订单中数量
		DECLARE @notDistributeCount INT
		DECLARE @productShelfCode VARCHAR(20)  --上品编号
				

		SET  @outTypeCount=0
		
		
		--update tb_orderSaleProduct set stockPrice=b.stockPriceReal from 
		--tb_orderSaleProduct a,erp..tb_product b where a.productId=b.id and   a.stockPrice=0 and a.orderId=@orderId

		DECLARE authors_cursor2 CURSOR FOR
			SELECT  productShelfCode,sum(buyCount),productId,stockId from tb_tempSaleProduct 
			where orderId=@orderId group by productShelfCode,buyCount,productId,stockId
		OPEN authors_cursor2
		FETCH NEXT FROM authors_cursor2  INTO @productShelfCode,@buyCount,@productId,@stockId
		WHILE @@FETCH_STATUS = 0
		BEGIN			
			
			if(@productShelfCode is null or @productShelfCode='') 
			BEGIN
				set @productShelfCode=''
				
			END
			ELSE
			BEGIN
				if exists( select 1 from tb_qhOrderSaleProduct where orderId =@orderId and productCode=@productShelfCode)
				begin
					INSERT INTO erp..tb_notCanDistributeProduct(orderId,productCode,outCount,productId) 
					values(@orderId,@productShelfCode,@buyCount,@stockId)
					SET @outTypeCount=@outTypeCount+1
				end
				else
				begin
					--货架数量
					if(@magSourceRemark='taobao')
					begin
						select  @shelCount=sum(productCount) from erp..tb_shelfProductCountTemp 
						where  productCode=@productShelfCode and  shelfCode not in('X0000','Y0000','A0000') 
					end
					else
					begin
						select  @shelCount=sum(productCount) from erp..tb_shelfProductCountTemp 
						where  productCode=@productShelfCode and  shelfCode not in('X0000','Y0000','A0000') 
						and shelfCode not like  'T____'  -- ---剔除淘宝货架
	
					end
		                                --         and shelfCode not like 'C07__'  and shelfCode not like 'C08__'  and shelfCode not like 'C09__'  and shelfCode 
					--not like 'C10__'  and shelfCode not like 'C11__'  and shelfCode not like 'C12__' 
		                                        -- 锁定C07-C12的不配货  孙雷  10.07.139
					if(@shelCount is null) set @shelCount=0
					if(@shelCount<0) set @shelCount=0
					-- -可配货订单中数量
					
				
					--可配货订单商品
					SELECT @inOrderCount=sum(buyCount) FROM tb_tempSaleProduct
						where productShelfCode=@productShelfCode and  				
						(
							orderId in(select orderId from erp..tb_canDistributeOrderTemp)
							or orderId in
							(
								select orderId from erp..tb_tempWorkOrder where  
								orderId in(select orderId from erp..tb_notCanDistributeProduct) and orderId <>@orderId 
								and magSourceRemark='taobao' 
								and orderid not in(
								select orderId from tb_notneedKcOrderSale where productCode =@productShelfCode )
							)
						)      
					
					---淘宝已算出缺货商品
					/*select @inOrderCount2=sum(a.outCount) from erp..tb_notCanDistributeProduct  a
					inner join   erp..tb_tempWorkOrder b on a.orderId=b.orderId and magSourceRemark='taobao'
					 where productCode=@productShelfCode
					
					set 	@inOrderCount=isnull(@inOrderCount,0)+isnull(@inOrderCount2,0)
					*/
					
					if(@inOrderCount is null) set @inOrderCount=0
					
					--配货但未取货完成的
					select @notDistributeCount=sum(productCount)  from erp..tb_distributeProductShelfTemp 
					 where productCode=@productShelfCode
						
					if(@notDistributeCount is null) set @notDistributeCount=0			
		
					if((ISNULL(@shelCount,0)-ISNULL(@inOrderCount,0)-ISNULL(@notDistributeCount,0))<0)
					BEGIN
						SET @outCount=@buyCount*-1 --计算库存
					END
					ELSE
					BEGIN
						SET @outCount=ISNULL(@shelCount,0)-ISNULL(@inOrderCount,0)-ISNULL(@notDistributeCount,0)-@buyCount --计算库存
					END
					if(@outCount<0) --货架数量不够
					BEGIN
						INSERT INTO erp..tb_notCanDistributeProduct(orderId,productCode,outCount,productId) 
						values(@orderId,@productShelfCode,@outCount*-1,@stockId)
						SET @outTypeCount=@outTypeCount+1
					END
			end
			END
			--end
			
			FETCH NEXT FROM authors_cursor2  
			INTO @productShelfCode,@buyCount,@productId,@stockId
		END
		CLOSE authors_cursor2
		DEALLOCATE authors_cursor2

		IF(@outTypeCount=0)
		BEGIN
			INSERT INTO erp..tb_canDistributeOrderTemp(orderId) values(@orderId)
		END 

		FETCH NEXT FROM authors_cursor 
		INTO @orderId,@doManId,@magSourceRemark
	END

	CLOSE authors_cursor


	DEALLOCATE authors_cursor
	
	

	delete from erp..tb_canDistributeOrder 

	
	insert into erp..tb_canDistributeOrder(orderId) select orderId from erp..tb_canDistributeOrderTemp 
	
	--delete from erp..tb_canDistributeOrder where orderId not in( select orderId from  erp..tb_canDistributeOrderTemp) --删除已经不能配货订单
	
	--insert into erp..tb_canDistributeOrder(orderId) select orderId from erp..tb_canDistributeOrderTemp 
	--where orderId not in(select orderId from erp..tb_canDistributeOrder)--加入新订单
	
	
	declare @dateAdd dateTime


	set 	@dateAdd =getDate()

	insert into  ERP..tb_tempSaleProductHis(productShelfCode,buyCOunt,productId,orderId,isHasProduct,StockId,addDate)
	select productShelfCode,buyCOunt,productId,orderId,isHasProduct,StockId,@dateAdd from  tb_tempSaleProduct
	
	insert into ERP..tb_distributeProductShelfTempHis(id,distributeId,productCode,shelfCode,productCount,addDate)
	select id,distributeId,productCode,shelfCode,productCount,@dateAdd  from erp..tb_distributeProductShelfTemp

	insert into   ERP..tb_canDistributeOrderTempHis(orderId,addDate)
	select orderId,@dateAdd from  erp..tb_canDistributeOrderTemp
	
	
	insert into erp..tb_shelfProductCountTempHis(id,shelfCode,productCode,productCount,productRemark,addDate)
	select id,shelfCode,productCode,productCount,productRemark,@dateAdd  from erp..tb_shelfProductCountTemp
	
	/*

	delete from erp..tb_orderNotReplenish

	insert into erp..tb_orderNotReplenish(orderId,colorId,productId,metricsId,outCount)
	select a.orderId,c.colorId,c.productId,c.metricsId,outCount from  erp..tb_notCanDistributeProduct a
	inner join  tb_order b on a.orderId=b.id and b.createTime<='2010-11-07'
	inner join erp..tb_productStock c on c.id=a.productId
	*/
	
	delete from erp..tb_cannotPhProduct

	insert into   erp..tb_cannotPhProduct
	select a.id,a.saleProductId,(a.buyCount-isnull(b.productCount,0)-isnull(c.buyCount,0)) as qh  from 
	(
	select  min(saleProductId) as saleProductId,b.id,sum(buyCount) as buyCount from supermarket..tb_orderSaleProduct   a
	inner join erp..tb_productStock b on a.colorId=b.colorId and a.metricsId=b.metricsId

	where orderId in(select orderId from erp..tb_notCanDistributeProduct)  
	
	group by  b.id) as a
	left join 
	(
	select  b.id,sum(a.productCount) as productCount from erp..tb_shelfProductCount a 
	inner join erp..tb_productStock b  on a.productCode=b.productShelfCode
		where   shelfCode not in('X0000','Y0000','A0000') and a.productCount>0 
	group by b.id
	) as b  on a.id=b.id
	left join 
	(
		select b.id,sum(buyCount) as buyCount from supermarket..tb_orderSaleProduct   a
		inner join erp..tb_productStock b on a.colorId=b.colorId and a.metricsId=b.metricsId
		where orderId in(select orderId from erp..tb_canDistributeOrder) 
		group by b.id
	) 
	as c  on a.id=c.id
	

	 where a.buyCount-isnull(b.productCount,0)-isnull(c.buyCount,0)>0 
	
	exec erp..p_setcannotPhProduct	
	
	delete from  erp..tb_orderNotReplenish
	
	insert into  erp..tb_orderNotReplenish(orderId,colorid,productId,metricsId,outCount)
	
	select a.orderId,b.colorid,b.productId,b.metricsId,a.outCount from erp..tb_notCanDistributeProduct a
	inner join erp..tb_productStock b on a.productId=b.id
	inner join supermarket..tb_orderSaleProduct c on  a.orderId=c.orderId and c.colorId=b.colorId and c.metricsid=b.metricsid
	
	 where a.productId in(select * from erp..tb_notBuyProduct)


	insert into tb_befor7daysOrder(orderId)
	select a.orderId  from erp..tb_canDistributeOrder a
inner join tb_order b on a.orderId=b.id where dateDiff(day,createTime,getDate())>7 and a.orderId not in(select orderId from tb_befor7daysOrder ) and b.magSourceRemark<>'taobao'
	
	delete from tb_befor7daysOrder where orderId not in(select orderId from   erp..tb_canDistributeOrder )
	/*
	delete from erp..tb_orderNotReplenish

	insert into  erp..tb_orderNotReplenish(orderId,productId,colorId,metricsId,outCount)
	select a.orderId,c.id,d.id as colorId,e.id as metricsId,sum(a.outCount) as outCount
	 from erp..tb_notCanDistributeProduct a 
	inner join erp..tb_productStock b on a.productCode=b.productshelfCode 
	inner join erp..tb_product c on b.productId=c.id 
	inner join erp.dbo.tb_productColorCode d on d.id=b.colorId 
	inner join erp.dbo.tb_productMetricsCode e on e.id=b.MetricsId 
	left join erp.dbo.tb_shelfProductCount f on f.productCode=a.productCode  and f.shelfCode='A0000' 
	left join( 

	select  b.colorId,b.metricsId,sum(b.buyCount) as needInCount from erp. dbo.tb_buyProductList a  	

	inner join erp.dbo.tb_buyProductProtity b on a.id=b.buyProductId and a.buyStatus in(1,2,3) and isdeleted<>1 	
	group by productId, colorId, metricsId having(sum(b.buyCount)>0)) g 
	on g.colorId=d.id and g.metricsId=e.id 
	where  isnull(g.needInCount,0) =0 and isnull(f.productCount,0)=0
	
	group by a.orderId,c.id,a.productCode,d.id,e.id,c.name,d.codeName,e.codeName,c.fillTimeRemark,isnull(f.productCount,0),isnull(g.needInCount,0) 
	order by a.orderId




	delete from   erp..tb_orderNotReplenish from  
	erp..tb_orderNotReplenish as  a 
	 inner join (
		select c.productId ,c.colorId,c.metricsId  from erp..tb_orderInstockProduct a ,erp..tb_orderInstock b,erp..tb_productStock c 
		where b.status in (0,1) and b.id=a.instockId and a.productCode=c.productShelfCode 
		group by c.productId,c.colorId,c.metricsId  having sum(a.productCount) >0)  as b 
	on   a.colorId=b.colorId and a.metricsId=b.metricsId
*/
