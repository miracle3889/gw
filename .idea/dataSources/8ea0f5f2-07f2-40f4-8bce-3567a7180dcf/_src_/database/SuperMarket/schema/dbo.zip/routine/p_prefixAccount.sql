

CREATE       procedure p_prefixAccount
as 
	declare @memberId int --会员号
	declare @mobileNum varchar(50) --会员号
	declare @orderCode varchar(200)--订单号
	declare @content varchar(200)--订单号

	declare @orderId int --订单ID
	DECLARE  @realPrice INT,
		 @backPrice INT,
		 @useGift INT,
		@giveAccount int
	
	DECLARE authors_cursor CURSOR FOR
	
	select id,orderCode,memberId,useGift from tb_order where orderstatus in(2,3,17) and isDelete!=1
	and DATEDIFF(hour,createTime,getdate())>=168 and createTime>='2008-12-18' and createTime < '2009-1-6' and  orderCode not in(select orderCode from tb_accountOpLog where opType=1) --大于168小时
	
	OPEN authors_cursor
	FETCH NEXT FROM authors_cursor 
	INTO @orderId,@orderCode,@memberId,@useGift
	WHILE @@FETCH_STATUS = 0
	BEGIN
		begin tran 
		SELECT @realPrice=SUM(b.payValue*a.buyCount),@backPrice=SUM(b.payValue*a.backCount) 
		FROM dbo.tb_orderSaleProduct a
		INNER JOIN dbo.tb_orderSaleProductPay b ON a.id=b.orderSaleProductId 
		WHERE b.payType=1 AND a.orderId=@orderId   --得到定单总价格	
		set @giveAccount=0
		if((@realPrice-@backPrice-@useGift)>=20000)
			set @giveAccount=4000--满200
		if((@realPrice-@backPrice-@useGift)>=50000)
			set @giveAccount=10000--满500
		if((@realPrice-@backPrice-@useGift)>=70000)
			set @giveAccount=14000--满500
		if((@realPrice-@backPrice-@useGift)>=100000)
			set @giveAccount=20000--满500
		if(@giveAccount>0)
		begin
			exec  p_addAccountOpLog @memberID,@giveAccount,1,@orderCode --圣诞
			select @mobileNum=mobileNum from tb_member where id=@memberId
			set @content=cast((@giveAccount/100) as varchar(20))+'元现金已经返还到您的优邮帐户上，无任何使用限制，谢谢您的惠顾，欢迎您的再次光临。www.yoyo18.com'
			exec p_sendMsgByClass @mobileNum,@content,10,0
		end
		commit tran 

		FETCH NEXT FROM authors_cursor 
		INTO @orderId,@orderCode,@memberId,@useGift
	END
	
	CLOSE authors_cursor
	DEALLOCATE authors_cursor