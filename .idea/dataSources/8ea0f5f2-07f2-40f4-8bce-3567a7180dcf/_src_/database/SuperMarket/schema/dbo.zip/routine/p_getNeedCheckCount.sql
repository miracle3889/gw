/*----------------------------------------得到需要审核的定单数量-------------------------------------------------*/
CREATE PROCEDURE p_getNeedCheckCount 
AS
	--SELECT COUNT(*) FROM tb_order WHERE orderStatus=5 AND magazineCode=1 AND isDelete!=1 and payType<>7
	select 0