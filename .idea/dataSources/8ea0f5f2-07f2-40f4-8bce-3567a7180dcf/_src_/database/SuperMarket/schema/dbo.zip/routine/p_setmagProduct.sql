
CREATE procedure p_setmagProduct 
as 

update tb_magProduct set salePrice=b.salePrice,saleCount=b.saleCount from tb_magProduct a,(

select a.id,b.saleId,sum((c.buyCount-c.backCount-isNULL(f.getCount,0))) as saleCount ,sum((c.buyCount-c.backCount-isNULL(f.getCount,0))*e.payValue) as salePrice from tb_magSourceRemark a
inner join  tb_magProduct b on a.id=b.magId 
inner join tb_order d on  d.magSourceRemark like a.magSource and d.isdelete<>1   and orderstatus in(1,2,3,17,13,20) and d.createTime>=a.issueTime
inner join  tb_ordersaleProduct c on c.saleProductId=b.saleId and   c.orderId=d.id  
inner join tb_orderSaleProductPay e on e.orderSaleProductId=c.id and e.payType=1
left join  (select orderSaleId,sum(getCount) as getCount from  tb_backProduct  group by orderSaleId) f on f.orderSaleId=c.id
group by  a.id,b.saleId  ) b where a.magId=b.id and a.saleId=b.saleId



update tb_magProduct set salePriceOther=b.salePrice,saleCountOther=b.saleCount from tb_magProduct a,(

select a.id,b.saleId,sum((c.buyCount-c.backCount-isNULL(f.getCount,0))) as saleCount ,
sum((c.buyCount-c.backCount-isNULL(f.getCount,0))*e.payValue) as salePrice from tb_magSourceRemark a
inner join  tb_magProduct b on a.id=b.magId 
inner join tb_order d on  d.magSourceRemark not  like '[0-9]%' and d.isdelete<>1   
and orderstatus in(1,2,3,17,13,20) and d.createTime>=a.issueTime

inner join  tb_ordersaleProduct c on c.saleProductId=b.saleId and   c.orderId=d.id  
inner join tb_orderSaleProductPay e on e.orderSaleProductId=c.id and e.payType=1
left join  (select orderSaleId,sum(getCount) as getCount from  tb_backProduct  group by orderSaleId) f on f.orderSaleId=c.id
group by  a.id,b.saleId  ) b where a.magId=b.id and a.saleId=b.saleId






update tb_magSourceRemark set salePrice=b.salePrice from tb_magSourceRemark a,(


select a.id,sum(b.productPrice+b.deliverPrice-b.useAccount-b.useGift-b.backPrice-isnull(c.payPrice,0)) as salePrice 

from tb_magSourceRemark a
inner join tb_order b  on  b.magSourceRemark like a.magSource and b.isdelete<>1  and orderstatus in(1,2,3,17,13,20) and b.createTime>=a.issueTime
left join  tb_backOder c on c.ordeId=b.id and c.isDeleted<>1 and payPrice>0
group by a.id


) as b where a.id=b.id
