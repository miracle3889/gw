/*---------------更新会员信息(确认收货人处修改)-------------------------*/
CREATE PROCEDURE p_web_updateMember2 @name VARCHAR(50),@HomeAddrRegional INT,
				  @HomeAddr VARCHAR(500),@ComplanyAddrRegional INT, @ComplanyAddr VARCHAR(500),
				  @mobileNum VARCHAR(50),@phoneNum VARCHAR(50),
				  @post VARCHAR(50),@memberId INT,@provinceId INT,@cityId INT,@addrId INT,@payType INT,@deliverTime VARCHAR(32) 
AS
	BEGIN TRAN
	
	UPDATE dbo.tb_member SET name=@name,homeAddrRegional=@HomeAddrRegional,complanyAddrRegional=@ComplanyAddrRegional,
	complanyAddr=@ComplanyAddr,homeAddr=@HomeAddr,
	mobileNum=@mobileNum,phoneNum=@phoneNum,post=@post ,provinceId=@provinceId,cityId=@cityId,addrId=@addrId,payType=@payType,deliverTime=@deliverTime WHERE id=@memberId

	IF(@@ERROR<>0)
	BEGIN
		ROLLBACK TRAN 
	END
	COMMIT TRAN