-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[p_transformPurchase]
AS
BEGIN
	declare @unitPrice bigint,@multiId_Comfirm int,@purchaseId int,@purchaseCode varchar(100)

	-- 插入有采购单的库存
	DECLARE MyCursor CURSOR	
	FOR
		select saleCode,applyUserId,brandId,taxPrice,suppliderId,factoryId,SUM(puchaseCount) puchaseCount,SUM(productCount) productCount from (
			select saleCode,applyUserId,brandId,skucode,suppliderId,factoryId,taxPrice,productCount+notInCount as puchaseCount,productCount from (

				select sum(case when isStopInStorage =1 then  0 else 
					case when b.amount-b.storageCount<0 then 0 else b.amount-b.storageCount end  
					 end ) as notInCount,b.skucode,min(a.taxPrice) as taxPrice,MIN(a.saleCode) as saleCode
					 ,MIN(suppliderId) as suppliderId,MIN(factoryId) as factoryId,
					 min(applyUserId) as applyUserId,min(brandId) as brandId 
				   from SuperMarket..pro_purchase a 
				inner join  SuperMarket..pro_purchase_child  b on a.purchaseCode=b.purchaseCode
				where a.approvalstatus = 3
				group by skucode

			) as x
			inner join ERP..tb_productStock  y on x.skucode=y.productShelfCode
			where productCount+notInCount>0
		) as m group by saleCode,taxPrice,suppliderId,factoryId ,applyUserId,brandId
	
	
	
	
	OPEN MyCursor
	
	--循环一个游标
	DECLARE @salecode varchar(20),@applyUserId int,@brandId int,@taxPrice int,@suppliderId int ,@factoryId int ,@puchaseCount int ,@productCount int,@notPaidMoney int
		FETCH NEXT FROM  MyCursor INTO @salecode,@applyUserId,@brandId,@taxPrice,@suppliderId,@factoryId,@puchaseCount,@productCount
	WHILE @@FETCH_STATUS =0
		BEGIN
			--插入采购单主表  
			--1.获取purchaseCode
			--2.获取pid
			--3.unitPrice
			
			
			--获取不含税单价
			set @unitPrice = @taxPrice/1.17
			
			--获取图片pid
			INSERT INTO ERP..tb_multimedia_pid(type,count)VALUES (1,0) 
			
		     set @multiId_Comfirm=SCOPE_IDENTITY()
		     
		     --获得未付款金额   --
		     select @notPaidMoney = SUM(
				case when isStopInStorage=1 then 
					case when storageAmount*taxPrice-paidMoney<0 then 0 else storageAmount*taxPrice-paidMoney end 
				else  
					case when totalMoney-paidMoney<0 then 0 else totalMoney-paidMoney end 
				end
			 ) 
		      from SuperMarket..pro_purchase a 
		      where a.approvalStatus = 3 and a.saleCode = @salecode 
		     
		     declare @day varchar(3) 
		     set @day =  cast((cast(RAND()*20 as int)+10) as varchar(3))
		     --插入主表
			insert into supplyCenter..pro_purchase 
			(
			 purchaseCode,saleCode,contractId,suppliderId,totalMoney,totalPrice,amount,taxPrice,unitPrice,exceptOnlineTime,exceptArriveTime,
			 applytime,approvalstatus,approvaltype,currentprocess,paidMoney,applyUserId,picId,brandId,factoryId,
			 stockamount,notPaidMoney,removeUserId
			)
			values
			(
				'',@salecode,0,@suppliderId,@taxPrice*@puchaseCount,@unitPrice*@puchaseCount,@puchaseCount,@taxPrice,@unitPrice,
				GETDATE(),GETDATE(),GETDATE(),3,2,1,0,@applyUserId,@multiId_Comfirm,@brandId,@factoryId,@productCount,@notPaidMoney,0
			)
			--1.获取purchaseCode
			set @purchaseId = SCOPE_IDENTITY()
			set @purchaseCode = CAST(@purchaseId as varchar(100))
			while(LEN(@purchaseCode)<4) set @purchaseCode = '0'+@purchaseCode
			set @purchaseCode = 'CP164'+@day+@purchaseCode
			update supplyCenter..pro_purchase set purchaseCode = @purchaseCode where id = @purchaseId
			
			
			-- 插入子表信息
			
			insert into supplyCenter..pro_purchase_child(skucode,purchaseCode,amount,storageCount,qualityCount) 
			select isnull(skucode,''),@purchaseCode,productCount+notInCount as puchaseCount,0,productCount from (
				select sum(case when isStopInStorage =1 then  0 else 
					case when b.amount-b.storageCount<0 then 0 else b.amount-b.storageCount end  
					 end ) as notInCount,b.skucode,min(a.taxPrice) as taxPrice,MIN(a.saleCode) as saleCode
					 ,MIN(suppliderId) as suppliderId,MIN(factoryId) as factoryId,
					 min(applyUserId) as applyUserId,min(brandId) as brandId 
				   from SuperMarket..pro_purchase a 
				inner join  SuperMarket..pro_purchase_child  b on a.purchaseCode=b.purchaseCode
				where a.approvalstatus = 3
				group by skucode

				) as x
				inner join ERP..tb_productStock  y on x.skucode=y.productShelfCode
			where productCount+notInCount>0 and saleCode = @salecode
			
			
			
			FETCH NEXT FROM  MyCursor INTO @salecode,@applyUserId,@brandId,@taxPrice,@suppliderId,@factoryId,@puchaseCount,@productCount
		
		
		END	

	--关闭游标
	CLOSE MyCursor
	--释放资源
	DEALLOCATE MyCursor
	
	
	
	--插入没有采购单的库存
	DECLARE noPurchaseCursor CURSOR	
	FOR
		select salecode,MIN(x.stockPriceReal) taxPrice,SUM(productCount) purchaseCount from (
			select b.id as saleCode,c.stockPriceReal,a.productShelfCode,a.productCount from  erp..tb_productStock a
			inner join SuperMarket..tb_saleProduct b on a.productId=b.productId 
			inner join ERP..tb_product c on c.id=b.productId  and c.categoryOneId!=51
			where b.id not in(
				select saleCode from (
			select saleCode,skucode,taxPrice,productCount+notInCount as puchaseCount,productCount from (
			select sum(case when isStopInStorage =1 then  0 else 
				case when b.amount-b.storageCount<0 then 0 else b.amount-b.storageCount end  
				 end ) as notInCount,b.skucode,min(a.taxPrice) as taxPrice,MIN(a.saleCode) as saleCode
			   from SuperMarket..pro_purchase a 
			inner join  SuperMarket..pro_purchase_child  b on a.purchaseCode=b.purchaseCode
			where a.approvalstatus = 3
			group by skucode
			) as x
			inner join ERP..tb_productStock  y on x.skucode=y.productShelfCode
			where productCount+notInCount>0
			) as m group by saleCode 
			)   and  a.productCount>0
		) as x group by x.salecode
	
	
	
	
	OPEN noPurchaseCursor
	
	--循环一个游标
		FETCH NEXT FROM  noPurchaseCursor INTO @salecode,@taxPrice,@puchaseCount
	WHILE @@FETCH_STATUS =0
		BEGIN
			--插入采购单主表  
			--1.获取purchaseCode
			--2.获取pid
			--3.unitPrice
			
			
			--获取不含税单价
			set @unitPrice = @taxPrice/1.17
			
			--获取图片pid
			INSERT INTO ERP..tb_multimedia_pid(type,count)VALUES (1,0) 
			
		     set @multiId_Comfirm=SCOPE_IDENTITY()
		     
		     
		     select @brandId = b.id from SuperMarket..tb_saleProduct a 
		       inner join SuperMarket..tb_brandNick b on a.brandId = b.brandId 
		       where a.id = @salecode
		     --插入主表
			insert into supplyCenter..pro_purchase 
			(
			 purchaseCode,saleCode,contractId,suppliderId,totalMoney,totalPrice,amount,taxPrice,unitPrice,exceptOnlineTime,exceptArriveTime,
			 applytime,approvalstatus,approvaltype,currentprocess,paidMoney,applyUserId,picId,brandId,factoryId,
			 stockamount,notPaidMoney,removeUserId
			)
			values
			(
				'',@salecode,0,68,@taxPrice*@puchaseCount,@unitPrice*@puchaseCount,@puchaseCount,@taxPrice,@unitPrice,
				GETDATE(),GETDATE(),GETDATE(),3,2,1,0,189,@multiId_Comfirm,@brandId,1,@puchaseCount,0,0
			)
			--1.获取purchaseCode
			set @purchaseId = SCOPE_IDENTITY()
			set @purchaseCode = CAST(@purchaseId as varchar(100))
			while(LEN(@purchaseCode)<4) set @purchaseCode = '0'+@purchaseCode
			set @purchaseCode = 'CP164'+@day+@purchaseCode
			update supplyCenter..pro_purchase set purchaseCode = @purchaseCode where id = @purchaseId
			
			
			-- 插入子表信息
			
			insert into supplyCenter..pro_purchase_child(skucode,purchaseCode,amount,storageCount,qualityCount) 	
				select isnull(a.productShelfCode,''),@purchaseCode,a.productCount,0,0 from  erp..tb_productStock a
				inner join SuperMarket..tb_saleProduct b on a.productId=b.productId 
				inner join ERP..tb_product c on c.id=b.productId  and c.categoryOneId!=51
				where b.id not in(
					select saleCode from (
				select saleCode,skucode,taxPrice,productCount+notInCount as puchaseCount,productCount from (
				select sum(case when isStopInStorage =1 then  0 else 
					case when b.amount-b.storageCount<0 then 0 else b.amount-b.storageCount end  
					 end ) as notInCount,b.skucode,min(a.taxPrice) as taxPrice,MIN(a.saleCode) as saleCode
				   from SuperMarket..pro_purchase a 
				inner join  SuperMarket..pro_purchase_child  b on a.purchaseCode=b.purchaseCode
				where a.approvalstatus = 3
				group by skucode
				) as x
				inner join ERP..tb_productStock  y on x.skucode=y.productShelfCode
				where productCount+notInCount>0
				) as m group by saleCode 
				)   and  a.productCount>0 and b.id = @salecode
			
			
			
			FETCH NEXT FROM  noPurchaseCursor INTO @salecode,@taxPrice,@puchaseCount
		
		
		END	

	--关闭游标
	CLOSE noPurchaseCursor
	--释放资源
	DEALLOCATE noPurchaseCursor
	
	--插入审批记录表
	 insert into supplyCenter..pro_approval	
			(
				documentId,documentType,approvalUserId,approvalTime,approvalResult,mediaRemark,configId
				
			)
    select purchaseCode,2,189,GETDATE(),1,0,2 from supplyCenter..pro_purchase 
    
    
    
    --更新采购单类型 退回或者老系统付
    update supplyCenter..pro_purchase set removeType=1 where totalMoney>notpaidmoney   --退回 1    ;老系统付完是2
 
	update supplyCenter..pro_purchase set removeType=2 where totalMoney<=notpaidmoney 
END
