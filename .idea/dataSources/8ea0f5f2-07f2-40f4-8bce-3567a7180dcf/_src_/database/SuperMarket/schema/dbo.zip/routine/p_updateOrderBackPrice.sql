/*-------------退回商品核算并给以积分-------------------------------*/
CREATE  PROCEDURE p_updateOrderBackPrice @orderId INT
AS 
	DECLARE  @realPrice INT,
		 @backPrice INT,
		 @memberID INT,
		 @SCOREMONEY INT, --积分换算标准
		 @orderCode varchar(50),
		@magazineCodeS varchar(20)

	declare @cardClass int --h会员级别 
	DECLARE @orderStatus INT
	DECLARE @deliverPrice INT
	DECLARE @provinceId INT
	DECLARE @useGift INT
	declare @hour int      
	declare @backPrice2 int    
	declare @getScore int
	declare @scoreMsg int 
	declare @buyCount  int 
	declare @mobileNum varchar(50) 
	declare @EMail varchar(200)	

	SET @SCOREMONEY=100		 
	

	SELECT @realPrice=SUM(b.payValue*a.buyCount),@backPrice=SUM(b.payValue*a.backCount) 
	FROM dbo.tb_orderSaleProduct a
	INNER JOIN dbo.tb_orderSaleProductPay b ON a.id=b.orderSaleProductId 
	WHERE b.payType=1 AND a.orderId=@orderId   --得到定单总价格
	
	
	SELECT @memberID=memberId,@hour=dateDiff(Hour,createTime,visaTime),@orderStatus=orderStatus ,@orderCode=orderCode, 
	@useGift=useGift,@deliverPrice=deliverPrice,@provinceId=provinceId,@magazineCodeS=magazineCodeS,@buyCount=buyCountOrder,
	@backPrice2=backPrice
	 FROM tb_order WHERE id=@orderId 
	
	--核算会员级别 
	
	select  top 1 @cardClass=memberClass from tb_memberCard where memberId=@memberId
	if(@cardClass is null)
		set @cardClass=0

	
	--返积分
	set @getScore=((@realPrice-@backPrice)/@SCOREMONEY)

	if(@cardClass=1 or @cardClass =2 )
		set @getScore=@getScore*2
	
	exec  p_rollBackOrderScore @orderCode

	UPDATE tb_order SET backPrice=@backPrice WHERE id=@orderId --核算退回商品价值	


	
	
	select @scoreMsg=score,@mobileNum=mobileNum,@EMail=EMail from tb_member where id=@memberID

	
	if ( @orderStatus=3  or @orderStatus=17)
		begin
			if ( @orderStatus=3  )
			BEGIN
		     		if   EXISTS (select 1 from tb_rejectOrder where orderId=@orderId)
					DELETE FROM  tb_rejectOrder where orderId=@orderId

				
			END

			
		    	 exec  p_addScoreOpLog @memberID,@getScore,1,@orderCode
	
	               

		end
		--圣诞返券
			/*if exists(select 1 from  tb_preMemberGift where orderId=@orderId)
			begin
			             declare @giftCount int
				declare @i int
				select @giftCount=(productPrice-useGift-backPrice)/30000  from tb_order where id=@orderId and  createTime>='2010-02-20' and   createTime<='2011-01-10' and  id in(select orderId from tb_preMemberGift) 
				if(@giftCount is null)  set @giftCount=0
				set @i=0
				while(@i<@giftCount)
				begin
			               	 exec   p_sendGiftCard20TwoMonth @memberID ,78 
				              set @i=@i+1
				end
	
				delete from  tb_preMemberGift where orderId=@orderId
			end*/
		
	
	
	
	--记录到需入库订单
	if(@orderStatus=11 or @orderStatus=17 or @orderStatus=18)
		begin
			if  not EXISTS (select 1 from tb_rejectOrder where orderId=@orderId)
				begin
					insert into tb_rejectOrder(orderId) values(@orderId)
				end
			--exec p_rollBackRejectOrderScore  @orderCode

			--积分商品积分退回
			SELECT @realPrice=SUM(b.payValue*a.backCount) 
			FROM dbo.tb_orderSaleProduct a
			INNER JOIN dbo.tb_orderSaleProductPay b ON a.id=b.orderSaleProductId 
			WHERE b.payType=2  AND a.orderId=@orderId   --得到定单总价格
		
		
			if(@realPrice>0)
			begin
				exec  p_addScoreOpLog @memberID,@realPrice,6,@orderCode --积分商品退积分
			end

			IF(@backPrice IS NULL)
			SET @backPrice=0
			IF(@realPrice IS NULL)
			SET @realPrice=0
			


			if(@orderStatus=17)
			begin
				exec p_computeOrderPriceBack  @orderId
			end
		end
	
	--重新核算运费 
	--IF (@orderStatus=17 or @orderStatus=11 or @orderStatus=18)
	--	BEGIN
		--	EXEC  p_computeOrderPriceBack @orderId
	--	--END
	--UPDATE tb_member SET score=score+(@realPrice-@backPrice)/@SCOREMONEY WHERE id=@memberID --核算添加积分
	/*declare @isGiveCount int
	select @isGiveCount=SUM(opAmount) from dbo.tb_accountOpLog where opType=4 and  orderCode=@orderCode
	if(@isGiveCount  is  null) set @isGiveCount=0
	
		if((@realPrice-@backPrice-@useGift)>=100000 )
			begin
				set @isGiveCount=@isGiveCount*-1+20000
				exec  p_addAccountOpLog @memberID,@isGiveCount,4,@orderCode --圣诞
			end
		if((@realPrice-@backPrice-@useGift)<100000 and (@realPrice-@backPrice-@useGift)>=50000)
			begin

				set @isGiveCount=@isGiveCount*-1+10000
				exec  p_addAccountOpLog @memberID,@isGiveCount,4,@orderCode --圣诞
			end
			if((@realPrice-@backPrice-@useGift)<50000 and (@realPrice-@backPrice-@useGift)>=30000)
			begin
				set @isGiveCount=@isGiveCount*-1+5000
				exec  p_addAccountOpLog @memberID,@isGiveCount,4,@orderCode --圣诞
			end
		
	*/
	
	


	declare @content nvarchar(500)
	if(@hour<=72)
		begin
		--INSERT INTO dbo.tb_memberScoreHis(score,memberId,addOrSub,source,orderId)
		--VALUES ((@realPrice-@backPrice)/@SCOREMONEY,@memberID,1,1,@orderId)  --添加积分操作记录
		if (@magazineCodeS<>'R')
		begin
			if not EXISTS(select 1 from tb_blackNum where mobileNum=@mobileNum)
			begin
				
				set @content='优邮网感谢您的惠顾,您此次订购获得积分'+cast(@getScore as  nvarchar(20))+'分,您当前共有积分'+cast(@scoreMsg as  nvarchar(20))+'分,如果对我们的商品或服务有任何意见,请致电优邮售后热线:057128820123,每天8:30-21:00,恭候您的来电.www.yoyo18.com'
				exec p_sendMsg @mobileNum,@content
				
				declare @sendUrl varchar(500)
	 			declare @title varchar(500)
				  if(@EMail is not null and  @EMail<>'')
				  begin
					if not EXISTS  (select 1 from tb_unsubscribe where email=@EMail) 
					begin --http://www.yoyo18.com/web/emailOrderPass.yoyo?orderId=1000&memberId=946&type=1
					 set @sendUrl='http://www.yoyo18.com/web/emailOrderPass.yoyo?orderId='+cast(@orderId as varchar(20))+'&memberId='+cast(@memberID as varchar(20))+'&type=1'
					set @title=('优邮提示——您的订单'+@orderCode+'已确认送达')
		 			exec p_sendEmail @sendUrl,@EMail,@title
					end
				 end
			end
		end
	end

	--if(@buyCount=1 and @magazineCodeS<>'R' and  @magazineCodeS<>'CFT'  and ( @orderStatus=3  or @orderStatus=17))
	--	begin
	--		if not EXISTS(select 1 from tb_blackNum where mobileNum=@mobileNum)
	--		begin
	--			set @content='您的此次订单被系统随机选中幸运订单奖10元现金抵用券，激活码0909090，再次感谢您的惠顾。'
	--			exec p_sendMsg @mobileNum,@content
		--	end
		--end

	
			/* delete from tb_memberGift where giftType=919 and memberId =@memberId
			declare @count int 
			select @count=(productPrice-backPrice-useGift-useAccount)/20000  from tb_order  
			where magSourceRemark<>'taobao' and visaTime>='2011-09-01' and productPrice-backPrice-useGift-useAccount>=20000 and id=@orderId

			while(@count>=1)
			begin				
				exec p_sendGiftCard20  @memberId,919
				exec p_sendGiftCard  @memberId,919
				exec p_sendMsgByClass @mobileNum,'初秋感恩季，30元礼券已赠送您的账户，优邮网',9999,1
				set @count=@count-1
			end*/