CREATE PROCEDURE p_checkGroupStock 	@groupProductId int, @colorId int,
						@metricsId int,	@buyCount int,	@count int
					
AS	
	declare @realCount int
	declare @DDlCount int
	declare @saleProductId int
	declare @return int
	set @return=0
	
	SELECT @realCount=SUM(a.productCount) FROM ERP.dbo.tb_productStock a WITH(TABLOCKX)  
	inner join tb_saleProduct b on b.productId=a.productId
	inner join tb_groupProduct c on c.saleProductId=b.id
 	WHERE c.id=@groupProductId AND a.colorId=@colorId AND a.metricsId=@metricsId   
	
	select @saleProductId=saleProductId from tb_groupProduct
	where id=@groupProductId

	SELECT @DDlCount=SUM(a.buyCount) FROM v_allBuyProduct a WITH(TABLOCKX)  
  	WHERE a.saleProductId=@saleProductId AND a.colorId=@colorId AND a.metricsId=  @metricsId   
  	IF(@DDlCount IS NULL)
             BEGIN 
	     SET @DDlCount=0
             END
 	IF(@realCount-@DDlCount>=@buyCount*@count)
	begin
	     set @return=1
	end
	else
	begin
	     set @return=@saleProductId
	end
select @return