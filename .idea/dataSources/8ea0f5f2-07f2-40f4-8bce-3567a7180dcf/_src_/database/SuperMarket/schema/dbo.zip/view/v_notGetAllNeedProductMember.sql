CREATE  VIEW dbo.v_notGetAllNeedProductMember
AS
/*SELECT tb4.memberId, tb5.name, tb5.mobileNum, tb5.callRemark, MAX(tb4.addTime) 
      AS addTime
FROM ERP.dbo.tb_productStock tb1 
LEFT OUTER JOIN
   (
	SELECT SUM(a.buyCount) AS buyCount,  a.colorId AS colorId, a.metricsId AS metricsId
         	FROM dbo.tb_orderSaleProduct a 
		INNER JOIN  dbo.tb_order b ON b.id = a.orderId 
         	WHERE b.orderStatus in(1,20) AND b.isDelete != 1
         	GROUP BY  a.colorId, a.metricsId
) tb2
 ON  tb1.colorId = tb2.colorId AND  tb1.metricsId = tb2.metricsId 
LEFT OUTER JOIN
  (
	SELECT  SUM(buyCount) AS buyCount, colorId,  metricsId FROM tb_shoppingBag a 
	INNER JOIN dbo.tb_SaleProduct c ON a.saleProductId = c.id
         	WHERE resource = 0 AND isStock = 1
         	GROUP BY  a.colorId, a.metricsId
 ) tb3 ON   tb1.colorId = tb3.colorId AND 	tb1.metricsId = tb3.metricsId 

INNER JOIN   ( 
select memberId,a.colorId,a.metricsId,a.isdeleted,a.addTime,a.needCount from  dbo.tb_registProduct a
inner join tb_saleProduct b on a.saleId=b.id and a.isdeleted=0 and  b.isdeleted=0
) tb4
 ON      tb1.colorId = tb4.colorId AND tb1.metricsId = tb4.metricsId 
 INNER JOIN
 dbo.tb_member tb5 ON tb5.id = tb4.memberId
WHERE (tb1.productCount - ISNULL(tb2.buyCount, 0) - ISNULL(tb3.buyCount, 0) 
      - tb4.needCount )< 0
GROUP BY tb4.memberId, tb5.name, tb5.mobileNum, tb5.callRemark
*/

--select  a.memberId, b.name, b.mobileNum,b.callRemark, MAX(a.addTime)  AS addTime   from tb_registProduct a
--inner join tb_member b on a.memberId=b.id where a.isQh=1 and isdeleted=0
--GROUP BY a.memberId, b.name, b.mobileNum,b.callRemark

select  a.memberId, b.name, b.mobileNum,b.callRemark, MAX(a.addTime)  AS addTime,sum( case d.isdeleted when 0 then ( case a.isQh when 0 then a.needCount*c.payValue else 0 end ) else 0 end  )  as  hasPrice   from tb_registProduct a
inner join tb_member b on a.memberId=b.id  
    inner join tb_saleProductPay c on c.saleProductId=a.saleId and c.payStyleId=1
       inner join tb_saleProduct d on d.id=a.saleId  
where a.memberId  in(select memberId from tb_registProduct where isQh=1 and isDeleted=0) and a.isDeleted=0 and isQh=0 and a.addTime<=dateadd(day,-3,getDate())
GROUP BY a.memberId, b.name, b.mobileNum,b.callRemark



