CREATE procedure p_sendwaittaobaoMsg @taobaoId varchar(50),@mobileNum varchar(50),@createTime varchar(50)
as                      
	declare @msg nvarchar(65)
	if(cast(@createTime as dateTime)<cast('2012-02-28' as dateTime))
	begin
		insert into tb_isSendTaobaoWaitId(taobaoId) values(@taobaoId)
	end
	else
	begin
	if DATEPART ( hour ,getDate()) =20
	begin
		if DATEPART ( hour ,@createTime) <=18
		begin
			if not exists (select 1 from tb_order where  memberId in(select id from tb_member where mobileNum=@mobileNum) and  createTime>=convert(varchar(10),getDate(),120))
			begin
			begin tran 
			set @msg='亲，您今天在莉家拍下的宝贝还未付款哦！此订单莉将为您保留24小时，逾期将会取消，喜欢就尽快付款吧！如有疑问可咨询旺旺客服！~莉~'
			--set @msg='亲，您今天在莉家拍下的宝贝还未付款哦！双十一活动接近尾声，喜欢就尽快付款吧！如有疑问可咨询旺旺客服！~莉~'
			if not exists (select 1 from tb_isSendTaobaoWaitId where taobaoId=@taobaoId )
			begin
				if not exists(select 1 from c3..tb_smsMission where mobileNum=@mobileNum
						 and content=@msg and convert(varchar(10),sendTime,120)= convert(varchar(10),getDate(),120))
				begin
					INSERT INTO c3.dbo.tb_smsMission(sourceType,mobileNum,content,sendTime,orderByClass,sendManId) VALUES(0,@mobileNum,@msg,getDATE(),999,1)
				end
			end
			insert into tb_isSendTaobaoWaitId(taobaoId) values(@taobaoId)
			commit tran 
			end
		end
	end

	if DATEPART ( hour ,getDate()) =10
	begin
		if DATEPART ( hour ,@createTime) >18
		begin
			if not exists (select 1 from tb_order where  memberId in(select id from tb_member where mobileNum=@mobileNum) and  createTime>=convert(varchar(10),dateAdd(day,-1,getDate()),120))
			begin
			begin tran 
			set @msg='亲，您昨晚在莉家拍下的宝贝还未付款哦！此订单莉将为您保留24小时，逾期将会取消，喜欢就尽快付款吧！如有疑问可咨询旺旺客服！~莉~'
			if not exists (select 1 from tb_isSendTaobaoWaitId where taobaoId=@taobaoId )
			begin
				if not exists(select 1 from c3..tb_smsMission where mobileNum=@mobileNum
						 and content=@msg and convert(varchar(10),sendTime,120)= convert(varchar(10),getDate(),120))
				begin
					INSERT INTO c3.dbo.tb_smsMission(sourceType,mobileNum,content,sendTime,orderByClass,sendManId) VALUES(0,@mobileNum,@msg,getDATE(),999,1)
				end
			end
			insert into tb_isSendTaobaoWaitId(taobaoId) values(@taobaoId)
			commit tran 
			end
		end
	end
	end