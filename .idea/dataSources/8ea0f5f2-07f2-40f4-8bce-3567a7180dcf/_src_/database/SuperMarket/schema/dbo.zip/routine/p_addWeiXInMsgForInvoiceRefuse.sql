CREATE procedure [dbo].[p_addWeiXInMsgForInvoiceRefuse] 
	@msgcontent varchar(2000),
	@invoiceId varchar(100) ,
	@approvalUserId int 
as	
	declare @ret int
	declare @userId int
	declare @approvalType	INT  --审批类型
	declare @invoiceCode varchar(30)	--发票编号
 BEGIN 
 begin tran
	set @ret = 0
	select @approvalType=approvalType,@invoiceCode=invoiceCode from SuperMarket..Pro_invoice_main where id=@invoiceId
	--申请人
	insert into SuperMarket..tb_weiXinMsg(userId,msgType,msgcontent)
			select id,'news',REPLACE(@msgcontent,'ruhnn_openId',openId) from ERP..tb_user 
			where id = (select applyUserId from SuperMarket..Pro_invoice_main where id=@invoiceId)
	
    --定义游标.获取前面几个审批人
   DECLARE c_userId CURSOR FAST_FORWARD FOR
     SELECT approvalUserId from SuperMarket..pro_approval where documentId=@invoiceCode and approvalUserId <> @approvalUserId
   -- 打开游标.
   OPEN c_userId
   --填充数据.
   FETCH NEXT FROM c_userId INTO @userId;
   --假如检索到了数据，才处理.
   WHILE @@fetch_status = 0
	   BEGIN
		  insert into SuperMarket..tb_weiXinMsg(userId,msgType,msgcontent)
			select id,'news',REPLACE(@msgcontent,'ruhnn_openId',openId) from ERP..tb_user where id = @userId
		 --填充下一条数据.
		 FETCH NEXT FROM c_userId INTO @userId
	   END
	   -- 关闭游标
	   CLOSE c_userId
	   --释放游标.
	   DEALLOCATE c_userId
	if @@error <> 0  
      begin 
		set @ret=-1
		rollback tran 
	  end
	else
		begin 
			set @ret=1
		end
	commit tran
	select @ret as 'ret'
 END