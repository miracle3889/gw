/*-----------------删除购物车组合商品------------------------------------------*/
CREATE   PROCEDURE p_web_delShoppingBagGroup @shopingBagId INT,@memberId INT
AS
	BEGIN
    
	DECLARE @hasMinPrice INT --满就送赠品的满足条件
	DECLARE @realPrice INT	--除了该商品之外其他商品的价格

	SELECT @hasMinPrice=minPrice FROM dbo.tb_shoppingBag a
	INNER JOIN dbo.tb_saleProduct b ON a.saleProductId=b.id
	INNER JOIN dbo.tb_saleType c ON b.saleTypeId=c.id 
	WHERE c.isGive=1
	AND c.minPrice>0 AND a.memberId=@memberId  --得到满就送商品的满足条件
		
	IF(@hasMinPrice is null)
	BEGIN
		SET @hasMinPrice=0
	END
		
	SELECT @realPrice=SUM(b.payValue*a.buyCount) 
	FROM dbo.tb_shoppingBag a
	INNER JOIN dbo.tb_saleProductPay b ON a.saleProductId=b.saleProductId 
	WHERE b.payStyleId=1 AND a.memberId=@memberId  AND isPresent=0
	AND a.groupph!=@shopingBagId --得到除了该商品之外其他商品的价格
	
	IF(@realPrice IS NULL)
	BEGIN
		SET @realPrice=0
	END	
	IF(@realPrice=0) --如删除次商品之后购物车中除赠品外的商品的价格为0，即没有其他商品则删除所有赠品
	BEGIN
		/*--------------删除原有的赠品-----------------------------*/
		DELETE FROM dbo.tb_shoppingBag WHERE memberId=@memberId 
		AND saleProductId IN 
		(
			 SELECT a.id FROM dbo.tb_saleProduct a 
			 INNER JOIN dbo.tb_saleType b ON a.saleTypeId=b.id
			 WHERE b.isGive=1
	       	)
	END
	ELSE
	BEGIN
		IF(@realPrice<@hasMinPrice)  --赠品条件不够
		BEGIN
			/*--------------删除原有的满就送赠品-----------------------------*/
			DELETE FROM dbo.tb_shoppingBag WHERE memberId=@memberId 
			AND saleProductId IN 
			(
				 SELECT a.id FROM dbo.tb_saleProduct a 
				 INNER JOIN dbo.tb_saleType b ON a.saleTypeId=b.id
				 WHERE b.isGive=1 AND b.minPrice>0
		       	)
		END
	END
    	    DELETE FROM dbo.tb_shoppingBag WHERE groupph=@shopingBagId AND memberId=@memberId --删除该商品
	    DELETE FROM tb_groupPh WHERE id=@shopingBagId AND memberId=@memberId
	END