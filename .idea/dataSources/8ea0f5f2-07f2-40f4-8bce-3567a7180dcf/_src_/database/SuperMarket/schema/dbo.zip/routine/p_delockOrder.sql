/*------------------------------------------------------回滚定单------------------------------------------------------------------------------------*/
CREATE  PROCEDURE p_delockOrder @orderId INT,@lockManId int
AS	
	BEGIN TRAN 
		insert into tb_lockOrderHis select * from tb_lockOrder where orderId=@orderId
		delete from tb_lockOrder where orderId=@orderId
	COMMIT TRAN