/*添加商品到组合表，根据id得到组合中的商品编号*/ 
CREATE   PROCEDURE   p_addGroupProduct
@groupId int,@saleProductId int,@productPrice int

  AS   
DECLARE @id int
BEGIN
      Insert into SuperMarket.dbo.tb_groupProduct(groupId,saleProductId,productCode,productPrice)   
                    Values(@groupId,   @saleProductId,   '0',   @productPrice)   
      Set   @id=@@Identity   
     update SuperMarket.dbo.tb_groupProduct set productCode='G'+cast(@id as varchar) where productCode='0'
  end