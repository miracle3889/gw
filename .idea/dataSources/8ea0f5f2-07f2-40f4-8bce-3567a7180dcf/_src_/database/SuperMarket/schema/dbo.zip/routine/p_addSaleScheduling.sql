
CREATE procedure [dbo].[p_addSaleScheduling] @ndate varchar(20),@nickId int,
@userId int
as
	if not exists(select 1 from [SuperMarket].[dbo].[tb_saleScheduling] where nickId=@nickId and ndate=@ndate)
	begin
		insert into [SuperMarket].[dbo].[tb_saleScheduling](ndate,nickId,userId)
		values(@ndate,@nickId,@userId)
		
		select SCOPE_IDENTITY()
	end
	else
		select 0 