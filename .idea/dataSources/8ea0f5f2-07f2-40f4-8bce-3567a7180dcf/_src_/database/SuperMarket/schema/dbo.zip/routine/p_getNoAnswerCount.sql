
/*-------------------------------------------------得到未接来电---------------------------------------------*/
CREATE   PROCEDURE p_getNoAnswerCount 
AS
	DECLARE @count INT
/*
	UPDATE dbo.tb_noAnswerCall SET isCallBack=1,callRemark=('▲后来已呼'+CASE  a.callType WHEN 0 THEN  '入' ELSE '出' END +'▲'+c.callCause)
	FROM dbo.tb_callHis a,dbo.tb_noAnswerCall b,dbo.tb_callCause c 
	WHERE b.isCallBack=0 AND a.callcallerCode=b.callcallerCode  AND c.id=a.callCauseId
	AND a.callTime>=b.callInTime
*/
	SELECT @count=COUNT(*) FROM dbo.tb_noAnswerCall WHERE isCallBack=0
	SELECT @count