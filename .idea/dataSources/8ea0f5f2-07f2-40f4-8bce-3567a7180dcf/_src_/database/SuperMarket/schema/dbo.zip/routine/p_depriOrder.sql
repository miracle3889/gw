
CREATE  PROCEDURE p_depriOrder @orderId INT,@priorityManId int
AS	
	BEGIN TRAN 
		delete from tb_priorityOrder where orderId=@orderId
		update tb_order set remark=REPLACE(remark,'★','')  where id  =@orderId
	COMMIT TRAN