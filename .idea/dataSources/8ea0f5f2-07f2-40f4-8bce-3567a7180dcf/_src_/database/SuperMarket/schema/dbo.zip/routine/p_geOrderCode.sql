/*--------------------得到定单编号---------------------------------*/
CREATE  PROCEDURE  p_geOrderCode @code VARCHAR(50) OUTPUT
AS
	
	EXEC ERP.dbo.p_getNowDate @code OUTPUT
	begin tran 
	DECLARE @temp INT
	SELECT  @temp=MAX(intCode) FROM tb_orderCode WITH(HOLDLOCK)   WHERE CONVERT(VARCHAR(10),GETDATE(),120)=CONVERT(VARCHAR(10),addDate,120) 
	IF( @temp=0 OR  @temp IS NULL)
	BEGIN
		SET @temp=1
	END
	ELSE
	BEGIN
		SET @temp=@temp+1
	END
	DECLARE @CharTemp VARCHAR(10)
	SET @CharTemp=CAST(@temp AS VARCHAR(10))
	WHILE(LEN(@CharTemp)<4)
	BEGIN
		SET @CharTemp='0'+@CharTemp
	END
	SET @code='SD'+@code+@CharTemp
	INSERT INTO tb_orderCode (intCode) VALUES(@temp)
	commit tran