CREATE VIEW dbo.v_allBuyProductCheckOrder080627
AS

SELECT a.productId AS saleProductId, a.buyCount AS buyCount, a.colorId AS colorId, 
      a.metricsId AS metricsId, 1 AS type,0 as   needInCount
FROM dbo.tb_orderSaleProduct a INNER JOIN
      dbo.tb_order b ON b.id = a.orderId
WHERE b.orderStatus IN (1, 6)  AND b.isDelete != 1
UNION ALL
SELECT c.productId AS saleProductId, buyCount, colorId, metricsId, 2 AS type,0 as   needInCount
FROM tb_shoppingBag a INNER JOIN
      dbo.tb_SaleProduct c ON a.saleProductId = c.id
WHERE resource = 0 AND isStock = 1
union all
select productId as saleProductId, -1*sum(case isBuyStock when 1 then b.buyCount else   0 end)  as buyCount, colorId, metricsId,3 as type,
sum(case isBuyStock when 0 then b.buyCount else   0 end) as needInCount from erp. dbo.tb_buyProductList a
inner join erp.dbo.tb_buyProductProtity b on a.id=b.buyProductId and a.buyStatus in(1,2,3) and isdeleted<>1
group by productId, colorId, metricsId having(sum(b.buyCount)>0)


