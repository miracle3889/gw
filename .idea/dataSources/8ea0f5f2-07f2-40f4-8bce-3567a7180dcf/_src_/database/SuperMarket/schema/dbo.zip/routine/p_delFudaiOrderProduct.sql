
CREATE  procedure p_delFudaiOrderProduct @colorId int ,@metricsId int ,@orderId int

as 
	delete from SuperMarket..tb_fudaiOrderProduct where orderId=@orderId and colorId=@colorId and metricsId=@metricsId
	
		select  sum(c.payValue) from SuperMarket..tb_fudaiOrderProduct a
	inner join SuperMarket..tb_saleProduct b on a.productId=b.productId and b.saleTypeId=1 
	 inner join SuperMarket..tb_saleProductPay c on c.saleProductId=b.id  where a.orderId=@orderId 
	
	