create view v_orderCount as
select memberId,count(*) as orderCount from tb_order where isDelete <> 1
group by memberId
