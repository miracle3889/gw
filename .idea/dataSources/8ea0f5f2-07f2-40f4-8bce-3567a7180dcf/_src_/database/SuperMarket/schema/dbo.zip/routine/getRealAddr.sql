
CREATE  FUNCTION [dbo].[getRealAddr] (@addr varchar(500))  
RETURNS varchar(500)  AS  
BEGIN 
	declare @addrReal varchar(500)
	declare @char varchar(10)
	set @addrReal=''
 	while(len(@addr)>0)
		begin
			set @char=subString(@addr,1,1)
			if(ISNUMERIC(@char)=1)
			   set @addrReal=@addrReal+'*'
			else
		           set @addrReal=@addrReal+@char
			
			set @addr=subString(@addr,2,len(@addr))
		end 
	return @addrReal
END
