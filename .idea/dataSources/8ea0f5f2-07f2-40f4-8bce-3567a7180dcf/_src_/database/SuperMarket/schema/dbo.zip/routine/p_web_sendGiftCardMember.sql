
CREATE      procedure p_web_sendGiftCardMember
AS

	
	declare @id int

	set @id=0
	declare saleCount cursor for select id from tb_member where addDate <'2010-06-01' and email is not null and email!='' and source!='CFT'
		and id not in (select memberId from tb_order) and id not in (select memberId from tb_memberGift where giftType=96 )
	open saleCount
	fetch NEXT from saleCount into @id

	while @@fetch_status=0
	begin
		exec p_sendGiftCard @id,96
		fetch NEXT from saleCount into @id 
	end 	

	close saleCount
	deallocate saleCount