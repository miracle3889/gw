
CREATE procedure p_addTaobaoalipay @orderCode varchar(50),@memo varchar(200)
as 
	
	declare @code varchar(50)

	select @code=orderCode  from tb_taobaoCode where taobaoTid=@orderCode 
	
	update ab_member201210 set alipay=@memo where nickName 
	in(select taobaoNickName from tb_taobaoMember where  memberId in(select memberId from tb_order where orderCode=@code) )

	
