CREATE procedure [dbo].[p_setlableDate] 
as 

delete from tb_lableTemp
insert into tb_lableTemp select id from tb_productLable where needDate is null

update tb_productLable set needDate=myDate from tb_productLable a,(
select id,myDate from (
select id,cast(year(getDate())  as varchar(10))+'-'+subString(datex,0,charindex('.',datex))+'-'+subString(datex,charindex('.',datex)+1,len(datex)-charindex('.',datex))  as myDate from (
SELECT  id,
 rtrim(ltrim(subString(lable,charIndex('预售',lable)+2,(charIndex('开始',lable)-charIndex('预售',lable)-2)))) as datex  FROM tb_productLable  
where  needDate is null and productId<>7740
) as x where subString(datex,0,charindex('.',datex))-month(getDate())>=-1 ) as x) b where a.id=b.id





update tb_productLable set needDate=myDate from tb_productLable a,(
select id,myDate from (
select id,cast(year(getDate())+1  as varchar(10))+'-'+subString(datex,0,charindex('.',datex))+'-'+subString(datex,charindex('.',datex)+1,len(datex)-charindex('.',datex))  as myDate from (
SELECT  id,
 rtrim(ltrim(subString(lable,charIndex('预售',lable)+2,(charIndex('开始',lable)-charIndex('预售',lable)-2)))) as datex  FROM tb_productLable  
where  needDate is null
) as x where subString(datex,0,charindex('.',datex))-month(getDate())<-1 ) as x) b where a.id=b.id




INSERT INTO c3.dbo.tb_smsMission(sourceType,mobileNum,content,sendTime,orderByClass,sendManId) 

select 1,'18657179000','编号为'+cast(min(b.saleProductId) as varchar(10))+'的商品预售填写有问题',getDate(),9999,1 from tb_order a
inner join tb_orderSaleProduct b on a.id=b.orderId
inner join tb_orderSaleLable c on c.orderSaleId=b.id
inner join tb_productLable d on d.id=c.lableId
 where createTime>=convert(varchar(10),dateAdd(day,-4,getDate()) ,120) and needDate<getDate()
and  d.id in(select * from tb_lableTemp)
group by d.productId



INSERT INTO c3.dbo.tb_smsMission(sourceType,mobileNum,content,sendTime,orderByClass,sendManId) 

select 1,'18668122055','编号为'+cast(min(b.saleProductId) as varchar(10))+'的商品预售填写有问题',getDate(),9999,1 from tb_order a
inner join tb_orderSaleProduct b on a.id=b.orderId
inner join tb_orderSaleLable c on c.orderSaleId=b.id
inner join tb_productLable d on d.id=c.lableId
 where createTime>=convert(varchar(10),dateAdd(day,-4,getDate()) ,120) and needDate<getDate()
and  d.id in(select * from tb_lableTemp)
group by d.productId



INSERT INTO c3.dbo.tb_smsMission(sourceType,mobileNum,content,sendTime,orderByClass,sendManId) 

select 1,'18657105551','编号为'+cast(min(b.saleProductId) as varchar(10))+'的商品预售填写有问题',getDate(),9999,1 from tb_order a
inner join tb_orderSaleProduct b on a.id=b.orderId
inner join tb_orderSaleLable c on c.orderSaleId=b.id
inner join tb_productLable d on d.id=c.lableId
 where createTime>=convert(varchar(10),dateAdd(day,-4,getDate()) ,120) and needDate<getDate()
and  d.id in(select * from tb_lableTemp)
group by d.productId
