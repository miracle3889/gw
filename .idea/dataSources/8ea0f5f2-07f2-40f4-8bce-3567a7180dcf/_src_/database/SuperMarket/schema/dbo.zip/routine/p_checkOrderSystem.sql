CREATE procedure p_checkOrderSystem
as 
	delete from tb_tempCheckOrder
	
	
	insert into tb_tempCheckOrder
	--货到付款 非第一单 或则第一单但是地址没问题
	select id from tb_order where isdelete<>1 and orderstatus=5 and payType=1  and (buyCountOrder>1 or (buyCountOrder=1 and doMan=-3))
	and orderCode not in(
		--包含缺货商品
		select  a.orderCode from
		 (
			select  orderCode,colorId, metricsId,sum(buycount) as buycount  from tb_orderSaleProduct  a
			inner join tb_order b on a.orderId=b.id and  b. isdelete<>1 and b.orderstatus=5 and b.payType=1  and  (buyCountOrder>1 or (buyCountOrder=1 and doMan=-3))
			group by colorId,metricsId,orderCode
		 )a
		inner join erp..tb_productStock b on   a.colorId=b.colorId and a.metricsId=b.metricsId
		left  join 
		(
			select colorId,metricsId,sum(buycount) as buycount from  tb_temp_waitPhProduct  group by   colorId,metricsId
		) c on a.colorId=c.colorId and a.metricsId=c.metricsId
	
		left  join 
		(
			SELECT  colorId, metricsId,SUM(buyCount)  as buyCount FROM tb_shoppingBag 
			WHERE resource = 0 AND isStock = 1 group by  colorId, metricsId
		) d on a.colorId=d.colorId and a.metricsId=d.metricsId
		
		where   b.productCount-(a.buycount+isnull(c.buycount,0)+isnull(d.buycount,0)) <0
		)
	
	
	update tb_order set orderStatus=1 ,magSourceRemark='autoY',checkRemark=convert(varchar(20),getDate(),120)+'老会员不缺货自动审核',isUpdate=0  
	where id in(select orderId from tb_tempCheckOrder)
	
	delete from tb_temp_waitPhProduct where orderId in(select orderId from tb_tempCheckOrder)
	
	insert into tb_temp_waitPhProduct(orderId,saleProductId,buyCount,colorId,metricsId)
	SELECT a.orderId,a.productId AS saleProductId, a.buyCount AS buyCount, a.colorId AS colorId, 
	      a.metricsId AS metricsId
        FROM dbo.tb_orderSaleProduct a 
	INNER JOIN   dbo.tb_order b ON b.id = a.orderId
	WHERE b.orderStatus =1 AND b.isDelete != 1 and a.orderId in(select orderId from tb_tempCheckOrder)
	
	
	/*INSERT INTO c3.dbo.tb_smsMission(sourceType,mobileNum,content,sendTime,orderByClass,sendManId) 
	
	select 1,replace(mobileNum,'|',''),'优邮提示:您的订单'+b.orderCode+'已经审核通过,我们将尽快将订单送达。www.yoyo18.com' ,getDate(),9999,1
	from tb_member a
	inner join tb_order b on a.id=b.memberId  where  b.id in(select orderId from tb_tempCheckOrder)
	and replace(mobileNum,'|','') like '1%' and len(replace(mobileNum,'|',''))=11 
	*/
	
	insert into tb_orderstatusHis(orderId,orderstatus,doMan,remark)  select orderId,1,0,'老会员不缺货自动审核'  from tb_tempCheckOrder
	
	delete from tb_tempCheckOrder
	
	
	insert into tb_tempCheckOrder
	select id from tb_order where isdelete<>1 and orderstatus=5 and payType<>1 and  ispayMent=1
	and orderCode not in(
		select  a.orderCode from 
		(
			select  orderCode,colorId, metricsId,sum(buycount) as buycount  from tb_orderSaleProduct  a
			inner join tb_order b on a.orderId=b.id and  b. isdelete<>1 and b.orderstatus=5 and b.payType<>1  and ispayMent=1
			group by colorId,metricsId,orderCode
		)   a
		inner join erp..tb_productStock b on   a.colorId=b.colorId and a.metricsId=b.metricsId
		left  join 
		(
			select colorId,metricsId,sum(buycount) as buycount from  tb_temp_waitPhProduct  group by   colorId,metricsId
		) c on a.colorId=c.colorId and a.metricsId=c.metricsId
		
		left  join 
		(
			SELECT  colorId, metricsId,SUM(buyCount)  as buyCount FROM tb_shoppingBag 
			WHERE resource = 0 AND isStock = 1 group by  colorId, metricsId
		) d on a.colorId=d.colorId and a.metricsId=d.metricsId
		
		where   b.productCount-(a.buycount+isnull(c.buycount,0)+isnull(d.buycount,0)) <0
	)


	update tb_order set orderStatus=1 ,magSourceRemark='autoPay',checkRemark=checkRemark+convert(varchar(20),getDate(),120)+'已付款订单自动审核',isUpdate=0  where id in(select orderId from tb_tempCheckOrder)
	
	insert into tb_orderstatusHis(orderId,orderstatus,doMan,remark)  select orderId,1,0,'已付款订单自动审核'  from tb_tempCheckOrder
	
	delete from tb_temp_waitPhProduct where orderId in(select orderId from tb_tempCheckOrder)
	
	insert into tb_temp_waitPhProduct(orderId,saleProductId,buyCount,colorId,metricsId)
	SELECT a.orderId,a.productId AS saleProductId, a.buyCount AS buyCount, a.colorId AS colorId, 
	      a.metricsId AS metricsId
        	FROM dbo.tb_orderSaleProduct a 
	INNER JOIN   dbo.tb_order b ON b.id = a.orderId
	WHERE b.orderStatus =1 AND b.isDelete != 1 and a.orderId in(select orderId from tb_tempCheckOrder)
	
	
	/*INSERT INTO c3.dbo.tb_smsMission(sourceType,mobileNum,content,sendTime,orderByClass,sendManId) 
	
	select 1,replace(mobileNum,'|',''),'优邮提示:您的订单'+b.orderCode+'已经审核通过,我们将尽快将订单送达。www.yoyo18.com' ,getDate(),9999,1
	from tb_member a
	inner join tb_order b on a.id=b.memberId  where  b.id in(select orderId from tb_tempCheckOrder)
	and replace(mobileNum,'|','') like '1%' and len(replace(mobileNum,'|',''))=11
	*/

	--缺货判断显示在网站上
	delete from tb_tempShowOutIfStockOrder
	insert into tb_tempShowOutIfStockOrder
	
	select a.orderId,a.colorId,a.metricsId from (select orderId,colorId, metricsId,sum(buycount) as buycount  from tb_orderSaleProduct  a
	inner join tb_order b on a.orderId=b.id and  b. isdelete<>1 and b.orderstatus=5   
	group by colorId,metricsId,orderId) a
	inner join erp..tb_productStock b on   a.colorId=b.colorId and a.metricsId=b.metricsId
	left  join 
	(
		select colorId,metricsId,sum(buycount) as buycount from  tb_temp_waitPhProduct  group by   colorId,metricsId
	) c on a.colorId=c.colorId and a.metricsId=c.metricsId

	left  join 
	(
		SELECT  colorId, metricsId,SUM(buyCount)  as buyCount FROM tb_shoppingBag 
		WHERE resource = 0 AND isStock = 1 group by  colorId, metricsId
	) d on a.colorId=d.colorId and a.metricsId=d.metricsId
	where   b.productCount-(a.buycount+isnull(c.buycount,0)+isnull(d.buycount,0)) <0


	update tb_orderSaleProduct set isOutOfStock=0 where orderId in(select id from tb_order where isdelete<>1 and orderstatus=5  )

	
	update tb_orderSaleProduct set isOutOfStock=1 from tb_orderSaleProduct a,tb_tempShowOutIfStockOrder b  where a.orderId=b.orderId and a.colorId=b.colorId and a.metricsId=b.metricsId