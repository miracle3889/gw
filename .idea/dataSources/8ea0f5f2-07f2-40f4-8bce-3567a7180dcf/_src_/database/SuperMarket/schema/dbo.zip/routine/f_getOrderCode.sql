


CREATE function [dbo].[f_getOrderCode]( @id int,@Suffix varchar(3),@nickName varchar(50))
RETURNS VARCHAR(50)
as 
begin
	--@suffix 01 淘宝  00系统  02 tee
	declare @nickId int
	declare @nickString varchar(10)
	select @nickId=ID from supermarket..tb_brandNick where nickName=@nickName
	--substring(cast(datePart(year,GETDATE()) as char(4)),3,4)+
	set @nickString=cast(@nickId as varchar(10))
	while(len(@nickString)<3)
	begin
		set @nickString='0'+@nickString	
	end
	return CAST(@id as varchar(50))+@Suffix+@nickString
end 