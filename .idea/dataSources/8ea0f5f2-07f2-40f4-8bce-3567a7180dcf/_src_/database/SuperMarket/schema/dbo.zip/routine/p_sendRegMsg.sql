CREATE         procedure p_sendRegMsg
as 
	declare @memberId int
	declare @memberName varchar(200)
	declare @mobileNum varchar(50)
	declare @EMail varchar(200)
	declare @saleCode varchar(200)
	declare @saleCode0 varchar(200)
	declare @saleProductName varchar(200)
	declare @salePrice varchar(200)
	declare @oldsalePrice varchar(200)
	declare @nickname varchar(200)
	declare @endTime varchar(200)
	declare @i int
	set @i=0
	set @saleCode=''
	DECLARE authors_cursor0 CURSOR FOR
	--SELECT top 4 saleProductName,saleCode,salePrice FROM dbo.tb_searchSaleEntity a 
		--inner join dbo.tb_hotSale b on b.saleId=substring(a.saleCode,2,len(a.saleCode))
		--where a.isGroup=0 order by newId()

	select   top 4 saleProductName,c.saleCode,a.price,b.salePrice,cast(DATEPART ( month , endTime ) as  varchar(10))+'月'+cast(DATEPART ( day , endTime ) as varchar(10))+'日' from dbo.tb_weekProduct a
inner join dbo.tb_saleProductOldPrice b on a.saleId=b.saleId
inner join dbo.tb_saleProduct c on a.saleId=c.id
inner join dbo.tb_searchSaleEntity d on a.saleId=d.saleId
 where startTime<=getDate() and endTime>=getDate()  order by newId()

	OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @saleProductName,@saleCode0,@salePrice,@oldsalePrice,@endTime
	WHILE @@FETCH_STATUS = 0
	BEGIN
		set @saleCode=@saleCode+@saleCode0+','
		FETCH NEXT FROM authors_cursor0 
		INTO @saleProductName,@saleCode0,@salePrice,@oldsalePrice,@endTime
	END
	CLOSE authors_cursor0
	DEALLOCATE authors_cursor0

	DECLARE authors_cursor CURSOR FOR
	select id,name,mobileNum,EMail,nickname from dbo.tb_member where dateDiff(day,addDate,getDate()) in(7,15,30)
	and mobileNum not in(select mobileNum from tb_blackNum) and source<>'CFT'
	OPEN authors_cursor
	FETCH NEXT FROM authors_cursor 
	INTO @memberId,@memberName,@mobileNum,@EMail,@nickname
	WHILE @@FETCH_STATUS = 0
	BEGIN
		declare @content nvarchar(500)
		print @oldsalePrice
		print @salePrice
		set @content='优邮本周特价：'+dbo.getRealProductName(@saleProductName)+'原价'+ (cast(ROUND((cast(@oldsalePrice as int)*1.0/100.0),1) as  decimal(15,1))   )+'元现仅需'+ (cast(ROUND((cast(@salePrice as int)*1.0/100.0),1) as  decimal(15,1))   )+'元（截至'+@endTime+'），www.yoyo18.com' 
		 if(@mobileNum is not null )
			 begin
				if(len(@mobileNum)>=11 )
					begin
						 exec p_sendMsg @mobileNum,@content
						 declare @sendUrl varchar(500)
						  if(@EMail is not null and  @EMail<>'')
						  begin
							if not EXISTS  (select 1 from tb_unsubscribe where email=@EMail) 
							begin
							 set @sendUrl='http://www.yoyo18.com/web/emailProductSearch.yoyo?saleCode='+@saleCode+'&email='+@EMail
	 						declare @title varchar(200)
							if(@memberName is null or @memberName ='')
							begin
							if(@nickname is null or @nickname ='')
							set @nickname=''
							else
							set @nickname=@nickname+'，'
							end
							else
							set @nickname=@memberName+'，'
							set @title=@nickname+'看看优邮为您精心挑选了什么？'
							-- exec p_sendEmail2 @sendUrl,@EMail,@title
							end
						  end
			                end
	                 end
		FETCH NEXT FROM authors_cursor 
		INTO @memberId,@memberName,@mobileNum,@EMail,@nickname
	END
	
	CLOSE authors_cursor
	DEALLOCATE authors_cursor