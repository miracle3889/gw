CREATE PROCEDURE p_updatePayment @orderId INT,@isPayment int  --更新是否付款,55为免费商品送礼券的giftType
AS
	DECLARE @memberId INT
	DECLARE @freeProductCount INT
	DECLARE @isPaymentInt INT
	DECLARE @mobileNum VARCHAR(50)
	DECLARE @content NVARCHAR(500)
	DECLARE @magSourceRemark VARCHAR(50)
	DECLARE @cityId INT
	DECLARE @olderStatus INT
	DECLARE @getScore INT
	DECLARE @payTypeId INT

	DECLARE @cardCount INT
	DECLARE @productPrice INT
	SET @cardCount=0
	DECLARE @i INT
	SET @i=0

	set @payTypeId=0
	set @freeProductCount=0
	
			--免费商品付款成功之后送20元礼券
			--select @memberId=memberId,@olderStatus=orderstatus,@isPaymentInt=isPayment,@payTypeId=payType,
			--@magSourceRemark=magazineCodeS,@content=orderCode,@memberId=memberId,@cityId=cityId,@getScore=getScore,@productPrice=productPrice
			--from tb_order where id=@orderId
			
			---if (@isPayment = 1 and @isPaymentInt <> 1)
			--begin
				UPDATE tb_order SET isPayment = @isPayment ,paymentDate=getdate() WHERE id = @orderId and isPayment<>1
			--end
						
			--if (@isPayment=1 and @payTypeId=9)
			--begin
			--	exec  p_addMemberCardCardType @memberId,'TCK',1,-2,5 --送钻石卡
			--end
			
			-- 如果用户购买了 J21315 送礼券
			--SELECT @cardCount=isnull(sum(buyCount),0) FROM tb_orderSaleProduct WHERE saleProductId=21315 and orderId=@orderId
			--IF (@cardCount > 0)
			--BEGIN
			--	if (@isPayment=1 and (@payTypeId=7 or @payTypeId=8) )
				--begin
				--	WHILE (@i<@cardCount)
				--	BEGIN
				--		exec  p_sendGiftCardByCardNum @memberId, 'CFT50card'
				--		SET @i=@i+1
				--	END
				--	if(@productPrice=@cardCount*100)
				--	begin
				--		update tb_order set  orderstatus=3,visaTime=getDate(),visaRemark='LIQUAN' where id=@orderId
				--	end
				--end
			--END


		/*	if (@isPayment=1 and @getScore>0)
			begin
				select @freeProductCount=sum(buyCount) from tb_orderSaleProduct where saleProductCode like 'K%' and orderId=@orderId
				if (@freeProductCount>0)
				begin
					if (@isPaymentInt !=1)--之前没有收到过钱
					begin
						exec p_sendGiftCard20 @memberId,55 --送20元礼券
					end
				end
				--自动判断库存审核订单
				if(@olderStatus=5 or @olderStatus=6 ) 
	   			begin
					IF not EXISTS( 
						SELECT 1 FROM tb_orderSaleProduct a
						INNER JOIN erp..tb_productStock c ON a.colorId=c.colorId and a.metricsId=c.metricsId and a.orderId=@orderId
						LEFT  JOIN 
						(
							SELECT X.productId AS saleProductId,X.colorId AS colorId, 
							      X.metricsId AS metricsId,sum(X.buyCount) AS buyCount
							FROM dbo.tb_orderSaleProduct X INNER JOIN
							      dbo.tb_order Y ON Y.id = X.orderId
							WHERE Y.orderStatus IN (1, 6) AND Y.isDelete != 1
							GROUP by  X.productId,X.colorId,X.metricsId
							
						) as d on d.colorId=a.colorId and d.metricsId=a.metricsId
						LEFT  JOIN 
						(
							SELECT  sum(buyCount) as buyCount, colorId, metricsId
							FROM tb_shoppingBag 
							WHERE resource = 0 AND isStock = 1
							GROUP by  colorId, metricsId
						
						) as e on e.colorId=a.colorId and e.metricsId=a.metricsId
						 group by a.colorId,a.metricsId,c.productCount,d.buyCount,e.buyCount
						 having (c.productCount)-sum(a.buyCount)-isnull(d.buyCount,0) -isnull(e.buyCount,0)<0
					)
					BEGIN
						UPDATE dbo.tb_order SET orderStatus=1 ,magSourceRemark='autoPay',checkRemark=convert(varchar(20),getDate(),120)+'系统',isUpdate=0 WHERE id=@orderId
						if( @magSourceRemark='Y')
						begin
						  select @mobileNum=mobileNum from dbo.tb_member where id=@memberId and mobileNum not in(select mobileNum from tb_blackNum)
				 		    if(@mobileNum is not null )
							     begin
								if(len(@mobileNum)>=11 )
								begin
									if(@cityId=1)
									begin
										set @content='优邮提示:您的订单'+@content+'已经审核通过,我们会在72小时内将订单送达。www.yoyo18.com '
									end
									else
									begin
										set @content='优邮提示:您的订单'+@content+'已经审核通过,我们将尽快将订单送达。www.yoyo18.com '
									end
							                exec p_sendMsgByClass @mobileNum,@content,9999,1
								end
				   			  end
						end
					END
	
				end
			end*/