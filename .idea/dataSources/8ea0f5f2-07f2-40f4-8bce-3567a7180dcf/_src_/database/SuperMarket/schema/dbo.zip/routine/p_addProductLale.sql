CREATE PROCEDURE "dbo"."p_addProductLale" @productId int,
								  @lable varchar(20),
								  @needDate varchar(50)
as 
        declare @lableId int
	insert into  tb_productLable(productId,lable,needDate)
	values(@productId,@lable,@needDate)
	set @lableId=SCOPE_IDENTITY()
	select @lableId