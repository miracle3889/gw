

CREATE   procedure p_updateMagazine  @issuesCode varchar(10),
				@magCode varchar(10),
				@issueTime varchar(20),
				@coverPic varchar(50) ,
			      	@pageNum int,
				@id int
as 
	declare @insertId int
	/*if EXISTS (select 1 from  dbo.tb_MagazineIs where issuesCode= @issuesCode and id<>@id)
	begin
		set @insertId=-1 
	end
	else
	begin*/
		if(@coverPic<>'')
		begin
			update   dbo.tb_MagazineIs set issuesCode=@issuesCode,
							magCode=@magCode,
							issueTime=@issueTime,
							coverPic=@coverPic,
							pageNum=@pageNum where id=@id
		end
		else
		begin
			update   dbo.tb_MagazineIs set issuesCode=@issuesCode,
							magCode=@magCode,
							issueTime=@issueTime,
							pageNum=@pageNum where id=@id
		end
		set @insertId=1
	--end
	select @insertId