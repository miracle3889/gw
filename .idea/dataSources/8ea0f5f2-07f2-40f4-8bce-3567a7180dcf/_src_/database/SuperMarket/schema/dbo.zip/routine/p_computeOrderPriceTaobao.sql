CREATE       PROCEDURE p_computeOrderPriceTaobao     @orderId int
AS
	insert into dbo.tb_orderSaleProductPay(orderSaleProductId,payType,payValue)
				select a.id,payStyleId,payValue
				from tb_orderSaleProduct a
				inner join dbo.tb_saleProductPay b on b.saleProductId=a.saleProductId
				where a.orderId=@orderId
	 exec p_computeOrderPrice @orderId  
	 declare @payPrice int
	 declare @memberId int
	  declare @orderCode varchar(50)
	 select @payPrice=productPrice+deliverPrice-useGift,@memberId=memberId,@orderCode=orderCode from tb_order where id =@orderId
	
	 update tb_order set useaccount=@payPrice where id =@orderId
	
	set @payPrice=@payPrice*-1
	exec dbo.p_addAccountOpLog @memberId,@payPrice,1,@orderCode

	
