CREATE  PROCEDURE  p_get_ZaZhi_ProductCount @saleId INT,@colorId INT,@metricsId INT
AS
	DECLARE @productId INT
	SET @productId=0

	DECLARE @buyCount INT          --购买数量
	SET @buyCount=0
	DECLARE @buyCountI INT          --购买数量  3，11，17，18
	SET @buyCountI=0
	DECLARE @backCount INT          --拒收
	SET @backCount=0

	DECLARE	@juShouCount INT         --退货
	SET @juShouCount=0
	DECLARE @juShouTuiHuoCount INT   --拒收退货返库中
	SET @juShouTuiHuoCount=0
	DECLARE @delOrderCount INT       --删除订单返库中(待入库)
	SET @delOrderCount=0

	select @productId=productId from tb_saleProduct where id=@saleId
	

 
--购买数量  拒收
	if (@colorId!=0 and @metricsId!=0)
	begin
		select @buyCount=sum (b.buyCount), @buyCountI=sum(case when a.orderstatus in (3,11,17,18)  then b.buyCount else 0 end )
		 ,@backCount=sum (b.backCount) 
		from   tb_order a inner join tb_orderSaleProduct b on a.id=b.orderId 
		where a.isDelete!=1 and b.buyCount>0 and a.orderstatus in (1,20,13,2,3,17,11,18) 
		and b.saleProductId in (select id from tb_saleProduct where productId=@productId) and b.colorId=@colorId and b.metricsId=@metricsId
		and a.magazineCodeS not in ('CFT','Y','taobao','') and a.memberId not in (873561 ,884612)
	end
	else
	begin
		select @buyCount=sum (b.buyCount), @buyCountI=sum(case when a.orderstatus in (3,11,17,18)  then b.buyCount else 0 end )
		 ,@backCount=sum (b.backCount) 
		from   tb_order a inner join tb_orderSaleProduct b on a.id=b.orderId 
		where a.isDelete!=1 and b.buyCount>0 and a.orderstatus in (1,20,13,2,3,17,11,18) 
		and b.saleProductId in (select id from tb_saleProduct where productId=@productId) 
		and a.magazineCodeS not in ('CFT','Y','taobao','') and a.memberId not in (873561 ,884612)
	end





	--拒收未返库
	if (@colorId!=0 and @metricsId!=0)
	begin
		select @juShouCount=sum(c.backCount) from tb_rejectOrder a, tb_order b, tb_orderSaleProduct c 
		where a.orderId=b.id and c.orderId=b.id and c.backCount!=0 and b.isDelete!=1
		and c.saleProductId in (select id from tb_saleProduct where productId=@productId)
		and colorId=@colorId and metricsId=@metricsId
		and b.magazineCodeS not in ('CFT','Y','taobao','') and b.memberId not in (873561 ,884612)
	end
	else
	begin
		select @juShouCount=sum(c.backCount) from tb_rejectOrder a, tb_order b, tb_orderSaleProduct c 
		where a.orderId=b.id and c.orderId=b.id and c.backCount!=0 and b.isDelete!=1
		and c.saleProductId in (select id from tb_saleProduct where productId=@productId)
		and b.magazineCodeS not in ('CFT','Y','taobao','') and b.memberId not in (873561 ,884612)
	end
	
	
	if @juShouCount is null
		set @juShouCount=0
		
			
	
	

	--拒收退货返库中
	if (@colorId!=0 and @metricsId!=0)
	begin
		select @juShouTuiHuoCount=sum(a.productCount) from erp..tb_orderInstockProduct a ,erp..tb_orderInstock b,
						erp..tb_productStock c,erp..tb_orderInstockOrder d 
		where b.status in (0,1) and b.id=a.instockId and a.productCode=c.productShelfCode 
		and c.productId=@productId
		and colorId=@colorId and metricsId=@metricsId
		and b.id=d.instockId and d.orderId in (
			select id from tb_order where magazineCodeS not in ('CFT','Y','taobao','') and memberId not in (873561 ,884612)
		)
	end
	else
	begin
		select @juShouTuiHuoCount=sum(a.productCount) from erp..tb_orderInstockProduct a ,erp..tb_orderInstock b,
						erp..tb_productStock c,erp..tb_orderInstockOrder d  
		where b.status in (0,1) and b.id=a.instockId and a.productCode=c.productShelfCode 
		and c.productId=@productId
		and b.id=d.instockId and d.orderId in (
			select id from tb_order where magazineCodeS not in ('CFT','Y','taobao','') and memberId not in (873561 ,884612)
		)
	end
	




	--拒收退货返库中 = 拒收退货返库中-删除订单返库中(待入库)
	--删除订单返库中(待入库)
	if (@colorId!=0 and @metricsId!=0)
	begin
		select @delOrderCount=sum(b.buyCount) from superMarket..tb_order a,superMarket..tb_orderSaleProduct b 
		where  a.isdelete=1 and b.orderId=a.id and 
		a.id in(select d.orderId from erp..tb_orderInstock c ,erp..tb_orderInstockOrder d where c.id=d.instockId and d.type=1 and c.status in(1,0))
		and b.saleProductId in (select id from tb_saleProduct where productId=@productId)
		and colorId=@colorId and metricsId=@metricsId
		and a.magazineCodeS not in ('CFT','Y','taobao','') and a.memberId not in (873561 ,884612)
	end
	else
	begin
		select @delOrderCount=sum(b.buyCount) from superMarket..tb_order a,superMarket..tb_orderSaleProduct b 
		where  a.isdelete=1 and b.orderId=a.id and 
		a.id in(select d.orderId from erp..tb_orderInstock c ,erp..tb_orderInstockOrder d where c.id=d.instockId and d.type=1 and c.status in(1,0))
		and b.saleProductId in (select id from tb_saleProduct where productId=@productId)
		and a.magazineCodeS not in ('CFT','Y','taobao','') and a.memberId not in (873561 ,884612)
	end
	
	
	if (@delOrderCount is null)
	begin
		SET @delOrderCount=0
	end
	
	
	SET @juShouTuiHuoCount=@juShouTuiHuoCount-@delOrderCount

	
SELECT @productId as productId ,
@juShouCount as juShouCount ,@juShouTuiHuoCount as juShouTuiHuoCount ,@delOrderCount as delOrderCount ,
@buyCount as buyCount, @buyCountI as buyCountI ,@backCount as backCount
	--   productId,库存,配货中数量,发货中,已送达,退货
	--   拒收未返库,退货未返库,拒收退货返库中,删除订单返库中(待入库),报损报失