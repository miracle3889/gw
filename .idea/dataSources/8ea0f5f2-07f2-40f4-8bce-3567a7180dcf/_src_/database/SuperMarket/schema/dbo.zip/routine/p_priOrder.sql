CREATE  PROCEDURE p_priOrder @orderId INT,@priorityManId int
AS	
	BEGIN TRAN 
		delete from tb_priorityOrder where orderId=@orderId
		insert into tb_priorityOrder(orderId,priorityManId) values(@orderId,@priorityManId)
		update tb_order set remark=remark+'★' where id  =@orderId
	COMMIT TRAN