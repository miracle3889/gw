CREATE procedure p_addScoreOpLog @memberID  int,
				 @amount int,
                                 @opType int,/*0、积分换购，扣减积分1、购物获得积分2、推荐好友注册成功每次获得20个积分3、撰写商品评论，人工审核通过之后，获得10个积分（每人每商品限获得一次），99充值卡注册送100分
， ,51 积分换礼券,55注册送积分，9为手工增加*/
				 @orderCode varchar(50)
as
	begin tran
		declare @score int
		select @score=score from tb_member where id = @memberID  --先取出当前用户现有积分，做日志记录用
		if(@orderCode is not null and @orderCode<>'')
		begin
			declare  @magazineCodeS varchar(50)
			select @magazineCodeS=magazineCodeS from tb_order where orderCode=@orderCode
			if(@magazineCodeS is not null and @magazineCodeS='M')
				set @amount=@amount+@amount
			
		end
		update tb_member set score = @score+@amount where id = @memberID  --修改用户积分

		insert tb_scoreOpLog(memberID,originScore,opAmount,opType,orderCode) 
		Values(@memberId,@score,@amount,@opType,@orderCode)
	commit tran