CREATE  PROCEDURE  p_getProductCount @saleId INT,@colorId INT,@metricsId INT
AS
	DECLARE @productId INT
	SET @productId=0
	DECLARE @stockCount INT          --库存
	SET @stockCount=0
	DECLARE @jiRuStockCount INT          --记入库存
	SET @jiRuStockCount=0
	DECLARE @orderStockCount INT          --订单中数量
	SET @orderStockCount=0
	DECLARE @needCount INT          --缺货数量
	SET @needCount=0

	DECLARE @buyCount INT          --购买数量
	SET @buyCount=0
	DECLARE @buyCountI INT          --购买数量  3，11，17，18
	SET @buyCountI=0
	DECLARE @backCount INT          --拒收
	SET @backCount=0
	
	DECLARE @taobaoDaiPeiHuoCount INT --淘宝待配货  包含：等待配货、待取货、取货中
	SET @taobaoDaiPeiHuoCount=0

	DECLARE @peiHuoCount INT         --配货中数量
	SET @peiHuoCount=0
	DECLARE @faHuoCount INT          --发货中
	SET @faHuoCount=0
	DECLARE @songDaCount INT         --已送达
	SET @songDaCount=0
	DECLARE @tuiHuoCount INT         --退货
	SET @tuiHuoCount=0
	DECLARE	@juShouCount INT         --拒收未返库
	SET @juShouCount=0
	DECLARE @tuiHuoCountKu INT       --退货未返库
	SET @tuiHuoCountKu=0
	DECLARE @juShouTuiHuoCount INT   --拒收退货返库中
	SET @juShouTuiHuoCount=0
	DECLARE @delOrderCount INT       --删除订单返库中(待入库)
	SET @delOrderCount=0
	DECLARE @baoSunCount INT         --报损报失
	SET @baoSunCount=0

	select @productId=productId from tb_saleProduct where id=@saleId
	--库存
	if (@colorId!=0 and @metricsId!=0)
	begin
		select @stockCount=sum(productCount) from erp..tb_productStock where productId=@productId and colorId=@colorId and metricsId=@metricsId
	end
	else
	begin
		select @stockCount=sum(productCount) from erp..tb_productStock where productId=@productId 
	end

-- --订单中数量  记入库存
	--if (@colorId!=0 and @metricsId!=0)
	--begin
	--	select @jiRuStockCount=isnull(sum(allStockCount),0) from dbo.v_allBuyProductNewRemark where saleProductId=@productId  and colorId=@colorId and metricsId=@metricsId
	--end
	--else
	--begin
	--	select @jiRuStockCount=isnull(sum(allStockCount),0) from dbo.v_allBuyProductNewRemark where saleProductId=@productId
	--end

--缺货数量
	if (@colorId!=0 and @metricsId!=0)
	begin
		select @needCount=sum(needCount) from tb_registProduct where saleId in (select id from tb_saleProduct where productId=@productId) 
		and isdeleted=0 and colorId=@colorId and metricsId=@metricsId
		and convert(varchar(10),isnull(addTime,''),120)!=convert(varchar(10),isnull(addShoopingTime,''),120)
		
	end
	else
	begin
		select @needCount=sum(needCount) from tb_registProduct where saleId in (select id from tb_saleProduct where productId=@productId) 
		and isdeleted=0 and convert(varchar(10),isnull(addTime,''),120)!=convert(varchar(10),isnull(addShoopingTime,''),120)
	end
 
--购买数量  拒收
	if (@colorId!=0 and @metricsId!=0)
	begin
		select @buyCount=sum (b.buyCount), @buyCountI=sum(case when a.orderstatus in (3,11,17,18)  then b.buyCount else 0 end )
		 ,@backCount=sum (b.backCount) 
		from   tb_order a inner join tb_orderSaleProduct b on a.id=b.orderId 
		where a.isDelete!=1 and b.buyCount>0 and a.orderstatus in (1,20,13,2,3,17,11,18) 
		and b.saleProductId in (select id from tb_saleProduct where productId=@productId) and b.colorId=@colorId and b.metricsId=@metricsId
	end
	else
	begin
		select @buyCount=sum (b.buyCount), @buyCountI=sum(case when a.orderstatus in (3,11,17,18)  then b.buyCount else 0 end )
		 ,@backCount=sum (b.backCount) 
		from   tb_order a inner join tb_orderSaleProduct b on a.id=b.orderId 
		where a.isDelete!=1 and b.buyCount>0 and a.orderstatus in (1,20,13,2,3,17,11,18) 
		and b.saleProductId in (select id from tb_saleProduct where productId=@productId) 
	end


	--配货中
	if (@colorId!=0 and @metricsId!=0)
	begin
		select @peiHuoCount=sum(b.buyCount) from superMarket..tb_order a,superMarket..tb_orderSaleProduct b 
		where a.isDelete!=1 and a.orderStatus in (20,13) 
		and b.saleProductId in (select id from tb_saleProduct where productId=@productId) and a.id=b.orderId 
		and colorId=@colorId and metricsId=@metricsId
	end
	else
	begin
		select @peiHuoCount=sum(b.buyCount) from superMarket..tb_order a,superMarket..tb_orderSaleProduct b 
		where a.isDelete!=1 and a.orderStatus in (20,13) 
		and b.saleProductId in (select id from tb_saleProduct where productId=@productId) and a.id=b.orderId
	end


	--淘宝待配货  包含：等待配货、待取货、取货中
	if (@colorId!=0 and @metricsId!=0)
	begin
		select @taobaoDaiPeiHuoCount=sum(case when magazineCodeS ='taobao' then b.buyCount else 0 end ),@orderStockCount=sum(b.buyCount) 
		from superMarket..tb_order a,superMarket..tb_orderSaleProduct b 
		where a.isDelete!=1 and a.orderStatus in (1) 
		and b.saleProductId in (select id from tb_saleProduct where productId=@productId) and a.id=b.orderId -- and magazineCodeS='taobao'
		and colorId=@colorId and metricsId=@metricsId
		
		--select @taobaoDaiPeiHuoCount=@taobaoDaiPeiHuoCount+isnull(sum(buyCount),0) 
		--from tb_temp_waitPhProduct where colorId=@colorId and metricsId=@metricsId and saleProductId=@productId
	end
	else
	begin
		select @taobaoDaiPeiHuoCount=sum(case when magazineCodeS ='taobao' then b.buyCount else 0 end ),@orderStockCount=sum(b.buyCount) 
		from superMarket..tb_order a,superMarket..tb_orderSaleProduct b 
		where a.isDelete!=1 and a.orderStatus in (1) 
		and b.saleProductId in (select id from tb_saleProduct where productId=@productId) and a.id=b.orderId -- and magazineCodeS='taobao'
		
		--select @taobaoDaiPeiHuoCount=@taobaoDaiPeiHuoCount+isnull(sum(buyCount),0) 
		--from tb_temp_waitPhProduct where saleProductId=@productId
	end
	
	

	--发货中
	if (@colorId!=0 and @metricsId!=0)
	begin
		select @faHuoCount=sum(b.buyCount) from superMarket..tb_order a,superMarket..tb_orderSaleProduct b 
		where a.isDelete!=1 and a.orderStatus in (2) 
		and b.saleProductId in (select id from tb_saleProduct where productId=@productId) and a.id=b.orderId
		and colorId=@colorId and metricsId=@metricsId
	end
	else
	begin
		select @faHuoCount=sum(b.buyCount) from superMarket..tb_order a,superMarket..tb_orderSaleProduct b 
		where a.isDelete!=1 and a.orderStatus in (2) 
		and b.saleProductId in (select id from tb_saleProduct where productId=@productId) and a.id=b.orderId
	end
	


	--已送达
	if (@colorId!=0 and @metricsId!=0)
	begin
		select @songDaCount=sum(b.buyCount-b.backCount) from superMarket..tb_order a,superMarket..tb_orderSaleProduct b 
		where a.isDelete!=1 and a.orderStatus in (3,17) 
		and b.saleProductId in (select id from tb_saleProduct where productId=@productId) and a.id=b.orderId
		and colorId=@colorId and metricsId=@metricsId
	end
	else
	begin
		select @songDaCount=sum(b.buyCount-b.backCount) from superMarket..tb_order a,superMarket..tb_orderSaleProduct b 
		where a.isDelete!=1 and a.orderStatus in (3,17) 
		and b.saleProductId in (select id from tb_saleProduct where productId=@productId) and a.id=b.orderId
	end
	


	--退货
	if (@colorId!=0 and @metricsId!=0)
	begin
		select @tuiHuoCount=sum(getCount) from tb_backProduct where getCount>0 
		and saleId in (select id from tb_saleProduct where productId=@productId)
		and colorId=@colorId and metricsId=@metricsId
	end
	else
	begin
		select @tuiHuoCount=sum(getCount) from tb_backProduct where getCount>0 
		and saleId in (select id from tb_saleProduct where productId=@productId)
	end
	

	
	if @tuiHuoCount is null
		set @tuiHuoCount=0

	--拒收未返库
	if (@colorId!=0 and @metricsId!=0)
	begin
		select @juShouCount=sum(c.backCount) from tb_rejectOrder a, tb_order b, tb_orderSaleProduct c 
		where a.orderId=b.id and c.orderId=b.id and c.backCount!=0 and b.isDelete!=1
		and c.saleProductId in (select id from tb_saleProduct where productId=@productId)
		and colorId=@colorId and metricsId=@metricsId
	end
	else
	begin
		select @juShouCount=sum(c.backCount) from tb_rejectOrder a, tb_order b, tb_orderSaleProduct c 
		where a.orderId=b.id and c.orderId=b.id and c.backCount!=0 and b.isDelete!=1
		and c.saleProductId in (select id from tb_saleProduct where productId=@productId)
	end
	
	
	if @juShouCount is null
		set @juShouCount=0
		

	--退货未返库
	if (@colorId!=0 and @metricsId!=0)
	begin
		select @tuiHuoCountKu=sum(getCount) from tb_backProduct 
		where backId not in (select orderId from erp..tb_orderInstockOrder where type=3)
		and saleId in (select id from tb_saleProduct where productId=@productId)
		and colorId=@colorId and metricsId=@metricsId
	end
	else
	begin
		select @tuiHuoCountKu=sum(getCount) from tb_backProduct 
		where backId not in (select orderId from erp..tb_orderInstockOrder where type=3)
		and saleId in (select id from tb_saleProduct where productId=@productId)
	end
	
	

	--拒收退货返库中
	if (@colorId!=0 and @metricsId!=0)
	begin
		select @juShouTuiHuoCount=sum(a.productCount) from erp..tb_orderInstockProduct a ,erp..tb_orderInstock b,erp..tb_productStock c 
		where b.status in (0,1) and b.id=a.instockId and a.productCode=c.productShelfCode 
		and c.productId=@productId
		and colorId=@colorId and metricsId=@metricsId
	end
	else
	begin
		select @juShouTuiHuoCount=sum(a.productCount) from erp..tb_orderInstockProduct a ,erp..tb_orderInstock b,erp..tb_productStock c 
		where b.status in (0,1) and b.id=a.instockId and a.productCode=c.productShelfCode 
		and c.productId=@productId
	end
	




	--拒收退货返库中 = 拒收退货返库中-删除订单返库中(待入库)
	--删除订单返库中(待入库)
	if (@colorId!=0 and @metricsId!=0)
	begin
		select @delOrderCount=sum(b.buyCount) from superMarket..tb_order a,superMarket..tb_orderSaleProduct b 
		where  a.isdelete=1 and b.orderId=a.id and 
		a.id in(select d.orderId from erp..tb_orderInstock c ,erp..tb_orderInstockOrder d where c.id=d.instockId and d.type=1 and c.status in(1,0))
		and b.saleProductId in (select id from tb_saleProduct where productId=@productId)
		and colorId=@colorId and metricsId=@metricsId
	end
	else
	begin
		select @delOrderCount=sum(b.buyCount) from superMarket..tb_order a,superMarket..tb_orderSaleProduct b 
		where  a.isdelete=1 and b.orderId=a.id and 
		a.id in(select d.orderId from erp..tb_orderInstock c ,erp..tb_orderInstockOrder d where c.id=d.instockId and d.type=1 and c.status in(1,0))
		and b.saleProductId in (select id from tb_saleProduct where productId=@productId)
	end
	
	
	if (@delOrderCount is null)
	begin
		SET @delOrderCount=0
	end
	
	
	SET @juShouTuiHuoCount=@juShouTuiHuoCount-@delOrderCount

	if (@colorId!=0 and @metricsId!=0)
	begin
		select @delOrderCount=@delOrderCount+sum(b.buyCount) from superMarket..tb_order a,superMarket..tb_orderSaleProduct b 
		where  a.isdelete=1 and b.orderId=a.id and
		a.id in(select orderid  from erp..tb_dealUpdateOrder where  isIn=0 ) 
		and b.saleProductId in (select id from tb_saleProduct where productId=@productId)
		and colorId=@colorId and metricsId=@metricsId
	end
	else
	begin
		select @delOrderCount=@delOrderCount+sum(b.buyCount) from superMarket..tb_order a,superMarket..tb_orderSaleProduct b 
		where  a.isdelete=1 and b.orderId=a.id and
		a.id in(select orderid  from erp..tb_dealUpdateOrder where  isIn=0 ) 
		and b.saleProductId in (select id from tb_saleProduct where productId=@productId)
	end
	

	if (@delOrderCount is null)
	begin
		SET @delOrderCount=0
	end

	

	--报损报失
	if (@colorId!=0 and @metricsId!=0)
	begin
		select @baoSunCount=sum(a.productCount) from erp..tb_shelfProductOpHis a 
		inner join erp..tb_productStock b on a.productCode=b.productShelfCode	where a.shelfCode in ('X0000','Y0000') and a.type=0 
		and productId=@productId
		and colorId=@colorId and metricsId=@metricsId
	end
	else
	begin
		select @baoSunCount=sum(a.productCount) from erp..tb_shelfProductOpHis a 
		inner join erp..tb_productStock b on a.productCode=b.productShelfCode	where a.shelfCode in ('X0000','Y0000') and a.type=0 
		and productId=@productId
	end
	
	
	set @songDaCount=@songDaCount-@tuiHuoCount
SELECT @productId as productId,@stockCount as stockCount ,@peiHuoCount as peiHuoCount ,@faHuoCount as faHuoCount ,@songDaCount as songDaCount ,@tuiHuoCount as tuiHuoCount ,
@juShouCount as juShouCount ,@tuiHuoCountKu as tuiHuoCountKu ,@juShouTuiHuoCount as juShouTuiHuoCount ,@delOrderCount as delOrderCount ,@baoSunCount as baoSunCount ,
@buyCount as buyCount, @buyCountI as buyCountI ,@backCount as backCount,@jiRuStockCount as jiRuStockCount, @needCount as needCount, @orderStockCount as orderStockCount, @taobaoDaiPeiHuoCount as taobaoDaiPeiHuoCount
	--   productId,库存,配货中数量,发货中,已送达,退货
	--   拒收未返库,退货未返库,拒收退货返库中,删除订单返库中(待入库),报损报失