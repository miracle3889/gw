
/*--------------------生成礼券----------------------------------------*/
CREATE  PROCEDURE p_markGiftCad_HT @makeCount INT,@area INT,@price INT,@needPrice INT 
AS	
	
	DECLARE @cardCode INT
	DECLARE @maxCode INT
	DECLARE @defalut INT
	DECLARE @psw INT
	DECLARE @returnValue  INT
	DECLARE @pswC VARCHAR(50)
	DECLARE @i INT
	SET @returnValue=0
	SET @i=0
	SET @defalut=180000 --默认的初始
	BEGIN TRAN 
	WHILE(@i<@makeCount)
	BEGIN

			SELECT @maxCode=MAX(intId) FROM dbo.tb_giftCard WHERE area=@area --得到最大的卡号
			IF(@maxCode IS NULL)
				BEGIN
					SET @maxCode=@defalut
				END
			SET @maxCode=@maxCode+1 --序号加一
		
			SET @cardCode=@area*1000000+@maxCode --设置卡号
			
			SET @psw=RAND()*100000000 --设置8位密码
			IF(@psw<10000000)		
			SET @psw=@psw+10000000
	
			SET @pswC=CAST(@psw AS VARCHAR(50))
	
			INSERT INTO dbo.tb_giftCard(cardCode,psw,price,actLastTime,area,intId,needPrice,createType)
			VALUES (@cardCode,dbo.md5(@psw),@price*100,DATEADD(day,30,GETDATE()),@area,@maxCode,@needPrice*100,1)
			
			--INSERT INTO tb_makedCard(code,psw,price) VALUES (@cardCode,@psw,@price)
			SET @i=@i+1
		
	END
	SET @returnValue=1
	COMMIT TRAN 
	SELECT @returnValue
