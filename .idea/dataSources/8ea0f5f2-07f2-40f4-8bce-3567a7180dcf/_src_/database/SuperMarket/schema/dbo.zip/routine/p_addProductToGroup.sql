/*---------------添加商品到组合 ----------------------------*/
CREATE procedure  p_addProductToGroup @saleId int,@groupId int
as
     declare @saleCode varchar(50)
     declare @salePrice int
     declare @requireCount int
     declare @intCode int
     declare @groupCode varchar(50)
     declare @oldPrice int
     declare @payValue int
     declare @productId int
     declare @remark varchar(500)
    
     select @groupCode=code,@salePrice=salePrice,@requireCount=requireCount from dbo.tb_saleGroup where id=@groupId
     set @payValue=@salePrice/@requireCount
    select @oldPrice=oldPrice,@remark=remark,@productId=productId from tb_saleProduct where id=@saleId
     select @intCode=max(cast(subString(saleCode,len(saleCode)-2,3) as int)) from tb_saleProduct  where groupId=@groupId 
    if(@intCode is null)
	    begin
	  	  set @intCode=0
	   end
	set @intCode=@intCode+1
	set @saleCode=cast(@intCode as varchar(10))
	while(len(@saleCode)<3)
	begin
		set @saleCode='0'+@saleCode
	end
  set @saleCode=@groupCode+@saleCode
 
INSERT INTO dbo.tb_saleProduct(saleCode,productId,oldPrice,remark,saleCount,salePlanId,saleTypeId,groupId)
		VALUES(@saleCode,@productId,@oldPrice,@remark,-1,324,9,@groupId)
declare @currentId int
set @currentId=scope_identity()
insert into dbo.tb_saleProductPay(saleProductId,payStyleId,payValue) values(@currentId,1,@payValue)