
CREATE  view v_magSourceCount as
select count(*) as amount, magSourceRemark from tb_order 
where magSourceRemark is not null and magSourceRemark <> '' and isDelete <> 1
group by magSourceRemark


