/***********************添加商品组合到购物车***************************************/
CREATE PROCEDURE p_addShoppingBagGroup @groupId int, @groupCode varchar(50), @buyCount int, @memberId int

AS 	
	declare @returnId int
	begin tran
		insert into tb_shoppingBag(productCode,saleProductId,buyCount,memberId,type)
		values(@groupCode,@groupId,@buyCount,@memberId,2)	
		set @returnId=@@Identity
	commit tran
	select @returnId