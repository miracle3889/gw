/*---------------------------------------------------------客服-添加会员----------------------------------------------------*/
CREATE PROCEDURE p_AddMemberWithPost  @name VARCHAR(50),@sex INT,
				           @post VARCHAR(50),@mobileNum VARCHAR(50),
				           @phoneNum VARCHAR(50),@homeAddr VARCHAR(200),
				           @complanyAddr VARCHAR(200),@score INT,
				           @account INT,@EMail VARCHAR(50),@homeAddrRegional INT,@complanyAddrRegional INT,@provinceId INT,@cityId INT,@bir varchar(50),@postAddr VARCHAR(200),@postRegional INT,@addUser int 
AS
	DECLARE @returnValue INT
	SET @returnValue=0
	BEGIN TRAN
		INSERT INTO  dbo.tb_member(name,sex,post,mobileNum,phoneNum,
						homeAddr,complanyAddr,score,account,EMail,homeAddrRegional,complanyAddrRegional,provinceId ,cityId,birth,payAddr,payRegional,addUser) 
		VALUES (@name,@sex,@post,@mobileNum,@phoneNum,
						@homeAddr,@complanyAddr,@score,@account,@EMail,@homeAddrRegional,@complanyAddrRegional,@provinceId ,@cityId,@bir, @postAddr,@postRegional,@addUser)
		SET @returnValue=SCOPE_IDENTITY()
	COMMIT TRAN
	SELECT @returnValue
