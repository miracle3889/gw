

/*----------------得到销售组合的id-------------------------------------*/
CREATE   PROCEDURE p_GetSaleGroupId @productCode VARCHAR(50),@productName VARCHAR(50)
AS
  DROP TABLE tmpGroupT
  DECLARE @sql VARCHAR(2000)
  SET @sql='SELECT id INTO tmpGroupT FROM dbo.tb_saleProductGroup WHERE 1=1 AND isDelete=0'
  IF(LEN(@productCode)>0)
	  BEGIN
	      SET @sql=@sql+' AND groupCode like ''%'+ @productCode+'%'''
	  END
  IF(LEN(@productName)>0)
 	  BEGIN
	      SET @sql=@sql+' AND groupName like ''%'+ @productName+'%'''
	  END 
  EXEC(@sql)
  IF(@@ROWCOUNT=0)
  BEGIN
	DROP TABLE tmpGroupT
	SET @sql='SELECT a.id AS id  INTO tmpGroupT FROM dbo.tb_saleProductGroup a
	INNER JOIN dbo.tb_groupProduct b ON b.groupId=a.id
	INNER JOIN dbo.tb_saleProduct c ON b.saleProductId=c.id
	INNER JOIN ERP.dbo.tb_product d ON c.productId=d.id
	WHERE 1=1  AND a.isDelete=0'
 	IF(LEN(@productCode)>0)
	BEGIN
	   SET @sql=@sql+' AND b.productCode  like  ''%'+ @productCode+'%'''
	END
 	IF(LEN(@productName)>0)
 	BEGIN
	   SET @sql=@sql+' AND d.name like ''%'+ @productName+'%'''
	END 
        EXEC(@sql)
  END
 SELECT id FROM  tmpGroupT