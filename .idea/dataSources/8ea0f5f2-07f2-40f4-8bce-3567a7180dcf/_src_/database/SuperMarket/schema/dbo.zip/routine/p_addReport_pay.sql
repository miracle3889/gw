CREATE PROCEDURE p_addReport_pay

AS
/* Procedure body */