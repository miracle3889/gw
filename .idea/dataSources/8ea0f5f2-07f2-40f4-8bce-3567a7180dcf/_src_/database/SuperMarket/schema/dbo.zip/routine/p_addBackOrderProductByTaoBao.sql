/*-----------------------------------------------------退货单退回商品----------------------------------------------------------------*/
CREATE PROCEDURE p_addBackOrderProductByTaoBao @backOrderId int, @orderId int ,@orderSaleId int, @backCount int 

AS
	begin tran 

	insert into tb_backProduct(backId,orderSaleId,saleId,colorId,metricsId,backCount,getCount,type) 
	select @backOrderId,@orderSaleId,saleProductId,colorId,metricsId,@backCount,@backCount,1 
	from tb_orderSaleProduct where id=@OrderSaleId  and orderId= @orderId
	
	update tb_backOder set BackPrice=BackPrice+b.payValue*c.backCount , payPrice=payPrice+b.payValue*c.backCount 
	from tb_orderSaleProduct a 
	inner join tb_orderSaleProductPay b on b.orderSaleProductId=a.id and b.payType=1 
	inner join tb_backProduct c on c.orderSaleId=a.id 
	where tb_backOder.id=@backOrderID and a.id=@orderSaleId and a.orderId=@orderId

	--insert into tb_updateTabaoProductCount(productCode,productCount,reMark)
	-- select productShelfCode,@backCount,'换货' from erp..tb_productStock  a,tb_orderSaleProduct b where a.colorId=b.colorId and a.metricsId=b.metricsId and  b. id=@OrderSaleId  and b.orderId= @orderId

	commit tran