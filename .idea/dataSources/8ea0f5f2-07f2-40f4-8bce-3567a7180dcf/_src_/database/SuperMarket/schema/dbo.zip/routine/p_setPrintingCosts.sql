CREATE procedure p_setPrintingCosts
as 
	update tb_magSourceRemark set firstBuyTime=b.firstBuyTime from  tb_magSourceRemark a,
	(
	
			select id ,min(firstBuyTime)  as firstBuyTime  from (
			select  a.id,convert(varchar(10),b.createTime ,120) as dayTime,min( b.createTime ) as firstBuyTime  from tb_magSourceRemark a
			inner join tb_order b on b. magSourceRemark like a.magSource and  b.createTime>=a.issueTime  and a.firstBuyTime is null
			group by a.id ,convert(varchar(10),b.createTime ,120) having count(*)>3) as x group by id


	)
	 as b  where a.id=b.id		
	
	delete from tb_magCost where  magId in(select id from tb_magSourceRemark where firstBuyTime is not null  and isSetPrint=0)
	
	DECLARE @magId INT
	DECLARE @printCost INT
	DECLARE @postCost INT
	DECLARE @firstBuyTime DATETIME
	DECLARE @printCostTemp INT
	DECLARE @postCostTemp INT
	DECLARE @BuyTimeTemp DATETIME

	DECLARE authors_cursor0 CURSOR FOR
	select id,cost*issueCount as printCost,(50*issueCount*precent/100)*isPost as postCost,firstBuyTime 
	from tb_magSourceRemark where firstBuyTime is not null  and isSetPrint=0     --id not in(select magId from  tb_magCost)

	OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0 
	INTO @magId,@printCost,@postCost,@firstBuyTime
	WHILE @@FETCH_STATUS = 0
	BEGIN	
		delete from tb_magCost where magId=@magId
		SET @printCostTemp=(@printCost*80/100)/30
		SET @postCostTemp=(@postCost*80/100)/30
		
		SET @BuyTimeTemp=@firstBuyTime
		
		WHILE(@BuyTimeTemp<=DATEADD(day,30,@firstBuyTime))
		BEGIN
			INSERT INTO tb_magCost(magTime,printCost,postCost,magId) VALUES(@BuyTimeTemp,@printCostTemp,@postCostTemp,@magId)
			SET @BuyTimeTemp=DATEADD(day,1,@BuyTimeTemp) 
		END
	
		SET @printCostTemp=(@printCost*20/100)/30
		SET @postCostTemp=(@postCost*20/100)/30
		SET @BuyTimeTemp=DATEADD(day,31,@firstBuyTime) 
		
		WHILE(@BuyTimeTemp<DATEADD(day,60,@firstBuyTime))
		BEGIN
			INSERT INTO tb_magCost(magTime,printCost,postCost,magId) VALUES(@BuyTimeTemp,@printCostTemp,@postCostTemp,@magId)
			SET @BuyTimeTemp=DATEADD(day,1,@BuyTimeTemp) 
		END

		FETCH NEXT FROM authors_cursor0 
		INTO @magId,@printCost,@postCost,@firstBuyTime
	END
	CLOSE authors_cursor0
	DEALLOCATE authors_cursor0
	
	
	update tb_magSourceRemark set isSetPrint=1  where  firstBuyTime is not null  and isSetPrint=0 
	
	
	delete from  tb_productPrintCost
	


	insert into tb_productPrintCost(saleId,costTime,printCost,magId)
	

	select saleId,convert(varchar(10),b.magTime,120),isnull(sum((cast(b.printCost as bigint)*cast(a.precent as bigint))/cast(c.totalPrecent as bigint)),0) 
	,a.magid 
	from tb_magProduct a
	inner join tb_magCost b on a.magid=b.magId
	inner join 
	(
		select magId,sum(precent) as totalPrecent from tb_magProduct
		group by magId
	) c on c.magId=b.magId
	
	group by saleId,convert(varchar(10),b.magTime,120),a.magid
	order by saleId,convert(varchar(10),b.magTime,120)