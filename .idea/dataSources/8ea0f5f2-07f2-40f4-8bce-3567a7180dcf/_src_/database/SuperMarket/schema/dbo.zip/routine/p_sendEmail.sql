
CREATE  procedure p_sendEmail @EmailUrl varchar(200),@DestEmailAddr varchar(200),@title varchar(200)
as 
	insert into dbo.tb_EmailMission(EmailHtml,title,EmailAddr) 
	values(@EmailUrl,@title,@DestEmailAddr)
	

