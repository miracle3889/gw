
/*------------------------------------------------------------添加定单------------------------------------------------------------------------------------*/
CREATE  PROCEDURE p_addOrder   @payType INT,@deliverType INT,@deliverPrice INT,
				     @memberId INT,@orderStatus INT, 
				     @doMan INT,@reMark VARCHAR(200),
				     @orderSource INT,@magazineCode VARCHAR(50),
				     @receviceMan VARCHAR(50),@post VARCHAR(50),
				     @receviceAddr1 VARCHAR(200),@receviceAddr2 VARCHAR(200),
				     @receviceMobile VARCHAR(50),@addrId INT,
				     @useAccount INT,@getScore INT,@regionalId1 int,@regionalId2 int
AS
	DECLARE @code VARCHAR(50)
	DECLARE @score INT 
	DECLARE @returnId INT
	DECLARE @tempScore INT

	SET @returnId=0
	BEGIN TRAN 

	/*---------------------------得到销售商品应扣除的积分------------------------------------*/
	SELECT @score=SUM(a.payValue)
	FROM tb_saleProductPay a
	INNER JOIN tb_payStyle b  ON a.payStyleId=b.id 
	INNER JOIN tb_shoppingBag c ON a.saleProductId=c.saleProductId
	WHERE   c.memberId=@memberId AND b.id=2
	SET @tempScore=0

	IF(@score IS NOT NULL)
	BEGIN
		SELECT  @tempScore=score-@score FROM tb_member WHERE id=@memberId --判断积分
	END
	IF(@tempScore<0)
	BEGIN
		SET  @returnId=-1
	END
	ELSE
	BEGIN
			EXEC p_geOrderCode @code OUTPUT --得到订单号
			/*--------------------------生成定单信息----------------------------------------------*/
			INSERT INTO dbo.tb_order(orderCode,payType,deliverType,deliverPrice,memberId,orderStatus,
						   doMan,reMark,orderSource,magazineCodeS,receviceMan,post,receviceAddr1,
					               receviceAddr2,receviceMobile,addrId,useAccount,getScore,regionalId1,regionalId2)
			VALUES(@code,@payType,@deliverType,@deliverPrice,@memberId,@orderStatus,
				 @doMan,@reMark,@orderSource,@magazineCode,@receviceMan,@post,@receviceAddr1,
					               @receviceAddr2,@receviceMobile,@addrId,@useAccount,@getScore,@regionalId1 ,@regionalId2 )
			SET @returnId=SCOPE_IDENTITY() --得到刚刚插入的定单id 
			/*---------------------------插入定单单件商品-------------------------------------------*/
			INSERT INTO dbo.tb_orderSaleProduct(orderId,colorId,metricsId,saleProductCode,saleProductId,buyCount,isRand)
		        	SELECT @returnId,colorId,metricsId,productCode,saleProductId,buyCount,isRand FROM dbo.tb_shoppingBag WHERE 
			memberId=@memberId AND type=1
			
			/*---------------------------得到销售商品应扣除的积分------------------------------------*/
			SELECT @score=SUM(a.payValue)
			FROM tb_saleProductPay a
			INNER JOIN tb_payStyle b  ON a.payStyleId=b.id 
			INNER JOIN tb_orderSaleProduct c ON a.saleProductId=c.saleProductId
			WHERE   c.orderId=@returnId AND b.id=2
			
			IF(@score  IS NULL)
			BEGIN
				SET @score=0
			END

			UPDATE dbo.tb_member SET  score=score-@score WHERE  id=@memberId
			/*----------------------------扣除定单所用帐户余额和添加所得积分----------------------------*/
			UPDATE dbo.tb_member SET account=account-@useAccount--,score=score+@getScore 
			WHERE id=@memberId
			DELETE  FROM tb_shoppingBag WHERE memberId=@memberId  --删除购物车中单件商品 
			DECLARE @realPrice INT
			SELECT @realPrice=SUM(b.payValue*a.buyCount) 
			FROM dbo.tb_orderSaleProduct a
			INNER JOIN dbo.tb_orderSaleProductPay b ON a.id=b.orderSaleProductId 
			WHERE b.payType=1 AND a.orderId=@returnId  
			UPDATE tb_order SET getScore=@realPrice/100,productPrice=@realPrice  WHERE id=@returnId
			
	END
	IF(@@ERROR<>0)
	BEGIN
		SET  @returnId=0
		ROLLBACK TRAN 
	END
	COMMIT TRAN 
	SELECT @returnId