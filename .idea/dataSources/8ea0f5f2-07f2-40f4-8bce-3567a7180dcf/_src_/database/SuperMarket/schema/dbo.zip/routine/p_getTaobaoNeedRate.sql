CREATE procedure p_getTaobaoNeedRate @startTime varchar(50),@endTime varchar(50),@top int,@isSend int
as

declare @sql varchar(5000)

set @sql='select d.taobaoTid,a.visaTime,c.taobaoOid,memberId,b.saleProductId from tb_order a
inner join tb_orderSaleProduct b on a.id=b.orderId
inner join tb_taobaoOId c on c.orderSaleId = b.id
inner join tb_taobaoCode d on d.orderCOde=a.orderCOde where orderstatus=3  and magSourceRemark=''taobao'' 
and createTime>=''2012-08-01'' and taobaoOid not in(select taobaoOId from tb_taobaoSendRate)'

if(len(@startTime)>0)
begin
	set @sql=@sql+'and visaTime>='''+@startTime+''''
end
if(len(@endTime)>0)
begin
	set @sql=@sql+'and visaTime<='''+@endTime+''''
end



	set @sql=@sql+' and memberId in(select memberId from tb_taobaoMember where taobaoNickName in(select nickName from tb_blackNickName))'


if(@isSend=0)
begin
	exec(@sql)
end
else
begin
	set @sql='insert into tb_taobaoSendRate(taobaoId,taobaoOid) select top '+cast(@top as varchar(10))+' taobaoTid,taobaoOid from ('+@sql+') as x'
	exec(@sql)
end


