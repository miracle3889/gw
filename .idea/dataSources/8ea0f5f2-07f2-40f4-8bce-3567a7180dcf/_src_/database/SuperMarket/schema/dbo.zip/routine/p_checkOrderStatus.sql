/*-----------------------检查当前定单状态------------------------------------*/
CREATE PROCEDURE p_checkOrderStatus @orderID INT
AS
   DECLARE @orderStatus INT
   DECLARE @isUpdate INT
   DECLARE @returnValue INT
   SET  @returnValue=0
   SELECT @orderStatus=orderStatus,@isUpdate=isUpdate FROM dbo.tb_order WHERE id=@orderID and orderstatus in(1,5,6)

	  if(@orderStatus is null)
		set @orderStatus=0
	
	if(@orderStatus=0)
	begin
		SET @returnValue=-1 
	end
	else
	begin
   		BEGIN TRAN
			IF(@isUpdate=-1 OR @isUpdate=-2)
			BEGIN
				SET @returnValue=-1
			END
			ELSE
			BEGIN
				UPDATE dbo.tb_order SET isUpdate=1 WHERE id=@orderID
				SET @returnValue=1
			END
			    IF(@@ERROR<>0)
			    BEGIN
				SET  @returnValue=0
			        ROLLBACK TRAN 
			    END 
  		COMMIT TRAN 
	end 
  SELECT @returnValue