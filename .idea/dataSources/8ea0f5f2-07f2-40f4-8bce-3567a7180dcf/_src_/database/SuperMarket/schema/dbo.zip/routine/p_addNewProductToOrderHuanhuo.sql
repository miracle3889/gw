CREATE procedure p_addNewProductToOrderHuanhuo @saleId int,@colorId int ,@metricsId int,@count int ,@orderId int
as 
	 declare @mysaleId int
	
	 INSERT INTO dbo.tb_orderSaleProduct(orderId,colorId,metricsId,saleProductCode,
				saleProductId,buyCount,isRand,stockPrice,productId,needInType,isRegister,giftPrice)	

	select 	@orderId,@colorId,@metricsId,saleCode,
		id,@count,0,0,productId,0,0,0 from tb_SaleProduct where id=@saleId and saleTypeId=1 
				

	SET @mysaleId=SCOPE_IDENTITY() --得到刚刚插入的定单id 
	insert into dbo.tb_orderSaleProductPay(orderSaleProductId,payType,payValue)
				select a.id,payStyleId,payValue
				from tb_orderSaleProduct a
				inner join dbo.tb_saleProductPay b on b.saleProductId=a.saleProductId
				where a.id=@mysaleId
