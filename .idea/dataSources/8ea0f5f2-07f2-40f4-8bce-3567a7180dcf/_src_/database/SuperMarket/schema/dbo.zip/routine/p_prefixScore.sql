CREATE     procedure p_prefixScore
as 
	declare @memberId int --会员号
	declare @orderCode varchar(200)--订单号
	declare @orderId int --订单ID
	declare @getScore  int --积分
	declare @cardClass  int --积分

	DECLARE authors_cursor CURSOR FOR
	
	select id,orderCode,memberId,getScore from tb_order where orderstatus=2 and isDelete!=1
	and DATEDIFF(hour,createTime,getdate())>=72 and isSetScore=0 --大于72小时
	
	OPEN authors_cursor
	FETCH NEXT FROM authors_cursor 
	INTO @orderId,@orderCode,@memberId,@getScore
	WHILE @@FETCH_STATUS = 0
	BEGIN
		begin tran 
			if(@getScore is null ) set @getScore=0
			exec  p_rollBackOrderScore @orderCode --删除上次积分
			exec  p_addScoreOpLog @memberID,@getScore,1,@orderCode --添加积分
			update tb_order set isSetScore=1 where id=@orderId
		commit tran 

		FETCH NEXT FROM authors_cursor 
		INTO @orderId,@orderCode,@memberId,@getScore
	END
	
	CLOSE authors_cursor
	DEALLOCATE authors_cursor