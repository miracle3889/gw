
CREATE procedure p_addFudaiOrderProduct @colorId int ,@metricsId int ,@orderId int
as
	declare @skuId varchar(50)
	declare @productId int 
	declare @totalValue int 
	select @skuId=productshelfCode,@productId=productId from erp..tb_productStock where colorId=@colorId and metricsId=@metricsId
	begin tran 
	delete from SuperMarket..tb_fudaiOrderProduct where orderId=@orderId and skuId=@skuId
	insert into  SuperMarket..tb_fudaiOrderProduct(orderId,skuId,colorId,metricsId,productCount,productId)
	values(@orderId,@skuId,@colorId,@metricsId,1,@productId)
	commit tran 
	
	
	select @totalValue=sum(c.payValue) from SuperMarket..tb_fudaiOrderProduct a
	inner join SuperMarket..tb_saleProduct b on a.productId=b.productId and b.saleTypeId=1 
	 inner join SuperMarket..tb_saleProductPay c on c.saleProductId=b.id  where a.orderId=@orderId 
	 
	 
	 select @totalValue
	