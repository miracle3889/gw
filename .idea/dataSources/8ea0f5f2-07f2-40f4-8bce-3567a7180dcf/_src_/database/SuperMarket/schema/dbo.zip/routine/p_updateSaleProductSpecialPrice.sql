/*******商品修改，增加特价******/
CREATE   PROCEDURE p_updateSaleProductSpecialPrice @saleProductId INT,@oldPrice INT,
					   @saleCount INT,@remark VARCHAR(5000),@isSpecial int,@specialPrice int, @stockPriceReal int
AS
	DECLARE @returnValue INT
	SET @returnValue=0

	DECLARE @saleId INT --存储商品原价格
	SET @saleId=0
	BEGIN TRAN 
		UPDATE  dbo.tb_saleProduct SET oldPrice=@oldPrice,remark=@remark,isSpecial=@isSpecial,
		saleCount=@saleCount WHERE id=@saleProductId
		
		--修改成本价 2012-03-16
		update erp..tb_product set stockPriceReal=@stockPriceReal where id in (
			select productId from tb_saleProduct where id=@saleProductId
			)

		--如果@isSpecial=1 将商品设为特价商品
		IF (@isSpecial=1)
		BEGIN			
			SELECT @saleId=saleId FROM tb_saleSpecialPrice WHERE saleId=@saleProductId--取特价商品表是否有此商品
			IF (@saleId=0)
			BEGIN
				INSERT INTO tb_saleSpecialPrice (productPrice,saleId) VALUES (@specialPrice,@saleProductId)--此表存商品原价
			END
			ELSE
			BEGIN
				UPDATE tb_saleSpecialPrice SET productPrice=@specialPrice WHERE saleId=@saleId
			END
		END
		ELSE
		BEGIN
			DELETE tb_saleSpecialPrice WHERE saleId=@saleProductId
		END
		SET @returnValue=1
	COMMIT TRAN
	SELECT @returnValue