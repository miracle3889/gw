/*-----------------添加货到通知商品到购物车------------------------------------------*/
CREATE   PROCEDURE p_addShoppingBagRegist @saleCode VARCHAR(20),@buyCount INT,
				  @saleProductId INT,@colorId INT,
                                  @metricsId INT,@memberId INT
AS
     DECLARE @returnValue INT
     DECLARE @colorCode VARCHAR(2)
     DECLARE @metricsCode VARCHAR(2)
     SET @returnValue=0   
	     DECLARE @productId INT
             DECLARE @realCount INT 
             DECLARE @DDlCount INT 
	     DECLARE @isRand INT
	     SET @isRand=0
	     SELECT @productId=productId FROM tb_saleProduct WHERE id=@saleProductId
	     IF(@colorId=0)
	     BEGIN
	             IF EXISTS (SELECT *
	             FROM dbo.sysobjects
	             WHERE id = object_id(N'.[dbo].[tb_randColor]') AND 
	                  OBJECTPROPERTY(id, N'IsUserTable') = 1) 
		DROP TABLE dbo.tb_randColor 
	
		  SELECT TOP 1 SUM(productCount) AS myCount, colorId
		  INTO dbo.tb_randColor
		  FROM ERP.dbo.tb_productStock
		  WHERE (productId = @productId)
		  GROUP BY colorId
		  ORDER BY myCount DESC
		  SELECT TOP 1 @colorId=colorId FROM tb_randColor 
  		  SET @isRand=1
	     END
          
	  SELECT @realCount=productCount,@saleCode=productShelfCode FROM ERP.dbo.tb_productStock   
		WHERE productId=@productId AND colorId=@colorId AND metricsId=@metricsId   
	  SELECT @DDlCount=SUM(a.buyCount) FROM v_allBuyProductNew a  --  INNER JOIN tb_saleProduct b ON a.saleProductId=b.id 
		   WHERE a.saleProductId=@productId AND a.colorId=@colorId AND a.metricsId=  @metricsId   
	   IF(@realCount IS NULL) SET @realCount=0 
	    IF(@DDlCount IS NULL) SET @DDlCount=0


	    IF(@realCount-@DDlCount>=@buyCount)
                 BEGIN    
		     INSERT INTO tb_shoppingBag(productCode,buyCount,saleProductId,colorId,metricsId,memberId,isRand,isStock,isRegister) 
			VALUES(@saleCode,@buyCount,@saleProductId,@colorId,@metricsId,@memberId,@isRand,1,1)                           
	   	     SET @returnValue=1
               END
    SELECT @returnValue
