CREATE procedure p_addShelfStockByNotStock @shelfCode varchar(50),@productCode varchar(50),@count int,@dealManId int,@type INT,@remark VARCHAR(100)
AS 
	if EXISTS(select 1 from tb_goodsShelf  where code=@shelfCode )
		BEGIN
			if EXISTS(select 1 from tb_productStock  where productShelfCode=@productCode )
			BEGIN
				begin tran
					if EXISTS(select 1 from tb_shelfProductCount where shelfCode=@shelfCode and productCode=@productCode)
					begin
						update tb_shelfProductCount set productCount=productCount+@count where shelfCode=@shelfCode and productCode=@productCode
					end
					else
					begin
						insert into tb_shelfProductCount(shelfCode,productCode,productCount) values(@shelfCode,@productCode,@count)
					end
					
					if(@@error<>0)
						rollback tran 
					insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,dealManId,optype,remark) values(@shelfCode,@productCode,@count,@dealManId,@type,@remark)
					if(@@error<>0)
						rollback tran 
					SELECT 1
				commit tran
			END
			ELSE
			BEGIN	
				SELECT -2
			END
		END
		ELSE
		BEGIN
			SELECT -1
		END
