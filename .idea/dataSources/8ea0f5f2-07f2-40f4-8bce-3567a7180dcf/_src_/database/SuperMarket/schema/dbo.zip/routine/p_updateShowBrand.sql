/**********修改品牌信息***********/
CREATE  procedure p_updateShowBrand @brandId int,@brandLogo varchar(50),@brandLogoPath varchar(50),
			@chinaName varchar(50),@enName varchar(50),@boss varchar(50),
			@addr varchar(50),@dateAddr varchar(50),@story varchar(2000),
			@description varchar(300),@keywords varchar(300),@title varchar(300)
as
	declare @showBrandId int
	declare @returnValue int
	
	SET @showBrandId=0

	SELECT @showBrandId=id FROM tb_showBrand WHERE brandId=@brandId
	IF (@showBrandId != 0)
	BEGIN
		IF (@brandLogo is not null and @brandLogo!='')
		BEGIN
			UPDATE tb_showBrand SET brandLogo=@brandLogo,brandLogoPath=@brandLogoPath,chinaName=@chinaName,enName=@enName,boss=@boss,
				addr=@addr,dateAddr=@dateAddr,story=@story,description=@description,keywords=@keywords,title=@title WHERE brandId=@brandId
			set @returnValue=1
		END
		ELSE
		BEGIN
			UPDATE tb_showBrand SET brandLogoPath=@brandLogoPath,chinaName=@chinaName,enName=@enName,boss=@boss,
				addr=@addr,dateAddr=@dateAddr,story=@story,description=@description,keywords=@keywords,title=@title WHERE brandId=@brandId
			set @returnValue=1
		END
	END
	ELSE
	BEGIN
		IF (@brandLogo is not null and @brandLogo!='')
		BEGIN
			INSERT INTO tb_showBrand (brandId,brandLogo,brandLogoPath,chinaName,enName,boss,addr,dateAddr,story,description,keywords,title) 
				VALUES (@brandId,@brandLogo,@brandLogoPath,@chinaName,@enName,@boss,@addr,@dateAddr,@story,@description,@keywords,@title)
			set @returnValue=1
		END
		ELSE
		BEGIN
			INSERT INTO tb_showBrand (brandId,brandLogoPath,chinaName,enName,boss,addr,dateAddr,story,description,keywords,title) 
				VALUES (@brandId,@brandLogoPath,@chinaName,@enName,@boss,@addr,@dateAddr,@story,@description,@keywords,@title)
			set @returnValue=1
		END

	END
	
	select @returnValue