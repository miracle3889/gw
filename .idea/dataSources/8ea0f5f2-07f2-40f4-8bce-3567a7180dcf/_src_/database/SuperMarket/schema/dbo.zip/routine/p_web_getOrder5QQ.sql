CREATE PROCEDURE p_web_getOrder5QQ @orderId int
AS
	declare @returnCode varchar(4)
	declare @productInt int

	set @returnCode=''
	set @productInt=0
	select top 1 @productInt=saleProductId from tb_orderSaleProduct where saleProductId in (21853,19701,19955) and orderId=@orderId

	if (@productInt<>0)
	begin
		if (@productInt=21853)
		begin
			set @returnCode='1402'
		end
		if (@productInt=19701)
		begin
			set @returnCode='1401'
		end
		if (@productInt=19955)
		begin
			set @returnCode='1403'
		end
	end
	
	select @returnCode