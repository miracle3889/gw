

CREATE   procedure p_sendEmailbyClass @EmailUrl varchar(200),@DestEmailAddr varchar(200),@title varchar(200),@sendClass int
as 
	insert into dbo.tb_EmailMission(EmailHtml,title,EmailAddr,sendClass) 
	values(@EmailUrl,@title,@DestEmailAddr,@sendClass)