CREATE VIEW dbo.v_orderMember
AS
SELECT DISTINCT *
FROM dbo.tb_member
WHERE (id IN
          (SELECT memberId
         FROM tb_order
         WHERE isDelete <> 1))
