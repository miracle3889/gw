CREATE VIEW dbo.v_web_productOnIndex
AS
SELECT DISTINCT 
      TOP 25 saleProductName, htmlPath, receviceMan, createTime, addr, ptype
FROM dbo.tb_tempProductIndex
WHERE (receviceMan <> '') AND (receviceMan IS NOT NULL) AND (addr <> '') AND 
      (addr IS NOT NULL) AND (addr <> '无') AND (addr NOT LIKE '%<%')
ORDER BY createTime DESC
