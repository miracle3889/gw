


/*-------------------------------------修改财付通商品价格--------------------------------*/
CREATE      procedure p_web_updateCFTProductPrice @saleId int, @price int 
AS

	update tb_saleProduct set realPrice=@price where id=@saleId and id!=16709 and id!=16699

	update tb_saleProductPay set payValue=@price where saleProductId=@saleId and saleProductId!=16709 and saleProductId!=16699