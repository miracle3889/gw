

/*----------------添加商品到组合中-----------------*/
CREATE   procedure p_web_addSaleProductToGroup  @groupId int,@productString varchar(500),@memberId int,@buyCount int 
as

	declare @returnCount int
	declare @isBuy int
	if(@groupId=1069)
		set @buyCount=0
	
	if(@groupId=1069)
	begin
		select @returnCount=count(*) from tb_groupPh where groupId=1069  AND memberId=@memberId and isBuy=0
    		if(@returnCount>0)
		begin
			set @returnCount=0
			select @returnCount
			return
		end
     
		select @returnCount=count(*) from tb_shoppingBag a inner join tb_saleProduct b on a.saleProductId=b.id where (b.saleTypeId=17 or   b.saleTypeId=18) and a.memberId=@memberId
		if(@returnCount>0)
		begin
			set @returnCount=1
			select @returnCount
			return
		end
	end

	declare @identityCode int 
	insert into tb_groupCheckIdentityCode(addDate) values (getDate())
	set @identityCode= scope_identity()
	
	declare @charId int
	while(len(@productString)>4)
	begin
	set  @charId= charindex('Q',@productString)
	declare @tmp1 varchar(50) --截出以逗号分割的部分
	declare @a varchar(50)--saleId
	declare @b varchar(50)--colorId
	declare @c varchar(50)--MetricsId
        declare @d varchar(50)--buyCount
	if(@charId=0)
	begin
		set @tmp1= @productString
		set @productString=''
	end
	else
	begin	
		set @tmp1= subString(@productString,1, @charId-1)
		set @productString=subString(@productString, @charId+1, len(@productString)-@charId+1)
	end
	
		declare @i int 
		declare @mydesvalue varchar(50) 
		set @i=1

		while(len(@tmp1)>0)
		begin
			declare  @index int
			set @index= charindex('S',@tmp1)
			if(@index=0)
			begin
				set @mydesvalue=@tmp1
				set @tmp1=''
			end
			else
			begin
				set @mydesvalue=subString(@tmp1,1, @index-1)
				set @tmp1=subString(@tmp1, @index+1, len(@tmp1)-@index+1)
			end
			 if(@i=1)
			begin
				set @a=@mydesvalue
			end
			 if(@i=2)
			begin
				set @b=@mydesvalue
			end
			 if(@i=3)
			begin
				set @c=@mydesvalue
			end
			 if(@i=4)
			begin
				set @d=@mydesvalue
				
			end
		            set @i=@i+1
		end 
		insert into tb_tmpGroupProductCheck(saleId,colorId,MetricsId,buyCount,code) values(@a,@b,@c,@d,@identityCode)
	end



declare @returnValue int
declare @requireCount int
declare @userselectCount int
declare @saleType int 
declare @isCount int
set @isCount=0
select @requireCount=requireCount,@saleType=saleType from tb_saleGroup where id=@groupId

select  @userselectCount=sum(buyCount) from tb_tmpGroupProductCheck where code=@identityCode
if (@saleType=1)
begin
	select @isCount=count(*) from tb_saleProduct where groupId=@groupId and id not 
	in (select saleId from tb_tmpGroupProductCheck where code=@identityCode ) and isDeleted=0
end

if (@isCount=0)
begin
	if(@requireCount!=@userselectCount)
		begin
			set @returnValue=-1--所选数量不一
		end
	else
		begin
		insert into tb_groupPh(groupId,buyCount,memberId) values(@groupId,@buyCount,@memberId)
		declare @groupph int
		set @groupph=scope_identity()
				 
		INSERT INTO tb_shoppingBag(productCode,buyCount,saleProductId,colorId,metricsId,memberId,isRand,groupph,resource) 
		select b.saleCode,a.buyCount,a.saleId,a.colorId,a.metricsId,@memberId,0,@groupph,1 from 
		tb_tmpGroupProductCheck a inner join tb_saleProduct b on a.saleId=b.id and a.code=@identityCode
				
				
			set @returnValue=1 
	end
end
else
begin
	set @returnValue=-1
end
	delete from tb_tmpGroupProductCheck where code=@identityCode
	select @returnValue