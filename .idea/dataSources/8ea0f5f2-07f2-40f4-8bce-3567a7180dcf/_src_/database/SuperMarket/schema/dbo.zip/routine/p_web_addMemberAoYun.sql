/*-------------------添加奥运送项链注册会员-------------------------*/
CREATE PROCEDURE p_web_addMemberAoYun @EMail VARCHAR(200),@psw VARCHAR(50),@recommendId INT,@name VARCHAR(50),@phoneNum VARCHAR(50),@mobileNum VARCHAR(50),@complanyAddr VARCHAR(200),@homeAddr VARCHAR(200),@post VARCHAR(50),@ip VARCHAR(50),@QQ VARCHAR(16),@MSN VARCHAR(50),@nickname VARCHAR(32),@source VARCHAR(16),@remark VARCHAR(50)  
AS
	DECLARE @COUNT INT
	DECLARE @returnValue INT
	SET @returnValue=0
	SELECT @COUNT=COUNT(*) FROM dbo.tb_member WHERE EMail=@EMail
	IF(@COUNT>0)
	BEGIN
		SET @returnValue=-1
	END
	ELSE
	BEGIN
		SELECT @COUNT=COUNT(*) FROM dbo.tb_member WHERE source=@source and remark=@remark and mobileNum=@mobileNum 
		IF(@COUNT>0)
		BEGIN
			SET @returnValue=-2
		END
		ELSE
		BEGIN
			SELECT @COUNT=COUNT(*) FROM dbo.tb_member WHERE nickname=@nickname 
			IF(@COUNT>0)
			BEGIN
				SET @nickname=@nickname+'1'
			END
			
			INSERT INTO dbo.tb_member(EMail,psw,type,checkCode,recommendId,name,phoneNum,mobileNum,complanyAddr,homeAddr,post,regIp,QQ,MSN,nickname,source,remark)
			VALUES (@EMail,dbo.md5(@psw),1,dbo.md5(CAST(rand()*10000 AS INT)),@recommendId,@name,@phoneNum,@mobileNum,@complanyAddr,@homeAddr,@post,@ip,@QQ,@MSN,@nickname,@source,@remark)
			SET @returnValue=scope_identity()
			IF(@@ERROR<>0)
			BEGIN	
				SET @returnValue=0
			END
		END
	END
	SELECT @returnValue