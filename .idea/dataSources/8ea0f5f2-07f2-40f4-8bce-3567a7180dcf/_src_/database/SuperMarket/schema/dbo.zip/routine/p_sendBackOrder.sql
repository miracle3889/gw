
CREATE PROCEDURE p_sendBackOrder @deliverManId INT
AS
	UPDATE supermarket..tb_backOder set backStatusId=2  WHERE  backStatusId=1 and  isUpdate!=1 and isDeleted!=1   and deliverManId=@deliverManId
	SELECT 1
