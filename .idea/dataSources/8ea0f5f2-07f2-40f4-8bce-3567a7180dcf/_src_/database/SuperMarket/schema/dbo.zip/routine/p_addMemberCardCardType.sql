CREATE procedure p_addMemberCardCardType @memberId int --会员编号
				,@cardCode varchar(50),--卡号
				 @cardClass int,--卡级别,
				@addManId int,
				@cardType int
as
	IF(@cardType=7)
	BEGIN
		DELETE FROM tb_memberCard WHERE memberId=@memberId
		RETURN 
	END
	declare @cardCount int
	declare @cardCode2 Varchar(2)
	select  @cardCode2=subString(@cardCode,1,2)
	if(@cardCode2='SH')
		SET @cardClass=1
	IF(@cardType>1)
	BEGIN		
		exec p_geCardTypeCode @cardType,@cardCode output
	END	
	--print @cardCode
	--有实物卡
	if(@cardType=1)
	begin
		if exists (select 1 from tb_cardCodeSource where cardCode=@cardCode and isUse=0)
		BEGIN
			select @cardCount=count(*) from tb_memberCard where cardCode=@cardCode
			if(@cardCount>0)
			RETURN
		END
		ELSE
		BEGIN
			RETURN 
		END
		
	end

	select @cardCount=count(*) from tb_memberCard where memberId=@memberId

	if(@cardCount is null)
		set @cardCount=0
	if(@cardCount=0)
	begin
		insert into tb_memberCard(memberId,cardCode,memberClass,addManId) values(@memberId,@cardCode,@cardClass,@addManId)
	end
	else
	begin
		update tb_memberCard set memberClass=@cardClass,addManId=@addManId, cardCode=@cardCode where memberId=@memberId
	end

	--有实物卡
	if(@cardType=1)
	BEGIN
		UPDATE tb_cardCodeSource SET isUse=1 WHERE cardCode=@cardCode 
	END