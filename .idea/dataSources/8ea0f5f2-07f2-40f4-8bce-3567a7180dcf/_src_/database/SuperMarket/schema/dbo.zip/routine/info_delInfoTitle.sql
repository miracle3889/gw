
/*---------------修改资讯标题------------------------------------------------*/
CREATE  PROCEDURE info_delInfoTitle @id int
AS
	declare @returnValue int
	set @returnValue=0
	BEGIN TRAN 
		if (@id != 0)
		begin
			update info_title set isDel=1 where id=@id 
			if (@@error<>0)
			begin
				rollback tran
			end
			update info_content set isDel=1 where titleId=@id 
			if (@@error<>0)
			begin
				rollback tran
			end
		end
	commit tran
	if (@@error=0)
	begin
		set @returnValue=1
	end
	
	select @returnValue