CREATE      PROCEDURE p_SendReport 
AS
	DECLARE @orderCount INT
	DECLARE @orderPiceT INT
	DECLARE @channelName VARCHAR(50)
	DECLARE @orderCountC INT
	DECLARE @orderPice INT
	DECLARE @msg NVARCHAR(800)
	SET @msg=''
	SET @orderCount=0
	SET @orderPiceT=0
	DECLARE cs  CURSOR   FOR 
	SELECT  magazineCodeS,count(*),sum(productPrice-backPrice)/100 FROM tb_order
	WHERE createTime>CONVERT(VARCHAR(10),getDate(),120) AND 
	orderStatus in(1,2,3,13,17,20)  AND isDelete!=1 and (backCode is null or backCode ='')
	GROUP BY magazineCodeS
	OPEN cs
	FETCH NEXT FROM cs INTO  @channelName,@orderCountC,@orderPice
	WHILE @@fetch_status=0
	BEGIN
             if @orderCountC >=10
	SET @msg=@msg+@channelName+CAST(@orderCountC AS VARCHAR(10))+'单'+
	CAST(@orderPice AS VARCHAR(10))+';'
	SET @orderCount=@orderCount+@orderCountC
	SET @orderPiceT=@orderPiceT+@orderPice
	FETCH NEXT FROM cs INTO  @channelName,@orderCountC,@orderPice
	END
	close cs
	deallocate cs

	set @msg = substring(@msg,1,len(@msg)-1)

	declare @stockP int
	select  @stockP=sum(buyCount*stockPrice)/100 from tb_orderSaleProduct where orderId in
	(select id from  tb_order where isDelete!=1 and orderStatus in(1,2,3,13,17,20) and (backCode is null or backCode ='')
	and createTime>CONVERT(VARCHAR(10),getDate(),120))

	declare @shCount int
	declare @getScore int
	SELECT  @getScore=sum(getScore),@shCount=count(*) FROM tb_order
	WHERE createTime>CONVERT(VARCHAR(10),getDate(),120) AND orderStatus=5 AND isDelete!=1 and (backCode is null or backCode ='')

	declare @dsCount int
	declare @dsgetScore int
	SELECT  @dsgetScore=sum(getScore),@dsCount=count(*) FROM tb_order
	WHERE createTime>CONVERT(VARCHAR(10),getDate(),120) AND orderStatus=6 AND isDelete!=1 and (backCode is null or backCode ='')
	
	SET @msg=substring(CONVERT(VARCHAR(10),getDate(),120),6,2)+substring(CONVERT(VARCHAR(10),getDate(),120),9,2)+'共'+CAST(@orderCount AS VARCHAR(10))
	+'单'+CAST(@orderPiceT AS VARCHAR(10))+'毛'+CAST((@orderPiceT-@stockP) AS VARCHAR(10))+';'+'审'+CAST(@shCount AS VARCHAR(10))+'单'+CAST(@getScore AS VARCHAR(10))+';'
	+'收'+CAST(@dsCount AS VARCHAR(10))+'单'+CAST(@dsgetScore AS VARCHAR(10))+';'+@msg

	 EXEC p_sendMsg '13868009945',@msg
	 EXEC p_sendMsg '13335710806',@msg
	 EXEC p_sendMsg '13588886660',@msg
	 EXEC p_sendMsg '13666688852',@msg
	 EXEC p_sendMsg '13666688851',@msg
	 EXEC p_sendMsg '13957183909',@msg
	 EXEC p_sendMsg '13382082999',@msg
              EXEC p_sendMsg '13666635319',@msg

	declare @stockValue int
	declare @inValue int
	declare @outValue int
	declare @onwayValue int
	declare @todayNeed int
	declare @totalNeed int
	declare @todayHave int
	declare @todayArrived int
	declare @todayRefused int
	declare @todayGet int
	
	
	select @stockValue = isNull(sum(a.stockPrice*b.pStock)/100,0) from erp..tb_product as a left join 
	(select productId,sum(productCount) as pStock from erp..tb_productStock group by productId ) as b on a.id = b.productId
	where a.id in (select productId from tb_saleProduct where isDeleted = 0)
	
	
	select @inValue = isNull(sum(buyPrice*buyCount)/100,0) from erp..tb_buyProductList where isDeleted = 0 and buyStatus = 4 and inTime > CONVERT(VARCHAR(10),getDate(),120)
	
	
	select @outValue = isNull(sum(b.buyCount*b.stockPrice)/100,0) from tb_order as a left join tb_orderSaleProduct as b on a.id = b.orderid
	where a.isDelete != 1 and a.orderStatus = 2 and a.setTime > CONVERT(VARCHAR(10),getDate(),120)
	
	select @onwayValue = isNull(sum(buyPrice*buyCount)/100,0) from erp..tb_buyProductList where buyStatus = 1 and isDeleted = 0
	
	select @totalNeed = isNull(sum(productPrice+transport+proxy-useAccount-useGift)/100,0) from tb_order where isDelete != 1 and orderStatus = 2 and payType = 1
	
	select @todayNeed = isNull(sum(productPrice+transport+proxy-useAccount-useGift)/100,0) from tb_order where isDelete != 1 and orderStatus = 2 and payType = 1 and setTime > CONVERT(VARCHAR(10),getDate(),120)
	
	select @todayHave = isNull(sum(ProductPrice+transport+proxy-useAccount-useGift)/100,0) from tb_order where isDelete != 1 and orderStatus = 2 and payType != 1 and setTime > CONVERT(VARCHAR(10),getDate(),120)
	
	select @todayArrived = isNull(sum(productPrice+transport+proxy-useAccount-useGift)/100,0) from tb_order where isDelete != 1 and orderStatus in (3,17) and payType = 1 and visaTime > CONVERT(VARCHAR(10),getDate(),120)
	
	select @todayRefused = isNull(sum(backPrice)/100,0) from tb_order where isDelete != 1 and orderStatus = 17 and  payType = 1 and visaTime > CONVERT(VARCHAR(10),getDate(),120)
	
	set @todayGet = isNull(@todayArrived - @todayRefused,0)
	
	SET @msg=substring(CONVERT(VARCHAR(10),getDate(),120),6,2)+substring(CONVERT(VARCHAR(10),getDate(),120),9,2)+'入'+CAST(@inValue AS VARCHAR(10))+'出'
	         +CAST(@outValue AS VARCHAR(10))+'在'+CAST(@stockValue AS VARCHAR(10))+'途'+CAST(@onwayValue AS VARCHAR(10))+'已收'+CAST(@todayHave AS VARCHAR(10))+'应收'
	         +CAST(@todayNeed AS VARCHAR(10))+'累计'+CAST(@totalNeed AS VARCHAR(10))+'录回'+CAST(@todayGet AS VARCHAR(10))
		
	EXEC p_sendMsg '13335710806',@msg
	EXEC p_sendMsg '13666688851',@msg
             EXEC p_sendMsg '13957183909',@msg
             EXEC p_sendMsg '13666635319',@msg
	EXEC p_sendMsg '13868009945',@msg