


CREATE    FUNCTION [dbo].[isHasNumRealAddr] (@addr varchar(500))  
RETURNS int  AS  
BEGIN 
	
	declare @char varchar(10)
 	while(len(@addr)>0)
		begin
			set @char=subString(@addr,1,1)
			if(ISNUMERIC(@char)=1)
			   begin
			   	return 1	
				break
			   end	
			set @addr=subString(@addr,2,len(@addr))	
		end 
	return 0
END


