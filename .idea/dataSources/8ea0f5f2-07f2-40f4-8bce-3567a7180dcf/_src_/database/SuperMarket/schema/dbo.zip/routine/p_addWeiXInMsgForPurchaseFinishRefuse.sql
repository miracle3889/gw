CREATE procedure [dbo].[p_addWeiXInMsgForPurchaseFinishRefuse] 
	@msgcontent varchar(2000),
	@purchaseId varchar(100) ,
	@approvalUserId int 
as	
	declare @ret int
	declare @userId int
	declare @approvalType	INT  --审批类型
	declare @purchaseCode varchar(30)	--采购单编号
 BEGIN 
 begin tran
	set @ret = 0
	select top 1 @approvalType=a.approvalType,@purchaseCode=b.purchaseCode from
	 SuperMarket..pro_purchase_finish a join supermarket..pro_purchase b on a.purchaseId = b.id
	 where a.purchaseId = @purchaseId and a.approvalStatus=2 order by a.applyTime desc
	--申请人
	insert into SuperMarket..tb_weiXinMsg(userId,msgType,msgcontent)
			select id,'news',REPLACE(@msgcontent,'ruhnn_openId',openId) from ERP..tb_user 
			where id = (select top 1 applyUserId from SuperMarket..pro_purchase_finish where purchaseId = @purchaseId and approvalStatus=2 order by applyTime desc)
	
    --定义游标.获取前面几个审批人
   DECLARE c_userId CURSOR FAST_FORWARD FOR
     SELECT approvalUserId from SuperMarket..pro_approval where documentId=@purchaseCode and
      documentType=@approvalType and approvalUserId <> @approvalUserId
   -- 打开游标.
   OPEN c_userId
   --填充数据.
   FETCH NEXT FROM c_userId INTO @userId;
   --假如检索到了数据，才处理.
   WHILE @@fetch_status = 0
	   BEGIN
		  insert into SuperMarket..tb_weiXinMsg(userId,msgType,msgcontent)
			select id,'news',REPLACE(@msgcontent,'ruhnn_openId',openId) from ERP..tb_user where id = @userId
		 --填充下一条数据.
		 FETCH NEXT FROM c_userId INTO @userId
	   END
	   -- 关闭游标
	   CLOSE c_userId
	   --释放游标.
	   DEALLOCATE c_userId
	if @@error <> 0  
      begin 
		set @ret=-1
		rollback tran 
	  end
	else
		begin 
			set @ret=1
		end
	commit tran
	select @ret as 'ret'
 END