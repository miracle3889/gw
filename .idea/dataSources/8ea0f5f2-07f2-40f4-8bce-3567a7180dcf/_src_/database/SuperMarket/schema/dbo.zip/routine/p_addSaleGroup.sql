/*添加商品组合的属性，同步更新tb_groupProduct的组号*/ 
CREATE   PROCEDURE   p_addSaleGroup
@groupName varchar(50),@groupRemark varchar(50),@picPath varchar(50),@totalCount int,@requireCount int,@saleCount int,@saleTypeId int,@salePlanId int
  AS   
  begin   
DECLARE @id int,@groupCode varchar(20),@pCode varchar(20)

SELECT @pCode=code FROM dbo.tb_saleType WHERE id=@saleTypeId
      Insert  into  SuperMarket.dbo.tb_saleProductGroup(groupName, groupCode, groupRemark, picPath, totalCount, requireCount, saleCount, saleTypeId, salePlanId )   
                    Values(@groupName,'0',@groupRemark,@picPath,@totalCount,@requireCount,@saleCount,@saleTypeId,@salePlanId)   
     set @id=@@Identity
     set @pCode=LTRIM(RTRIM('Z'+@pCode))+cast(@id as varchar) 
     update SuperMarket.dbo.tb_saleProductGroup set groupCode=@pCode  where groupCode='0'
select @id
  end