/*------------------------添加网站图片------------------------------*/
CREATE  PROCEDURE p_addWebPic @minPic VARCHAR(50),@middlePic VARCHAR(50),@maxPic VARCHAR(50),@productId INT,@listPic VARCHAR(50),@maxPicReal VARCHAR(50)
AS
	BEGIN TRAN addweb

		DECLARE @count INT
		select @count=count(*) from dbo.tb_webPic where type=1 and productId=@productId

		set @count=@count+1

		INSERT INTO dbo.tb_webPic(productId,picPath,type,orderbyClassPic)
		VALUES(@productId,@maxPic,1,@count)--插入大图

		DECLARE @myId INT
		
		SET @myId=SCOPE_IDENTITY()--得到大图的id

		UPDATE dbo.tb_webPic SET code=@myId WHERE id=@myId--更新批号

		INSERT INTO dbo.tb_webPic(productId,picPath,type,code,orderbyClassPic)
		VALUES(@productId,@minPic,2,@myId,@count)--插入小图

		INSERT INTO dbo.tb_webPic(productId,picPath,type,code,orderbyClassPic)
		VALUES(@productId,@middlePic,3,@myId,@count)--插入中图

		INSERT INTO dbo.tb_webPic(productId,picPath,type,code,orderbyClassPic)
		VALUES(@productId,@listPic,4,@myId,@count)--插入列表图

		INSERT INTO dbo.tb_webPic(productId,picPath,type,code,orderbyClassPic)
		VALUES(@productId,@maxPicReal,5,@myId,@count)--插入列表图


	IF(@@ERROR<>0)
	BEGIN
		ROLLBACK TRAN addweb
	END
	COMMIT TRAN addweb