CREATE procedure p_addEveryDayCallMission
as 
	--每日电话情况
	if EXISTS(select 1 from dbo.tb_noAnswerCall where  callcallerCode='00000000'
	 and convert(varchar(10),callInTime,120)=convert(varchar(10),getDate(),120))
		begin
		
			delete from tb_everyDayCallmission where convert(varchar(10),callDate,120)=convert(varchar(10),getDate(),120)
			
			insert into tb_everyDayCallmission(needCallCount,callCount,isCall)
			select 30,count(*),1 from dbo.tb_noAnswerCall where  callcallerCode='28888770'
			 and convert(varchar(10),callInTime,120)=convert(varchar(10),getDate(),120)
		end
	else
		begin
			delete from tb_everyDayCallmission where convert(varchar(10),callDate,120)=convert(varchar(10),getDate(),120)
			
			insert into tb_everyDayCallmission(needCallCount,callCount,isCall)
			select 30,count(*),0 from dbo.tb_noAnswerCall where  callcallerCode='28888770'
			 and convert(varchar(10),callInTime,120)=convert(varchar(10),getDate(),120)
		end