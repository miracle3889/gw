CREATE PROCEDURE p_getbackProduct  @startdate varchar(10), @enddate varchar(10)
AS 

SELECT  商品名称,sum( 退回数量) as 退回数量, sum(退回金额 / 100 ) AS 退回金额 
FROM dbo.tb_temp_backProductEvery a 
 where 日期>=@startdate and 日期<@enddate   
group by 商品名称  order by sum( 退回数量) desc

