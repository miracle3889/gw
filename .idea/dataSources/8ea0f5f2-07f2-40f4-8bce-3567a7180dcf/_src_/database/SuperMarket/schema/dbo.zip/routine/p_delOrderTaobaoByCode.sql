/*------------------------------------------------------回滚定单------------------------------------------------------------------------------------*/
CREATE  PROCEDURE p_delOrderTaobaoByCode @orderCode varchar(50) 
AS	
	BEGIN TRAN 
		declare @orderId int 
		select @orderId=id from supermarket..tb_order where orderCode=@orderCode  and orderstatus in(1,2)
		if(isnull(@orderId,0)>0)
		begin
			update supermarket..tb_order set isdelete=1,deleteManId=0 where id=@orderId 
			delete from supermarket..tb_taobaoCode where orderCode  in(select orderCode from tb_order where id=@orderId)
			delete from tb_temp_waitPhProduct where orderId=@orderId
		end
			delete from supermarket..tb_temp_waitPhProduct where orderId =@orderId
	COMMIT TRAN