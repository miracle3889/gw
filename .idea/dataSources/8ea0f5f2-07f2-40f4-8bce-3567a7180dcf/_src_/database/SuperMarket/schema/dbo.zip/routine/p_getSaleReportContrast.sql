
CREATE procedure [dbo].[p_getSaleReportContrast] @userId int
as

if exists(
	--select 1 from erp..tb_userRole where roleId=9 and userId=@userId)
	
	select 1 from (select distinct(id),pageId from ERP..tb_pageTag where pageId in (
	select a.rightId from ERP..tb_roleRight a 
	left join ERP..tb_userRole b on a.roleId=b.roleId 
	where b.userId=@userId and a.isDesignated=0 
	union all 
	select rightId from ERP..tb_userBrandRight where userId=@userId
	)) t where id=33)
	
	select a.id,a.brandId,a.chName,isnull(thisMonth,0) as thisMonth,isnull(lastMonth,0) as lastMonth
	,isnull(lastMonthtoday,0) as lastMonthtoday from supermarket..tb_brandNick a
	left join (
	
	--本月销售额
	select sellerNick,sum(cast(payment as bigInt)) as thisMonth from  reportruhnn..tb_report_pay 
	where  CONVERT(varchar(7),rDate,120)= CONVERT(varchar(7),GETDATE(),120)
	 and  rDate>=CONVERT(varchar(7),GETDATE(),120)+'-01'
	
	group by sellerNick 
	) b on a.nickName=b.sellerNick
	left join (
	--上月销售额
	select sellerNick,sum(cast(payment as bigInt)) as lastMonth
	 from reportruhnn..tb_report_pay
	where  CONVERT(varchar(7),rDate,120)= CONVERT(varchar(7),dateadd(month,-1,GETDATE()),120)  
	and  rDate>=CONVERT(varchar(7),dateadd(month,-1,GETDATE()),120)+'-01'
	group by sellerNick
	
	) as c   on a.nickName=c.sellerNick
	left join (
	select sellerNick,sum(cast(payment as bigInt)) as lastMonthtoday from reportruhnn..tb_report_pay 
	where  CONVERT(varchar(7),rDate,120)= CONVERT(varchar(7),dateadd(month,-1,GETDATE()),120)
	and rDate<=dateadd(month,-1,GETDATE()) and  rDate>=CONVERT(varchar(7),dateadd(month,-1,GETDATE()),120)+'-01'
	group by sellerNick) as d  on a.nickName=d.sellerNick
	
 	where a.isdel=0
	order by isnull(thisMonth,0) desc
	
	 
	 
	 