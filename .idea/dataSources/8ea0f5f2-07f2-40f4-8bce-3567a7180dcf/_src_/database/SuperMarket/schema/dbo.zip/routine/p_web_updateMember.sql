/*---------------更新会员信息(完善个人资料时修改)-------------------------*/
CREATE PROCEDURE p_web_updateMember @name VARCHAR(50),@sex INT,
				  @birth VARCHAR(50),@HomeAddrRegional INT,
				  @HomeAddr VARCHAR(500),@ComplanyAddrRegional INT, @ComplanyAddr VARCHAR(500),
				  @mobileNum VARCHAR(50),@phoneNum VARCHAR(50),
				  @post VARCHAR(50),@memberId INT,@provinceId INT,@cityId INT,@isNeedMag INT,@QQ VARCHAR(16),@MSN VARCHAR(50),@nickname VARCHAR(32) 
AS
	BEGIN TRAN
	DECLARE @isUpdate INT
	DECLARE @addrId INT
	DECLARE @isnickname INT
	SET @isnickname=0
	SET @isUpdate=0
	SET @addrId=1
	IF(@ComplanyAddr='')
	BEGIN
		SET @addrId=2
	END
	select @isnickname=id from tb_member where nickname=@nickname and id!=@memberId and nickname is not null 
	IF(@isnickname=0)
	BEGIN
		UPDATE dbo.tb_member SET name=@name,sex=@sex,birth=@birth,
		homeAddrRegional=@HomeAddrRegional,complanyAddrRegional=@ComplanyAddrRegional,complanyAddr=@ComplanyAddr,homeAddr=@HomeAddr,
		mobileNum=@mobileNum,phoneNum=@phoneNum,post=@post ,provinceId=@provinceId,cityId=@cityId,addrId=@addrId,QQ=@QQ,MSN=@MSN,nickname=@nickname  WHERE id=@memberId
		
		
		IF(@isNeedMag=1)
		BEGIN
			 IF NOT EXISTS(SELECT * FROM  dbo.tb_memberMagazine WHERE memberId=@memberId)
			BEGIN
				INSERT INTO  dbo.tb_memberMagazine(magazineId,memberId,doMan) VALUES(1,@memberId,-1)
			END
		END
		set @isUpdate=1
		IF(@@ERROR<>0)
		BEGIN
			ROLLBACK TRAN 
		END
	END	
	
	COMMIT TRAN
	select @isUpdate