CREATE PROCEDURE p_addbackOrderEvery 
AS 
declare @date varchar(10)

set @date=dateAdd(day,-30,getDate())

delete from   tb_temp_backOrderEvery where 日期>=@date


insert into tb_temp_backOrderEvery
select *  from (
select convert(varchar(10),a.visaTime,120) as 日期,e.id as 城市Id,e.name as 城市, 

count( distinct case webCategoryId when 12 then b.saleProductId else 0 end) -1 as 化妆品种类 , 

sum(case webCategoryId when 12 then b.buyCount else 0 end) as 化妆品数量, 
sum(case webCategoryId when 12 then b.buyCount*d.payValue else 0 end) as 化妆品金额  , 


count( distinct case webCategoryId when 7 then b.saleProductId else 0 end) -1 as 服装种类 , 
sum(case webCategoryId when 7 then b.buyCount else 0 end) as 服装数量,
sum(case webCategoryId when 7 then b.buyCount*d.payValue else 0 end)  as 服装金额 ,


count( distinct case webCategoryId when 12 then 0  when 7 then 0 else b.saleProductId end)-1 as  日用品种类 ,

sum(case webCategoryId when 12 then 0  when 7 then 0 else b.buyCount end) as  日用品数量,
sum(case webCategoryId when 12 then 0  when 7 then 0 else b.buyCount*d.payValue end)  as 日用品金额,
'拒收' as 类型

 from tb_order a
inner join tb_orderSaleProduct b on a.id=b.orderId and a.isdelete<>1 and b.backCount>0
inner join tb_orderSaleProductPay d on d.orderSaleProductId=b.id and d.payType=1
inner join tb_saleProduct c on c.id=b.saleProductid  
inner join tb_city e on e.id=a.cityId where visaTime>=@date
group by convert(varchar(10),a.visaTime,120),e.id,e.name


union all

select convert(varchar(10),a.visaTime,120) as 日期,e.id as 城市Id,e.name as 城市, 

count( distinct case webCategoryId when 12 then b.saleProductId else 0 end) -1 as 化妆品种类 , 

sum(case webCategoryId when 12 then X.getCount else 0 end) as 化妆品数量, 
sum(case webCategoryId when 12 then X.getCount*d.payValue else 0 end) as 化妆品金额  , 


count( distinct case webCategoryId when 7 then b.saleProductId else 0 end) -1 as 服装种类 , 
sum(case webCategoryId when 7 then X.getCount else 0 end) as 服装数量,
sum(case webCategoryId when 7 then X.getCount*d.payValue else 0 end)  as 服装金额 ,


count( distinct case webCategoryId when 12 then 0  when 7 then 0 else b.saleProductId end)-1 as  日用品种类 ,

sum(case webCategoryId when 12 then 0  when 7 then 0 else X.getCount end) as  日用品数量,
sum(case webCategoryId when 12 then 0  when 7 then 0 else X.getCount*d.payValue end)  as 日用品金额,
'退货' as 类型
 from tb_backOder a
inner join tb_order Y on a.ordeId=Y.id  
inner join tb_backProduct X on a.id=X.backId and a.isDeleted<>1 and X.getCount>0
inner join tb_orderSaleProduct b on X.orderSaleId=b.id 
inner join tb_orderSaleProductPay d on d.orderSaleProductId=b.id and d.payType=1
inner join tb_saleProduct c on c.id=b.saleProductid 
inner join tb_city e on e.id=Y.cityId 
 where a.visaTime>=@date
group by convert(varchar(10),a.visaTime,120),e.id,e.name

) as b

