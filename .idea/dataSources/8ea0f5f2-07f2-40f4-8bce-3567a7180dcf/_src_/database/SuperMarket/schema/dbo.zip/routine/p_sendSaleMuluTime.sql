CREATE   PROCEDURE p_sendSaleMuluTime @saleId INT,@startDate VARCHAR(10) ,@endDate VARCHAR(10)
AS 
	DECLARE @isUpdate int
	set @isUpdate=0
	DECLARE @returnValue int
	set @returnValue=0
	
	select @isUpdate=saleId from tb_saleMuluTime where saleId=@saleId
	if (@isUpdate = 0)
	begin
		INSERT INTO tb_saleMuluTime (saleId, startDate, endDate) values (@saleId, @startDate, @endDate)
		set @returnValue = 1
	end
	else
	begin
		UPDATE tb_saleMuluTime SET startDate=@startDate , endDate=@endDate WHERE saleId=@saleId
		set @returnValue = 2
	end
	
	select @returnValue