CREATE PROCEDURE p_addCallHisEvery
AS 

delete from tb_temp_callEvery where convert(varchar(10),日期,120) =convert(varchar(10),getDate(),120)
 
insert into tb_temp_callEvery 


select  convert(varchar(10),callTime,120) as 日期,count(*) as 通话量,sum(dateDiff(second,callTime,isnull(callendTime,callTime)))/count(*)  as 通话时长   from tb_callHis
 where callcalledCode <>'8099'  and convert(varchar(10),callTime,120) =convert(varchar(10),getDate(),120)
 and wavFile<>'111.wav'

group by convert(varchar(10),callTime,120) order by convert(varchar(10),callTime,120) 


