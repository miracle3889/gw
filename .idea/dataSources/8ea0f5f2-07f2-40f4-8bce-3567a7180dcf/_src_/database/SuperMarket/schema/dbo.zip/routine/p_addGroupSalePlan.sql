/*-------------------------------添加商品销售计划--------------------------------------*/
CREATE PROCEDURE p_addGroupSalePlan  @doMan INT 
AS 
	DECLARE @returnValue INT
	SET @returnValue=0
	DECLARE @Code VARCHAR(50)
	BEGIN TRAN 
	EXEC p_getSalePlanCode 1,@Code OUTPUT
	INSERT INTO dbo.tb_salePlan(doMan,code,type) VALUES(@doMan,@Code,1)
	SET @returnValue=SCOPE_IDENTITY()
	COMMIT TRAN 
	SELECT @returnValue
