CREATE procedure p_checkFudaiOrder @orderId int,@dealManId int 
as
	if exists (select 1 from SuperMarket..tb_fudaiOrderOper where orderId=@orderId and status=0)
	begin
		update SuperMarket..tb_fudaiOrderOper set status=1,dealManId=@dealManId,dealTime=GETDATE() where orderId=@orderId
		select 1
	end
	else
	begin
		if exists (select 1 from SuperMarket..tb_fudaiOrderOper where orderId=@orderId and status=1 and dealManId=@dealManId)
		begin
		   update SuperMarket..tb_fudaiOrderOper set dealTime=GETDATE() where orderId=@orderId
			select 1
		end
		else
		begin
			select -1 
		end
	end