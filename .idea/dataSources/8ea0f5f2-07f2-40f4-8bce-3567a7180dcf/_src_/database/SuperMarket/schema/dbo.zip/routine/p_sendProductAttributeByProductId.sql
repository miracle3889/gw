/**********生成临时库存表指定的PRODUCTID***********/
CREATE  procedure p_sendProductAttributeByProductId @productId INT

AS



	delete from tb_productAttribute where productId=@productId --删除属性


--如果样式规格，卖完就下架，跟据库存，设定isUndercarriage
update erp..tb_productStock  set isUndercarriage=1 where id in (	
select b.id from erp..tb_productStock b where b.productId=@productId
and b.isShowUndercarriage=1 
and b.productCount-( 
select isnull(sum(c.buyCount),0)--+isnull(sum(c.allStockCount),0)+isnull(sum(c.tuiHuoCount),0) 
from dbo.v_allBuyProductNew c 
where c.saleProductId=b.productId and c.colorId=b.colorId and c.metricsId=b.metricsId )<=0 

)


update erp..tb_productStock  set isUndercarriage=0 where id in (	
select b.id from erp..tb_productStock b where b.productId=@productId
and b.isShowUndercarriage=1 
and ( b.productCount-( select isnull(sum(c.buyCount),0)--+isnull(sum(c.allStockCount),0)+isnull(sum(c.tuiHuoCount),0) 
from dbo.v_allBuyProductNew c 
where c.saleProductId=b.productId and c.colorId=b.colorId and c.metricsId=b.metricsId ) >0 
)
)



insert into tb_productAttribute (productId,colorId,colorName,metricsId,metricsname,productCount,allStockCount)
select a.productId,c.id,c.codeName,d.id,d.codeName, 
--isnull(a.productCount,0)-isnull(sum(e.buyCount),0), isnull(sum(e.allStockCount),0)+isnull(sum(e.tuiHuoCount),0)
isnull(a.productCount,0)-isnull(sum(e.buyCount),0), 0

from   ERP.dbo.tb_productStock a
inner join ERP..tb_productColorCode c on a.colorId=c.id  
inner join ERP..tb_productMetricsCode d on a.metricsId=d.id 
left join dbo.v_allBuyProductNew e on e.saleProductId=a.productId and e.colorId=a.colorId and e.metricsId=a.metricsId
 where isUndercarriage=0 and a.productId=@productId
group by a.productId,c.id,c.codeName,d.id,d.codeName,a.productCount


update tb_productAttribute set stockCountDate=f.expectedInTime 
from tb_productAttribute a,erp..tb_buyProductList f,erp..tb_buyProductProtity g 
	WHERE f.isDeleted<>1 and f.buyStatus IN (1, 2, 3) and g.buyProductId=f.id and f.expectedInTime is not null
	--and f.isBuyStock=1 -- 没有记入库存的采购单时间也显示
 and a.productId=f.productId and a.colorId=g.colorId and a.metricsId=g.metricsId and a.productId=@productId

update tb_productAttribute set stockCountDate=dateadd(day,1, getDate()) where stockCountDate<=getDate() and productId=@productId


/*
select a.productId,c.id,c.codeName,d.id,d.codeName,isnull(a.productCount-isnull(sum(e.buyCount),0)+isnull(j.aProductCount,0),0) from  
 ERP.dbo.tb_productStock a
inner join ERP..tb_productColorCode c on a.colorId=c.id  
inner join ERP..tb_productMetricsCode d on a.metricsId=d.id 
left join dbo.v_allBuyProductNewRemark e on e.saleProductId=a.productId and e.colorId=a.colorId and e.metricsId=a.metricsId
left join (
select isnull(sum(g.productCount),0) as aProductCount,f.id as fId from erp..tb_orderInstockProduct g ,erp..tb_orderInstock h,erp..tb_productStock f 
		where h.status in (0,1) and h.id=g.instockId and g.productCode=f.productShelfCode 
 group by f.id
) j on j.fId=a.id
 where isUndercarriage=0 and a.productId=@productId
group by a.productId,c.id,c.codeName,d.id,d.codeName,a.productCount,j.aProductCount
*/


--删除临时库存表，不是 卖完补货周期短 and qhcllbId!=3，库存为0的记录
delete tb_productAttribute from tb_productAttribute a, tb_saleProduct b where b.productId=a.productId -- and b.qhcllbId!=3-- and b.isDeleted=0
 --and isnull((a.productCount+a.allStockCount),0)<=0 
 and isnull(a.productCount,0)<=0 
and b.saleTypeId=1 and a.productId=@productId