
CREATE procedure [dbo].[p_addtaobaoMember] @nickName varchar(200),
								   @name varchar(100),
								   @mobile varchar(100),
								   @addr varchar(600),
								   @post varchar(50)
as
begin tran 
	--通过数据库锁，控制并发
	update tb_taobaoMember set source='taobao' where taobaoNickName=@nickName --and name = @name
	
	if @@rowcount =0
	begin
		declare @memberId int
		insert  into   tb_member(nickname,type,name,mobileNum,phoneNum,homeAddr,post,source,comeFrom,provinceId,
		cityId,homeAddrRegional)
		values (@nickName,1,isnull(@name,@nickName),@mobile,@mobile,@addr,@post,'taobao','taobao',4,4,226)

		set @memberId=SCOPE_IDENTITY()

		insert into  tb_taobaoMember(memberId,taobaoNickname,source) values (@memberId,@nickName,'taobao')

		select @memberId 
	end
	else
	begin
		select memberId   from  tb_taobaoMember where taobaoNickName=@nickName
	end
commit tran 

