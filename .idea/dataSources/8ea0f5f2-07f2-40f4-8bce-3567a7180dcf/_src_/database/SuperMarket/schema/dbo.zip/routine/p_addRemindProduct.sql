CREATE PROCEDURE p_addRemindProduct @productCode varchar(50),@startTime varchar(50),@addManId int
AS
	if EXISTS (select 1 from tb_remindProduct where productCode=@productCode )
	begin
		update tb_remindProduct set remindTime=@startTime,addmanid=@addManId where productCode=@productCode
	end
	else
	begin
		insert into tb_remindProduct(productCode,remindTime,addmanid) values(@productCode,@startTime,@addManId)
	end
