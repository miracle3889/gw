/*------------------------------------------------------回滚定单------------------------------------------------------------------------------------*/
CREATE  PROCEDURE p_delOrderTaobao @orderId INT,@deleteManId int
AS	
	BEGIN TRAN 
		if exists(select 1 from supermarket..tb_order where id=@orderId  and orderstatus in(1,2,13,20) )
		begin
			update supermarket..tb_order set isdelete=1,deleteManId=@deleteManId where id=@orderId 
			delete from supermarket..tb_taobaoCode where orderCode  in(select orderCode from tb_order where id=@orderId)
			delete from tb_temp_waitPhProduct where orderId=@orderId
		end
	COMMIT TRAN