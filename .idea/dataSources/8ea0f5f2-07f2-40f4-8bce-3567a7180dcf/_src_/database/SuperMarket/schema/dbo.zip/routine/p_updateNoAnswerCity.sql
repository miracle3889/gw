create procedure p_updateNoAnswerCity
as 
update tb_noAnswerCall set cityName =b.area from tb_noAnswerCall a,

(select a.id,c.name as area from 
(
SELECT id,callCallerCode,subString(callCallerCode,2,7) as pre FROM tb_noAnswerCall 
where isCallBack=0 and callCallerCode like '01__________' and cityName is null
) as a
inner join  c3..tb_mobileArea b on a.pre=b.Tel
inner join tb_city c on c.id=b.cityId

 ) as b where a.id=b.id


update tb_noAnswerCall set cityName =b.area from tb_noAnswerCall a,
(select  a.id,c.name as area  from 
(
SELECT id,callCallerCode,subString(callCallerCode,1,3) as pre FROM tb_noAnswerCall 
where isCallBack=0 and callCallerCode not like '01__________' and  callCallerCode like '0[1-2]%' and cityName is null
) as a
inner join tb_areaCode  b on b.code=a.pre 
inner join tb_city c on c.id=b.cityId
 ) as b where a.id=b.id


update tb_noAnswerCall set cityName =b.area from tb_noAnswerCall a,
(select  a.id,c.name as area  from 
(
SELECT id,callCallerCode,subString(callCallerCode,1,4) as pre FROM tb_noAnswerCall 
where isCallBack=0 and callCallerCode not like '01__________' and  callCallerCode like '0[3-9]%' and cityName is null
) as a
inner join tb_areaCode  b on b.code=a.pre 
inner join tb_city c on c.id=b.cityId
 ) as b where a.id=b.id


