/*--------------------------更新浏览历史-----------------------------------*/
CREATE PROCEDURE p_setViewHis
AS

	SELECT saleID,COUNT(*) AS viewCount INTO #tmp FROM tb_viewHis GROUP BY saleID

	UPDATE tb_saleProduct SET viewCount=oldCount+b.viewCount FROM tb_saleProduct a 
	, #tmp b WHERE a.id=b.saleId