/**********生成临时库存表***********/
CREATE  procedure p_sendProductAttribute

AS

--如果样式规格，卖完就下架，跟据库存，设定isUndercarriage
update erp..tb_productStock  set isUndercarriage=1 where id in (
select b.id from erp..tb_productStock b where b.isShowUndercarriage=1 
and ( 
	b.productCount-( 
		select isnull(sum(c.buyCount),0)--+isnull(sum(c.allStockCount),0)+isnull(sum(c.tuiHuoCount),0)  
		from dbo.v_allBuyProductNew c 
		where c.saleProductId=b.productId and c.colorId=b.colorId and c.metricsId=b.metricsId ) 
	)<=0
)


update erp..tb_productStock  set isUndercarriage=0 where id in (
select b.id from erp..tb_productStock b where b.isShowUndercarriage=1 
and ( 
	b.productCount-( 
		select isnull(sum(c.buyCount),0)--+isnull(sum(c.allStockCount),0)+isnull(sum(c.tuiHuoCount),0) 
		from dbo.v_allBuyProductNew c 
		where c.saleProductId=b.productId and c.colorId=b.colorId and c.metricsId=b.metricsId ) 
	)> 0
)





	delete from tb_productAttribute  --删除属性

insert into tb_productAttribute(productId,colorId,colorName,metricsId,metricsname,productCount,allStockCount)
select a.productId,c.id,c.codeName,d.id,d.codeName,
-- isnull(a.productCount,0)-isnull(sum(e.buyCount),0), isnull(sum(e.allStockCount),0)+isnull(sum(e.tuiHuoCount),0)
 isnull(a.productCount,0)-isnull(sum(e.buyCount),0), 0
--,h.expectedInTime 
-- isnull(a.productCount-isnull(sum(e.buyCount),0),0) 
from  ERP.dbo.tb_productStock a
inner join ERP..tb_productColorCode c on a.colorId=c.id  
inner join ERP..tb_productMetricsCode d on a.metricsId=d.id 
left join dbo.v_allBuyProductNew e on e.saleProductId=a.productId and e.colorId=a.colorId and e.metricsId=a.metricsId
--left join (
--	select top 1 f.expectedInTime,f.productId, g.colorId, g.metricsId FROM erp..tb_buyProductList f,erp..tb_buyProductProtity g 
--	WHERE f.isDeleted<>1 and f.buyStatus IN (1, 2, 3) and 
--	f.isBuyStock=1 and g.buyProductId=f.id and expectedInTime is not null and expectedInTime>=getdate()
--) h on h.productId=a.productId and h.colorId=a.colorId and h.metricsId=a.metricsId

 where isUndercarriage=0 --and a.productCount>0 --添加库存大于0 的颜色规格
group by a.productId,c.id,c.codeName,d.id,d.codeName,a.productCount--,h.expectedInTime 


update tb_productAttribute set stockCountDate=f.expectedInTime 
from tb_productAttribute a,erp..tb_buyProductList f,erp..tb_buyProductProtity g 
	WHERE f.isDeleted<>1 and f.buyStatus IN (1, 2, 3) and g.buyProductId=f.id and f.expectedInTime is not null 
	--and f.isBuyStock=1  -- 没有记入库存的采购单时间也显示
 and a.productId=f.productId and a.colorId=g.colorId and a.metricsId=g.metricsId and a.productCount<=0

update tb_productAttribute set stockCountDate=dateadd(day,1, getDate()) where stockCountDate<=getDate()


--删除临时库存表，b.qhcllbId=1卖完就下架，库存为0的记录
--新规则 不是 卖完补货周期短 
delete tb_productAttribute from tb_productAttribute a, tb_saleProduct b where b.productId=a.productId-- and b.isDeleted=0 
-- and b.qhcllbId!=3 
-- and isnull((a.productCount+a.allStockCount),0)<=0
 and isnull(a.productCount,0)<=0



-- 系统恢复 已删除 销售类型为A、B、J 重新设isDeleted=0
UPDATE tb_saleProduct SET isDeleted=0 where isSystem=0 and isDeleted=1-- and saleTypeId in (1,16,2)


-- 系统删除 未删除 销售类型为A、B、J  如果可用库存有小于0的 不是 卖完补货周期短  重新设isDeleted=1 
-- 新规则  不是 卖完补货周期短 and qhcllbId!=3
UPDATE tb_saleProduct SET isDeleted=1 where isSystem=0 and isDeleted=0 --and qhcllbId!=3 
	--and saleTypeId in (1,16,2) -- 所有商品
	and productId not in (
		select distinct productId from tb_productAttribute where 
		--isnull(productCount+allStockCount,0)>0 group by productId 
		isnull(productCount,0)>0 group by productId 
	-- 取出现有可用库存>0 且以productId,colorId,metricsId 分组
	)

	-- 没入库的卖完补货周期短  
	UPDATE tb_saleProduct SET isDeleted=1 where isSystem=0 and isDeleted=0 --and qhcllbId=3 
	and productId not in ( 
		SELECT distinct productId FROM ERP..tb_buyProductList WHERE (buyStatus = 4) -- 入库的
	)
	and productId not in (
		select distinct productId from tb_productAttribute where 
		--isnull(productCount+allStockCount,0)>0 group by productId 
		isnull(productCount,0)>0 group by productId 
	)