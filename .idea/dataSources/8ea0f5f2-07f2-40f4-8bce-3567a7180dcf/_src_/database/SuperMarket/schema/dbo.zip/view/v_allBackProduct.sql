CREATE VIEW dbo.v_allBackProduct
AS
SELECT a.orderSaleId, a.colorId, a.metricsId,sum( a.backCount) as backCount, b.ordeId AS orderId
FROM dbo.tb_backProduct a INNER JOIN
      dbo.tb_backOder b ON a.backId = b.id
WHERE (b.isDeleted <> 1)   group by a.orderSaleId, a.colorId, a.metricsId,b.ordeId

