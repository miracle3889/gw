/*-------------------------------修改首页商品排序--------------------------------------*/
CREATE PROCEDURE p_updateSetHtmlOrder  @typeI INT, @typeII INT, @id INT, @isOrder INT 
AS 
	DECLARE @idI INT
	SET @idI=0
	DECLARE @isOrderI INT
	SET @isOrderI=0
	DECLARE @idII INT
	SET @idII=0
	DECLARE @isOrderII INT
	SET @isOrderII=0
	DECLARE @returnValue INT
	SET @returnValue=0


	BEGIN TRAN 
	select @idII=id,@isOrderII=isOrder from tb_setIndex where id=@id

	select @idI=id,@isOrderI=isOrder from tb_setIndex where typeI=@typeI and typeII=@typeII and isOrder=@isOrder and isDeleted=0
	
	if (@idI != 0  and @idII != 0 )
	begin
		update tb_setIndex set isOrder=@isOrderI where id=@id
		update tb_setIndex set isOrder=@isOrderII where id=@idI 
		set @returnValue=1
	end
	else
	begin
		if (@idI = 0 and @idII != 0)
		begin
			update tb_setIndex set isOrder=@isOrder where id=@id
			set @returnValue=1
		end
	end
	COMMIT TRAN 
	SELECT @returnValue