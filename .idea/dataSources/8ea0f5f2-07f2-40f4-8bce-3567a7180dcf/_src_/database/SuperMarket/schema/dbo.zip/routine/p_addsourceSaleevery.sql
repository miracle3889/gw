CREATE PROCEDURE p_addsourceSaleevery
AS 
declare @date varchar(10)

set @date=dateAdd(day,-30,getDate())

INSERT INTO tb_temp_sourceSaleevery(日期,Y订单数,Y订单金额,Y退货,Y拒收)

select convert(varchar(10),createTime,120),count(*),sum(productPrice+deliverPrice-useAccount-useGift),sum(isnull(b.payPrice,0)),sum(backPrice) from tb_order a 
left join (
select ordeId,sum(payPrice) as payPrice  from tb_backOder where payPrice>0 and isDeleted<>1 group by ordeId 
) as b  on  a.id=b.ordeId
 where orderstatus in(1,2,3,17,13,20) and isdelete<>1
and  createTime>=@date and magazineCodeS='Y'   and  convert(varchar(10),createTime,120) 
not in(select convert(varchar(10),日期,120) FROM tb_temp_sourceSaleevery)
group by convert(varchar(10),createTime,120)
 order by convert(varchar(10),createTime,120)


UPDATE tb_temp_sourceSaleevery SET Y订单数=b.Y订单数,Y订单金额=b.Y订单金额 ,Y退货=b.Y退货 ,Y拒收=b.Y拒收 
FROM 
tb_temp_sourceSaleevery a,
(
	select convert(varchar(10),createTime,120) as 日期,
	count(*) as Y订单数 ,
	sum(productPrice+deliverPrice-useAccount-useGift) as Y订单金额,
	sum(isnull(b.payPrice,0)) as Y退货,sum(backPrice) as Y拒收
	 from tb_order a
	left join (
	select ordeId,sum(payPrice) as payPrice  from tb_backOder where payPrice>0 and isDeleted<>1 group by ordeId 
	) as b  on a.id=b.ordeId
	 where orderstatus in(1,2,3,17,20,13) and isdelete<>1
	and  createTime>=@date and magazineCodeS='Y'   
	group by convert(varchar(10),createTime,120)
) as b where  convert(varchar(10),a.日期,120)=convert(varchar(10),b.日期,120)




INSERT INTO tb_temp_sourceSaleevery(日期,发杂志单数,发杂志金额,发杂志退货,发杂志拒收)

select convert(varchar(10),createTime,120),count(*),sum(productPrice+deliverPrice-useAccount-useGift),sum(isnull(b.payPrice,0)),sum(backPrice) from tb_order a
left join (
select ordeId,sum(payPrice) as payPrice  from tb_backOder where payPrice>0 and isDeleted<>1 group by ordeId 
) as b  on  a.id=b.ordeId 
inner join tb_marketCode m on a.magSourceRemark like m.code and m.type=0
 where orderstatus in(1,2,3,17,20,13) and isdelete<>1
and  createTime>=@date  and magazineCodeS<>'Y'   
 and  convert(varchar(10),createTime,120) not in(select convert(varchar(10),日期,120) FROM tb_temp_sourceSaleevery)
group by convert(varchar(10),createTime,120)
 order by convert(varchar(10),createTime,120)


UPDATE tb_temp_sourceSaleevery SET 发杂志单数=b.发杂志单数,发杂志金额=b.发杂志金额 ,发杂志退货=b.发杂志退货 ,发杂志拒收=b.发杂志拒收 
FROM 
tb_temp_sourceSaleevery a,
(
	select convert(varchar(10),createTime,120) as 日期,
	count(*) as 发杂志单数 ,
	sum(productPrice+deliverPrice-useAccount-useGift) as 发杂志金额,
	sum(isnull(b.payPrice,0)) as 发杂志退货,sum(backPrice) as 发杂志拒收
	 from tb_order a
	left join (
	select ordeId,sum(payPrice) as payPrice  from tb_backOder where payPrice>0 and isDeleted<>1 group by ordeId 
	) as b  on  a.id=b.ordeId 	
	inner join tb_marketCode m on a.magSourceRemark like m.code and m.type=0
	 where orderstatus in(1,2,3,17,20,13) and isdelete<>1
	and  createTime>=@date   and magazineCodeS<>'Y'   
	group by convert(varchar(10),createTime,120)
) as b where  convert(varchar(10),a.日期,120)=convert(varchar(10),b.日期,120)







INSERT INTO tb_temp_sourceSaleevery(日期,邮寄单数,邮寄金额,邮寄退货,邮寄拒收)

select convert(varchar(10),createTime,120),count(*),sum(productPrice+deliverPrice-useAccount-useGift),sum(isnull(b.payPrice,0)),sum(backPrice) 
 from tb_order  a
	left join (
	select ordeId,sum(payPrice) as payPrice  from tb_backOder where payPrice>0 and isDeleted<>1 group by ordeId 
	) as b  on  a.id=b.ordeId 	
inner join tb_marketCode m on a.magSourceRemark like m.code and m.type=1
where orderstatus in(1,2,3,17,20,13) and isdelete<>1
and  createTime>=@date and magazineCodeS<>'Y'   
 and  convert(varchar(10),createTime,120) not in(select convert(varchar(10),日期,120) FROM tb_temp_sourceSaleevery)
group by convert(varchar(10),createTime,120)
 order by convert(varchar(10),createTime,120)


UPDATE tb_temp_sourceSaleevery SET 邮寄单数=b.邮寄单数,邮寄金额=b.邮寄金额 ,邮寄退货=b.邮寄退货 ,邮寄拒收=b.邮寄拒收 
FROM 
tb_temp_sourceSaleevery a,
(
	select convert(varchar(10),createTime,120) as 日期,
	count(*) as 邮寄单数 ,
	sum(productPrice+deliverPrice-useAccount-useGift) as 邮寄金额,
	sum(isnull(b.payPrice,0)) as 邮寄退货,sum(backPrice) as 邮寄拒收
	 from tb_order a 
	left join (
	select ordeId,sum(payPrice) as payPrice  from tb_backOder where payPrice>0 and isDeleted<>1 group by ordeId 
	) as b  on  a.id=b.ordeId 	
	inner join tb_marketCode m on a.magSourceRemark like m.code and m.type=1
	where orderstatus in(1,2,3,17,20,13) and isdelete<>1
	and  createTime>=@date and magazineCodeS<>'Y'   
	group by convert(varchar(10),createTime,120)
) as b where  convert(varchar(10),a.日期,120)=convert(varchar(10),b.日期,120)





INSERT INTO tb_temp_sourceSaleevery(日期,其他单数,其他金额,其他退货,其他拒收)

select convert(varchar(10),createTime,120),count(*),sum(productPrice+deliverPrice-useAccount-useGift),sum(isnull(b.payPrice,0)),sum(backPrice)  from tb_order a
left join (
	select ordeId,sum(payPrice) as payPrice  from tb_backOder where payPrice>0 and isDeleted<>1 group by ordeId 
	) as b  on  a.id=b.ordeId 	
 where orderstatus in(1,2,3,17,20,13) and isdelete<>1
and  createTime>=@date and magazineCodeS<>'Y'   
and ( magSourceRemark  not like '[0-9]%' or  magSourceRemark is null or magSourceRemark like '666%' or magSourceRemark like '777%')
 and  convert(varchar(10),createTime,120) not in(select convert(varchar(10),日期,120) FROM tb_temp_sourceSaleevery)
group by convert(varchar(10),createTime,120)
 order by convert(varchar(10),createTime,120)


UPDATE tb_temp_sourceSaleevery SET 其他单数=b.其他单数,其他金额=b.其他金额 ,其他退货=b.其他退货 ,其他拒收=b.其他拒收 
FROM 
tb_temp_sourceSaleevery a,
(
	select convert(varchar(10),createTime,120) as 日期,
	count(*) as 其他单数 ,
	sum(productPrice+deliverPrice-useAccount-useGift) as 其他金额,
	sum(isnull(b.payPrice,0)) as 其他退货,sum(backPrice) as 其他拒收
	 from tb_order a
	left join (
	select ordeId,sum(payPrice) as payPrice  from tb_backOder where payPrice>0 and isDeleted<>1 group by ordeId 
	) as b  on  a.id=b.ordeId 	
	 where orderstatus in(1,2,3,17,20,13) and isdelete<>1
	and  createTime>=@date and magazineCodeS<>'Y'   
	and ( magSourceRemark  not like '[0-9]%' or  magSourceRemark is null or magSourceRemark like '666%' or magSourceRemark like '777%')
	group by convert(varchar(10),createTime,120)
) as b where  convert(varchar(10),a.日期,120)=convert(varchar(10),b.日期,120)
