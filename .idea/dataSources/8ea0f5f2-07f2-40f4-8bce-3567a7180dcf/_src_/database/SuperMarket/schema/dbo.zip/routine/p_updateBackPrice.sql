CREATE PROCEDURE p_updateBackPrice @id int 

AS
declare @price int
declare @price1 int
declare @count int
declare @count1 int
set @price=0
set @price1=0
	begin tran
	select @count=count(*)
	from tb_backProduct a 
	--inner join tb_saleProductPay b on b.saleProductId=a.saleId and b.payStyleId=1 
	inner join tb_orderSaleProductPay b on b.orderSaleProductId=a.orderSaleId 
	where a.backId=@id and a.type=1
if(@count>0)
begin
	select @price=SUM(b.payValue*a.backCount)
	from tb_backProduct a 
	--inner join tb_saleProductPay b on b.saleProductId=a.saleId and b.payStyleId=1 
	inner join tb_orderSaleProductPay b on b.orderSaleProductId=a.orderSaleId 
	where a.backId=@id and a.type=1
end
	select @count1=count(*)
	from tb_backProduct a 
	--inner join tb_saleGroupPay b on b.groupProductId=a.saleId and b.payStyleId=1 
	inner join tb_orderSaleProductPay b on b.orderSaleProductId=a.orderSaleId 
	where a.backId=@id and a.type=2
if(@count1>0)
begin
	select @price1=SUM(b.payValue*a.backCount)
	from tb_backProduct a 
	--inner join tb_saleGroupPay b on b.groupProductId=a.saleId and b.payStyleId=1 
	inner join tb_orderSaleProductPay b on b.orderSaleProductId=a.orderSaleId 
	where a.backId=@id and a.type=2
end

update tb_backOder set BackPrice=@price1+@price where id=@id

	commit tran