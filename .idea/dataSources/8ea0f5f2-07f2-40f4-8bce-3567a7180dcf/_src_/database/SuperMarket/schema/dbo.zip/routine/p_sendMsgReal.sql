/*---------发送短信-------------------------*/

CREATE PROCEDURE p_sendMsgReal @mobileNum VARCHAR(11),@content VARCHAR(2000)
AS
	INSERT INTO c3.dbo.tb_smsMission(sourceType,mobileNum,content,sendTime) VALUES(0,@mobileNum,@content,getDATE())