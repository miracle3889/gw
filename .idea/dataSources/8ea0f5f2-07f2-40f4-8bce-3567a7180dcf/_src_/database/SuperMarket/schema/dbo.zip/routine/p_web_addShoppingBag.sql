

/*-----------------添加商品到购物车------------------------------------------*/
CREATE   PROCEDURE [dbo].[p_web_addShoppingBag]     @saleProductId INT,@colorId INT,@metricsId INT, @buyCount INT,@memberId INT
AS
     DECLARE @returnValue INT
       DECLARE @saleCode VARCHAR(50)
     DECLARE @colorCode VARCHAR(2)
     DECLARE @metricsCode VARCHAR(2)
     SET @returnValue=0
     
	if (@buyCount<=0)
	begin
		set @buyCount=1
	end
    declare @returnCount int
    declare @isBuy int
	--declare @addGo int
	--select @addGo=count(*) from tb_shelves where colorId=@colorId and metricsId=@metricsId
	--if (@addGo>0)
	--begin
	--	set @returnCount=-1
	--	select @returnCount
	--	return
	--end
   
    select @isBuy=count(*) from  tb_saleProduct where id=@saleProductId and (saleTypeId=17  or saleTypeId=18 or saleTypeId=19 or saleTypeId=20)
    if(@isBuy>0)
	set @buyCount=1
    if(@isBuy>0)
    begin
    --select @returnCount=count(*) from tb_groupPh where groupId=1024  AND memberId=@memberId and isBuy=0
    --if(@returnCount>0)
	--begin
	--set @returnCount=1
	--select @returnCount
	--return
	--end
     
    select @returnCount=count(*) from tb_shoppingBag a inner join tb_saleProduct b on a.saleProductId=b.id where (b.saleTypeId=17 or  b.saleTypeId=18 or saleTypeId=19 or saleTypeId=20) and a.memberId=@memberId
    if(@returnCount>0)
	begin
	set @returnCount=1
	select @returnCount
	return
	end
    end
     BEGIN TRAN
	     SELECT @saleCode=saleCode FROM tb_saleProduct WHERE id=@saleProductId         
	     SELECT @colorCode=code FROM ERP.dbo.tb_productColorCode WHERE id=@colorId
                  SELECT @metricsCode=code FROM ERP.dbo.tb_productMetricsCode WHERE id=@metricsId

	     SET @saleCode=@saleCode+@colorCode+@metricsCode
		if (@saleCode is not null)
		begin
	     INSERT INTO tb_shoppingBag(productCode,buyCount,saleProductId,colorId,metricsId,memberId,isRand,resource) 
			VALUES(@saleCode,@buyCount,@saleProductId,@colorId,@metricsId,@memberId,1,1)
		SET @returnValue=1
		end
	     
    COMMIT TRAN

   
    SELECT @returnValue