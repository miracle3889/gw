CREATE PROCEDURE p_updatePaymentByUser @orderId INT,@paymentDate varchar(50),@doManId int  
AS
	declare @addMan varchar(50)
	declare @mobileNum varchar(50)
	
	declare @content varchar(60)
	select @addMan=name from erp..tb_user where id=@doManId
	
	UPDATE tb_order SET isPayment = 1 ,paymentDate=@paymentDate,checkRemark=isnull(checkRemark,'')+'由'+@addMan+'于'+cast(getDate() as varchar(50))+'确认收款' WHERE id = @orderId 
			
	/* if EXISTS(select 1 from tb_order where isdelete<>1 and   orderstatus in(5,6) and id = @orderId) --待审核和待付款
	   	begin
			IF not EXISTS( 
					SELECT 1 FROM tb_orderSaleProduct a
					INNER JOIN erp..tb_productStock c ON a.colorId=c.colorId and a.metricsId=c.metricsId and a.orderId=@orderId
					LEFT  JOIN 
						(
							SELECT X.productId AS saleProductId,X.colorId AS colorId, 
							      X.metricsId AS metricsId,sum(X.buyCount) AS buyCount
							FROM dbo.tb_orderSaleProduct X INNER JOIN
							      dbo.tb_order Y ON Y.id = X.orderId
							WHERE Y.orderStatus IN (1, 6) AND Y.isDelete != 1
							GROUP by  X.productId,X.colorId,X.metricsId
							
						) as d on d.colorId=a.colorId and d.metricsId=a.metricsId
						LEFT  JOIN 
						(
							SELECT  sum(buyCount) as buyCount, colorId, metricsId
							FROM tb_shoppingBag 
							WHERE resource = 0 AND isStock = 1
							GROUP by  colorId, metricsId
						
						) as e on e.colorId=a.colorId and e.metricsId=a.metricsId						
						 group by a.colorId,a.metricsId,c.productCount,d.buyCount,e.buyCount
						 having (c.productCount)-sum(a.buyCount)-isnull(d.buyCount,0) -isnull(e.buyCount,0)<0
					)
					BEGIN
						UPDATE dbo.tb_order SET orderStatus=1 ,magSourceRemark='autoPay'+cast(@doManId as varchar(10)),isUpdate=0 WHERE id=@orderId
						
						  select @mobileNum=mobileNum from dbo.tb_member where id in(select memberId from tb_order where id=@orderId) 
							and mobileNum not in(select mobileNum from tb_blackNum)
				 		    if(@mobileNum is not null )
							     begin
								if(len(@mobileNum)>=11 )
								begin
									
										set @content='优邮提示:您的订单'+@content+'已经审核通过,我们将尽块将订单送达。www.yoyo18.com '
									
							                exec p_sendMsgByClass @mobileNum,@content,9999,1
								end
				   			  end
						
					END
	
				end*/