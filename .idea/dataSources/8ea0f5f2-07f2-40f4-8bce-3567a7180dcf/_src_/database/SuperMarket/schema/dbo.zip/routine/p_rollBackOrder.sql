/*------------------------------------------------------回滚定单------------------------------------------------------------------------------------*/
CREATE   PROCEDURE p_rollBackOrder @memberId INT,@orderId INT
AS
	DECLARE @returnValue INT
	SET @returnValue=0
	BEGIN TRAN 
	INSERT INTO dbo.tb_shoppingBag(productCode,saleProductId,colorId,metricsId,buyCount,memberId,type)
	SELECT saleProductCode,saleProductId,colorId,metricsId,buyCount,@memberId,1 FROM dbo.tb_orderSaleProduct WHERE orderId=@orderId
        	DECLARE @account INT
        	SELECT @account=useAccount FROM dbo.tb_order WHERE id=@orderId
	IF(@account IS NOT NULL)
	BEGIN
		UPDATE dbo.tb_member SET account=account+@account WHERE id=@memberId
	END
       	 UPDATE dbo.tb_order SET orderStatus =10 WHERE id=@orderId
	SET @returnValue=1
	COMMIT TRAN
        SELECT @returnValue