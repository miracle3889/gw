CREATE VIEW dbo.v_deliverOtherOrder
AS
SELECT *
FROM tb_order
WHERE (isUpdate = 0) AND (isDelete != 1) AND (regionalId1 IN (3, 6, 7, 8, 9) OR
      regionalId1 > 9) AND addrId = 1 AND orderStatus = 13 AND orderType = 1
UNION ALL
SELECT *
FROM tb_order
WHERE (isUpdate = 0) AND (isDelete != 1) AND (regionalId2 IN (3, 6, 7, 8, 9) OR
      regionalId2 > 9) AND addrId = 2 AND orderStatus = 13 AND orderType = 1
