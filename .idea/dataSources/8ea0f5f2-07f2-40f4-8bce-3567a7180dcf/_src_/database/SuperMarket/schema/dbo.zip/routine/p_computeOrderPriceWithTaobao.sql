CREATE procedure [dbo].[p_computeOrderPriceWithTaobao] @orderId int
as 
	declare @useGift int --使用礼券
	declare @deliverPrice int --送货费用
	declare @realPrice int --使用礼券
	declare @memberId int	
	declare @memberCount int	
	if exists (select 1 from tb_orderSaleProduct where orderId=@orderId and saleProductId=23577)
	begin
		if exists(select 1 from tb_orderSaleProduct where orderId=@orderId and saleProductId<>23577)
		begin
			declare @code varchar(50)
			declare @orderIdNew int 
			
			EXEC p_geOrderCodeNew 1,@code OUTPUT --得到订单号
			INSERT INTO dbo.tb_order(orderCode,payType,deliverType,deliverPrice,memberId,orderStatus,
						doMan,reMark,magazineCode,magazineCodeS,magSourceRemark,receviceMan,post,receviceAddr1,
						receviceAddr2,receviceMobile,addrId,useAccount,getScore,regionalId1,regionalId2,useGift,
						orderSource,provinceId ,cityId ,createTime,paymentDate)
			select @code,payType,deliverType,0,memberId,orderStatus,
						doMan,reMark+'福袋包含其他商品拆单',magazineCode,magazineCodeS,magSourceRemark,receviceMan,post,receviceAddr1,
						receviceAddr2,receviceMobile,addrId,useAccount,getScore,regionalId1,regionalId2,0,
						orderSource,provinceId ,cityId ,createTime,paymentDate from tb_order where id=@orderId
			
			 
			set @orderIdNew=SCOPE_IDENTITY()

			insert  into tb_taobaoCode (orderCode,taobaoTid) 
			select @code,taobaoTid from tb_taobaoCode where 
			orderCode in(select orderCode from tb_order where id=@orderId)

			update   tb_orderSaleProduct set orderId= @orderIdNew  where orderId= @orderId  and saleProductId =23577
			exec p_computeOrderPriceWithTaobao @orderIdNew
		end
		else
		begin
			update tb_order set deliverManId=590 where orderstatus=1 and deliverManId<=0 and id=@orderId
			insert into dbo.tb_fudaiOrder(orderId) values(@orderId)
		end
	end

	select @deliverPrice=deliverPrice,@useGift=useGift ,@memberId=memberId
	 from tb_order where id=@orderId 	


	SELECT @realPrice=SUM(b.payValue*a.buyCount) 
	FROM dbo.tb_orderSaleProduct a
	INNER JOIN dbo.tb_orderSaleProductPay b ON a.id=b.orderSaleProductId 
	WHERE b.payType=1 AND a.orderId=@orderId  and groupPh=0
	
	if @realPrice is null 
		set @realPrice=0
	
	/*select  @memberCount=count(*)   from tb_order where isdelete<>1 and memberId=@memberId
	
	if(@memberCount=1)
	begin
		if not exists (select 1 from tb_orderSaleProduct where saleProductId in(select saleId from tb_twoDimensionalCode) and orderId=@orderId)
		begin
			declare @orderSaleProductId int 
			INSERT INTO dbo.tb_orderSaleProduct(orderId,colorId,metricsId,saleProductCode,
					saleProductId,buyCount,stockPrice,productId,giftPrice)	

			values(@orderId,1564,1123,'RO111830101',11183,1,100,1644,0)
				
			set @orderSaleProductId=SCOPE_IDENTITY() 
			
			insert into dbo.tb_orderSaleProductPay(orderSaleProductId,payType,payValue) values(@orderSaleProductId,1,0)
		end
	end*/
	if(@realPrice<=0)
	begin
		update tb_order set isdelete=1,delcause='订单金额为0'  where  id=@orderId
		delete from tb_taobaoCode where orderCode in(select orderCode from tb_order where id=@orderId)
	end
	else
	begin
		update tb_order set getScore=0,productPrice=@realPrice,transport=@deliverPrice,needGetPrice=0,orderstatus=1,isPayment=1 where id=@orderId
	
		if exists(select 1   from tb_order where orderstatus =1 and isdelete<>1 and id=@orderId)
		begin
			delete from tb_temp_waitPhProduct where orderId=@orderId
			
			insert into tb_temp_waitPhProduct(orderId,saleProductId,buyCount,colorId,metricsId)
			SELECT a.orderId,a.productId AS saleProductId, a.buyCount AS buyCount, a.colorId AS colorId, 
			      a.metricsId AS metricsId
		        FROM dbo.tb_orderSaleProduct a 
			INNER JOIN   dbo.tb_order b ON b.id = a.orderId
			WHERE b.orderStatus =1 AND b.isDelete != 1 and a.orderId=@orderId
		end
	end