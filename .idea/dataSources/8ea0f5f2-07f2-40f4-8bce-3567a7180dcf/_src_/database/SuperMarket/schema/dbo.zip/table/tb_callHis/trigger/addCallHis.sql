CREATE TRIGGER addCallHis ON dbo.tb_callHis 
FOR INSERT
AS
	DECLARE @callTime dateTime
	DECLARE @wavFile VARCHAR(50)
	DECLARE @mobileNum VARCHAR(50)
	DECLARE @myId INT
	DECLARE @COUNT INT
	SET @myId=0
	/*SELECT @wavFile=wavFile,@callTime=callTime,@mobileNum=callcallerCode  FROM Inserted 

	SELECT @COUNT=COUNT(*) FROM tb_callHis WHERE wavFile=@wavFile  AND callcallerCode= @mobileNum
	IF(@COUNT>1)
	BEGIN 
		SELECT top 1 @myId=id FROM tb_callHis WHERE wavFile=@wavFile  AND callcallerCode= @mobileNum
		DELETE FROM  tb_callHis WHERE id=@myId
		UPDATE tb_callHis SET callTime=@callTime WHERE  wavFile=@wavFile  AND callcallerCode= @mobileNum
	END*/
