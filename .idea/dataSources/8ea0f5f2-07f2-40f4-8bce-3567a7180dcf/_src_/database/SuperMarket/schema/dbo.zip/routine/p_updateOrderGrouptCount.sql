/*------------------------更改定单商品数量------------------------------*/
CREATE   PROCEDURE p_updateOrderGrouptCount @groupId INT,@count INT,@orderId int
AS
	DECLARE @oldGroupCount INT
	DECLARE @returnValue INT
	SET @returnValue=0
	delete from  erp..tb_canDistributeOrder where orderId =@orderId
	IF(@count=0)--删除组合
		BEGIN
			DELETE FROM dbo.tb_groupPh  WHERE id=@groupId
			DELETE FROM dbo.tb_ordersaleProduct WHERE groupPh=@groupId AND orderId=@orderId
			SET @returnValue=1
		END
	ELSE
		BEGIN
			DECLARE @hasMinPrice INT --赠品选择最低价格
			DECLARE @realPrice INT	--总价
			DECLARE @realPrice2 INT		--总价
			
			SELECT @oldGroupCount=buyCount FROM tb_groupPh WHERE id=@groupId --原来组合的数量
		
			SELECT @hasMinPrice=minPrice FROM dbo.tb_orderSaleProduct a
			INNER JOIN dbo.tb_saleProduct b ON a.saleProductId=b.id
			INNER JOIN dbo.tb_saleType c ON b.saleTypeId=c.id 
			WHERE c.isGive=1
			AND c.minPrice>0 AND a.orderId=@orderId  ---赠品选择最低价格
			
			IF(@hasMinPrice is null)
			BEGIN
				SET @hasMinPrice=0
			END
			
			SELECT @realPrice=SUM(b.payValue*a.buyCount) 
			FROM dbo.tb_orderSaleProduct a
			INNER JOIN dbo.tb_orderSaleProductPay b ON a.id=b.orderSaleProductId 
			WHERE b.payType=1 AND a.orderId=@orderId  AND   a.isRand=0 AND a.groupPh!=@groupId --得到除了该商品之外其他商品的价格
				
			IF(@realPrice IS NULL)
			BEGIN
				SET @realPrice=0
			END	
			
			SELECT @realPrice2=SUM(a.salePrice*@count) 
			FROM dbo.tb_saleGroup a
			INNER JOIN dbo.tb_groupPh b ON a.id=b.groupId 
			WHERE  b.id=@groupId  --得到该商品的价格
			
			SET @realPrice=@realPrice+@realPrice2
			IF(@realPrice<@hasMinPrice)
			BEGIN
				SET @returnValue=-2 --赠品价格不准确请删除赠品或修改商品数量
			END
			ELSE
			BEGIN
				DECLARE  @saleId int ,@colorId int ,@MetricsId int ,@buyCount int ,@iscanBuy int
				SET @iscanBuy=1
				
			IF(@oldGroupCount<@count)
					BEGIN
						DECLARE authors_cursor CURSOR FOR
				         		SELECT   saleProductId,colorId,metricsId,a.buyCount/b.buyCount  FROM  dbo.tb_orderSaleProduct  a
		 				INNER JOIN tb_groupPh b ON a.groupPh=b.id  WHERE a.groupPh=@groupId
						OPEN authors_cursor
						FETCH NEXT FROM authors_cursor 
						INTO @saleId,@colorId,@MetricsId,@buyCount
					
						WHILE @@FETCH_STATUS = 0
						BEGIN
							declare  @productId int
							select  @productId=productId from  tb_saleProduct where  id=@saleId
							declare @realCount int,@DDlCount int
							select @realCount=SUM(productCount) from ERP.dbo.tb_productStock 
								 where  productId=@productId AND colorId=@colorId AND metricsId=@metricsId   
							select  @DDlCount=SUM(a.buyCount) FROM v_allBuyProductNew a 
							--inner  JOIN tb_saleProduct b ON a.saleProductId=b.id 
							where a.saleProductId=@productId AND a.colorId=@colorId AND a.metricsId=  @metricsId   
							 if(@realCount IS NULL)
								 begin
									set @realCount=0
								 end
							  if(@DDlCount IS NULL)
							                begin 
									set @DDlCount=0
							                 end
							  if(@realCount-@DDlCount<(@buyCount*(@count-@oldGroupCount)))
							  begin
								set  @iscanBuy=0 
							  end
							fetch next from  authors_cursor 
							into @saleId,@colorId,@MetricsId,@buyCount
						END
					
						CLOSE authors_cursor
						DEALLOCATE authors_cursor
					END
				IF(@iscanBuy=0)
					BEGIN
						SET @returnValue=-3--库存不够
					END
				ELSE
					BEGIN
						UPDATE tb_groupPh SET buyCount=@count where id=@groupId
						UPDATE dbo.tb_orderSaleProduct SET buyCount=(buyCount/@oldGroupCount)*@count WHERE groupPh=@groupId AND orderId=@orderId
						SET @returnValue=1
					END
			END
		END
/*
SELECT @realPrice=SUM(b.payValue*a.buyCount) 
	FROM dbo.tb_orderSaleProduct a
	INNER JOIN dbo.tb_orderSaleProductPay b ON a.id=b.orderSaleProductId 
	WHERE b.payType=1 AND a.orderId=@orderId  
	
	IF(@realPrice is null)
		SET @realPrice=0*/
		/*-----------核算运费-------------------------*/
	/*DECLARE @deliverPrice INT
	DECLARE @provinceId INT 
	DECLARE @payType INT 
	DECLARE @cityId INT 

	SELECT @provinceId=provinceId,@payType=payType,@cityId=cityId FROM tb_order WHERE  id=@orderId
	IF(@provinceId=1 OR @provinceId=2 OR @provinceId=3)
		BEGIN
			IF(@realPrice>=9800)
			BEGIN
				SET @deliverPrice=0
			END
			ELSE
			BEGIN
				IF(@cityId = 1)
					BEGIN
						IF(@payType = 1)
							SET @deliverPrice=500 
						ELSE
							SET @deliverPrice=0 
					END
					ELSE
					BEGIN
	                    				IF(@payType = 1)
							SET @deliverPrice=1000
						ELSE
							SET @deliverPrice=500 
					END
			END
		END
	ELSE
		BEGIN
			IF(@realPrice>=19800)
				BEGIN
					SET @deliverPrice=0
				END
				ELSE
				BEGIN
					IF(@payType = 1)
						SET @deliverPrice=1500 
					ELSE
						SET @deliverPrice=1000 
				END
		END
	
	UPDATE tb_order SET getScore=@realPrice/100,deliverPrice=@deliverPrice,productPrice=@realPrice WHERE id=@orderId */
	  exec p_computeOrderPrice @orderId
	if(@returnValue=1)
	begin
		if EXISTS(select 1 from tb_order where orderstatus in(20,13) and id=@orderId)
		begin
			update tb_order set isdelete=2 where  id=@orderId
		end
	end
	SELECT @returnValue