create procedure [dbo].[p_addWeiXInMsg_borrowDeduct] 
@msgcontent varchar(2000),
@userId int 
as	 
DECLARE @newId INT  
set @newId=0;
BEGIN
	 insert into SuperMarket..tb_weiXinMsg(userId,msgType,msgcontent)
	    select id,'news',REPLACE(@msgcontent,'ruhnn_openId',openId) from ERP..tb_user where id=@userId;
	 
	 set @newId=@@IDENTITY;
END
select @newId