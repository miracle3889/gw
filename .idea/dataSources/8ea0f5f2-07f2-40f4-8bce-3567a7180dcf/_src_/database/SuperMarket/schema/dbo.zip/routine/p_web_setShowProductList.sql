/*-------------------------------------生成列表页展示商品列表--------------------------------*/
CREATE procedure p_web_setShowProductList
AS
	declare @skinCareTypeId int
	set @skinCareTypeId=0
	declare @isShow int 
	
	delete tb_showProductList	
	declare @viewCount int
	set @viewCount=0
	declare @adminSetCount int
	set @adminSetCount=0

	declare saleSkinCareTypeId cursor for select skinCareTypeId from tb_SaleProduct 
		where webCategoryId=12 and skinCareTypeId !=0 and saleTypeId=1 and isDeleted=0 
		group by skinCareTypeId having count(skinCareTypeId)>24  

	open saleSkinCareTypeId
	fetch NEXT from saleSkinCareTypeId into @skinCareTypeId

	while @@fetch_status=0
	begin
		insert into tb_showProductList (saleId,productName,saleCode,price,htmlPath,webCategoryId,skinCareTypeId,cosmeticsId,isShow,isSkin)
		select top 4 e.saleId,e.saleProductName,e.saleCode,e.salePriceInt,e.htmlPath,c.webCategoryId,c.skinCareTypeId,c.cosmeticsId,sum(a.buyCount-a.backCount)*70+sum((a.buyCount-a.backCount)*b.payValue/100),0
				from dbo.tb_orderSaleProduct a 
					inner join dbo.tb_orderSaleProductPay b on a.id=b.orderSaleProductId
					inner join dbo.tb_SaleProduct c on a.saleProductId=c.id
					inner join dbo.tb_order d on a.orderId=d.id
					inner join tb_searchSaleEntity e on c.id=e.saleId 
					inner join tb_searchSaleEntityProtity f on c.id=f.saleId
					where b.payType=1 and f.webCategoryId=12 and  c.skinCareTypeId=@skinCareTypeId  
					and d.createTime>=dateADD(day,-7,getdate()) and d.orderstatus!=19 and d.isdelete!=1 and  a.saleProductId  in (select saleId from dbo.tb_searchSaleEntity where isqh=0)
					group by a.saleProductId,c.viewCount,c.adminSetCount,e.saleProductName,e.saleCode,e.salePriceInt,e.htmlPath,e.saleId,c.webCategoryId,c.skinCareTypeId,c.cosmeticsId
					order by  sum(a.buyCount-a.backCount)*70+sum((a.buyCount-a.backCount)*b.payValue/100) desc

/**把列表页顶部一样的商品，拉到和第24个商品的点击量一样**/
		set @viewCount=0
		set @adminSetCount=0
		select top 1 @viewCount=viewCount,@adminSetCount=adminSetCount from tb_saleProduct where webCategoryId=12 and skinCareTypeId=@skinCareTypeId and saleTypeId=1 and isDeleted=0 
			and id not in (
				select top 23 id from tb_saleProduct 
					where webCategoryId=12 and skinCareTypeId=@skinCareTypeId and saleTypeId=1 and isDeleted=0 
					order by (viewCount+adminSetCount) desc
				) order by (viewCount+adminSetCount) desc

		update tb_searchSaleEntity set viewCount=@viewCount,adminSetCount=@adminSetCount 
		where saleId in (select saleId from tb_showProductList where webCategoryId=12 and skinCareTypeId=@skinCareTypeId )
/****/

		fetch NEXT from saleSkinCareTypeId into @skinCareTypeId 
	end 	

	close saleSkinCareTypeId
	deallocate saleSkinCareTypeId

	declare @cosmeticsId int
	set @cosmeticsId=0

	declare saleCosmeticsId cursor for select CosmeticsId from tb_SaleProduct 
					where webCategoryId=12 and CosmeticsId !=0 and saleTypeId=1 and isDeleted=0 
					group by CosmeticsId having count(CosmeticsId)>24  

	open saleCosmeticsId
	fetch NEXT from saleCosmeticsId into @cosmeticsId

	while @@fetch_status=0
	begin
		insert into tb_showProductList (saleId,productName,saleCode,price,htmlPath,webCategoryId,skinCareTypeId,cosmeticsId,isShow,isSkin)
		select top 4 e.saleId,e.saleProductName,e.saleCode,e.salePriceInt,e.htmlPath,c.webCategoryId,c.skinCareTypeId,c.cosmeticsId,sum(a.buyCount-a.backCount)*70+sum((a.buyCount-a.backCount)*b.payValue/100),1
				from dbo.tb_orderSaleProduct a 
					inner join dbo.tb_orderSaleProductPay b on a.id=b.orderSaleProductId
					inner join dbo.tb_SaleProduct c on a.saleProductId=c.id
					inner join dbo.tb_order d on a.orderId=d.id
					inner join tb_searchSaleEntity e on c.id=e.saleId 
					inner join tb_searchSaleEntityProtity f on c.id=f.saleId
					where b.payType=1 and f.webCategoryId=12 and c.cosmeticsId=@cosmeticsId  
					and d.createTime>=dateADD(day,-7,getdate()) and d.orderstatus!=19 and d.isdelete!=1 and  a.saleProductId  in (select saleId from dbo.tb_searchSaleEntity where isqh=0)
					group by a.saleProductId,c.viewCount,c.adminSetCount,e.saleProductName,e.saleCode,e.salePriceInt,e.htmlPath,e.saleId,c.webCategoryId,c.skinCareTypeId,c.cosmeticsId
					order by sum(a.buyCount-a.backCount)*70+sum((a.buyCount-a.backCount)*b.payValue/100) desc
		
/**把列表页顶部一样的商品，拉到和第24个商品的点击量一样**/
		set @viewCount=0
		set @adminSetCount=0
		select top 1 @viewCount=viewCount,@adminSetCount=adminSetCount from tb_saleProduct where webCategoryId=12 and cosmeticsId=@cosmeticsId and saleTypeId=1 and isDeleted=0 
			and id not in (
				select top 23 id from tb_saleProduct 
					where webCategoryId=12 and cosmeticsId=@cosmeticsId and saleTypeId=1 and isDeleted=0 
					order by (viewCount+adminSetCount) desc
				) order by (viewCount+adminSetCount) desc

		update tb_searchSaleEntity set viewCount=@viewCount, adminSetCount=@adminSetCount 
		where saleId in (select saleId from tb_showProductList where webCategoryId=12 and cosmeticsId=@cosmeticsId)
/****/
		fetch NEXT from saleCosmeticsId into @cosmeticsId 
	end 	

	close saleCosmeticsId
	deallocate saleCosmeticsId