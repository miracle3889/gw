
CREATE procedure p_addProductToOrderHuanhuo @orderSaleId int ,@colorId int ,@metricsId int,@count int ,@orderId int
as 
	 declare @mysaleId int
	 declare @productCount int
	--select @productCount=a.productCount from supermarket..v_productStock  a
      --  inner join erp..tb_productStock b on a.productShelfCode=b.productShelfCode
      -- where b.colorId=@colorId and b.metricsId=@metricsId
	 
	--if(@productCount>=@count)
    --    begin
	
	 INSERT INTO dbo.tb_orderSaleProduct(orderId,colorId,metricsId,saleProductCode,
				saleProductId,buyCount,isRand,stockPrice,productId,needInType,isRegister,giftPrice)	

	select 	@orderId,@colorId,@metricsId,saleProductCode,
				saleProductId,@count,isRand,stockPrice,productId,needInType,isRegister,giftPrice 
	from tb_orderSaleProduct where id=@orderSaleId 
	
	SET @mysaleId=SCOPE_IDENTITY() --得到刚刚插入的定单id 
	insert into dbo.tb_orderSaleProductPay(orderSaleProductId,payType,payValue)
	select @mysaleId,payType,payValue from tb_orderSaleProductPay where orderSaleProductId=@orderSaleId


	update tb_order set  useGift=useGift+b.giftPrice from tb_order  a,tb_orderSaleProduct b 
	where a.id=b.orderId and b.id=@orderSaleId

	insert into tb_updateTabaoProductCount(productCode,productCount,reMark) select productShelfCode,@count,'换货old'+ cast(@orderId as varchar(10))  from erp..tb_productStock where colorId=@colorId and metricsId=@metricsId
	--end