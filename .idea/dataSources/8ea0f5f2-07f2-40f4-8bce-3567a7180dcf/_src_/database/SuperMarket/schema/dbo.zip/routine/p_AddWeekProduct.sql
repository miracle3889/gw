CREATE procedure p_AddWeekProduct @saleId int,@startTime varchar(50),@endTime varchar(50),@price int
as 
	declare @oldPrice int
	select @oldPrice=payValue from dbo.tb_saleProductPay where  payStyleId=1 and saleProductId=@saleId
	if not EXISTS(select 1 from tb_saleProductOldPrice where saleId=@saleId)
	begin
		insert into tb_saleProductOldPrice(saleId,salePrice) values(@saleId,@oldPrice)
	end
	else
	begin
		update tb_saleProductOldPrice set salePrice=@oldPrice where saleId=@saleId
	end
	
	if not EXISTS(select 1 from tb_weekProduct where saleId=@saleId and ((startTime>=@startTime and startTime<=@endTime) or (startTime<=@startTime and endTime>=@endTime)))
	begin
		insert into tb_weekProduct(startTime,endTime,saleId,price) values(@startTime,@endTime,@saleId,@price)
	end