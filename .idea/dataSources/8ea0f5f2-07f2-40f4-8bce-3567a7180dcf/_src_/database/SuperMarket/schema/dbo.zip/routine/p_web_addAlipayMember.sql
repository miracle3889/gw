/*-------------------添加支付宝用户 注册会员-------------------------*/
CREATE PROCEDURE p_web_addAlipayMember @EMail VARCHAR(200),@name VARCHAR(50),@mobileNum VARCHAR(50),@ip VARCHAR(50),@source VARCHAR(16),@zheShang varchar(200)    
AS
	DECLARE @COUNT INT
	DECLARE @REGCOUNT INT
	DECLARE @returnValue INT
	SET @returnValue=0
	set @REGCOUNT=0
	SELECT @COUNT=COUNT(*) FROM dbo.tb_member WHERE zheShang=@zheShang and EMail!=''
	IF(@COUNT>0)
	BEGIN
		SET @returnValue=-1
	END
	ELSE
	BEGIN
		SELECT @COUNT=COUNT(*) FROM dbo.tb_member WHERE EMail=@EMail and EMail!=''
		IF(@COUNT>0)
		BEGIN
			SET @EMail=''
		END

		INSERT INTO dbo.tb_member(EMail,type,checkCode,name,mobileNum,regIp,source,zheShang)
		VALUES (@EMail,1,dbo.md5(CAST(rand()*10000 AS INT)),@name,@mobileNum,@ip,@source,@zheShang)
		SET @returnValue=scope_identity()
		
		IF(@@ERROR<>0)
		BEGIN	
			SET @returnValue=0
		END

	END
	
	SELECT @returnValue