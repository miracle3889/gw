CREATE PROCEDURE p_getSalePar
AS 

---昨日销售额
DECLARE @count1 INT
DECLARE @price1 INT
DECLARE @count2 INT
DECLARE @price2 INT
DECLARE @count3 INT
DECLARE @price3 INT
DECLARE @count4 INT
DECLARE @price4 INT
DECLARE @count5 INT
DECLARE @price5 INT
DECLARE @countCFT INT
DECLARE @priceCFT INT


--昨日销售情况
--select   @count1=count(*),@price1=sum(productPrice+deliverPrice-useaccount-useGift) from tb_order where 
-- isdelete<>1 and  orderstatus in(1,2,3,13,17,11,18,20)  and convert(varchar(10),createTime,120)=convert(varchar(10),dateadd(day,-1,getDate()),120)

select   @count1=orderCount,@price1=orderPrice+backPrice+rejectPrice from tb_everyDayReport where   convert(varchar(10),addDate,120)=convert(varchar(10),dateadd(day,-1,getDate()),120)


---上周昨日销售额
--select  @count2=count(*),@price2=sum(productPrice+deliverPrice-useaccount-useGift) from tb_order where 
 --isdelete<>1 and  orderstatus in(1,2,3,13,17,11,18,20)  and convert(varchar(10),createTime,120)=convert(varchar(10),DATEADD ( Week , -1, dateadd(day,-1,getDate()) ) ,120)

select   @count2=orderCount,@price2=orderPrice+backPrice+rejectPrice from tb_everyDayReport 
where   convert(varchar(10),addDate,120)=convert(varchar(10),DATEADD ( Week , -1, dateadd(day,-1,getDate()) ) ,120)




--今日销售额
select   @count3=count(*),@price3=sum(productPrice+deliverPrice-useaccount-useGift) from tb_order where 
 isdelete<>1 and  orderstatus in(1,2,3,13,17,11,18,20)  and convert(varchar(10),createTime,120)=convert(varchar(10),getDate(),120) 


select   @countCFT=count(*),@priceCFT=sum(productPrice+deliverPrice-useaccount-useGift) from tb_order where 
 isdelete<>1 and  orderstatus in(1,2,3,13,17,11,18,20)  and convert(varchar(10),createTime,120)=convert(varchar(10),getDate(),120) 
and  magazineCodeS='CFT'


---上周今日此时销售额

select   @count4=count(*),@price4=sum(productPrice+deliverPrice-useaccount-useGift) from tb_order where 
 isdelete<>1 and  orderstatus in(1,2,3,13,17,11,18,20)  and createTime>= convert(varchar(10), DATEADD ( Week , -1, getDate() ) ,120) 
and createTime<= DATEADD ( Week , -1, getDate() )  


--上周今日销售额
--select   @count5=count(*),@price5=sum(productPrice+deliverPrice-useaccount-useGift) from tb_order where 
 --isdelete<>1 and  orderstatus in(1,2,3,13,17,11,18,20)  and  convert(varchar(10),createTime,120)=convert(varchar(10),DATEADD ( Week , -1, getDate() ),120)



select   @count5=orderCount,@price5=orderPrice+backPrice+rejectPrice from tb_everyDayReport 
where   convert(varchar(10),addDate,120)=convert(varchar(10),DATEADD ( Week , -1, getDate() ),120)


select @count1 as 昨日订单数,@price1 as 昨日销售额,@count2 as 上周昨日订单数,@price2 as 上周昨日销售额
          ,@count3 as  今日订单数,@price3 as 今日销售额 ,@count4 as  上周此时订单数,@price4 as 上周此时销售额
	 ,@count5 as  上周今日订单数,@price5 as 上周今日销售额
	, ((datePart(hour,getDate())-9)*60+datePart(minute,getDate()))  as 分钟,@countCFT as 财付通订单数,isnull(@priceCFT,0) as 财付通销售额