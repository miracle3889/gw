
	CREATE procedure p_competFudaiOrder @orderId int
	as
	begin tran 
		INSERT INTO dbo.tb_orderSaleProduct(orderId,colorId,metricsId,saleProductCode,
				saleProductId,buyCount,isRand,stockPrice,productId,needInType,isRegister)			
		
		select orderId,colorId,metricsId,skuId,b.id,a.productCount,1,0,a.productId,1,1
		 from SuperMarket..tb_fudaiOrderProduct a
		inner join tb_saleProduct b on a.productId=b.productId and b.saleTypeId=1 where a.orderId=@orderId
		
		insert into dbo.tb_orderSaleProductPay(orderSaleProductId,payType,payValue)
		select id,1,0 from tb_orderSaleProduct where orderId=@orderId and saleProductId not in(select saleProductId from tb_fudaiProduct)
		
		delete from SuperMarket..tb_fudaiOrderProduct where orderId=@orderId
	
		
		update tb_fudaiOrderOper set status=2,okTime=GETDATE() where orderId=@orderId 
	commit tran 