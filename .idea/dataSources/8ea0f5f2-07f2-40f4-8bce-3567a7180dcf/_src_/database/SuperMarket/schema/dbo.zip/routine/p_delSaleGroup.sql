/*---------------------------------删除销售商品-------------------------------------------------*/
CREATE  PROCEDURE p_delSaleGroup @saleGroupId INT,@type INT 
AS 
   DECLARE @returnValue INT 
   SET @returnValue=0
   BEGIN TRAN 
	UPDATE  dbo.tb_saleProductGroup SET  isDelete=@type WHERE id=@saleGroupId
	SET @returnValue=1
   COMMIT TRAN
 SELECT @returnValue