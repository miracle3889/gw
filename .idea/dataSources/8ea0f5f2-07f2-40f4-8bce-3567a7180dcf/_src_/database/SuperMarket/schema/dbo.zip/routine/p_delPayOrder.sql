/*------------------------删除已付款订单---------------------------------------*/
CREATE  PROCEDURE p_delPayOrder @orderId INT,@deleteManId int,@inAccount int,@inBackPrice int
AS
	DECLARE @returnValue INT
	  DECLARE @account INT
  	 DECLARE @TScore INT
	DECLARE @memberId INT
	DECLARE @orderPrice INT
	declare @orderCode varchar(50)

	SELECT @memberId=memberId,@account=useAccount,@orderCode=orderCode,@orderPrice=productPrice+deliverPrice-useAccount-useGift FROM dbo.tb_order WHERE id=@orderId --得到对应的会员号-使用的余额
	SET @returnValue=0
	IF(@orderPrice=(@inAccount+@inBackPrice))
	BEGIN
	BEGIN TRAN 
		 --使用的积分
		  SELECT  @TScore=sum(c.payValue*b.buyCount) FROM tb_order a 
		  INNER  join dbo.tb_orderSaleProduct b ON a.id=b.orderId
		  INNER join dbo.tb_orderSaleProductPay c ON b.id=c.orderSaleProductId
		  WHERE  a.id=@orderId and c.payType=2

		  IF(@account IS NOT NULL)
		  BEGIN
			if(@account>0)
			exec dbo.p_addAccountOpLogBySystem @memberId,@account,3,'删除订单',0
		  END
		
		IF(@TScore IS NOT NULL)
		BEGIN
			if(@TScore>0)
			exec dbo.p_addScoreOpLog @memberId,@TScore,9,'删除订单'
		END	
		UPDATE dbo.tb_order SET  isUpdate=0,isDelete=1,deleteManId=@deleteManId  WHERE id=@orderId --删除原定单
	
		--计算物流分拣订单数
 		DECLARE  @count INT
		DECLARE @distributeId INT 
		SELECT @distributeId=MAX(distributeId) FROM erp.dbo.tb_orderDistribute WHERE orderId=@orderId
	
		IF(@distributeId is null) SET @distributeId=0
		SELECT @count=count(*) from Supermarket.dbo.tb_order WHERE ( deliverManId>0 or ( deliverManId<=0 and   isdelete=1)) and id in(
		SELECT orderId FROM erp.dbo.tb_orderDistribute WHERE distributeId=@distributeId)

		UPDATE  erp.dbo.tb_Distribute set sortingCount=@count WHERE ID=@distributeId
		
		UPDATE dbo.tb_memberGift  SET isUse=0,useOder=0 WHERE useOder=@orderId 
		UPDATE dbo.tb_giftCard SET isUse=0,useOder=0 WHERE useOder=@orderId--礼券返还
		
		IF(@inAccount>0)
			EXEC  p_addAccountOpLogBySystem @memberId,@inAccount,4,'已付款订单',@deleteManId
		IF(@inBackPrice>0)
			INSERT INTO tb_payOrderBackPrice (orderId,orderCode,needBackPrice,addMan) VALUES(@orderId,@orderCode,@inBackPrice,@deleteManId)
		SET @returnValue=1
	COMMIT TRAN
	END
        -- SELECT @returnValue