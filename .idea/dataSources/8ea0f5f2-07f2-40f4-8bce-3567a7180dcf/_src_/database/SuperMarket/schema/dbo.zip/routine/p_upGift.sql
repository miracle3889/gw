/*--------------------------------更新礼券信息--------------------------------*/
CREATE  PROCEDURE p_upGift @giftL VARCHAR(200),@orderId INT 
AS
	if exists 
	(select * from tempdb.dbo.sysobjects where id =object_id('tempdb.dbo.#T1'))
			drop table #T1
	CREATE TABLE #T1(giftId int NULL)
	DECLARE @end INT
	SET @end=-1
	WHILE(@end!=0)
	BEGIN
		DECLARE @giftId INT
		SET @end=charindex(',',@giftL)
		IF(@end=0)
		break
		SET @giftId=SUBSTRING(@giftL,1,@end-1)
		SET @giftL=SUBSTRING(@giftL,@end+1,LEN(@giftL)-@end)
		INSERT INTO #T1(giftId) VALUES(@giftId)
	END

	--SELECT * FROM  #T1 
	
	UPDATE tb_memberGift SET isUse=1,useOder=@orderId WHERE 
	giftId IN(SELECT giftId FROM #T1)
	UPDATE tb_giftCard SET isUse=1,userTime=getDate(),useOder=@orderId WHERE id IN (SELECT giftId FROM #T1)

