CREATE VIEW dbo.v_backCauseEveryDay
AS
SELECT 日期, 城市Id, 城市, 原因, 数量, 价值 / 100 AS 价值, 类型
FROM dbo.tb_temp_backcauseEvery
