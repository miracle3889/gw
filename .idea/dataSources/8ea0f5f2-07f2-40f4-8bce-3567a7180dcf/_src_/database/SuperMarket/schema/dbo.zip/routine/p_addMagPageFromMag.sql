CREATE procedure p_addMagPageFromMag @magId int ,@pageNum int ,@issuesCode varchar(20),@tarPageNum int
as 
	declare @tarMagId int
	set @tarMagId=cast(@issuesCode as int)
	--select @tarMagId=id from tb_MagazineIs where issuesCode=@issuesCode
	insert into tb_magpage(magId,pageNum,saleCode,saleId,salePrice) 
	select @magId,@pageNum,saleCode,saleId,salePrice from tb_magpage
	where magId=@tarMagId and pageNum=@tarPageNum