create procedure p_addVisaOrder @totalCount int,@okCount int,@fileName varchar(50),@addManId int
as
	
	insert into tb_visaOrder(totalCount,okCount,fileName,addManId) values(@totalCount,@okCount,@fileName,@addManId)

	select scope_identity()
