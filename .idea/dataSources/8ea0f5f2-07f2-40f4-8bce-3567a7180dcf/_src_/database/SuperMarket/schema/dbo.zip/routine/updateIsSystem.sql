CREATE PROCEDURE updateIsSystem 
AS
	update tb_saleProduct set isDeleted=1 where productId in (
		-- select DISTINCT productId from erp..tb_productStock where isUndercarriage=0 group by productId having sum(productCount)<=0
		select distinct productId from tb_productAttribute group by productId having sum(productCount+allStockCount)<=0
	) and qhcllbId!=3 and isDeleted=0