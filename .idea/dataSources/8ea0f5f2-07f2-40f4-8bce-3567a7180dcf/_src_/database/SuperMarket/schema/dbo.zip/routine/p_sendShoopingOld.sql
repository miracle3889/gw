
CREATE        procedure p_sendShoopingOld
as 
	declare @memberId int
	declare @memberName varchar(200)
	declare @sendUrl nvarchar(500)
	declare @mobileNum varchar(50)
	declare @EMail varchar(200)
	declare @saleCode varchar(200)
	declare @saleCode0 varchar(200)
	declare @saleProductName varchar(200)
	declare @salePrice varchar(200)
	declare @nickname varchar(200)
	declare @i int
	set @i=0
	set @saleCode=''
	DECLARE authors_cursor CURSOR FOR
	
             select distinct  id,name,mobileNum,EMail,nickname from dbo.tb_member 
             where  id  in (select memberId from dbo.tb_shoppingBag where DATEDIFF(Hour, addDate, getdate())>24 and  DATEDIFF(Hour, addDate, getdate())<48)
            and Email like '%@%' and id not in(select id from tb_member where DATEDIFF(day, lastShoopingEmailDate, getdate())<15) 
	
             OPEN authors_cursor
	FETCH NEXT FROM authors_cursor 
	INTO @memberId,@memberName,@mobileNum,@EMail,@nickname
	WHILE @@FETCH_STATUS = 0
	BEGIN
		
		 if(@EMail is not null and  @EMail<>'')
			  begin
				if not EXISTS  (select 1 from tb_unsubscribe where email=@EMail) 
				begin
					declare @title varchar(200)
					if(@memberName is null or @memberName ='')
					begin
						if(@nickname is null or @nickname ='')
						set @nickname=''
						else
						set @nickname=@nickname+'，'
					end
					else
						set @nickname=@memberName+'，'
						set @title=@nickname+'您遗留在购物车中的商品'
						 set @sendUrl='http://www.yoyo18.com/web/emailGetShopCart.yoyo?memberId='+cast(@memberId as varchar(50))
	 					exec p_sendEmail2 @sendUrl,@EMail,@title
				end
			end
		update tb_member set lastShoopingEmailDate=getDate()  where id=@memberId
		FETCH NEXT FROM authors_cursor 
		INTO @memberId,@memberName,@mobileNum,@EMail,@nickname
	END
	
	CLOSE authors_cursor
	DEALLOCATE authors_cursor