/*-------------------索要目录册----------------------------------*/
CREATE  PROCEDURE  addMuLu @memberId int,@email varchar(60),@isOK INT
AS
	DECLARE @isGive INT
	set @isGive = 0
	SELECT @isGive=id FROM tb_mulu WHERE memberId=@memberId
	-- 0不要目录册 1要目录册
	IF (@isOK=0)
	BEGIN
		delete tb_mulu where memberId=@memberId
	END
	ELSE
	BEGIN
		-- 要目录册，@isGive=1已经存在，不操作 =0 插入
		IF (@isGive=0)
		BEGIN
			INSERT INTO tb_mulu (memberId, email) VALUES (@memberId,@email)
		END
	END