CREATE procedure p_setDeliverPrice @orderId int,@deliverPriceType int
as
	declare @transport int
	select @transport =deliverPay  from erp..tb_deliverPayShow where id=@deliverPriceType
	if(@transport is null) set @transport=0
	if exists(select 1 from tb_orderDeliverPay where orderId=@orderId)
	begin
		update tb_orderDeliverPay set transport =@transport where orderId=@orderId
	end
	else
	begin
		insert into tb_orderDeliverPay(orderId,transport,proxy) values (@orderId,@transport,0)	
	end