/*-------------------添加注册会员-------------------------*/
CREATE PROCEDURE p_addMemberTaobao @EMail VARCHAR(200),@name VARCHAR(50),@phoneNum VARCHAR(50),@mobileNum VARCHAR(50),@state VARCHAR(50),@city VARCHAR(50),@regional VARCHAR(50),
		@addr VARCHAR(200),@post VARCHAR(50),@nickname VARCHAR(32)
AS
	DECLARE @memberId INT
	DECLARE @provinceId INT
	DECLARE @cityId INT
	DECLARE @regionalId INT	

	if @EMail is null set @EMail=''
	if @phoneNum is null set @phoneNum=''
	SELECT @memberId=memberId FROM tb_taobaoMember   WHERE  taobaoNickname=@nickname
	if(@memberId is null) set @memberId=0
	IF(@memberId>0)
	BEGIN
		select @memberId 
	END
	ELSE
	BEGIN
			select @provinceId=pId,@cityId=id from tb_city  where name =@city
			if(@provinceId is null )
			set @provinceId=0
			
			if(@provinceId=0)
			begin
				set @provinceId=4
				set @cityId=26
				set @regionalId=236
			end
			else
			begin
				select @regionalId=id  from tb_regional where regional=@regional and pid=@cityId
				if(@regionalId is null )
				set @regionalId=0
				if(@regionalId=0)
					select top 1 @regionalId=id  from tb_regional where pid=@cityId
				if(@regionalId is null )
				set @regionalId=0
			end
			
			set @addr=@state+'|'+@city+'|'+@regional+'|'+@addr
			
			INSERT INTO dbo.tb_member(EMail,type,name,mobileNum,phoneNum,homeAddr,post,source,comeFrom,provinceId,cityId,homeAddrRegional)
			VALUES (@EMail,1,@name,isnull(@mobileNum,''),isnull(@phoneNum,''),@addr,@post,'taobao','taobao',@provinceId,@cityId,@regionalId)
			SET @memberId=scope_identity()
			
			insert into  tb_taobaoMember(memberId,taobaoNickname) values(@memberId,@nickname)
			select @memberId
	END