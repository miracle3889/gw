


/*-------------------------------------生成财付通商品--------------------------------*/
CREATE      procedure p_web_setnewCFTProduct 
AS

	
	declare @id int
	declare @CFTid int
	set @CFTid=0
	declare @productId int
	declare @insertProductId int
	declare @insertProductPayId int
	declare @problemSolvingId int
	declare @problemSolvingId1 int
	declare @productPayId int
	declare @hotspotId int
	declare @hotspotId1 int
	declare @productPay int
	declare @returnValue int
	declare @returnValue1 int


	declare saleCount cursor for select id from dbo.tb_saleProduct where saleTypeId=1 
		and productId not in (
			 select productId from dbo.tb_saleProduct where id in (
0
			)
		)
  -- and isDeleted=0 
	open saleCount
	fetch NEXT from saleCount into @id

	while @@fetch_status=0
	begin
		set @productId=0
		set @insertProductId=0
		set @insertProductPayId=0
		set @problemSolvingId=0
		set @problemSolvingId1=0
		set @productPayId=0
		set @hotspotId=0
		set @hotspotId1=0
		set @productPay=0
		set @returnValue=0
		set @returnValue1=0
		--首先取tb_saleProduct的productId.如果tb_saleProduct表里没有saleTypeId=16的商品记录.则插入.否则修改
		select @productId=productId from tb_saleProduct where id=@id
		set @CFTid=0
		select @CFTid=id from tb_saleProduct where productId=@productId and saleTypeId=16
		if(@CFTid is null)
		set @CFTid=0
		---if (@CFTid!=16709 and @CFTid!=13701 and @CFTid!=18336)
		--begin 
			if @CFTid<=0
			begin
				insert into tb_saleProduct (saleCode,productId,oldPrice,remark,saleCount,salePlanId,saleTypeId,
					isDeleted,htmlPath,keyWords,disCript,realPrice,adminSetCount,oldCount,viewCount,preKey,
					mRemark,webCategoryId,capabilityId,materialId,brandId,themeId,skinCareTypeId,cosmeticsId,qhcllbId,
					groupId,specialPrice,validDate) select saleCode,productId,oldPrice,remark,saleCount,salePlanId,saleTypeId,
					isDeleted,htmlPath,keyWords,disCript,realPrice,adminSetCount,oldCount,viewCount,preKey,
					mRemark,webCategoryId,capabilityId,materialId,brandId,themeId,skinCareTypeId,cosmeticsId,qhcllbId,
					groupId,specialPrice,validDate from tb_saleProduct where id=@id
	
				SET @insertProductId=SCOPE_IDENTITY() --得到刚刚插入的id 并修改
	--下面35行
				update tb_saleProduct set saleCode='J'+CAST(@insertProductId AS VARCHAR(10)),saleTypeId=16,htmlPath='J'+CAST(@insertProductId AS VARCHAR(10))+'.html' where id=@insertProductId
				
				insert into tb_saleProductPay (saleProductId,payStyleId,payValue) select saleProductId,payStyleId,payValue from tb_saleProductPay where saleProductId=@id
				set @insertProductPayId=SCOPE_IDENTITY() --得到刚刚插入的id 并修改
				select top 1 @productPay=payValue from tb_saleProductPay where id=@insertProductPayId
				update tb_saleProductPay set saleProductId=@insertProductId,payValue=cast(ROUND(((@productPay)/100.0*1),0) as  int)*100 where id=@insertProductPayId
				update tb_saleProduct set realPrice=cast(ROUND(((@productPay)/100.0*1),0) as  int)*100 where id=@insertProductId
	/***肌肤问题表\明星推荐表更新***/
	
				delete tb_saleProblemSolving where saleId=@insertProductId 
				insert into tb_saleProblemSolving (saleId,problemSolvingId) select @insertProductId,problemSolvingId from tb_saleProblemSolving where saleId=@id
				
				delete tb_saleHotspot where saleId=@insertProductId
				insert into tb_saleHotspot (saleId,hotspotId) select @insertProductId,hotspotId from tb_saleHotspot where saleId=@id
				
				delete tb_saleCapabilityCategory where saleId=@insertProductId
				insert into tb_saleCapabilityCategory (saleId,capabilityCategoryId) select @CFTid,capabilityCategoryId from tb_saleCapabilityCategory where saleId=@id
				
			end  
			else
			begin
				update tb_saleProduct set productId=t.productId,oldPrice=t.oldPrice,remark=t.remark,saleCount=t.saleCount,salePlanId=t.salePlanId,
				isDeleted=t.isDeleted,htmlPath='J'+CAST(@CFTid AS VARCHAR(10))+'.html',keyWords=t.keyWords,disCript=t.disCript,oldCount=t.oldCount,preKey=t.preKey,
				mRemark=t.mRemark,webCategoryId=t.webCategoryId,capabilityId=t.capabilityId,materialId=t.materialId,brandId=t.brandId,themeId=t.themeId,skinCareTypeId=t.skinCareTypeId,cosmeticsId=t.cosmeticsId,qhcllbId=t.qhcllbId,
				groupId=t.groupId,specialPrice=t.specialPrice,validDate=t.validDate from (select productId,oldPrice,remark,saleCount,salePlanId,
				isDeleted,htmlPath,keyWords,disCript,oldCount,preKey,
				mRemark,webCategoryId,capabilityId,materialId,brandId,themeId,skinCareTypeId,cosmeticsId,qhcllbId,
				groupId,specialPrice,validDate from tb_saleProduct where id=@id ) as t where id=@CFTid 
				
				select @productPayId=id from tb_saleProductPay where saleProductId=@CFTid
				--if (@CFTid<>16230)
				--begin
					if @productPayId=0
					begin
						insert into tb_saleProductPay (saleProductId,payStyleId,payValue) select saleProductId,payStyleId,payValue from tb_saleProductPay where saleProductId=@id
						set @insertProductPayId=SCOPE_IDENTITY() --得到刚刚插入的id 并修改
						select top 1 @productPay=payValue from tb_saleProductPay where id=@insertProductPayId
						update tb_saleProductPay set saleProductId=@CFTid,payValue=cast(ROUND(((@productPay)/100.0*1),0) as  int)*100 where id=@insertProductPayId
						update tb_saleProduct set realPrice=cast(ROUND(((@productPay)/100.0*1),0) as  int)*100 where id=@CFTid
					end
					else
					begin
						select top 1 @productPay=payValue from tb_saleProductPay where saleProductId=@id
						update tb_saleProductPay set payValue=cast(ROUND(((@productPay)/100.0*1),0) as  int)*100  where saleProductId=@CFTid
						update tb_saleProduct set realPrice=cast(ROUND(((@productPay)/100.0*1),0) as  int)*100 where id=@CFTid
					end
				--end
	
	/***肌肤问题表\明星推荐表更新***/
	
				delete tb_saleProblemSolving where saleId=@CFTid 
				insert into tb_saleProblemSolving (saleId,problemSolvingId) select @CFTid,problemSolvingId from tb_saleProblemSolving where saleId=@id
				
				delete tb_saleHotspot where saleId=@CFTid
				insert into tb_saleHotspot (saleId,hotspotId) select @CFTid,hotspotId from tb_saleHotspot where saleId=@id
				
				delete tb_saleCapabilityCategory where saleId=@CFTid
				insert into tb_saleCapabilityCategory (saleId,capabilityCategoryId) select @CFTid,capabilityCategoryId from tb_saleCapabilityCategory where saleId=@id
	
			end
		--end
		
		fetch NEXT from saleCount into @id 
	end 	


	close saleCount
	deallocate saleCount

delete tb_searchSaleEntityCFT where id in (
select b.id from tb_searchSaleEntityProtityCFT a, tb_searchSaleEntityCFT b where a.saleCode=b.saleCode and webCategoryId=7
)