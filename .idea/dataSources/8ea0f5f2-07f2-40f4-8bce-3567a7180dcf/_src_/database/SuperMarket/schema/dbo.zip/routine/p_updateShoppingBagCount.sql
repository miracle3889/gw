
/*--------------购物车上商品数量修改------------------------------------------*/
CREATE     PROCEDURE p_updateShoppingBagCount @buyCount INT,@id INT
                                 
AS
   DECLARE @returnValue INT
     SET @returnValue=0
    /*    BEGIN TRAN
	      DECLARE @productId INT
	      DECLARE @saleProductId INT
	      DECLARE @realCount INT
                  DECLARE @DDlCount INT
                  DECLARE @colorId INT 
                  DECLARE @metricsId INT 
	       DECLARE @oldCount  INT 

	    SELECT @saleProductId=saleProductId,@colorId=colorId,@metricsId=metricsId ,
                @oldCount= buyCount  from dbo.tb_shoppingBag where id=@id

	    SELECT @productId=productId FROM tb_saleProduct WHERE id=@saleProductId
	   
                SELECT @realCount=SUM(productCount) FROM ERP.dbo.tb_productStock   WHERE productId=@productId AND colorId=@colorId AND metricsId=@metricsId   
		
	    SELECT @DDlCount=SUM(a.buyCount) FROM v_allBuyProductNew a  
		   WHERE a.saleProductId=@productId AND a.colorId=@colorId AND a.metricsId=@metricsId   
	   IF(@realCount IS NULL)
	  BEGIN
		SET @realCount=0
	  END
	    IF(@DDlCount IS NULL)
                 BEGIN 
		SET @DDlCount=0--63846

                 END
	  print cast((@realCount) as  varchar(20))
 print cast((@DDlCount) as  varchar(20))
	 print cast((@buyCount) as  varchar(20))
 print cast((@oldCount) as  varchar(20))
	    IF((@realCount-@DDlCount)>=(@buyCount-@oldCount))
                 BEGIN               
		     update tb_shoppingBag set buyCount=@buyCount,isStock=1 where id=@id
	   	     SET @returnValue=1
               END
    COMMIT TRAN*/
	    update tb_shoppingBag set buyCount=@buyCount  where id=@id
	   	     SET @returnValue=1
   	 SELECT @returnValue