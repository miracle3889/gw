/*-------------------会员-------------------------*/
CREATE PROCEDURE p_web_updateMemberNum @id INT,@EMail VARCHAR(200),@psw VARCHAR(50),@recommendId INT,@name VARCHAR(50),@mobileNum VARCHAR(50),@homeAddr VARCHAR(200),@post VARCHAR(50),@ip VARCHAR(50),@QQ VARCHAR(16),@MSN VARCHAR(50),@nickname VARCHAR(50),@provinceId int,@cityId int,@homeAddrRegional int  
AS
	DECLARE @COUNT INT
	DECLARE @returnValue INT
	SET @returnValue=0
	DECLARE @score INT
	SET @score=0
	SELECT @COUNT=COUNT(*) FROM dbo.tb_member WHERE EMail=@EMail
	IF(@COUNT>0)
	BEGIN
		SET @returnValue=-1
	END
	ELSE
	BEGIN
		UPDATE dbo.tb_member 
		SET EMail=@EMail,psw=dbo.md5(@psw),type=1,recommendId=@recommendId,name=@name,homeAddr=@homeAddr,post=@post,regIp=@ip,QQ=@QQ,MSN=@MSN,nickname=@nickname,provinceId=@provinceId,cityId=@cityId,homeAddrRegional=@homeAddrRegional,complanyAddrRegional=@homeAddrRegional  
		WHERE id=@id
		SET @returnValue=scope_identity()
		SELECT @score=id from tb_scoreOpLog where memberId=@id and opType=55
		IF (@score=0)
		BEGIN
			exec p_addScoreOpLog @id, 100, 55, '注册送积分'
		END
		IF(@@ERROR<>0)
		BEGIN	
			SET @returnValue=0
		END
	END
	SELECT @returnValue