

CREATE            procedure p_sendshoopingMsg
as 
	declare @memberId int
	declare @saleId  int
	declare @productId  int
	declare @realCount  int
	declare @DDlCount  int
	declare @buyCount  int
	declare @colorId  int
	declare @metricsId  int
	declare @mobileNum varchar(50)
	declare @saleProductName varchar(200)
	declare @content nvarchar(500)
	
	
	DECLARE authors_cursor CURSOR FOR
	select memberId,mobileNum,max(a.id) from dbo.tb_shoppingBag  a 
	inner join tb_member b on a.memberId=b.id where  convert(varchar(10),dateAdd(day,-5,getDate()),120)= convert(varchar(10),a.addDate,120)
	 and b.mobileNum!='' and  len( b.mobileNum)=11
	and mobileNum not in(select mobileNum from tb_blackNum) and b.source<>'CFT'  group by memberId,b.mobileNum
	
	OPEN authors_cursor
	FETCH NEXT FROM authors_cursor 
	INTO @memberId,@mobileNum,@saleId
	WHILE @@FETCH_STATUS = 0
	BEGIN
		select @productId=b.id,@saleProductName=b.name,@colorId=c.colorId, @metricsId=c.metricsId,@buyCount=c.buycount  from tb_saleProduct a 
		inner join erp.dbo.tb_product b on a.productId=b.id
		inner join tb_shoppingBag c on c.saleProductId=a.id
		where c.id=@saleId
		
		SELECT @realCount=SUM(productCount) FROM ERP.dbo.tb_productStock   WHERE productId=@productId and colorId=@colorId AND metricsId=  @metricsId  
	    	 SELECT @DDlCount=SUM(a.buyCount) FROM v_allBuyProductNew a 
		WHERE a.saleProductId=@productId AND a.colorId=@colorId AND a.metricsId=  @metricsId   
		   IF(@realCount IS NULL)
		 BEGIN
			SET @realCount=0
		END
	 	   IF(@DDlCount IS NULL)
               	  BEGIN 
			SET @DDlCount=0
               	  END
		  IF(@realCount-@DDlCount>=@buyCount)
		begin
			set @content='优邮提示：您遗留在购物车中的商品'+@saleProductName+'库存已告警，如有需要请尽快下单。www.yoyo18.com' 
			 if(@mobileNum is not null )
				 begin
					if(len(@mobileNum)>=11 )
						begin
							 exec p_sendMsg @mobileNum,@content
							
				             	 end
		                	 end
		end
		FETCH NEXT FROM authors_cursor 
		INTO @memberId,@mobileNum,@saleId
	END
	
	CLOSE authors_cursor
	DEALLOCATE authors_cursor