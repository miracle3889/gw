CREATE PROCEDURE p_getWeekNeedproduct
AS 
	--未来一周销售排行
	
	select a.productCode,d.name as productName,e.codeName as colorName,f.codeName as metricsName ,a.saleCount,a.saleCount*c.old7/(case c.pre15 when 0 then 10000 else c.pre15 end) as old7Sale,
	b.productCount,isnull(g.inCount,0) as  inCount,isnull(h.buyCount,0) as  buyCount,n.name as userName
	from tb_15DaysSaleReport a
	inner join erp..tb_productStock b on a.productCode=b.productShelfCode and addDate >=dateAdd(day,-1,getDate())
	inner join 
	(
	select c.productId ,sum( case when costTime<getDate() then  (printCost*b.coefficient)/100 else 0 end) as pre15,
	sum( case when costTime<getDate() then 0 else   (printCost*b.coefficient)/100 end )  as old7
	from tb_productPrintCost a
	inner join tb_magSourceRemark b on a.magId=b.id 
	inner join tb_saleproduct c on c.id=a.saleId
	where costTime>=dateAdd(day,-16,getDate()) and costTime<=dateAdd(day,6,getDate()) 
	group by c.productId )  c on b.productId=c.productId 
	inner join erp..tb_product d on d.id=b.productId
	inner join erp..tb_productColorCode e on e.id=b.colorId
	inner join erp..tb_productMetricsCode f on f.id=b.metricsId
	left join 
	(
		select a.productid,b.colorId,b.metricsid,sum(case when a.buyStatus=4 then 0 else  b.buyCount end ) as inCount,max(a.id) as buyProductId
		from  erp.dbo.tb_buyProductList a
		inner join erp.dbo.tb_buyProductProtity b on  a.id=b.buyProductId  and isDeleted<>1
		group by a.productid,b.colorId,b.metricsid
	) g on g.productId=b.productId and g.colorId=b.colorId and g.metricsId=b.metricsid
	left join 
	(
		select  b.productId,b.colorId,b.metricsId,sum(b.buyCount) as buyCount from tb_order a
		inner join tb_orderSaleproduct b on a.id=b.orderId and a.orderstatus=1 and a.isdelete<>1 
	 group by b.productId,b.colorId,b.metricsId 
	) h on  h.productId=b.productId and h.colorId=b.colorId and h.metricsId=b.metricsid 
	left join erp.dbo.tb_buyProductList m  on m.id=g.buyProductId
	left join erp..tb_user n on n.id=m.buyUserId
	order by (a.saleCount*c.old7/(case c.pre15 when 0 then 10000 else c.pre15 end))+isnull(h.buyCount,0)-b.productCount desc