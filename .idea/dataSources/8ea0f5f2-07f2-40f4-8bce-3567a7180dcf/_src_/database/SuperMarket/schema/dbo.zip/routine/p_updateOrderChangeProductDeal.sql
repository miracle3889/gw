CREATE  procedure p_updateOrderChangeProductDeal @orderChangeProductId int,
							@dealMan int,
							@dealResult int,
							@dealRemark VARCHAR(200)
as
	declare @productId int
	declare @orderBackProductId int
	declare @saleId int
	declare @dealResult2  int
	declare @colorId int
	declare @metricsId int
	
	select @dealResult2=dealResult,@orderBackProductId=orderBackProductId from tb_changeProduct where id=@orderChangeProductId
	
	select @saleId=saleId,@colorId=colorId,@metricsId=metricsId from tb_orderBackProduct where  id=@orderBackProductId
	begin
		update tb_changeProduct  set dealTime=getDate(),dealman=@dealMan,
		dealResult=@dealResult,dealRemark=@dealRemark where id=@orderChangeProductId
		if(@dealResult=1 and @dealResult2=0)
		begin
			select @productId=productId from tb_saleProduct where id=@saleId
			update erp.dbo.tb_productStock set productCount=productCount+1 
			where productId=@productId and colorId=@colorId and metricsId=@metricsId
		end
		
	end
