/*----------------添加定单--------*/
CREATE   PROCEDURE p_addOrderNewPreSale      
				     @payType INT,
				     @deliverType INT,
				     @deliverPrice INT,
				     @memberId INT,
				     @orderStatus INT, 
				     @doMan INT,
				     @reMark VARCHAR(200),
				     @orderSource INT,
				     @magazineCode VARCHAR(50),
				     @receviceMan VARCHAR(50),
				     @post VARCHAR(50),
				     @receviceAddr1 VARCHAR(200),
				     @receviceAddr2 VARCHAR(200),
				     @receviceMobile VARCHAR(50),
				     @addrId INT,
				     @useAccount INT,
				     @getScore INT,
				     @regionalId1 int,
				     @regionalId2 int,
				     @provinceId INT,
				     @cityId INT,
				     @useGift VARCHAR(500),
				     @giftPice INT,
				     @magSource INT,
				     @magSourceRemark VARCHAR(50),
				     @isTransport int ,
				     @isProxy int
AS
	DECLARE @code VARCHAR(50)	
	DECLARE @magSourceCodeFirst VARCHAR(50)
	DECLARE @score INT 
	DECLARE @returnId INT
	DECLARE @account INT
	DECLARE @tempScore INT
	declare @return1 int
	declare @productCountTemp int
	SET @productCountTemp=0
	SET @returnId=0
	--if exists(select 1 from dbo.tb_shoppingBag a inner join tb_saleProduct b on a.saleProductId=b.id and b.qhcllbId=5 WHERE memberId=@memberId)
	if exists(select 1 from dbo.tb_shoppingBag  WHERE memberId=@memberId and saleProductId in(select saleId from tb_preSaleProduct))
	BEGIN
		/*----------下单条件满足------------------------*/
	
		if(@magSourceRemark is not null)
			begin
				set  @reMark=@magSourceRemark+'  '+@reMark --备注显示中添加 杂志编号
			end
				
		if(@useAccount is null) set @useAccount=0

		if(@giftPice is null) set @giftPice=0
		IF(@payType!=1)set @orderStatus=6 --待付款验证
				
		declare @freeType int
		set @reMark=@reMark+'免快递费 免手续费'
		set @freeType=3

				--计算会员订购数
				declare @buyCount int
					
				select @buyCount=count(*) from tb_order where isdelete<>1  and memberId  
					in(
						select id from tb_member where mobileNum 
						in
							(
								select mobileNum from tb_member where id=@memberId    and mobileNum <>'' and mobileNum is not null 
								union all 
								select phoneNum from tb_member where id=@memberId  and phoneNum <>'' and phoneNum is not null 
							)
						union all  
						select id from tb_member where phoneNum 
						in
							(
								select mobileNum from tb_member where id=@memberId    and mobileNum <>'' and mobileNum is not null 
								union all 
								select phoneNum from tb_member where id=@memberId  and phoneNum <>'' and phoneNum is not null 
							)
					) 
				set @buyCount=@buyCount+1
				
				BEGIN TRAN 
				EXEC p_geOrderCodeNew 1,@code OUTPUT --得到订单号
				SET @useAccount=0
				SET @giftPice=0
				/*---------------------生成定单信息----------------------------------*/
				INSERT INTO dbo.tb_order(orderCode,payType,deliverType,deliverPrice,memberId,orderStatus,
							   doMan,reMark,orderSource,magazineCodeS,receviceMan,post,
							receviceAddr1,receviceAddr2,receviceMobile,addrId,useAccount,
						getScore,regionalId1,regionalId2,provinceId ,cityId,useGift,magSource,magSourceRemark,buyCountOrder,freeType)
				VALUES(@code,@payType,@deliverType,@deliverPrice,@memberId,@orderStatus,
					 @doMan,@reMark,@orderSource,@magazineCode,@receviceMan,@post,
				@receviceAddr1,@receviceAddr2,@receviceMobile,@addrId,@useAccount,
				@getScore,@regionalId1,@regionalId2,@provinceId ,@cityId,@giftPice, @magSource,@magSourceRemark,@buyCount,@freeType)
	
				SET @returnId=SCOPE_IDENTITY() --得到刚刚插入的定单id 
				
				insert into tb_orderstatusHis(orderId,orderstatus,doMan) values(@returnId,@orderStatus,@doMan)
				
				if(@magSourceCodeFirst is  null or  @magSourceCodeFirst='')
				begin
					set @magSourceCodeFirst=@magSourceRemark
				end
				
				
				/*---------------------------插入定单单件商品-------------------------------------------*/
				INSERT INTO dbo.tb_orderSaleProduct(orderId,colorId,metricsId,saleProductCode,
				saleProductId,buyCount,isRand,stockPrice,productId,needInType,isRegister)			
	
			        SELECT @returnId,colorId,metricsId,productCode,saleProductId,sum(buyCount),isRand,c.stockPriceReal,b.productId,isNeedIn,isRegister
				FROM 	dbo.tb_shoppingBag a 
				inner join tb_saleProduct b on a.saleProductId=b.id --and b.qhcllbId=5
				inner join erp.dbo.tb_product c on b.productId=c.id
				WHERE memberId=@memberId AND groupPh=0 and a.buyCount>0 and   b.id in(select saleId from tb_preSaleProduct)
				group by colorId,metricsId,productCode,saleProductId,isRand,c.stockPriceReal ,b.productId,isNeedIn,isRegister
				order by productCode

	



				/******************添加单件商品价格到tb_orderSaleProductPay***************************/
				insert into dbo.tb_orderSaleProductPay(orderSaleProductId,payType,payValue)
				select a.id,payStyleId,(payValue*80/10000)*100
				from tb_orderSaleProduct a
				inner join dbo.tb_saleProductPay b on b.saleProductId=a.saleProductId
				where a.orderId=@returnId
				
				/*-------------------扣除积分-----------------------------*/
				if(@score>0)
				begin
					declare @getScoreX int
					set @getScoreX=(@score*(-1))
					exec  p_addScoreOpLog @memberId,@getScoreX,5,@code
				end
				
				
				DELETE  FROM tb_shoppingBag WHERE memberId=@memberId and saleProductId in(select saleId from tb_preSaleProduct)  --删除购物车中单件商品 				
				if(@magazineCode='CFT')
				begin
					exec p_computeOrderPriceCFT @returnId --核算运费    
				end
				else
				begin
					exec p_computeOrderPrice @returnId --核算运费         
				end
				
		COMMIT TRAN 			

		UPDATE tb_member SET payType=@payType,deliverType=@deliverType,magSourceCode=@magSourceRemark ,magSourceCodeFirst=@magSourceCodeFirst
				WHERE id=@memberId --设置用户最后一次的付费方式和送货方式

	insert into tb_preOrder(orderId) values(@returnId)
	SELECT @returnId
	END
	else
	begin
	select 0
	end