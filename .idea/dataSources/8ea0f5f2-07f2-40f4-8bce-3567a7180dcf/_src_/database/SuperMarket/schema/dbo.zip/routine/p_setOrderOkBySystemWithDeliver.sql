CREATE procedure p_setOrderOkBySystemWithDeliver @orderCode varchar(50),@price int,@transport int,@proxy int
as
	declare @oldPrice int
	declare @orderId int
	declare @returnValue int
	if(@price>=0)
	begin
		-- @orderId=id, 
		select  @orderId=max(id) ,@oldPrice=sum(productPrice+deliverPrice-useAccount-useGift) from tb_order 
		where (otherOrder=@orderCode or orderCode=@orderCode)

		if(@price=@oldPrice)
		begin
			DECLARE authors_cursor CURSOR FOR
			select  id  from tb_order 	where (otherOrder=@orderCode or orderCode=@orderCode)
			OPEN authors_cursor
			FETCH NEXT FROM authors_cursor 
			INTO @orderId 
			WHILE @@FETCH_STATUS = 0
			BEGIN
				update tb_order set orderstatus=3,visaTime=getDate(),isNotGetPrice=0 where id=@orderId
				exec SuperMarket.dbo.p_updateOrderBackPrice @orderId
				set @returnValue=1				
				
				FETCH NEXT FROM authors_cursor 
				INTO @orderId 
			END		
			CLOSE authors_cursor
			DEALLOCATE authors_cursor
		end
		else
		begin
			update tb_order set isNotGetPrice=0,visaTime=getDate() where id in  (select id from  tb_order where (otherOrder=@orderCode or orderCode=@orderCode )  )   and isNotGetPrice=1 

			set @returnValue=0
		end
	end
	if EXISTS (select 1 from tb_orderDeliverPay where orderId=@orderId)
	BEGIN
		UPDATE tb_orderDeliverPay SET transport= @transport,proxy= @proxy WHERE orderId=@orderId
	END
	ELSE
	BEGIN
		INSERT INTO tb_orderDeliverPay(orderId,transport,proxy) VALUES(@orderId,@transport,@proxy)
	END
	select @returnValue