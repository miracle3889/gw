/*-------------退回商品核算并给以积分-------------------------------*/
CREATE     PROCEDURE p_addOrderScore @orderId INT
AS 
	DECLARE  @realPrice INT,
		 @backPrice INT,
		 @memberID INT,
		 @SCOREMONEY INT, --积分换算标准
		 @orderCode varchar(50)
	SET @SCOREMONEY=100
		 
	
	SELECT @realPrice=SUM(b.payValue*a.buyCount),@backPrice=SUM(b.payValue*a.backCount) 
	FROM dbo.tb_orderSaleProduct a
	INNER JOIN dbo.tb_orderSaleProductPay b ON a.id=b.orderSaleProductId 
	WHERE b.payType=1 AND a.orderId=@orderId   --得到定单总价格
	
	DECLARE @orderStatus INT
	DECLARE @deliverPrice INT
	DECLARE @provinceId INT
	SELECT @orderStatus=orderStatus ,@orderCode=orderCode, @deliverPrice=deliverPrice,@provinceId=provinceId  FROM tb_order WHERE id=@orderId
	

	SELECT @memberID=memberId FROM tb_order WHERE id=@orderId --得到定单人
	declare @getScore int
	set @getScore=((@realPrice-@backPrice)/@SCOREMONEY)
	exec  p_addScoreOpLog @memberID,@getScore,1,@orderCode