/*----------------------修改销售组合---------------------------*/
CREATE procedure p_updateGroupSale @name varchar(50),
				@salePrice varchar(50),
				@groupRemark varchar(500),
				@picPath varchar(500),
				@totalCount int,
				@requireCount int,
				@groupId int,
				@saleType int
as
  declare @returnId int
  declare @salePrice2 int
  declare @requireCount2 int
 declare @payValue int
  if(@picPath='')
	begin
		  update dbo.tb_saleGroup set name=@name,salePrice=@salePrice,groupRemark=@groupRemark,totalCount=@totalCount,requireCount=@requireCount ,saleType=@saleType
		   where id=@groupId
	end
  else
	begin
		 update dbo.tb_saleGroup set name=@name,salePrice=@salePrice,groupRemark=@groupRemark,
			picPath=@picPath,totalCount=@totalCount,requireCount=@requireCount  ,saleType=@saleType
		   where id=@groupId

		update tb_searchSaleEntity set picPath=@picPath where saleCode='GA'+CAST(@groupId AS char(20)) 
	end

   select @salePrice2=salePrice,@requireCount2=requireCount from dbo.tb_saleGroup where id=@groupId
   set @payValue=@salePrice2/@requireCount2

   update tb_saleProductPay set payValue=@payValue  where saleProductId in(select id from tb_saleProduct where groupId=@groupId and groupId>0)
  set @returnId=1
  select @returnId
