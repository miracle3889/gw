

/*----------------------添加商品到购物车-------------------*/
CREATE  procedure p_web_addProductToFavorites @memberId int,@saleCode varchar(50)
as
	--declare @returnValeu int
	--set @returnValeu=0
	declare @isHas int
	set @isHas=0
	select @isHas=count(*) from tb_favorites where memberId=@memberId and saleCode=@saleCode and isdelete=0
	if(@isHas=0)
	begin
		insert into tb_favorites(memberId,saleCode) values(@memberId,@saleCode)
	end
	else
	begin
		update tb_favorites set addDate=getDate() where memberId=@memberId and saleCode=@saleCode 
	end
	select 1