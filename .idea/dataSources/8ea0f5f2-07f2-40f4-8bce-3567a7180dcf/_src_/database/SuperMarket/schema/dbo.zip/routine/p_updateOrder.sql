

/*--------------修改定单信息------------------------*/
CREATE   PROCEDURE p_updateOrder @payType INT,@deliverType INT,
				@receviceMan VARCHAR(50),@post VARCHAR(50),
				@receviceAddr1 VARCHAR(200),@receviceAddr2 VARCHAR(200),
				@regionalId1 INT,@regionalId2 INT,
				@receviceMobile VARCHAR(50),@addrId INT,
				@provinceId INT,@cityId INT,@reMark VARCHAR(200),
				@orderId INT
AS
	BEGIN TRAN 
		DECLARE @orderStatus INT
		DECLARE @payTypeOld INT
		SELECT @orderStatus=orderStatus,@payTypeOld=payType FROM tb_order WHERE id= @orderId  --得到定单状态和付费类型
		
		UPDATE tb_order SET  deliverType=@deliverType,
				receviceMan=@receviceMan,post=@post,
				receviceAddr1=@receviceAddr1,receviceAddr2=@receviceAddr2,
				regionalId1=@regionalId1,regionalId2=@regionalId2,
				receviceMobile=@receviceMobile,addrId=@addrId,
				provinceId=@provinceId,cityId=@cityId,reMark=@reMark 
				WHERE id=@orderId  --修改定单信息
		if(@orderStatus=1 or @orderStatus=5 or @orderStatus=6)
		begin
			UPDATE tb_order SET  payType=@payType
				WHERE id=@orderId  --修改定单信息
		end
		--if EXISTS(select 1 from tb_order where orderstatus in(20,13) and id=@orderId)
		--begin
		--	update tb_order set isdelete=2 where  id=@orderId
		--end
		IF(@payType!=@payTypeOld)
		BEGIN
			IF(@payType!=1)
			BEGIN
				
				if EXISTS(select 1 from tb_order where orderstatus in(1,5) and id=@orderId)
					begin
						UPDATE tb_order SET orderStatus=6  WHERE id=@orderId  --修改定单状态为等待收款
				
						insert into tb_orderstatusHis(orderId,orderstatus,doMan,remark) values(@orderId,6,1,'修改订单付费方式')
						delete from  erp..tb_canDistributeOrder where orderId =@orderId
					end
				
			END
		END
		 exec p_computeOrderPrice @orderId
	COMMIT TRAN