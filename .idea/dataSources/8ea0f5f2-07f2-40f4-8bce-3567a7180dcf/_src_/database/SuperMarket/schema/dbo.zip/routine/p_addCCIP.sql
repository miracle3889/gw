/*-------------------增加CC攻击IP----------------------------------*/
CREATE  PROCEDURE  p_addCCIP @ip1 varchar(32),@ip2 varchar(32)
AS
	DECLARE @returnValue INT

	set @returnValue=0
	SELECT @returnValue=id FROM dbo.ccIP WHERE ip2=@ip2
	IF(@returnValue=0)
	BEGIN
		insert into ccIP (ip1, ip2) values (@ip1,@ip2)
	END
	--SELECT @returnValue