



/*---------------------更改定状态--------------------------------------*/
CREATE  PROCEDURE p_changeOrderStatusCheck @orderId INT,@orderStatus INT,@userId int,@checkRemark varchar(500)
AS 
   declare @olderStatus int
   declare @memberId int
   declare @mobileNum varchar(50)
   declare @content nvarchar(500)
   declare @magSourceRemark varchar(50)
   declare @cityId int
   select @olderStatus=orderStatus,@magSourceRemark=magSourceRemark,@content=orderCode,@memberId=memberId,@cityId=cityId from tb_order where id=@orderId
   if(@olderStatus=5 and @cityId=1 and @magSourceRemark='Y')
   begin
	  if(@orderStatus!=19)
	  begin
             select @mobileNum=mobileNum from dbo.tb_member where id=@memberId and mobileNum not in(select mobileNum from tb_blackNum)
	     if(@mobileNum is not null )
	     begin
		if(len(@mobileNum)>=11 )
		begin
			set @content='优邮提示:您的订单'+@content+'已经审核通过,我们会在72小时内将订单送达。www.yoyo18.com '
	                        exec p_sendMsgByClass @mobileNum,@content,9999,1
		end
	     end
	  end
   end
      if(@orderStatus=19) 
   UPDATE dbo.tb_order SET orderStatus=@orderStatus,isdelete=1,checkRemark=isnull(checkRemark,'')+@checkRemark,isUpdate=0 WHERE id=@orderId
  else	
    UPDATE dbo.tb_order SET orderStatus=@orderStatus,checkRemark=isnull(checkRemark,'')+@checkRemark,isUpdate=0 WHERE id=@orderId

   insert into tb_orderstatusHis(orderId,orderstatus,doMan,remark) values(@orderId,@orderStatus,@userId,'审核订单')

	--更新网站购买记录状态
	update tb_orderRemark set orderStatus=@orderStatus where orderId=@orderId