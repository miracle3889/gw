/*------------------修改密码----------------------------*/
CREATE PROCEDURE p_addNoAnswerCall @callcallerCode VARCHAR(50)
AS
	if(@callcallerCode='28130158')
		begin
			INSERT INTO tb_noAnswerCall(callcallerCode) VALUES(@callcallerCode)
		end
	else
		begin
			 if not exists(select 1 from tb_noAnswerCall where isCallBack=0 and callcallerCode=@callcallerCode)
				begin
					INSERT INTO tb_noAnswerCall(callcallerCode) VALUES(@callcallerCode)
				end
			else
				begin
					update tb_noAnswerCall set callInTime=getDate()  where callcallerCode=@callcallerCode and isCallBack=0
				end
		end