/************生成榜单临时表CFT*************/
CREATE    procedure p_sendBangCFT 
as

	delete dbo.tb_bangCFT --删除榜单表

--财付通榜单
	declare @CFTid int
	declare @id int
	declare @productId int
	declare @productName varchar(200)
	declare @picPath varchar(300)
	declare @htmlPath varchar(300)
	declare @oldPrice int
	declare @salePrice int 
	declare @typeI int
	declare @typeII int
	declare @saleId int
	
	declare tjCFT cursor for select id from tb_bang
	open tjCFT
	fetch NEXT from tjCFT into @id
	
	while @@fetch_status<>-1 
	begin
		--首先取tb_saleProduct的productId.如果tb_saleProduct表里没有saleTypeId=16的商品记录
		select @saleId=saleId from tb_bang where id=@id
		set @productId=0
		select @productId=productId from tb_saleProduct where id=@saleId
		set @CFTid=0
		set @salePrice=0
		set @oldPrice=0
		set @typeI=0
		set @typeII=0
		select @CFTid=id from tb_saleProduct where productId=@productId and saleTypeId=16
		if(@CFTid is not null)
		begin
			select @productName=productName,@picPath=picPath,@typeI=typeI,@typeII=typeII from tb_bang where id=@id
			select @oldPrice=oldPrice,@salePrice=salePriceInt,@htmlPath=htmlPath from tb_searchSaleEntityCFT where saleId=@CFTid
			if (@oldPrice!=0 and @salePrice!=0)
			begin
				insert into tb_bangCFT (productName,picPath,htmlPath,oldPrice,salePrice,saleId,typeI,typeII) 
				values (@productName,@picPath,@htmlPath,@oldPrice,@salePrice,@CFTid,@typeI,@typeII)
			end
		end
		fetch NEXT from tjCFT into @id 
	end 

	close tjCFT
	deallocate tjCFT