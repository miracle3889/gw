
/*------------------------------------------------------------更新订单的赠品------------------------------------------------------------------------------------*/
CREATE  PROCEDURE p_addNewPresent  	@orderId int, @saleProductId int,
						@colorId int, @metricsId int
AS
	declare @count int
	declare @select int
	declare @saleCode varchar (50)
	declare @type int
	declare @id int
	delete from  erp..tb_canDistributeOrder where orderId =@orderId
	select @type=b.minPrice from tb_saleProduct a
	inner join tb_saleType b on b.id=a.saleTypeId
	where a.id=@saleProductId

	begin tran
	select @count=a.productCount from ERP.dbo.tb_productStock a
	inner join tb_saleProduct b on b.productId=a.productId
	where b.id=@saleProductId and a.colorId=@colorId and a.metricsId=@metricsId

	DECLARE @realCount INT
	DECLARE @DDlCount INT 
	DECLARE @productId INT
	
	SELECT @productId=productId FROM tb_saleProduct WHERE id=@saleProductId
              
	SELECT @realCount=SUM(productCount) FROM ERP.dbo.tb_productStock WHERE productId=@productId AND colorId=@colorId AND metricsId=@metricsId   

	SELECT @DDlCount=SUM(a.buyCount) FROM v_allBuyProduct a --  INNER JOIN tb_saleProduct b ON a.saleProductId=b.id 
		   WHERE a.saleProductId=@productId AND a.colorId=@colorId AND a.metricsId=  @metricsId   
	
  	 IF(@DDlCount IS NULL)
                 BEGIN 
		SET @DDlCount=0
                 END

	select @count=a.productCount from ERP.dbo.tb_productStock a
	inner join tb_saleProduct b on b.productId=a.productId
	where b.id=@saleProductId and a.colorId=@colorId and a.metricsId=@metricsId--得到库存数量  @realCount-@DDlCount>=1
	 

	if (@realCount-@DDlCount>=1)
	begin
		/*if (@type=0)
		begin
			select @count=count(*) from tb_orderSaleProduct a
			inner join tb_saleProduct b on b.id=a.saleProductId
			inner join tb_saleType c on c.id=b.saleTypeId and c.minPrice=0
			where orderId=@orderId  
	
			select @id=a.saleProductId from tb_orderSaleProduct a
			inner join tb_saleProduct b on b.id=a.saleProductId
			inner join tb_saleType c on c.id=b.saleTypeId and c.minPrice=0
			where orderId=@orderId  
		end
		else
		begin
			select @count=count(*) from tb_orderSaleProduct a
			inner join tb_saleProduct b on b.id=a.saleProductId
			inner join tb_saleType c on c.id=b.saleTypeId and c.minPrice!=0
			where orderId=@orderId and a.isRand=1

			select @id=a.saleProductId from tb_orderSaleProduct a
			inner join tb_saleProduct b on b.id=a.saleProductId
			inner join tb_saleType c on c.id=b.saleTypeId and c.minPrice=@type
			where orderId=@orderId  
		end
		if (@count=0)
		begin*/
			insert into dbo.tb_orderSaleProduct(orderId,colorId,metricsId,saleProductCode,saleProductId,buyCount,isRand,stockPrice)
			select @orderId,@colorId,@metricsId,saleCode,a.id,1,1,b.stockPriceReal from dbo.tb_saleProduct a
			inner join erp.dbo.tb_product b on a.productid=b.id
	 		where  a.id=@saleProductId

			declare @myId INT
			SET @myId=SCOPE_identity()
			insert into dbo.tb_orderSaleProductPay(orderSaleProductId,payType,payValue)
			select a.id,payStyleId,payValue
			from tb_orderSaleProduct a
			inner join dbo.tb_saleProductPay b on b.saleProductId=a.saleProductId
			where a.id=@myId
			
			set @select = 1
		end
		/*end
		else
		begin
			select @saleCode=saleCode from tb_saleProduct where id=@saleProductId
			
			update tb_orderSaleProduct set colorId=@colorId , metricsId=@metricsId ,
			 saleProductCode=@saleCode , saleProductId=@saleProductId
			where orderId=@orderId and isRand=1 and saleProductId=@id
			set @select = -1
		end
	end
	else
	begin
		set @select = 0
	end*/
	commit tran
	if(@select=1)
	begin
		if EXISTS(select 1 from tb_order where orderstatus in(20,13) and id=@orderId)
		begin
			update tb_order set isdelete=2 where  id=@orderId
		end
	end
	
	exec p_computeOrderPrice @orderId
	select @select