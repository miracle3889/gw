--设定网站定单最近成交
CREATE PROCEDURE p_web_setOrderRemark 
AS
	declare @createTime datetime

	select top 1 @createTime=createTime from dbo.tb_orderRemark order by createTime desc
	if (@createTime is not null)
	begin
		insert into tb_orderRemark (saleId,memberName,nickname,colorName,metricsName,buyCount,createTime,memberCard,orderId,orderStatus) 
		select b.saleProductId,isnull(e.name,null) ,isnull(e.nickname,null)  ,c.codeName as cname,d.codeName as mname,b.buyCount as bCount, 
						a.createTime,isnull(f.id,0),a.id,a.orderStatus
						 from tb_order a inner join tb_orderSaleProduct b on a.id=b.orderId 
						inner join erp..tb_productColorCode c on b.colorId=c.id 
						inner join erp..tb_productMetricsCode d on b.metricsId=d.id 
						inner join tb_member e on e.id=a.memberId 
						left join tb_memberCard f on f.memberId=e.id 
						where a.isDelete!=1 and b.buyCount>0 
						--and a.orderStatus!=4 and a.orderStatus!=5 --and a.orderStatus!=11 
						and a.createTime>@createTime
					order by a.createTime desc
	end
	--更新现在到一个月前的订单状态
	update tb_orderRemark set orderStatus=a.orderStatus from tb_order a,tb_orderRemark b 
	where b.orderId=a.id and a.createTime > DATEADD(day,-30,GETDATE())