
/*------------------------------------------------------------添加退货单------------------------------------------------------------------------------------*/
CREATE  PROCEDURE p_backOrderByTaobao   @orderId int, @doman int 
AS
	declare @returnId int
	
	BEGIN TRAN 
	declare @code varchar(50)
	/*----------------------------插入一条新的订单----------初始退货状态和支付状态设1--------退货价设0---------*/
	EXEC p_geBackOrderCode @code OUTPUT
	
	insert into tb_backOder(ordeId, code, backTypeId, BackPrice, backPriceTypeId, backCauseTypeId, backCauseRemak, backStatusId, payStatusId,addr,deliverPrice,doman,payAccount)

	select id,@code,1,0,11,1,remark,3,1,receviceAddr1,0,@doman,0 from tb_order where id=@orderId
	


	COMMIT TRAN
	set @returnId=@@identity
	select @returnId
