CREATE procedure p_addRegistTask @dealManId int,@dealCount int
as
	declare @insertId int
	declare @sql varchar(500)
	
	insert into tb_registTask(dealManId,dealCount) values(@dealManId,@dealCount)
	
	set @insertId=SCOPE_IDENTITY( )
	
	set @sql='insert into tb_registTaskMember(taskId,memberId,lastAddTime)
	select top '+cast(@dealCount as varchar(10))+'  '+cast(@insertId as varchar(10))+',memberId,addTime from v_getAllNeedMember'
	
	exec(@sql)

	select @insertId
