
create view v_firstOrder as select min(createTime) as firTime,memberID from tb_order group by memberID
