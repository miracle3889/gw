CREATE PROCEDURE p_BACK
AS
	DECLARE @code VARCHAR(50)
	SET @code=CONVERT(VARCHAR(20),GETDATE(),120)
	SET  @code=SUBSTRING(@code,3,2)+SUBSTRING(@code,6,2)+SUBSTRING(@code,9,2) --取得当前日期如070603
	SET  @code='E:\DBBackup\ERP'+@code
	PRINT @code
	BACKUP DATABASE ERP
	TO disk =@code
	WITH FORMAT,
	NAME = 'Full Backup of MyNwind'

