

/*-------------------------------------提取新品和热卖商品--------------------------------*/
CREATE   procedure p_web_setnewProductAndhotPoduct 
AS

	declare @oneShop varchar(100)
	declare @twoShop varchar(100)
	declare @threeShop varchar(100)

	--取出前三页商品编号
	declare @sizePage int
	declare @id int 
	set @sizePage=0 

	declare hotSort cursor for select id from dbo.tb_hotSale order by score desc
	open hotSort
	fetch NEXT from hotSort into @id

	while @@fetch_status<>-1 
	begin
		--取热卖第一页的saleId+';'字符串进行组合.
		if @sizePage<12
		begin
			select @oneShop=@oneShop+cast(saleId as varchar(5)) from dbo.tb_hotSale where id=@id
			set @oneShop=@oneShop+';'
		end
		else
		begin	
			--取热卖第二页的saleId+';'字符串进行组合.
			if @sizePage<24
			begin
				select @twoShop=@twoShop+cast(saleId as varchar(5)) from dbo.tb_hotSale where id=@id
				set @twoShop=@twoShop+';'
			end
			else
			begin
				--取热卖第三页的saleId+';'字符串进行组合.
				if @sizePage<36
				begin
					select @threeShop=@threeShop+cast(saleId as varchar(5)) from dbo.tb_hotSale where id=@id
					set @threeShop=@threeShop+';'
				end
			end
		end
		fetch NEXT from hotSort into @id 
		set @sizePage=@sizePage+1
	end 

	close hotSort
	deallocate hotSort	

	--建立新品表

	delete from dbo.tb_newSale
	
	insert into dbo.tb_newSale(saleId,addMan)
	select a.id,1 from tb_saleProduct a
	inner join tb_saleplan b on a.salePlanId=b.id
	where saleTypeId=1 and isDeleted=0
	and addTime<=dateAdd(day,-1,getdate()) and b.isOk=1 and  a.id  in (select saleId from dbo.tb_searchSaleEntity where isqh=0)

	--建立热卖表
	delete from dbo.tb_hotSale
	
	insert into dbo.tb_hotSale(saleId,addManId,dir,score)
	select top 100  a.saleProductId,1,0,((c.viewCount+c.adminSetCount)+sum(a.buyCount-a.backCount)*15+sum((a.buyCount-a.backCount)*b.payValue)*50) as score 
	from dbo.tb_orderSaleProduct a
	inner join dbo.tb_orderSaleProductPay b on a.id=b.orderSaleProductId
	inner join dbo.tb_SaleProduct c on a.saleProductId=c.id
	inner join dbo.tb_order d on a.orderId=d.id
	where b.payType=1 and c.isDeleted!=1 and c.webCategoryId=12  and d.createTime>=dateADD(day,-15,getdate()) and d.orderstatus in (6,1,20,13,2,3,17,12,15,14) and d.isdelete!=1 and  a.saleProductId  in (select saleId from dbo.tb_searchSaleEntity where isqh=0)
	group by a.saleProductId,c.viewCount,c.adminSetCount
	order by  (c.viewCount+c.adminSetCount)+sum(a.buyCount-a.backCount)*15+sum((a.buyCount-a.backCount)*b.payValue)*50 desc

	insert into dbo.tb_hotSale(saleId,addManId,dir,score)
	select top 100  a.saleProductId,1,0,((c.viewCount+c.adminSetCount)+sum(a.buyCount-a.backCount)*15+sum((a.buyCount-a.backCount)*b.payValue)*50) as score 
	from dbo.tb_orderSaleProduct a
	inner join dbo.tb_orderSaleProductPay b on a.id=b.orderSaleProductId
	inner join dbo.tb_SaleProduct c on a.saleProductId=c.id
	inner join dbo.tb_order d on a.orderId=d.id
	where b.payType=1 and c.isDeleted!=1 and c.webCategoryId = 7  and d.createTime>=dateADD(day,-15,getdate()) and d.orderstatus in (6,1,20,13,2,3,17,12,15,14) and d.isdelete!=1 and  a.saleProductId  in (select saleId from dbo.tb_searchSaleEntity where isqh=0)
	group by a.saleProductId,c.viewCount,c.adminSetCount
	order by  (c.viewCount+c.adminSetCount)+sum(a.buyCount-a.backCount)*15+sum((a.buyCount-a.backCount)*b.payValue)*50 desc

	insert into dbo.tb_hotSale(saleId,addManId,dir,score)
	select top 100  a.saleProductId,1,0,((c.viewCount+c.adminSetCount)+sum(a.buyCount-a.backCount)*15+sum((a.buyCount-a.backCount)*b.payValue)*50) as score 
	from dbo.tb_orderSaleProduct a
	inner join dbo.tb_orderSaleProductPay b on a.id=b.orderSaleProductId
	inner join dbo.tb_SaleProduct c on a.saleProductId=c.id
	inner join dbo.tb_order d on a.orderId=d.id
	where b.payType=1 and c.isDeleted!=1 and c.webCategoryId != 7 and  c.webCategoryId != 12 and c.webCategoryId!=0 and d.createTime>=dateADD(day,-15,getdate()) and d.orderstatus in (6,1,20,13,2,3,17,12,15,14) and d.isdelete!=1 and  a.saleProductId  in (select saleId from dbo.tb_searchSaleEntity where isqh=0)
	group by a.saleProductId,c.viewCount,c.adminSetCount
	order by  (c.viewCount+c.adminSetCount)+sum(a.buyCount-a.backCount)*15+sum((a.buyCount-a.backCount)*b.payValue)*50 desc

	--热卖重新排序
	set @id=0
	declare @i int
	declare @valueStr int 
	declare @saleId int
	set @saleId=0 
	declare hotSo cursor for select id from dbo.tb_hotSale order by score desc
	open hotSo
	fetch NEXT from hotSo into @id
	
	while @@fetch_status<>-1 
	begin
		--拆分原热卖表第一页的所有saleId
		while len(@oneShop) > 0 
		begin 
		SELECT @i = Charindex(';',@oneShop)
		set @valueStr = cast(SUBSTRING ( @oneShop , 1 , @i-1 ) as int) 
		--如果新建的热卖表存在此商品. 对score值进行改变.*0.7
		select @saleId=id from dbo.tb_hotSale where saleId=@valueStr
		if @saleId>0
		begin
			update dbo.tb_hotSale set score=cast(round(score*0.7,0) as int) where id=@saleId
		end 
		set @oneShop = SUBSTRING ( @oneShop , @i+1 , len(@oneShop)-@i  ) 
		end 

		--拆分原热卖表第二页的所有saleId


		while len(@twoShop) > 0 
		begin 
		SELECT @i = Charindex(';',@twoShop)
		set @valueStr = cast(SUBSTRING ( @twoShop , 1 , @i-1 ) as int) 
		select @saleId=id from dbo.tb_hotSale where saleId=@valueStr
		if @saleId>0
		begin
			update dbo.tb_hotSale set score=cast(round(score*0.8,0) as int) where id=@saleId
		end 
		set @twoShop = SUBSTRING ( @twoShop , @i+1 , len(@twoShop)-@i  ) 
		end 

		--拆分原热卖表第三页的所有saleId
		while len(@threeShop) > 0 
		begin 
		SELECT @i = Charindex(';',@threeShop)
		set @valueStr = cast(SUBSTRING ( @threeShop , 1 , @i-1 ) as int) 

		select @saleId=id from dbo.tb_hotSale where saleId=@valueStr
		if @saleId>0
		begin
			update dbo.tb_hotSale set score=cast(round(score*0.9,0) as int) where id=@saleId
		end 
		set @threeShop = SUBSTRING ( @threeShop , @i+1 , len(@threeShop)-@i  ) 
		end 


		fetch NEXT from hotSo into @id 
	end 
	close hotSo
	deallocate hotSo

	--财付通新品
	delete tb_newSaleCFT
	declare @CFTid int
	--insert into tb_newSaleCFT (saleId,addMan) select saleId,addMan from tb_newSale where saleId=@id
	declare @productId int
	declare newSoCFT cursor for select saleId from dbo.tb_newSale
	open newSoCFT
	fetch NEXT from newSoCFT into @id
	
	while @@fetch_status<>-1 
	begin
		--首先取tb_saleProduct的productId.如果tb_saleProduct表里没有saleTypeId=16的商品记录
		select @productId=productId from tb_saleProduct where id=@id
		set @CFTid=0
		select @CFTid=id from tb_saleProduct where productId=@productId and saleTypeId=16
		if(@CFTid is not null)
		begin
			insert into tb_newSaleCFT (saleId,addMan) select @CFTid,addMan from tb_newSale where saleId=@id
		end
		fetch NEXT from newSoCFT into @id 
	end 

	close newSoCFT
	deallocate newSoCFT

	--财付通热卖
	declare hotSoCFT cursor for select saleId from dbo.tb_hotSale order by score desc
	open hotSoCFT
	fetch NEXT from hotSoCFT into @id
	
	while @@fetch_status<>-1 
	begin
		--首先取tb_saleProduct的productId.如果tb_saleProduct表里没有saleTypeId=16的商品记录
		select @productId=productId from tb_saleProduct where id=@id
		set @CFTid=0
		select @CFTid=id from tb_saleProduct where productId=@productId and saleTypeId=16
		if(@CFTid is not null)
		begin
			insert into tb_hotSaleCFT (saleId,addManId,dir,score) select @CFTid,addManId,dir,score from tb_hotSale where saleId=@id
		end
		fetch NEXT from hotSoCFT into @id 
	end 

	close hotSoCFT
	deallocate hotSoCFT

	exec p_web_setnewProductAndhotPoductCFT