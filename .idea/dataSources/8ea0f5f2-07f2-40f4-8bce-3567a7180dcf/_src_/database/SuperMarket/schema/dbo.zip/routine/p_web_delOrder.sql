/*------------------------------------------------------回滚定单------------------------------------------------------------------------------------*/
CREATE   PROCEDURE [dbo].[p_web_delOrder] @orderId INT,@deleteManId int
AS
	if  exists (select 1 from tb_order where id=@orderId and isDelete<>1 and orderStatus=1 and memberId=@deleteManId )
	begin
	DECLARE @returnValue INT
	DECLARE @memberId INT
	  DECLARE @account INT
  	DECLARE @TScore INT

	SELECT @memberId=memberId,@account=useAccount FROM dbo.tb_order WHERE id=@orderId --得到对应的会员号
	SET @returnValue=0
	BEGIN TRAN 
	
	
		select @TScore=sum(c.payValue*b.buyCount) from tb_order a 
		inner join dbo.tb_orderSaleProduct b on a.id=b.orderId
		inner join dbo.tb_orderSaleProductPay c on b.id=c.orderSaleProductId
		where a.id=@orderId and c.payType=2
	
		
		declare @remark varchar(50)
		set @remark='删除订单'+cast(@orderId as varchar(10))
		IF(@account IS NOT NULL)
		BEGIN
			if not exists(select 1 from tb_AccountOpLog where orderCode=@remark )
			begin
				if(@account>0)
				exec dbo.p_addAccountOpLogBySystem @memberId,@account,3,@remark,0
			end
			--UPDATE dbo.tb_member SET account=account+@account WHERE id=@memberId --帐户余额反还
		END
		
		IF(@TScore IS NOT NULL)
		BEGIN
			if not exists(select 1 from tb_ScoreOpLog  where orderCode=@remark )
			begin
			if(@TScore>0)
				exec dbo.p_addScoreOpLog @memberId,@TScore,9,@remark
			end
			--UPDATE dbo.tb_member SET score=score+@TScore WHERE id=@memberId --帐户几分反还
		END

		
	
		UPDATE dbo.tb_order SET  isUpdate=0,isDelete=1,deleteManId=@deleteManId  WHERE id=@orderId --删除原定单
	
	 	declare @count int
		declare @distributeId int 
		--select @distributeId=max(distributeId) from erp.dbo.tb_orderDistribute where orderId=@orderId
		
		--if(@distributeId is null) set @distributeId=0
		--select @count=count(*) from Supermarket.dbo.tb_order where ( deliverManId>0 or ( deliverManId<=0 and   isdelete=1)) and id in(
		--select orderId from erp.dbo.tb_orderDistribute where distributeId=@distributeId)
	
	
		--update erp.dbo.tb_Distribute set sortingCount=@count where id=@distributeId
	
		UPDATE dbo.tb_memberGift  SET isUse=0,useOder=0 WHERE useOder=@orderId
		UPDATE dbo.tb_giftCard SET isUse=0,useOder=0 WHERE useOder=@orderId--礼券返还
		
		DELETE FROM  tb_advanceOrder  WHERE orderId=@orderId
		SET @returnValue=1

		--更新网站购买记录
		delete tb_orderRemark where orderId = @orderId

		delete from tb_temp_waitPhProduct where orderId=@orderId
		COMMIT TRAN
        SELECT @returnValue
        end 