create procedure p_checkCallHis
as 
 declare @count1 int
 declare @count2 int

select @count1=count(*)*0.8 from tb_callHis  where callTime>= dateAdd(minute,-30,dateAdd(Week,-1,getDate())) and callTime<= dateAdd(Week,-1,getDate()) and callcalledCode<>'8099'



select @count2=count(*) from tb_callHis  where callTime>= dateAdd(minute,-30,getDate())  and callcalledCode<>'8099'


if(@count2<@count1)
begin
	exec  p_sendMsgByClass '13868009945','半小时内通话数低于上周80%',999,1
end
