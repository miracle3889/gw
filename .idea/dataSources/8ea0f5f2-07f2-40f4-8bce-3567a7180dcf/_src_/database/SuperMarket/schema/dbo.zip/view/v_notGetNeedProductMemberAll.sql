CREATE VIEW dbo.v_notGetNeedProductMemberAll
AS
SELECT a.memberId, b.name, b.mobileNum, b.callRemark, MAX(a.addTime) 
      AS addTime,0  as hasPrice
FROM dbo.tb_registProduct a INNER JOIN
      dbo.tb_member b ON a.memberId = b.id
WHERE (a.memberId IN
          (SELECT memberId
         FROM tb_registProduct
         WHERE isQh = 1 AND isDeleted = 0)) AND (a.isdeleted = 0) AND 
      (a.memberId NOT IN
          (SELECT memberId
         FROM dbo.v_notGetAllNeedProductMember))
GROUP BY a.memberId, b.name, b.mobileNum, b.callRemark

