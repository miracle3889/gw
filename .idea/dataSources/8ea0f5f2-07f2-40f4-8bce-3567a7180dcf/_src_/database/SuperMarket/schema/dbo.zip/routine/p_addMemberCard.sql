/*-----------录入会员卡号----------------------*/
CREATE procedure p_addMemberCard @memberId int --会员编号
				,@cardCode varchar(50),--卡号
				 @cardClass int,--卡级别,
				@addManId int
as
	declare @cardCount int
	declare @cardCode2 Varchar(2)
	select  @cardCode2=subString(@cardCode,1,2)
	if(@cardCode2='SH')
		SET @cardClass=1
	select @cardCount=count(*) from tb_memberCard where cardCode=@cardCode
	if(@cardCount is null)
		set @cardCount=0
	if(@cardCount=0)
	begin
		insert into tb_memberCard(memberId,cardCode,memberClass,addManId) values(@memberId,@cardCode,@cardClass,@addManId)
	end
	else
	begin
		update tb_memberCard set memberClass=@cardClass,addManId=@addManId where cardCode=@cardCode
	end