
create  procedure p_addweitaoDetial @title varchar(200),@nickName varchar(200),@oldContent varchar(200),
@timex varchar(200),@dateTime varchar(200),@magId int
as 
 begin tran 
	delete from dbo.tb_weitaoVote where detialId in(select id from tb_weitaodetial where nickName=@nickName and weitaoMaID=@magId)
	
	delete from tb_weitaodetial where nickName=@nickName and weitaoMaID=@magId
	
	insert into   dbo.tb_weitaodetial(title,nickName,oldContent,timex,[dateTime],weitaoMaID)
	values(@title,@nickName,@oldContent,@timex,@dateTime,@magId)
	select   SCOPE_IDENTITY()
  commit tran 