/*------------------------修改用户地址列表-----------------------------*/
CREATE   PROCEDURE [dbo].[p_web_updateMemberAddr] @memberName VARCHAR(32),@provinceId INT,@cityId INT,
					@regionalId int,@addr VARCHAR(120),@mobileNum VARCHAR(12),
				@phoneNum VARCHAR(32),@deliverTime VARCHAR(32),@post VARCHAR(6),@id int,@memberId int
AS
	DECLARE @returnValue INT
	set @returnValue=0	

	update tb_memberAddr set isSet=0 where memberId=@memberId --重置isSet


	--DECLARE @tbId INT
	--set @tbId=0
	--if (@id=-1) -- 支付宝地址
	--begin
	--	select @tbId=id from tb_memberAddr where memberName=@memberName and memberId=@memberId
	--end
	--set @id=@tbId	


	if (@id=0)
	begin
		insert into tb_memberAddr (memberName,provinceId,cityId,regionalId,addr,mobileNum,phoneNum,deliverTime,post,memberId,isSet) 
		values (@memberName,@provinceId,@cityId,@regionalId,@addr,@mobileNum,@phoneNum,@deliverTime,@post,@memberId,1)
		set @returnValue=@@IDENTITY
	end
	else
	begin
		update tb_memberAddr set memberName=@memberName,provinceId=@provinceId,cityId=@cityId,regionalId=@regionalId,addr=@addr,
				mobileNum=@mobileNum,phoneNum=@phoneNum,deliverTime=@deliverTime,post=@post,addDate=getdate(),isSet=1 
				where isDelete=0 and id=@id and memberId=@memberId 
		set @returnValue=@id
	end
	update tb_memberAddr set isSet=0 where memberId=@memberId and id!=@returnValue 
	SELECT @returnValue