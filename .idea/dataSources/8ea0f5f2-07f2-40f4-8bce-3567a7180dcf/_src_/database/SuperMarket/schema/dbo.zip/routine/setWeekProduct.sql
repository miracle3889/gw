

CREATE   procedure setWeekProduct
as 
	begin  tran 
		update tb_saleProductOldPrice set isSet=-1 where saleId in(
		select saleId  from tb_weekProduct 
		where startTime>=DATEADD(wk,  DATEDIFF(wk,0,getdate()),  -7) and endTime<=DATEADD(wk,  DATEDIFF(wk,0,getdate()),  -1) ) --and isSet=0--设定需要修改回原价的商品
	
		--过期的修改回原价格
		update dbo.tb_saleProductPay set payValue=y.salePrice from tb_saleProductPay x, 
		(select saleId,salePrice from  tb_saleProductOldPrice  where isSet=-1 )as y where x.saleProductId=y.saleId and x.payStyleId=1
		
		update tb_saleProductOldPrice set isSet=1 where  isSet=-1 

	commit tran 
	--到时间期的修改价格
	update dbo.tb_saleProductPay set payValue=y.price from tb_saleProductPay x, 
	( 
	  	select saleId,price from tb_weekProduct  where startTime<=getDate() and endTime>=getDate()
	)as y 
	  where x.saleProductId=y.saleId and x.payStyleId=1

	  update tb_saleProductOldPrice set isSet=0 where saleId in
	(  
		select saleId from tb_weekProduct  where startTime<=getDate() and endTime>=getDate()
	)


	delete  from tb_currentWeekProduct
	insert into tb_currentWeekProduct(saleId,price,oldPrice)
	select a.saleId,price,b.salePrice as oldPrice from tb_weekProduct  a
	inner join  tb_saleProductOldPrice b on a.saleId=b.saleId
	
	 where startTime<=getDate() and endTime>=getDate()