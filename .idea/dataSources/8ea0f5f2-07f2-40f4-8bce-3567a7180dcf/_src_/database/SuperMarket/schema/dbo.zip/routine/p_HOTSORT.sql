CREATE procedure p_HOTSORT 
AS
	declare @sizePage int
	declare @id int 
	set @sizePage=0 

	declare hotSort cursor for select id from dbo.tb_hotSale order by score desc
	open hotSort
	fetch NEXT from hotSort into @id

	while @@fetch_status<>-1 
	begin
		if @sizePage<12
		begin
			update dbo.tb_hotSale set score=cast(round(score*0.7,0) as int) where id=@id
		end
		else
		begin
			if @sizePage<24
			begin
				update dbo.tb_hotSale set score=cast(round(score*0.8,0) as int) where id=@id
			end
			else
			begin
				if @sizePage<36
				begin
					update dbo.tb_hotSale set score=cast(round(score*0.9,0) as int) where id=@id
				end
			end
		end
		fetch NEXT from hotSort into @id 
		set @sizePage=@sizePage+1
	end 

	close hotSort
	deallocate hotSort