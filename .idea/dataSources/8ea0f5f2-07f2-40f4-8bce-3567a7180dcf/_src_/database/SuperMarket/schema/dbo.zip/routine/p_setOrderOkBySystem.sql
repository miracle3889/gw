CREATE procedure p_setOrderOkBySystem @orderCode varchar(50),@price int
as
	declare @oldPrice int
	declare @orderId int
	declare @returnValue int
	select @orderId=id, @oldPrice=(productPrice+deliverPrice-useAccount-useGift) from tb_order where (otherOrder=@orderCode or orderCode=@orderCode)
	if(@price=@oldPrice)
	begin
		update tb_order set orderstatus=3,visaTime=getDate() where id=@orderId
		exec SuperMarket.dbo.p_updateOrderBackPrice @orderId
		set @returnValue=1
	end
	else
	begin
		set @returnValue=0
	end

	select @returnValue