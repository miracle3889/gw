CREATE PROCEDURE p_setMarkGiftCad_HT 
AS
	declare @returnValue int
	set @returnValue=0
	select @returnValue=count(*) from tb_giftCard where createType=1 and price=2000 and isAct=0
	if (@returnValue<2000)
	begin
		exec p_markGiftCad_HT 2000,571,20,100
	end
	set @returnValue=0
	select @returnValue=count(*) from tb_giftCard where createType=1 and price=1000 and isAct=0
	if (@returnValue<2000)
	begin
		exec p_markGiftCad_HT 2000,571,10,50 
	end