CREATE VIEW dbo.v_availableCount
AS


SELECT SUM(productCount) as availableCount,productId, colorId, metricsId
        FROM erp.dbo.tb_productStock
        GROUP BY productId, colorId, metricsId

