/**********增加超清大图***********/
CREATE  procedure p_addBigPic @saleCode varchar(50),@picName varchar(60)

AS
	declare @bigPicId int
	declare @returnValue int
	
	SET @bigPicId=0

	SELECT @bigPicId=id FROM tb_BigPic WHERE saleCode=@saleCode
	IF (@bigPicId != 0)
	BEGIN
		
		UPDATE tb_BigPic SET picPath=@picName WHERE saleCode=@saleCode
		set @returnValue=1
	END
	ELSE
	BEGIN 
		INSERT INTO tb_BigPic (saleCode,picPath) VALUES (@saleCode,@picName)
		set @returnValue=1
	END
	
	select @returnValue