/*--------------添加网站属性------------------------------------------*/
CREATE PROCEDURE p_addWebAttribute @tableName VARCHAR(50),@attributeName VARCHAR(50)
AS
       
       DECLARE @sql VARCHAR(200)
       SET @sql='INSERT INTO '+@tableName+'(name) VALUES('''+@attributeName+''')  SELECT scope_identity()'
       EXEC(@sql)
      
