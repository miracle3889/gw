/*------------------------------添加审核备注--------------------------------------*/
CREATE PROCEDURE [p_addCheckRemark]  @userId INT,@orderId INT,@checkRemark   VARCHAR(500)
AS
                DECLARE @userName VARCHAR(50)--审核人
	   SELECT @userName=name FROM ERP.dbo.tb_product where id=@userId
	   set @checkRemark=getdate()+'  '+@userName+'  '+@checkRemark+'<br>'
	   update tb_order set checkRemark=checkRemark+@checkRemark where id=@orderId