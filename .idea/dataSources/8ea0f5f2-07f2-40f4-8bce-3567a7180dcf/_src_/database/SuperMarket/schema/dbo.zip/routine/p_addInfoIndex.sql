
/*---------------加入首页资讯内容---------------------------------------------------------*/
CREATE    PROCEDURE p_addInfoIndex @id INT,@isIndex INT,@isIndexContent VARCHAR(256) 
AS
	DECLARE @returnValue INT 
	begin tran
		UPDATE info_title set isIndex=@isIndex ,isIndexContent=@isIndexContent where id=@id
		if (@@error<>0)
		begin
			set @returnValue=0
		end
		else
		begin
			set @returnValue=1
		end
	commit tran
	SELECT @returnValue