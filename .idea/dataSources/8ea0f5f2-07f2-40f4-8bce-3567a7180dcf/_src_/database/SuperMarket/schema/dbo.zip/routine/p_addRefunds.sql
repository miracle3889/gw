CREATE procedure [dbo].[p_addRefunds] @refundId varchar(50),@oid  varchar(50),@status varchar(50),@created varchar(50),
@Tid varchar(50),@TotalFee varchar(50),@RefundFee varchar(50),@Modified varchar(50),@Reason varchar(50),@Desc varchar(200)
,@orderStatus varchar(50),@goodStatus varchar(50)
as 
	if not exists(select 1 from supermarket..tb_refunds where refundId=@refundId and [status]=@status)
	begin
	insert  supermarket..tb_refunds(refundId,oid,[status],created,Tid,total_fee,Refund_Fee,Modified,Reason,[Desc],orderStatus,goodStatus)
	 values(@refundId,@oid,@status,@created,@Tid,@TotalFee,@RefundFee,@Modified,@Reason,@Desc,@orderStatus,@goodStatus)
	end
	