
/*------------------------------------------------------回滚定单------------------------------------------------------------------------------------*/
CREATE  PROCEDURE p_rollBackOrderNewNew @orderId INT
AS
	DECLARE @returnValue INT
	DECLARE @memberId INT
	declare @orderGroupId int
	declare @groupCode varchar(50)
	declare @saleGroupId int
	declare @buyCount int
	declare @returnId int

	SELECT @memberId=memberId FROM dbo.tb_order WHERE id=@orderId --得到对应的会员号
	SET @returnValue=0
	BEGIN TRAN 
	
	INSERT INTO dbo.tb_shoppingBag(productCode,saleProductId,colorId,metricsId,buyCount,memberId,type,groupPh)
	SELECT saleProductCode,saleProductId,colorId,metricsId,buyCount,@memberId,1,groupPh 
	FROM dbo.tb_orderSaleProduct WHERE orderId=@orderId  and groupPh=0--定单中商品返回到用户购物车中
	
	INSERT INTO dbo.tb_shoppingBag(productCode,saleProductId,colorId,metricsId,buyCount,memberId,type,groupPh)
	SELECT saleProductCode,saleProductId,colorId,metricsId,a.buyCount/b.buyCount,@memberId,1,groupPh FROM dbo.tb_orderSaleProduct a
	inner join tb_groupPh b on a.groupPh=b.id 
	WHERE orderId=@orderId  and groupPh<>0--定单中商品返回到用户购物车中
	
	update tb_groupPh set isBuy=0 where id in(SELECT groupPh FROM dbo.tb_orderSaleProduct WHERE orderId=@orderId )

              DECLARE @account INT
  	DECLARE @TScore INT
             SELECT @account=useAccount FROM dbo.tb_order WHERE id=@orderId
	
	select @TScore=sum(c.payValue*b.buyCount) from tb_order a 
	inner join dbo.tb_orderSaleProduct b on a.id=b.orderId
	inner join dbo.tb_orderSaleProductPay c on b.id=c.orderSaleProductId
	where a.id=@orderId and c.payType=2
	
	declare @remark varchar(50)
	set @remark=cast(@orderId as varchar(10))
	IF(@account IS NOT NULL)
	BEGIN
		if not exists(select 1 from tb_AccountOpLog where orderCode=@remark )
		begin
			if(@account>0)
			exec dbo.p_addAccountOpLogBySystem @memberId,@account,2,@remark,0
		end
		--UPDATE dbo.tb_member SET account=account+@account WHERE id=@memberId --帐户余额反还
	END
	
	IF(@TScore IS NOT NULL)
	BEGIN
		if not exists(select 1 from tb_ScoreOpLog  where orderCode=@remark )
		begin
		if(@TScore>0)
			exec dbo.p_addScoreOpLog @memberId,@TScore,9,@remark
		end
		--UPDATE dbo.tb_member SET score=score+@TScore WHERE id=@memberId --帐户几分反还
	END
	
	
	UPDATE dbo.tb_order SET  isUpdate=0,isDelete=1  WHERE id=@orderId --删除原定单
	
 	declare @count int
	declare @distributeId int 
	--select @distributeId=max(distributeId) from erp.dbo.tb_orderDistribute where orderId=@orderId

	--select @count=count(*) from Supermarket.dbo.tb_order where ( deliverManId>0 or ( deliverManId<=0 and   isdelete=1)) and id in(
	--select orderId from erp.dbo.tb_orderDistribute where distributeId=@distributeId)


	--update erp.dbo.tb_Distribute set sortingCount=@count where id=@distributeId
	
	DECLARE @giftId INT
	SELECT @giftId=giftId FROM dbo.tb_memberGift WHERE useOder=@orderId 
	--UPDATE dbo.tb_memberGift  SET isUse=0 WHERE giftId=@giftId
	--UPDATE dbo.tb_giftCard SET isUse=0 WHERE id=@giftId  
	UPDATE dbo.tb_memberGift  SET isUse=0,useOder=0 WHERE useOder=@orderId
	UPDATE dbo.tb_giftCard SET isUse=0,useOder=0 WHERE useOder=@orderId--礼券返还
	
	SET @returnValue=1

	--更新网站购买记录
	delete tb_orderRemark where orderId = @orderId
	
	delete from tb_temp_waitPhProduct where orderId=@orderId
	COMMIT TRAN
        SELECT @returnValue