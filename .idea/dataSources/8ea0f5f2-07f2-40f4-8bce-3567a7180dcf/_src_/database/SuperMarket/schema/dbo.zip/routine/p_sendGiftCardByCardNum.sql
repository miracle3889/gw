CREATE PROCEDURE p_sendGiftCardByCardNum @memberId INT , @cardNum varchar(20) 
AS

	DECLARE @giftId INT
	set @giftId=0
	DECLARE @countLimit INT
	set @countLimit=0
	DECLARE @type INT
	set @type=0
	DECLARE @id INT
	set @id=0
	DECLARE @memberCardCount INT
	set @memberCardCount=0
	DECLARE @countSize INT
	set @countSize=0
	DECLARE @price INT
	set @price=0
	DECLARE @returnValue INT
	set @returnValue=0


	SET XACT_ABORT ON
	BEGIN TRAN
		-- 取出指定卡类型 @countLimit此卡号可用次数 0无限    @type卡金额类型 0=10元  1=20元  2=50元 
		SELECT @id=id, @countLimit=countLimit, @type=type FROM tb_publicCard WHERE cardNum = @cardNum AND validDate > getDate()
		if (@id<>0 and @memberId<>0)
		begin
			-- 取此用户拥有此卡张数
			SELECT @countSize=COUNT(*) FROM tb_memberGift WHERE giftType = @id AND memberId = @memberId
			IF (@countLimit = 0 or @countSize < @countLimit) -- 如果此卡为无限 或者 用户拥有的比可用次数少 送礼券
			BEGIN
				IF (@type=0)
				BEGIN
					SET @price=1000
				END
				IF (@type=1)
				BEGIN
					SET @price=2000
				END
				IF (@type=2)
				BEGIN
					SET @price=5000
				END

				--选出当前可用的一张price元优惠券
				SELECT TOP 1 @giftId=id FROM tb_giftCard WHERE createType=1 and price=@price and isAct=0 -- and giftType=1
				
				IF (@giftId <> 0)
				BEGIN
					--将此券设置为已激活
					UPDATE dbo.tb_giftCard SET isAct=1, actTime=GETDATE(), actMan=0, useLastTime=DATEADD(day,30,GETDATE()) 
					WHERE id=@giftId
					--IF (@@ERROR<>0)
					--BEGIN
					--	rollback tran
					--END
	
					--将此券赠予用户
					INSERT INTO dbo.tb_memberGift (giftId,memberId,giftType) VALUES (@giftId,@memberId,@id)
					--IF (@@ERROR<>0)
					--BEGIN
					--	rollback tran
					--END
					SET @returnValue=@price
				END
				ELSE
				BEGIN
					SET @returnValue=-3
				END
			END
			ELSE
			BEGIN
				SET @returnValue=-2 -- 用户拥有此卡
			END
		end
		else
		begin
			SET @returnValue=-1 -- 无此卡号
		end


		SELECT @returnValue

	COMMIT TRAN