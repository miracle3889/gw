/*************************************退回的组合商品(没有用到)*******************************************************/
CREATE PROCEDURE p_addBackOrderGroup @backOrderId int, @orderSaleId int, @backCount int 
 AS	
	declare @id int
	begin tran
	insert into tb_backProduct(backId,orderSaleId,saleId,backCount,type) 
	select @backOrderId,@orderSaleId,saleGroupId,@backCount,2 
	from tb_orderSaleGroup 
	where id=@orderSaleId
	set @id=@@identity
	
	insert into tb_backGroupProduct(groupProductId,saleProductId,colorId,metricsId,backGroupId,buyCount,inCount,loseCount,lossCount)
	select groupProductId,saleProductId,colorId,metricsId,@id,buyCount,inCount,loseCount,lossCount
	from tb_orderSaleGroupProduct
	where orderSaleGroupId=@orderSaleId

	update tb_backOder set BackPrice=BackPrice+b.payValue*c.backCount 
	from tb_orderSaleGroup a 
	inner join tb_saleGroupPay b on b.groupProductId=a.saleGroupId and b.payStyleId=1 
	inner join tb_backProduct c on c.orderSaleId=a.id 
	where tb_backOder.id=@backOrderId and a.id=@orderSaleId

	commit tran