/*************************************增加评论Lucere*******************************************************/
CREATE PROCEDURE p_addCommentLucere @id int,@memberName varchar(50),@ip varchar(16) 
 AS	
	declare @saleCode varchar(16)
	declare @comment varchar(2000)
	declare @level int
	begin tran
	select @saleCode=saleCode,@comment=comment,@level=convert(int,substring(score,1,1)) from temp_lucereview where id=@id 
	
	print(@level)
	insert into tb_comment(saleCode, memberId, memberName, IP,createTime,content,[level],title,addway ) 
	values (@saleCode,0,@memberName,@ip,getDate(),@comment,@level,'',2)

	update temp_lucereview set isDealed=1 where id=@id
	
	commit tran