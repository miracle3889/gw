CREATE procedure p_addproductTohuanhuo @orderSaleId int,@orderId int,@huanhuoOrderId int,@buyCount int,@colorId int,@metricsId int
as
     declare @orderSaleProductId int 
     declare @realPrice int 
      declare @useGift int
     begin  tran
     INSERT INTO dbo.tb_orderSaleProduct(orderId,colorId,metricsId,saleProductCode,
					saleProductId,buyCount,stockPrice,productId,giftPrice)	
      select @huanhuoOrderId,@colorId,@metricsId,saleProductCode,saleProductId,@buyCount,stockPrice,productId,giftPrice
	from dbo.tb_orderSaleProduct where id=@orderSaleId and orderId=@orderId 
	
	
           set @orderSaleProductId=SCOPE_IDENTITY() 
		
           insert into dbo.tb_orderSaleProductPay(orderSaleProductId,payType,payValue) 
         select @orderSaleProductId,payType,payValue from dbo.tb_orderSaleProductPay where payType=1 and orderSaleProductId=@orderSaleId

	SELECT @realPrice=SUM(b.payValue*a.buyCount),@useGift=SUM(giftPrice*a.buyCount)
	FROM dbo.tb_orderSaleProduct a
	INNER JOIN dbo.tb_orderSaleProductPay b ON a.id=b.orderSaleProductId 
	WHERE b.payType=1 AND a.orderId=@huanhuoOrderId  and groupPh=0

	
	update tb_order set productPrice=@realPrice,useGift=@useGift  where id=@huanhuoOrderId

	
	insert into tb_updateTabaoProductCount(productCode,productCount,reMark) select productShelfCode,@buyCount,'换货'+ cast(@huanhuoOrderId as varchar(10))  from erp..tb_productStock where colorId=@colorId and metricsId=@metricsId
 commit tran