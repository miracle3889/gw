CREATE VIEW dbo.v_allBuyProductNew
AS
	--淘宝货架
	select b.productId AS saleProductId ,sum(a.productCount) as  buyCount,b.colorId,b.metricsId,9 as type,0 as needInCount,0 as twoDaysCount from erp..tb_shelfProductCount a
	inner join erp..tb_productStock b on a.productCode=b.productShelfCode
	 where shelfCode like 'T%' and a.productCount>0	
	group by b.productId,b.colorId,b.metricsId 
	UNION ALL
	

	select b.productId AS saleProductId ,sum(a.productCount) as  buyCount,b.colorId,b.metricsId,9 as type,0 as needInCount,0 as twoDaysCount from erp..tb_shelfProductCount a
	inner join erp..tb_productStock b on a.productCode=b.productShelfCode
	 where shelfCode not  like 'T%' and a.productCount>0	and  productCode in(select productCOde from tb_tempProductShelf)  and shelfCOde not in('X0000','Y0000')
	group by b.productId,b.colorId,b.metricsId 
	UNION ALL
	---订单中
	/*SELECT a.productId AS saleProductId, a.buyCount AS buyCount, a.colorId AS colorId, 
	      a.metricsId AS metricsId, 1 AS type,0 as   needInCount,0 as twoDaysCount
	FROM dbo.tb_orderSaleProduct a 
	INNER JOIN   dbo.tb_order b ON b.id = a.orderId
	--WHERE (b.orderStatus IN (1, 6)  or (b.orderStatus =5 and isPayment=1)) AND b.isDelete != 1
	WHERE b.orderStatus =1 AND b.isDelete != 1
	UNION ALL
	*/	
	select saleProductId,buyCount,colorId,metricsId, 1 AS type,0 as   needInCount,0 as twoDaysCount from tb_temp_waitPhProduct
	UNION ALL
	---购物车中
	SELECT c.productId AS saleProductId, buyCount, colorId, metricsId, 2 AS type,0 as   needInCount,0 as twoDaysCount
	FROM tb_shoppingBag a 
	INNER JOIN    dbo.tb_SaleProduct c ON a.saleProductId = c.id
	WHERE resource = 0 AND isStock = 1
	--union all
	--select productId as saleProductId, 0  as buyCount, colorId, metricsId,3 as type,
	--sum( b.buyCount)  as needInCount 	
	--,0 as twoDaysCount	
	--from erp. dbo.tb_buyProductList a
	--inner join erp.dbo.tb_buyProductProtity b on a.id=b.buyProductId and a.buyStatus in(1,2,3) and isdeleted<>1
	--group by productId, colorId, metricsId having(sum(b.buyCount)>0) 	

	---采购单
	--select productId as saleProductId, -1*sum(case isBuyStock when 1 then b.buyCount else   0 end)  as buyCount, colorId, metricsId,3 as type,
	--sum(case isBuyStock when 0 then b.buyCount else   0 end) as needInCount from erp. dbo.tb_buyProductList a
	--inner join erp.dbo.tb_buyProductProtity b on a.id=b.buyProductId and a.buyStatus in(1,2,3) and isdeleted<>1
	--group by productId, colorId, metricsId having(sum(b.buyCount)>0)
	
	--union all
	
	--select c.productId as saleProductId, (sum(backCount)*-1) as buyCount ,c.colorId,c.metricsId,4 as type ,0 as needInCount from tb_order a 
	--inner join tb_rejectOrder b on a.id=b.orderId 
	----inner join tb_orderSaleProduct c on c.orderid=a.id and c.backCount>0
	--group by c.colorId,c.productId,c.metricsId
	--订单入库单
	--union all
	--select c.productId as saleProductId,sum(a.productCount) *-1 as buyCount,c.colorId,c.metricsId,5 as  type ,0 as needInCount,0 as twoDaysCount 
	--from erp..tb_orderInstockProduct a ,erp..tb_orderInstock b,erp..tb_productStock c 
	--where b.status in (0,1) and b.id=a.instockId and a.productCode=c.productShelfCode 
	--group by c.productId,c.colorId,c.metricsId
	
	--union all
	---select  b.productId as saleProductId,sum(getCount) *-1 as buyCount,a.colorId,a.metricsId,6 as  type ,0 as needInCount  from tb_backProduct  a
	--inner join tb_saleProduct   b on a.saleId=b.id
	--where backId not in (select orderId from erp..tb_orderInstockOrder where type=3)
	--group by  b.productId,a.colorId,a.metricsId
		














