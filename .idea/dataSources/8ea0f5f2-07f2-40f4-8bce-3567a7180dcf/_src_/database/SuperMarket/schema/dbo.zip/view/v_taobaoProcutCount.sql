
CREATE view  v_taobaoProcutCount
as 

select x.productSHelfCode,x.buyCount-isnull(y.buyCount,0)-isnull(u.buyCount,0) as productCount 
from (
SELECT  b.productSHelfCode,SUM(a.productCount)   as buyCount
FROM ERP.dbo.tb_shelfProductCount a
inner join erp..tb_productStock b  on a.productCode=b.productSHelfCode 
WHERE (shelfCode LIKE 'T%') AND (a.productCount > 0)
group by  b.productSHelfCode,b.colorId,b.metricsId) 
as x 
left join 
(
SELECT c.productSHelfCode, sum(a.buyCount) as buyCount 
FROM dbo.tb_orderSaleProduct a 
INNER JOIN   dbo.tb_order b ON b.id = a.orderId
inner join erp..tb_productStock c on  a.colorId=c.colorId and a.metricsId=c.metricsId
WHERE (b.orderStatus IN (1)  or (b.orderStatus=20 and b.id in(
 
select b.orderId from erp..tb_distribute a
inner join  erp..tb_Orderdistribute b on a.id=b.distributeId
 where isTransfer=0

	)) )     AND b.isDelete != 1 and  b.magSourceRemark='taobao'	
group by  c.productSHelfCode
) as y on x.productSHelfCode=y.productSHelfCode
left join  --sum(buyCount) 
(
select skuCode as  productSHelfCode,sum(buyCount)   as buyCount from  tb_taobaoWaitBuyerProduct group by skuCode
) as u  on u.productSHelfCode=x.productSHelfCode

 



