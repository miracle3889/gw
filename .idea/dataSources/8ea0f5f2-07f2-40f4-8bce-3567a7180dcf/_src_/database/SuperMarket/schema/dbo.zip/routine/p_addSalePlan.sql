/*-------------------------------添加商品销售计划--------------------------------------*/
CREATE PROCEDURE p_addSalePlan  @doMan INT 
AS 
	DECLARE @returnValue INT
	SET @returnValue=0
	DECLARE @Code VARCHAR(50)
	BEGIN TRAN 
	EXEC p_getSalePlanCode 1,@Code OUTPUT
	INSERT INTO dbo.tb_salePlan(doMan,code) VALUES(@doMan,@Code)
	SET @returnValue=SCOPE_IDENTITY()
	COMMIT TRAN 
	SELECT @returnValue