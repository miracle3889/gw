CREATE VIEW dbo.v_buyProductOnshoopingbag
AS
SELECT c.productId AS saleProductId, a.buyCount, a.colorId, a.metricsId
FROM dbo.tb_shoppingBag a INNER JOIN
      dbo.tb_saleProduct c ON a.saleProductId = c.id
WHERE (a.resource = 0)

