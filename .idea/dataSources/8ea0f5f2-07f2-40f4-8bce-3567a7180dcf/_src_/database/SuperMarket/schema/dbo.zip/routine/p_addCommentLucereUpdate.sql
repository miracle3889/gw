/*************************************增加评论Lucere并修改过的*******************************************************/
CREATE PROCEDURE p_addCommentLucereUpdate @id int,@memberName varchar(50),@ip varchar(16),@comment varchar(2000),@level int,@saleCode varchar(16),@tDate varchar(16)  
 AS	
	begin tran

	insert into tb_comment(saleCode, memberId, memberName, IP, createTime, content,[level],title,isChecked,addway ) 
	values (@saleCode,0,@memberName,@ip,@tDate,@comment,@level,'',1,2)

	update temp_lucereview set isDealed=1 where id=@id
	
	commit tran