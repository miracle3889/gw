CREATE FUNCTION [dbo].[getRealGetPrice] (@order int)  
RETURNS int  AS  
BEGIN 
 	declare @productPrice int
	declare @deliverPrice int
	declare @useGift int
	declare @useGiftTemp int
	declare @useAccount int
	declare @backPrice int
	declare @priceTemp int
	declare @memberId int
	select @productPrice=productPrice,@deliverPrice=deliverPrice,@useGift=useGift,@useAccount=useAccount,@backPrice=backPrice,@memberId=memberId  from tb_order where id=@order
	set @useGiftTemp=0
	IF EXISTS (SELECT 1 FROM tb_memberCard where memberid=@memberId and memberClass=1)
	begin
		set @useGiftTemp=((@productPrice-@backPrice)/10000)*500
	end

	select @priceTemp=sum(price)  from  dbo.tb_memberGift  a
	inner join dbo.tb_giftCard b on a.giftId=b.id
	where a.useOder=@order
	
	IF(@priceTemp IS NULL) SET @priceTemp=0
	
	if(@priceTemp>(@productPrice-@backPrice))
	begin
		set @useGiftTemp=@useGiftTemp+ ((@productPrice-@backPrice)/5000)*1000
	end
	else
	BEGIN
		set @useGiftTemp=@priceTemp+@useGiftTemp
	END
	return @productPrice+@deliverPrice-@useGiftTemp-@useAccount-@backPrice
END