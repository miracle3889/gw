CREATE procedure p_addNeedProductFromShopping @memberId int
as
 begin tran
	insert into tb_registProduct(saleId,productId,colorId,metricsId,needCount,memberId)
	select a.saleProductId,b.productId,colorId,metricsId,buyCount,@memberId from 
	dbo.tb_shoppingBag a
	inner join tb_saleProduct b on a.saleProductId=b.id
	 where memberId=@memberId
	delete from tb_shoppingBag where memberId=@memberId
commit tran