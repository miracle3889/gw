CREATE PROCEDURE p_sendMsg @mobileNum VARCHAR(11),@content NVARCHAR(2000)
AS
	DECLARE @msgContent NVARCHAR(70)
	WHILE(LEN(@content)>0)
	BEGIN
		SET @msgContent=SUBSTRING(@content,1,60)
		SET @content=SUBSTRING(@content,61,LEN(@content))
		EXEC p_sendMsgReal @mobileNum,@msgContent
	END