CREATE PROCEDURE p_getNeedCheckPostCount 
AS 
	select count(*) from tb_needCheckPostAddrMember
