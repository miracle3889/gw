
/*------------------转换发货状态------------------------------------*/
CREATE  PROCEDURE p_addSaleToshoopingbag @memberId INT
AS 
	DECLARE @saleProductId INT
	DECLARE @saleCode VARCHAR(50)
	DECLARE @colorId INT
	DECLARE @metricsId INT
	DECLARE @needCount INT
	DECLARE @MYiD INT
	BEGIN TRAN

		DECLARE authors_cursor CURSOR FOR
		SELECT b.saleCode,b.id,a.colorId,a.metricsId,a.needCount,a.id
		FROM Supermarket.dbo.tb_needProdcut a 
		inner join tb_saleProduct b on b.productId=a.productId
		where  b.saleTypeId=1 and a.isReturnCall!=3 and a.memberID=@memberId
		
		OPEN authors_cursor
		FETCH NEXT FROM authors_cursor 
		INTO @saleCode,@saleProductId,@colorId,@metricsId,@needCount,@MYiD
		WHILE @@FETCH_STATUS = 0
		BEGIN
				DECLARE @returnValue INT 
				EXEC p_addShoppingBagNeed @saleCode,@needCount,@saleProductId,@colorId,@metricsId,@memberId,@returnValue output--定单发货减库存
				if(@returnValue=1)
				begin 
					DELETE FROM Supermarket.dbo.tb_needProdcut where id=@MYiD
				end
				FETCH NEXT FROM authors_cursor 
				INTO @saleCode,@saleProductId,@colorId,@metricsId,@needCount,@MYiD
		END
	CLOSE authors_cursor
	DEALLOCATE authors_cursor

	COMMIT TRAN
