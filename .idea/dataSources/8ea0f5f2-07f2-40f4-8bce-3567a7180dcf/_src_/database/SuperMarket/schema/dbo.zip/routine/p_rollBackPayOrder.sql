/*------------------------------------------------------回滚定单------------------------------------------------------------------------------------*/
CREATE  PROCEDURE p_rollBackPayOrder @orderId INT, @rollManId int, @inAccount INT, @inBackPrice int
AS
	DECLARE @returnValue INT
	DECLARE @memberId INT
	DECLARE @orderCode varchar(50)
	DECLARE @account INT
  	DECLARE @TScore INT
	DECLARE @orderPrice INT
	
	SELECT @memberId=memberId,@account=useAccount,@orderCode=orderCode,@orderPrice=productPrice+deliverPrice-useAccount-useGift FROM dbo.tb_order WHERE id=@orderId --得到对应的会员号
	SET @returnValue=0
	IF(@orderPrice=(@inAccount+@inBackPrice))
	BEGIN
	BEGIN TRAN 
		
		INSERT INTO dbo.tb_shoppingBag(productCode,saleProductId,colorId,metricsId,buyCount,memberId,type,groupPh)
		SELECT saleProductCode,saleProductId,colorId,metricsId,buyCount,@memberId,1,groupPh FROM dbo.tb_orderSaleProduct WHERE orderId=@orderId  and groupPh=0--定单中商品返回到用户购物车中
	
		INSERT INTO dbo.tb_shoppingBag(productCode,saleProductId,colorId,metricsId,buyCount,memberId,type,groupPh)
		SELECT saleProductCode,saleProductId,colorId,metricsId,a.buyCount/b.buyCount,@memberId,1,groupPh FROM dbo.tb_orderSaleProduct a
		inner join tb_groupPh b on a.groupPh=b.id 
		WHERE orderId=@orderId  and groupPh<>0--定单中商品返回到用户购物车中

		update tb_groupPh set isBuy=0 where id in(SELECT groupPh FROM dbo.tb_orderSaleProduct WHERE orderId=@orderId )

        	
		--返回积分
		select @TScore=sum(c.payValue*b.buyCount) from tb_order a 
		inner join dbo.tb_orderSaleProduct b on a.id=b.orderId
		inner join dbo.tb_orderSaleProductPay c on b.id=c.orderSaleProductId
		where a.id=@orderId and c.payType=2
	
		IF(@account IS NOT NULL)
		BEGIN
			if(@account>0)
			exec dbo.p_addAccountOpLogBySystem @memberId,@account,2,'返回购物车',0
			--UPDATE dbo.tb_member SET account=account+@account WHERE id=@memberId --帐户余额反还
		END
	
		IF(@TScore IS NOT NULL)
		BEGIN
			if(@TScore>0)
			exec dbo.p_addScoreOpLog @memberId,@TScore,9,'返回购物车'
			--UPDATE dbo.tb_member SET score=score+@TScore WHERE id=@memberId --帐户几分反还
		END
	
	
		UPDATE dbo.tb_order SET  isUpdate=0,isDelete=1  WHERE id=@orderId --删除原定单
	
	 	declare 	@count int
		declare @distributeId int 
		select @distributeId=max(distributeId) from erp.dbo.tb_orderDistribute where orderId=@orderId
	
		select @count=count(*) from Supermarket.dbo.tb_order where ( deliverManId>0 or ( deliverManId<=0 and   isdelete=1)) and id in(
		select orderId from erp.dbo.tb_orderDistribute where distributeId=@distributeId)
	
	
		update erp.dbo.tb_Distribute set sortingCount=@count where id=@distributeId
	
		UPDATE dbo.tb_memberGift  SET isUse=0,useOder=0 WHERE useOder=@orderId
		UPDATE dbo.tb_giftCard SET isUse=0,useOder=0 WHERE useOder=@orderId--礼券返还
		
		IF(@inAccount>0)
			EXEC  p_addAccountOpLogBySystem @memberId,@inAccount,4,'已付款订单',@rollManId
		IF(@inBackPrice>0)
			INSERT INTO tb_payOrderBackPrice (orderId,orderCode,needBackPrice,addMan) VALUES(@orderId,@orderCode,@inBackPrice,@rollManId)
		SET @returnValue=1
	COMMIT TRAN
	END
        SELECT @returnValue
