
CREATE  procedure [dbo].[p_updateSaleSchedulingProduct] @saleSchedulingId int,@saleId int
as 
	--重复提交 同一次上新记录已存在改商品
	if exists (select 1 from [SuperMarket].[dbo].[tb_saleSchedulingProduct] where schedulingId=@saleSchedulingId and saleId=@saleId)
	begin
		select 0 as ret
	end
	else
	begin
			--获取Nick
			declare @nickId int
			select @nickId=nickId  from SuperMarket..[tb_saleScheduling] where id=@saleSchedulingId
			--print @nickId
			if(@nickId>0)
			begin
				--同一个品牌下是否有此商品
			   if exists(	
				select 1 from [SuperMarket].[dbo].[tb_saleSchedulingProduct] where schedulingId in
				( 
					select id from SuperMarket..[tb_saleScheduling] where nickId=@nickId
				 ) and saleId=@saleId
				)
				begin
					update [SuperMarket].[dbo].[tb_saleSchedulingProduct] set schedulingId=@saleSchedulingId where saleId=@saleId
					and schedulingId in
					(  
						select id from SuperMarket..[tb_saleScheduling] where nickId=@nickId
					) --更新此品牌下的此商品的日期
				end
				else
				begin
					--新增
					insert into [SuperMarket].[dbo].[tb_saleSchedulingProduct](schedulingId,saleId ) values(@saleSchedulingId,@saleId)
				end
				select 1 as ret
			end
			else
			begin
				select -1 as ret
			end
		end