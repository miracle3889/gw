/*----------------------------------------得到需要付款的定单数量-------------------------------------------------*/
CREATE PROCEDURE p_getNeedPayCount 
AS
	--SELECT COUNT(*) FROM tb_order WHERE orderStatus=6  AND isDelete!=1
	select 0