CREATE   PROCEDURE p_updateSaleProductRemarks @saleProductId INT,@quality VARCHAR(500) ,
					  @inSize VARCHAR(500) ,@clearPRemark VARCHAR(500)
AS 
	 UPDATE  erp.dbo.tb_product SET quality=@quality,inSize=@inSize,useRemark=@clearPRemark WHERE id in (select productId from tb_saleProduct where id=@saleProductId)
