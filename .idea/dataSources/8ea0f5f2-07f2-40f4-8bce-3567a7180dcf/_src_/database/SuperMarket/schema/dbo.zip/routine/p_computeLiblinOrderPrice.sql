CREATE procedure [dbo].[p_computeLiblinOrderPrice] @orderId int
as 
	DECLARE @userAccount int  --使用帐户余额
	declare @useGift int --使用礼券
	declare @deliverPrice int --送货费用
	declare @payType int  --付款类型
	DECLARE @realPrice INT --实际价格
	DECLARE @realPriceGroup INT --实际价格
	DECLARE @realPriceReal INT --实际价格
	declare @memberId int --会员Id
	declare @type int
	declare @provinceId int
	declare @cityId int 
	declare @regionalId1 int
	declare @regionalId2 int 
	declare @addId int
	declare @isUse int
	declare @freeType int
	declare @doman int
	declare @magSourceRemark varchar(50)



	SELECT @realPrice=SUM(b.payValue*a.buyCount) 
	FROM dbo.tb_orderSaleProduct a
	INNER JOIN dbo.tb_orderSaleProductPay b ON a.id=b.orderSaleProductId 
	WHERE b.payType=1 AND a.orderId=@orderId  and groupPh=0

	if(@realPrice is null)
		set @realPrice=0
	if(@useGift is null)
		set @useGift=0
	if(@userAccount is null)
		set @userAccount=0
	
	set @realPriceReal=@realPrice-@useGift
	declare @cardClass int
	select top 1 @cardClass=memberClass from tb_memberCard where memberId=@memberId
	if(@cardClass is null)
	set @cardClass=0



	declare @transport int
	set @transport=0
	declare @proxy int
	set @proxy=0

	
	declare @useGiftXXX int
	declare @getScore INT  --所得积分
	
	--如果包含新优惠券
	if exists(select 1 from tb_memberGift a inner join tb_giftCard b on a.giftId=b.id  where a.useOder=@orderId and b.giftType=1) -- and @userAccount=0
	begin
			declare @useGift2 INT	
			declare @needPrice INT	
			--最大使用限额
			select @useGift2=sum(b.price),@needPrice=sum(needprice) from tb_memberGift a 
			inner join tb_giftCard b on a.giftId=b.id
			 where a.useOder=@orderId and b.giftType=1 and memberId=@memberId
			
			if(@needPrice<=@realPrice)
			begin
				set @useGift=@useGift2
				UPDATE tb_order SET useGift=@useGift  WHERE id=@orderId
				--if((@useGift2%10000)=0)
				if(1=1)
				begin
					if(@provinceId=1 or @provinceId=2 or @provinceId=3)
					SET @freeType=3
					else
					SET @type =5
				end
				else
				begin
					SET @freeType=3
				end
				if(@payType=1)
				begin
					update tb_order set payType=4,orderstatus=6 where  id=@orderId
				end
			end
			else
			begin
				set @useGift=0
				UPDATE tb_order SET useGift=0  WHERE id=@orderId
			end			
	end
	else--使用原礼券
	begin	
		select @useGiftXXX=sum(b.price) from tb_memberGift a 
		inner join tb_giftCard b on a.giftId=b.id
		 where a.useOder=@orderId and b.giftType=0
		
		if(@useGiftXXX is null ) set @useGiftXXX=0
			UPDATE tb_order SET useGift=@useGiftXXX  WHERE id=@orderId --更新使用礼券情况
		
		set @useGift=@useGiftXXX --更新使用礼券信息
		
		
		declare @maxUseGift INT --最多使用的礼券
		SET @maxUseGift=@realPrice/5000*1000
		
		
		SET @getScore=@realPrice/100
	
	
	
		/*if(@cardClass=1 or  @cardClass=2)--如果是优卡用户双倍积分
		begin

			SET @getScore=@getScore*2
			
			UPDATE tb_order SET useGift=useGift+@realPrice/10000*500  WHERE id=@orderId
			
			set @useGift=@useGift+@realPrice/10000*500 --使用了优卡
			--update tb_order set remark=remark+'优卡用户免运费 优惠'+cast((@realPrice/10000*500)/100 as varchar(10))+'元' where id=@orderId
			
			if(@maxUseGift<@useGift)
			BEGIN
				UPDATE tb_order SET useGift=@maxUseGift  WHERE id=@orderId
				SET @useGift=@maxUseGift
			END
			
		end
		ELSE
		BEGIN*/
			if(@maxUseGift<@useGift)
			BEGIN
				UPDATE tb_order SET useGift=@maxUseGift  WHERE id=@orderId
				SET @useGift=@maxUseGift
			END
		/*END*/
	end


DECLARE @returnCount INT
SET @returnCount=0

select @returnCount=count(*) from tb_orderSaleProduct a 
inner join tb_groupPh b on a.groupPh=b.id and a.groupPh>0  and b.groupId=1069 and  a.orderid=@orderId
if(@returnCount>0)
begin
	set @transport=2300
	set @proxy=0
end

--免运费
if @freeType=1
	set @transport=0
--免手续费
if @freeType=2
	set @proxy=0
--全免
if @freeType=3
	begin
		set @proxy=0
		set @transport=0
	end



if(@payType=1)
begin
	update tb_order set getScore=0,productPrice=@realPrice,deliverPrice=@transport+@proxy,proxy=@proxy,
	transport=@transport,needGetPrice=@realPrice+@transport+@proxy-@useGift-@userAccount where id=@orderId
end
else
begin
	IF(@realPrice+@transport+@proxy-@useGift-@userAccount<=0)
	begin		
		update tb_order set getScore=0,productPrice=@realPrice,deliverPrice=@transport+@proxy,proxy=@proxy,
		transport=@transport,needGetPrice=0,orderstatus=1,isPayment=1,paymentDate=getDate()  where id=@orderId
	end
	else
	begin
		update tb_order set getScore=0,productPrice=@realPrice,deliverPrice=@transport+@proxy,proxy=@proxy,
		transport=@transport,needGetPrice=0  where id=@orderId
	end
end

--计算余额用的多了的情况

declare @diff int 

set @diff=@realPrice+@transport+@proxy-@useGift-@userAccount 

if(@diff<0 )
begin
	if(@userAccount>=@diff)
	begin
		set @diff=@diff*-1
		update tb_order set useAccount=useAccount-@diff where id=@orderId
		exec dbo.p_addAccountOpLog @memberId,@diff,1,'核算订单使用余额多出返还'
	end
end


if exists(select 1   from tb_order where orderstatus =1 and isdelete<>1 and id=@orderId)
begin
	delete from tb_temp_waitPhProduct where orderId=@orderId
	
	insert into tb_temp_waitPhProduct(orderId,saleProductId,buyCount,colorId,metricsId)
	SELECT a.orderId,a.productId AS saleProductId, a.buyCount AS buyCount, a.colorId AS colorId, 
	      a.metricsId AS metricsId
        FROM dbo.tb_orderSaleProduct a 
	INNER JOIN   dbo.tb_order b ON b.id = a.orderId
	WHERE b.orderStatus =1 AND b.isDelete != 1 and a.orderId=@orderId

end