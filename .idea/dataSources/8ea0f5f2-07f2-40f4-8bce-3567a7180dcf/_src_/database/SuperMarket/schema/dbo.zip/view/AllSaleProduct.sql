CREATE VIEW dbo.AllSaleProduct
AS
SELECT a.saleCode AS saleCode, a.id AS productId, b.name AS productName, 
      1 AS type
FROM dbo.tb_saleProduct a INNER JOIN
      ERP.dbo.tb_product b ON a.productId = b.id
