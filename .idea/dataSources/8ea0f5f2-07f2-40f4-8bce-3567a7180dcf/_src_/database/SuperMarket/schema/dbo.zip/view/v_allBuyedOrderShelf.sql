CREATE VIEW dbo.v_allBuyedOrderShelf
AS


SELECT
(case b.pId when 0 then  b.id  else b.pId end ) as  deliverId,
(case b.pId when 0 then  b.name  else c.name end ) as  deliverName,
 a.orderCode, a.orderStatus, 
      CONVERT(varchar(10), a.visaTime, 120) AS visaTime, 
      (CASE orderstatus WHEN 11 THEN 0 WHEN 18 THEN 0 ELSE (SUM(a.productPrice + a.deliverPrice
       - a.useGift - a.useAccount) - SUM(a.backPrice)) END) AS productPrice, 
      SUM(a.backPrice) AS backPrice, 0 AS price3, a.payType
FROM dbo.tb_order a INNER JOIN
      ERP.dbo.tb_user b ON a.deliverManId = b.id
left join ERP.dbo.tb_user c ON c.id = b.pId
WHERE (a.isDelete <> 1) AND (a.orderStatus IN (3, 17, 11, 18)) AND  isNotgetPrice=0 and 
      (a.visaTime IS NOT NULL) and   b.id not in(select transportId from erp..tb_transport)
GROUP BY (case b.pId when 0 then  b.id  else b.pId end ),(case b.pId when 0 then  b.name  else c.name end ) , 
CONVERT(varchar(10), a.visaTime, 120), a.orderCode, a.payType, 
      a.orderStatus


