create procedure [dbo].[p_addWeiXInMsg_shichuanResult] @msgcontent varchar(2000),@styleId int --
as	 
	 declare @shejishi int
	 declare @banshi int
	 declare @shejizhuli int
	 select @shejishi = sheJiShiId,@banshi = banShiId from ERP..mf_pCodeFabricMsg where id = @styleId
	 select @shejizhuli = userid from ERP..tb_designer_assistant where userPid=@shejishi
	 
	 insert into tb_weiXinMsg(userId,msgType,msgcontent)
	    select id,'news',REPLACE(@msgcontent,'ruhnn_openId',openId) from ERP..tb_user where id in (@shejishi,@shejizhuli,@banshi)
	 
	 
	