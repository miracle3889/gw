CREATE PROCEDURE p_addsaleProductEvery
AS 
declare @date varchar(10)

set @date=dateAdd(day,-30,getDate())
delete from   tb_temp_saleProductEvery where 日期>=@date


insert into tb_temp_saleProductEvery
select convert(varchar(10),a.createTime,120) as  日期,d.name as 商品名称 ,n.codeName as 颜色,p.codename as 规格,sum(buyCount) as 销售数量,
sum(backCount) as 拒收数量 ,sum(isNull(x.getCount,0)) as 退货数量
 from tb_order a
inner join tb_orderSaleProduct b on a.id=b.orderId
inner join tb_saleProduct c on c.id=b.saleProductId
inner join erp..tb_product d on c.productId=d.id 
inner join erp.dbo.tb_productColorCode n on n.id=b.colorId
inner join erp.dbo.tb_productMetricsCode p on p.id=b.metricsId
left join 
(
	select orderSaleId,sum(getCount) as getCount from tb_backProduct group by orderSaleId
) as  X on x.orderSaleId=b.id 

where a.orderstatus in(1,2,3,13,20,11,17,18) and createTime>=@date and isdelete<>1
group by d.name ,n.codeName,p.codename,convert(varchar(10),a.createTime,120) 

