
/****** 对象: 存储过程 dbo.info_addInfo    脚本日期: 2009-2-20 14:31:43 ******/

/*-----------------------------------------------------------添加资讯-----------------------------------------------

-------------------------------------*/
CREATE  PROCEDURE info_addInfo @title varchar(128), @dir1Id int, @dir2Id int, @keywords varchar(32), @editorName varchar(32), @provenance varchar(32), @recommentTypeId int, @smallImg varchar(128)
AS
	declare @returnValue int
	set @returnValue=0
	if (@recommentTypeId != 0)
	begin
		insert into info_title (title, dir1Id, dir2Id, keywords, editorName, provenance, recommentTypeId, smallImg, recommentDate) values (@title, @dir1Id, @dir2Id, @keywords, @editorName, @provenance, @recommentTypeId, @smallImg,getdate())
	end
	else
	begin
		insert into info_title (title, dir1Id, dir2Id, keywords, editorName, provenance, recommentTypeId, smallImg) values (@title, @dir1Id, @dir2Id, @keywords, @editorName, @provenance, @recommentTypeId, @smallImg)
	end	

	set @returnValue=scope_identity()
	select @returnValue
