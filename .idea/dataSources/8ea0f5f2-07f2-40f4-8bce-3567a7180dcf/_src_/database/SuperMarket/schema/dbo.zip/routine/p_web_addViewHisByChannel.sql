/*-----------------------------根据渠道记录浏览记录-------------------------------------*/
CREATE PROCEDURE p_web_addViewHisByChannel @saleId INT,@memberId INT,
					   @memberName VARCHAR(50),@channelCode VARCHAR(50),
					   @ip VARCHAR(50)
AS
	INSERT INTO dbo.tb_viewHisByChanel (saleId,memberId,memberName,channelCode,ip)
	VALUES(@saleId,@memberId,@memberName,@channelCode,@ip)
