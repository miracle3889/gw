CREATE PROCEDURE p_addCityMag @magId INT,@magCount INT,@cityId INT,@opMan INT,@remark VARCHAR(50)
AS
	IF EXISTS(SELECT 1 FROM tb_cityMag  WHERE cityId=@cityId AND magId=@magId)
		BEGIN
			UPDATE tb_cityMag SET magCount=magCount+@magCount,remark=@remark WHERE magId=@magId AND cityId=@cityId
		END
	ELSE
		BEGIN
			INSERT INTO tb_cityMag(magId,cityId,magCount,remark) VALUES(@magId,@cityId,@magCount,@remark)
		END
	INSERT INTO tb_cityMagHis(magId,cityId,getCount,opMan) VALUES(@magId,@cityId,@magCount,@opMan)