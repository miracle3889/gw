create procedure p_getJobRunStatus
as 
declare @job_id uniqueidentifier
 select @job_id = job_id  from msdb.dbo.sysjobs where name = '核算定单能否配货'

exec master..xp_sqlagent_enum_jobs 1, 'sa', @job_id

