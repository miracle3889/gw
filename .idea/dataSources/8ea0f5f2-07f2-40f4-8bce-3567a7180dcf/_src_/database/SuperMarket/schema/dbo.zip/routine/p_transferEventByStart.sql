CREATE procedure p_transferEventByStart @eventId int,@eventContent varchar(2000),@dealManId int,@departId int,@otherDepart int
as
	begin tran 

		insert into SuperMarket.dbo.tb_eventDeal(eventId,giveManId,departId,dealStatus,replyContent,dealManId,dealTime) values(@eventId,@dealManId,@departId,2,@eventContent,@dealManId,getDate())

		insert into SuperMarket.dbo.tb_eventDeal(eventId,giveManId,departId) values(@eventId,@dealManId,@otherDepart)
		update SuperMarket.dbo.tb_event set currentDepartId=@otherDepart,eventStatus=1 where id=@eventId
	commit tran 

