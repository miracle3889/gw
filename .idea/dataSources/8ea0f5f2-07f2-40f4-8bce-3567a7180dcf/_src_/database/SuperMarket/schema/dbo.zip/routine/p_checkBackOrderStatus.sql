/*-----------------------检查当前定单状态------------------------------------*/
CREATE PROCEDURE p_checkBackOrderStatus @orderID INT
AS
   DECLARE @orderStatus INT
   DECLARE @isUpdate INT
   DECLARE @returnValue INT
   SET  @returnValue=0
   SELECT @orderStatus=backStatusId,@isUpdate=isUpdate FROM dbo.tb_backOder WHERE id=@orderID
   BEGIN TRAN
     IF(@orderStatus=3 or @orderStatus=4 or @orderStatus=5 or @orderStatus=6 or @isUpdate=2)/*----isUpdate=2为已生成退货单------*/
        BEGIN 
		SET @returnValue=-1
        END 
     ELSE
	BEGIN
		UPDATE dbo.tb_backOder SET isUpdate=1 WHERE id=@orderID
		SET @returnValue=1
	END
    IF(@@ERROR<>0)
    BEGIN
	SET  @returnValue=0
        ROLLBACK TRAN 
    END 
  COMMIT TRAN 
  SELECT @returnValue