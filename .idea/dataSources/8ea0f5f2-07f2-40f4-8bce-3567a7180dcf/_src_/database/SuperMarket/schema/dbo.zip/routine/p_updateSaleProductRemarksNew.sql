CREATE   PROCEDURE p_updateSaleProductRemarksNew @saleProductId INT,@quality VARCHAR(500) ,
					  @inSize VARCHAR(500) ,@clearPRemark VARCHAR(500),@newPRemark VARCHAR(500),@beautyRemark  VARCHAR(500)
AS 
	 UPDATE  erp.dbo.tb_product SET quality=@quality,inSize=@inSize,useRemark=@clearPRemark,newPRemark=@newPRemark,beautyRemark=@beautyRemark 
WHERE id in (select productId from tb_saleProduct where id=@saleProductId)

