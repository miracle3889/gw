/*----------------------添加赠品到购物车-------------------------------*/
CREATE  PROCEDURE p_web_addShoppingPresent  @memberId int, @saleProductId1 int,
						@colorId1 int, @metricsId1 int, 
						@saleProductId2 int,
						@colorId2 int, @metricsId2 int
AS
	DECLARE @saleCode VARCHAR(50) --销售编号
	DECLARE @colorCode VARCHAR(2) --颜色编号
	DECLARE @metricsCode VARCHAR(2) --规格编号
        
	BEGIN TRAN 
	if(@saleProductId2!=0) --如果买就送商品没有选择则删除满就送商品
	BEGIN 
		/*--------------删除原有的满就送赠品-----------------------------*/
		DELETE FROM dbo.tb_shoppingBag WHERE memberId=@memberId 
		AND saleProductId IN 
		(
			 SELECT a.id FROM dbo.tb_saleProduct a 
			 INNER JOIN dbo.tb_saleType b ON a.saleTypeId=b.id
			 WHERE b.isGive=1 AND minPrice>0
	        	)
	END
	else
	BEGIN
		if(@saleProductId1!=0)--如果满就送商品没有则删除买就送商品
		BEGIN
			/*--------------删除原有的赠品-----------------------------*/
			DELETE FROM dbo.tb_shoppingBag WHERE memberId=@memberId 
			AND saleProductId IN 
			(
				 SELECT a.id FROM dbo.tb_saleProduct a 
				 INNER JOIN dbo.tb_saleType b ON a.saleTypeId=b.id
				 WHERE b.isGive=1 AND minPrice=0
		        	)
		END
		--ELSE --否则删除所有的赠品
		--BEGIN
			/*--------------删除原有的赠品-----------------------------*/
		--DELETE FROM dbo.tb_shoppingBag WHERE memberId=@memberId 
		--	AND saleProductId IN 
		--(
		-- SELECT a.id FROM dbo.tb_saleProduct a 
		--INNER JOIN dbo.tb_saleType b ON a.saleTypeId=b.id
		-- WHERE b.isGive=1 
		--)
		--END
	END
	if(@saleProductId1>0)--添加买就送商品
	BEGIN
		 SELECT @saleCode=saleCode FROM tb_saleProduct WHERE id=@saleProductId1         
		 SELECT @colorCode=code FROM ERP.dbo.tb_productColorCode WHERE id=@colorId1
	         SELECT @metricsCode=code FROM ERP.dbo.tb_productMetricsCode WHERE id=@metricsId1
			
	         SET @saleCode=@saleCode+@colorCode+@metricsCode
		
		 INSERT INTO tb_shoppingBag(productCode,buyCount,saleProductId,colorId,metricsId,
		 memberId,isRand,isPresent)  VALUES (@saleCode,1,@saleProductId1,@colorId1,@metricsId1,@memberId,1,1)
	END
      	if(@saleProductId2>0) --添加满就送商品
	BEGIN
	         SELECT @saleCode=saleCode FROM tb_saleProduct WHERE id=@saleProductId2         
	          SELECT @colorCode=code FROM ERP.dbo.tb_productColorCode WHERE id=@colorId2
	         SELECT @metricsCode=code FROM ERP.dbo.tb_productMetricsCode WHERE id=@metricsId2
			
	         SET @saleCode=@saleCode+@colorCode+@metricsCode
		
		 INSERT INTO tb_shoppingBag(productCode,buyCount,saleProductId,colorId,metricsId,
		 memberId,isRand,isPresent)  VALUES (@saleCode,1,@saleProductId2,@colorId2,@metricsId2,@memberId,1,2)
	END
	 COMMIT TRAN