
CREATE procedure updateNeiGouOrder @skuCode varchar(50),@orderId int,@buyCount int 
as 
	if exists(select 1 from SuperMarket..tb_neigouOrder where orderId=@orderId and status=0)
	begin
		declare @saleId int
		declare @colorId int
		declare @metricId int
		declare @productId int 
		declare @stockPrice int 
		
		select @saleId =c.id,@productId=b.id,
		@colorId=a.colorId,@metricId=a.metricsId,@stockPrice=b.stockPriceReal
		 from erp..tb_productStock a
		inner join erp..tb_product b on a.productId=b.id 
		inner join supermarket..tb_saleProduct c on c.productId=b.id 
		where productShelfCode=@skuCode
		
		INSERT INTO supermarket.dbo.tb_orderSaleProduct(orderId,colorId,metricsId,saleProductCode,
				saleProductId,buyCount,isRand,stockPrice,productId,needInType,isRegister)	
		select @orderId,@colorId,@metricId,@skuCode,@saleId,@buyCount,1,@stockPrice,@productId,0,0
		
		declare @ordersaleId int 
		set @ordersaleId=SCOPE_IDENTITY()
		
		
		insert into dbo.tb_orderSaleProductPay(orderSaleProductId,payType,payValue)
		select @ordersaleId,1,0 
	end