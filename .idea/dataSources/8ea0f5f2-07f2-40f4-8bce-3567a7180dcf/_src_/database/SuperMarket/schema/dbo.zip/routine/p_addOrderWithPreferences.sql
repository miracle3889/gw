/*---------------添加定单--------*/
CREATE  PROCEDURE p_addOrderWithPreferences      
				    @payType INT,
				    @deliverType INT,
				     @deliverPrice INT,
				     @memberId INT,
				     @orderStatus INT, 
				     @doMan INT,
				     @reMark VARCHAR(200),
				     @orderSource INT,
				     @magazineCode VARCHAR(50),
				     @receviceMan VARCHAR(50),
				     @post VARCHAR(50),
				     @receviceAddr1 VARCHAR(200),
				     @receviceAddr2 VARCHAR(200),
				     @receviceMobile VARCHAR(50),
				     @addrId INT,
				     @useAccount INT,
				     @getScore INT,
				     @regionalId1 int,
				     @regionalId2 int,
				     @provinceId INT,
				     @cityId INT,
				     @useGift VARCHAR(50),
				     @giftPice INT,
				     @magSource INT,
				     @magSourceRemark VARCHAR(50),
				     @isTransport int ,
				     @isProxy int,
				     @PreferencesPrice int,
				     @PreferencesRemark VARCHAR(100)
AS
	DECLARE @code VARCHAR(50)
	
	DECLARE @magSourceCodeFirst VARCHAR(50)
	DECLARE @score INT 
	DECLARE @returnId INT
	DECLARE @account INT
	DECLARE @tempScore INT
	declare @return1 int
	declare @productCountTemp int
	SET @productCountTemp=0
	SET @returnId=0


  /*---------验证库存--------------------------*/
	select  top 1 @productCountTemp=c.productId
	from tb_shoppingBag  a 
	inner join tb_saleProduct b on a.saleProductId=b.id
	inner join ERP.dbo.tb_productStock c 
	on b.productId=c.productId and a.colorId=c.colorId and a.metricsId=c.metricsId
	where memberId=@memberId 
	group by c.productId,c.colorId,c.metricsId having (sum(productCount)-sum(buyCount))<0
	
	IF(@productCountTemp>0)
		BEGIN
			SET @returnId=0  --库存不足
			SELECT @returnId
			return 
		END
	
		/*---------判断账户余额是否够--------------------------*/
	SELECT  @account=account,@magSourceCodeFirst=magSourceCodeFirst FROM dbo.tb_member  WHERE id=@memberId --得到帐户余额
	IF(@useAccount>@account)
		BEGIN
			SET @returnId=-1  --帐户余额不够
			SELECT @returnId
			return 
		END
	
		
	/*----------得到销售商品应扣除的积分------------------------*/
		SELECT @score=SUM(a.payValue)
		FROM tb_saleProductPay a
		INNER JOIN tb_payStyle b  ON a.payStyleId=b.id 
		INNER JOIN tb_shoppingBag c ON a.saleProductId=c.saleProductId
		WHERE   c.memberId=@memberId AND b.id=2 and type=1

		SET @tempScore=0 
		
		IF(@score IS NOT NULL)--存在积分商品
		BEGIN
			SELECT  @tempScore=score-@score FROM tb_member WHERE id=@memberId --判断积分
		END
		
		IF(@score  IS NULL)
		BEGIN
					SET @score=0
		END
		
		IF(@tempScore<0 and @score>0)--又积分商品并且积分不够
		BEGIN
			SET  @returnId=-2 --积分不够
			SELECT @returnId
			return 
		END

	
		/*----------下单条件满足------------------------*/
	
		BEGIN TRAN 
				EXEC p_geOrderCodeNew 1,@code OUTPUT --得到订单号
				
				if(@magSourceRemark is not null)
				begin
					set  @reMark=@magSourceRemark+'  '+@reMark --备注显示中添加 杂志编号
				end
				
				if(@useAccount is null) set @useAccount=0
				if(@giftPice is null) set @giftPice=0
				
				IF(@payType!=1)
				BEGIN
					set @orderStatus=6 --待付款验证
				END
				
			  declare @freeType int
				set @freeType=0
			  if(@isTransport=1)
				begin
			  		if(@isProxy=1)
			  			begin
							set @reMark=@reMark+'免快递费 免手续费'
							set @freeType=3
							
						end
						else
						begin
							set @reMark=@reMark+'免快递费' 
							set @freeType=1
						end
				end
				else
				begin
					if(@isProxy=1)
			  		begin
							set @reMark=@reMark+'免手续费' 
							set @freeType=2
					end
				end

				declare @buyCount int
				select @buyCount=count(*)+1 from tb_order where memberId=@memberId and isdelete<>1
				/*---------------------生成定单信息----------------------------------*/
				INSERT INTO dbo.tb_order(orderCode,payType,deliverType,deliverPrice,memberId,orderStatus,
							   doMan,reMark,orderSource,magazineCodeS,receviceMan,post,
							receviceAddr1,receviceAddr2,receviceMobile,addrId,useAccount,
						getScore,regionalId1,regionalId2,provinceId ,cityId,useGift,magSource,magSourceRemark,buyCountOrder,freeType)
				VALUES(@code,@payType,@deliverType,@deliverPrice,@memberId,@orderStatus,
					 @doMan,@reMark,@orderSource,@magazineCode,@receviceMan,@post,
				@receviceAddr1,@receviceAddr2,@receviceMobile,@addrId,(@useAccount+@PreferencesPrice),
				@getScore,@regionalId1,@regionalId2,@provinceId ,@cityId,@giftPice, @magSource,@magSourceRemark,@buyCount,@freeType)
	
				SET @returnId=SCOPE_IDENTITY() --得到刚刚插入的定单id 
				
				insert into tb_orderstatusHis(orderId,orderstatus,doMan) values(@returnId,@orderStatus,@doMan)
				if(@magSourceCodeFirst is not null and @magSourceCodeFirst<>'')
				begin
					set @magSourceCodeFirst=@magSourceRemark
				end
				UPDATE tb_member SET payType=@payType,deliverType=@deliverType,magSourceCode=@magSourceRemark ,magSourceCodeFirst=@magSourceCodeFirst
				WHERE id=@memberId --设置用户最后一次的付费方式和送货方式
								

				
				DECLARE @sql VARCHAR(500)
				SET @sql='UPDATE tb_memberGift SET isUse=1,useOder='+CAST(@returnId AS VARCHAR(10))+' WHERE 
				giftId IN('+@useGift+'0)'
				EXEC(@sql)
				SET @sql='UPDATE tb_giftCard SET isUse=1,userTime=getDate(),useOder='
				+CAST(@returnId AS VARCHAR(10))+' WHERE id IN('+@useGift+'0)'
				EXEC(@sql)  --更新礼拳使使用过的礼券过期
				
				
				/*---------------------------插入定单单件商品-------------------------------------------*/
				INSERT INTO dbo.tb_orderSaleProduct(orderId,colorId,metricsId,saleProductCode,
				saleProductId,buyCount,isRand,stockPrice)
				
			            SELECT @returnId,colorId,metricsId,productCode,saleProductId,sum(buyCount),isRand,c.stockPriceReal
				FROM 	dbo.tb_shoppingBag a 
				inner join tb_saleProduct b on a.saleProductId=b.id
				inner join erp.dbo.tb_product c on b.productId=c.id
				WHERE memberId=@memberId AND type=1 and groupPh=0
				group by colorId,metricsId,productCode,saleProductId,isRand,c.stockPriceReal
				
				
				/*---------------------------插入定单组合商品-------------------------------------------*/
				INSERT INTO dbo.tb_orderSaleProduct(orderId,colorId,metricsId,saleProductCode,
				saleProductId,buyCount,isRand,groupPh,stockPrice)
			             SELECT @returnId,colorId,metricsId,productCode,saleProductId,a.buyCount*b.buyCount,isRand,a.groupPh,d.stockPriceReal
				FROM 	dbo.tb_shoppingBag a 
				inner join tb_groupPh b on a.groupPh=b.id
				inner join tb_saleProduct c on a.saleProductId=c.id
				inner join erp.dbo.tb_product d on c.productId=d.id
				WHERE a.memberId=@memberId AND type=1 and groupPh!=0
				
				
				update tb_groupPh set isBuy=1 where memberId=@memberId --设置组合商品已下单
	
	
				/******************添加单件商品价格到tb_orderSaleProductPay***************************/
				insert into dbo.tb_orderSaleProductPay(orderSaleProductId,payType,payValue)
				select a.id,payStyleId,payValue
				from tb_orderSaleProduct a
				inner join dbo.tb_saleProductPay b on b.saleProductId=a.saleProductId
				where a.orderId=@returnId
				
				/*-------------------扣除积分-----------------------------*/
				if(@score>0)
				begin
					declare @getScoreX int
					set @getScoreX=(@score*(-1))
					exec  p_addScoreOpLog @memberId,@getScoreX,0,@code
				end
				
				IF(@useAccount>0)
				BEGIN
					--UPDATE dbo.tb_member SET account=account-@useAccount WHERE id=@memberId --扣除帐户金额
					declare @useAccount2 int
					set @useAccount2=@useAccount*-1
					exec dbo.p_addAccountOpLog @memberId,@useAccount2,9,@code
				end
				
				DELETE  FROM tb_shoppingBag WHERE memberId=@memberId  --删除购物车中单件商品 
				 
				
				if(@PreferencesPrice>0)
					begin
						insert into tb_orderPreferences(orderId,orderCode,userId,dealRemark)
						values(@returnId,@code,@doMan,@PreferencesRemark)
					end
				exec p_computeOrderPrice @returnId --核算运费         
			 	
		COMMIT TRAN 			
			
		declare @memberName varchar(50)--会员名称
		declare @doTime varchar(50)
		declare @dealHisId int
		set set @memberName=null
	  	set @dealHisId=0
	  	select  top 1 @dealHisId=a.id,@memberName=b.name,@doTime=a.doTime  from dbo.tb_memberShoppingBagDealHis  a 
		inner join erp.dbo.tb_user  b on a.addManId=b.id where a.memberId=@memberId 
 		and a.isBuy=0 order by a.doTime desc --是否有对于该会员的购物车回访记录

   	        if(@dealHisId!=0)
		begin
			   update tb_order set reMark='由'+@memberName+'与'+@doTime+'回访 '+reMark where id=@returnId
		            update dbo.tb_memberShoppingBagDealHis set isBuy=1,buyDate=getDate(),buyOrder=@code where id=@dealHisId
		end      

		declare @productPrice int
		select @productPrice=productPrice,@deliverPrice=deliverPrice,@useGift=useGift,@useAccount=useAccount from  dbo.tb_order where id=@returnId
	  if(@payType<>1)
		begin
				declare @mobileNum varchar(50)     
				declare @content nvarchar(200)   
				select @mobileNum=mobileNum from dbo.tb_member where id=@memberId and mobileNum 
				not in(select mobileNum from tb_blackNum)
				if(@mobileNum is not null )
			  begin
					if(len(@mobileNum)>=11 )
					begin
						declare @payName nvarchar(50)
						select @payName=name from dbo.tb_payType where id=@payType
						set @content='优邮提示：您的订单成功提交，金额：'+cast(cast(ROUND(((@productPrice+@deliverPrice-@useGift-@useAccount)*1.0/100.0),1) as  decimal(15,1))  as varchar(100))+'元。您选择的付款方式：'+@payName+'，为了尽快给您发货，请及时付费。谢谢您的支持'
				    		exec p_sendMsg @mobileNum,@content
					end
				 end
		end          

	SELECT @returnId
