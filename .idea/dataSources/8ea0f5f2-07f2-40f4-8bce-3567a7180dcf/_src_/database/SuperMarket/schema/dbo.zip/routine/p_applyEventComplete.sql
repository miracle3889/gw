create procedure p_applyEventComplete @eventId int,@eventContent varchar(2000),@dealManId int,@departId int
as
	begin tran 
		update SuperMarket.dbo.tb_eventDeal set dealStatus=1,replyContent=@eventContent,
		dealManId=@dealManId,dealTime=getDate() where eventId=@eventId and departId=@departId and dealStatus=0
		update SuperMarket.dbo.tb_event set eventStatus=2 where id=@eventId
	commit tran 




