CREATE procedure [dbo].[p_hebingdingdan]
	as 
     
     insert into tb_needCheckhedanOrder(memberId,receviceMan)
     select x.memberId,x.receviceMan from (
	 select memberId,receviceMan    from supermarket..tb_order 
			where memberId  in(
				 select memberId from supermarket..tb_order where isdelete<>1 and orderstatus=1 and ID in(
				 select orderId  from erp..tb_canDistributeOrderTemp )
				 group by memberId) and orderStatus=1 and isDelete<>1  group by  memberId,receviceMan 
				 having COUNT(*)>1) as x
				 left join tb_needCheckhedanOrder y on x.memberId=y.memberId
				 and x.receviceMan=y.receviceMan				 
				 where  y.memberId is null
				 
				 
	--可配货订单去除锁定的订单
	delete from erp..tb_canDistributeOrderTemp where orderId 
	in(
		select  a.id  from tb_order a
		inner join tb_needCheckhedanOrder b on a.memberId=b.memberId 
		and a.receviceMan=b.receviceMan and a.isDelete<>1 and a.orderStatus=1 and b.isLock=1 
	)
	
	
	
	/*
	declare @memberId int
	declare @orderId int
	declare @receviceMan varchar(50)
	declare @code varchar(50)
	
	DECLARE authors_cursor CURSOR FOR	
		select memberId,receviceMan from tb_order where orderstatus=1  and isdelete<>1 
		and id in(select orderId from erp..tb_canDistributeOrderTemp) and id not in
		(select orderId from dbo.tb_fudaiOrder)
		group by memberId,receviceMan having count(*)>1 
	OPEN authors_cursor
	FETCH NEXT FROM authors_cursor 
	INTO @memberId,@receviceMan
	WHILE @@FETCH_STATUS = 0
	BEGIN	
		begin tran 
		EXEC p_geOrderCodeNew 1,@code OUTPUT --得到订单号
		INSERT INTO dbo.tb_order(orderCode,payType,deliverType,deliverPrice,memberId,orderStatus,
						doMan,reMark,magazineCode,magazineCodeS,magSourceRemark,receviceMan,post,receviceAddr1,
						receviceAddr2,receviceMobile,addrId,useAccount,getScore,regionalId1,regionalId2,useGift,
						orderSource,provinceId ,cityId ,createTime,paymentDate,deliverManId)
		
		select @code,min(payType),min(deliverType),sum(deliverPrice),memberId,min(orderStatus),
						min(doMan),min(reMark),min(magazineCode),min(magazineCodeS),min(magSourceRemark),receviceMan,min(post),min(receviceAddr1),
						min(receviceAddr2),min(receviceMobile),min(addrId),sum(useAccount),sum(getScore),min(regionalId1),min(regionalId2),sum(useGift),
						min(orderSource),min(provinceId) ,min(cityId) ,min(createTime),min(paymentDate)   ,max(deliverManId)
		from tb_order where orderstatus=1  and isdelete<>1
		 and id in(select orderId from erp..tb_canDistributeOrderTemp) and  memberId=@memberId 
		 and receviceMan=@receviceMan  and id not in
		(select orderId from dbo.tb_fudaiOrder)
		group by memberId,receviceMan

		
		set @orderId= SCOPE_IDENTITY() --得到刚刚插入的定单id 
		update tb_orderSaleProduct set  orderId=@orderId where orderId
		 in(
			select id from tb_order where orderstatus=1  and isdelete<>1 
			and id 	in(select orderId from erp..tb_canDistributeOrderTemp) 
			and  memberId=@memberId and receviceMan=@receviceMan  and id not in
			(select orderId from dbo.tb_fudaiOrder)
		    )
		
		
		---合算订单信息
		exec supermarket..p_computeOrderPriceWithTaobao @orderId
		
		--更新淘宝信息
		update tb_taobaoCode set orderCOde=@code where orderCOde in
		(
			select orderCode from tb_order where orderstatus=1  and isdelete<>1 
			and id 
			in
			(
				select orderId from erp..tb_canDistributeOrderTemp
			) and  memberId=@memberId and receviceMan=@receviceMan  and id not in
			(select orderId from dbo.tb_fudaiOrder)
		)
		
		
		---删除原来订单
		update tb_order set  isdelete=1 , visaRemark='合并订单'  
		where orderstatus=1  
		and isdelete<>1
		and id in(select orderId from erp..tb_canDistributeOrderTemp) 
		and  memberId=@memberId and receviceMan=@receviceMan  and id not in
		(select orderId from dbo.tb_fudaiOrder)
		
		
		commit tran 
		FETCH NEXT FROM authors_cursor 
	INTO @memberId,@receviceMan
	END
	CLOSE authors_cursor


	DEALLOCATE authors_cursor
*/