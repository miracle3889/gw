/**********删除没到时间 或过期的目录特价商品***********/
CREATE  procedure p_sendSaleMuluTimeDelete

AS


-- 

UPDATE tb_saleProduct SET isDeleted=1, isSystem=1 where  saleTypeId=24

UPDATE tb_saleProduct SET isDeleted=0, isSystem=0 where  saleTypeId=24 and id in (

SELECT saleId FROM tb_saleMuluTime WHERE startDate<=CONVERT(varchar(12) , getdate(), 23) and endDate>CONVERT(varchar(12) , getdate(), 23) 

)