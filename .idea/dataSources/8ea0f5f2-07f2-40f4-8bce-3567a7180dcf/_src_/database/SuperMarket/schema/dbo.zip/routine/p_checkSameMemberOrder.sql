CREATE PROCEDURE p_checkSameMemberOrder @orderId INT
AS
	DECLARE @memberId INT
	DECLARE @count INT
	SELECT @memberId=memberId FROM tb_order where id=@orderId
	
	SELECT @count=count(*) FROM tb_order WHERE memberId=@memberId AND orderstatus IN(1,20,13) AND isdelete<>1
	
	IF(@count>1)
	BEGIN
		DELETE FROM tb_advanceOrder WHERE memberId=@memberId
		INSERT INTO tb_advanceOrder(orderId,memberId) SELECT  id,memberId FROM tb_order WHERE memberId=@memberId AND orderstatus=1 AND isdelete<>1
	END