CREATE  PROCEDURE p_updateMemberWithPostCheck  @name VARCHAR(50),@sex INT,
				           @post VARCHAR(50),@mobileNum VARCHAR(50),
				           @phoneNum VARCHAR(50),@homeAddr VARCHAR(200),
				           @complanyAddr VARCHAR(200),@EMail VARCHAR(50),@id INT,
					@homeAddrRegional INT,@complanyAddrRegional INT,@provinceId INT,@cityId INT,@bir varchar(50),@callRemark varchar(50),@postAddr VARCHAR(200),@postRegional INT
AS
	DECLARE @returnValue INT
	SET @returnValue=0
	BEGIN TRAN 
		UPDATE  dbo.tb_member  SET name=@name,sex=@sex,post=@post,
					mobileNum=@mobileNum,phoneNum=@phoneNum,
				homeAddr=@homeAddr,complanyAddr=@complanyAddr,
				EMail=@EMail,homeAddrRegional=@homeAddrRegional,complanyAddrRegional=@complanyAddrRegional,provinceId=@provinceId ,cityId=@cityId ,birth=@bir,callRemark=@callRemark,
				payAddr=@postAddr,payRegional=@postRegional
		 WHERE id=@id

		 DELETE FROM tb_needCheckPostAddrMember WHERE memberid=@id
		 SET @returnValue=1
	COMMIT TRAN
	SELECT @returnValue