CREATE procedure p_changeOrder @distributeCode varchar(10),@orderId int,@doMan int
as 
	begin
	insert into tb_delayOrderRemark(distributeCode,orderId,doManId,remark) values(@distributeCode,@orderId,@doMan,'还原订单商品到货架')

	update erp..tb_Distribute set transferCount=transferCount+1 where pCode=@distributeCode
	
	update erp..tb_orderDistribute set isDistribute=1,distributeManId=-100,distributeDate=getDate() where orderId=@orderId and isDistribute=0

	if EXISTS (select 1 from tb_order where isdelete<>1 and id=@orderId and orderstatus=20)
	begin
		update tb_order set orderstatus =1 where id=@orderId
		insert into  SuperMarket.dbo.tb_orderstatusHis(orderId,orderstatus,remark,doMan) values(@orderId,1,'缺货压单重配货',-100)
	end
	end


