/*调查diaocha.jsp*/

CREATE PROCEDURE p_diaocha @diaocha1 VARCHAR(64),@diaocha2 VARCHAR(64),@diaocha3 VARCHAR(64),@diaocha4 VARCHAR(64),@diaocha5 VARCHAR(64),@diaocha6 VARCHAR(64),@diaocha7 VARCHAR(64),@diaocha8 VARCHAR(64),@diaocha9 VARCHAR(64),@diaocha10 VARCHAR(2000),@userIp VARCHAR(32),@memberId int 
AS
	DECLARE @returnValue INT
	DECLARE @isSet INT
	DECLARE @isOrder INT
	DECLARE @score INT
	BEGIN TRAN
	SELECT @isSet=COUNT(*) FROM dbo.tb_diaocha WHERE memberId=@memberId
	IF(@isSet=0)
	BEGIN
		SELECT @isOrder=COUNT(*) FROM dbo.tb_order WHERE memberId=@memberId
		IF(@isOrder>0)
		BEGIN
			INSERT INTO dbo.tb_diaocha(diaocha1,diaocha2,diaocha3,diaocha4,diaocha5,diaocha6,diaocha7,diaocha8,diaocha9,diaocha10,userIp,memberId,isOrder) VALUES (@diaocha1,@diaocha2,@diaocha3,@diaocha4,@diaocha5,@diaocha6,@diaocha7,@diaocha8,@diaocha9,@diaocha10,@userIp,@memberId,1) 
		
			SELECT @score=score FROM dbo.tb_member WHERE id=@memberId
		
			exec p_addScoreOpLog @memberId,100,4,''/*4为调查增加积分*/

			Set @returnValue=2
		END
		ELSE
		BEGIN
			INSERT INTO dbo.tb_diaocha(diaocha1,diaocha2,diaocha3,diaocha4,diaocha5,diaocha6,diaocha7,diaocha8,diaocha9,diaocha10,userIp,memberId) VALUES (@diaocha1,@diaocha2,@diaocha3,@diaocha4,@diaocha5,@diaocha6,@diaocha7,@diaocha8,@diaocha9,@diaocha10,@userIp,@memberId) 
			Set @returnValue=1
		END
	END
	ELSE
	BEGIN
		Set @returnValue=0
	END
	IF(@@ERROR<>0)
	BEGIN
		ROLLBACK TRAN 
	END
	COMMIT TRAN
	SELECT @returnValue