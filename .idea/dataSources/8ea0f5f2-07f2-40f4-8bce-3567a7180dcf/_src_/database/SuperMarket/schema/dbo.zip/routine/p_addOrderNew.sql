/*----------------添加定单--------*/
CREATE    PROCEDURE p_addOrderNew      
				     @payType INT,
				     @deliverType INT,
				     @deliverPrice INT,
				     @memberId INT,
				     @orderStatus INT, 
				     @doMan INT,
				     @reMark VARCHAR(200),
				     @orderSource INT,
				     @magazineCode VARCHAR(50),
				     @receviceMan VARCHAR(50),
				     @post VARCHAR(50),
				     @receviceAddr1 VARCHAR(200),
				     @receviceAddr2 VARCHAR(200),
				     @receviceMobile VARCHAR(50),
				     @addrId INT,
				     @useAccount INT,
				     @getScore INT,
				     @regionalId1 int,
				     @regionalId2 int,
				     @provinceId INT,
				     @cityId INT,
				     @useGift VARCHAR(500),
				     @giftPice INT,
				     @magSource INT,
				     @magSourceRemark VARCHAR(50),
				     @isTransport int ,
				     @isProxy int
AS
	if(@memberid=4715)
	return 
        
	if not exists(select 1 from dbo.tb_shoppingBag  WHERE memberId=@memberId )
             begin
		select max(id) from tb_order where memberId=@memberId and isdelete<>1 and createTime>=convert(varchar(10),getDate(),120)
		return
 	     end
	DECLARE @code VARCHAR(50)
	
	DECLARE @magSourceCodeFirst VARCHAR(50)
	DECLARE @score INT 
	DECLARE @returnId INT
	DECLARE @account INT
	DECLARE @tempScore INT
	declare @return1 int
	declare @productCountTemp int
	SET @productCountTemp=0
	SET @returnId=0
	--连带销售
             if exists(select 1 from tb_shoppingBag WHERE memberId=@memberId and saleProductId  in(select assSaleId from tb_assSale ) )
	begin
		declare @count1 int
		declare @count2 int

		select @count1 =sum(buyCount) from tb_shoppingBag WHERE memberId=@memberId and saleProductId  in(select mainSaleId from tb_assSale )
		select @count2 =sum(buyCount) from tb_shoppingBag WHERE memberId=@memberId and saleProductId  in(select assSaleId from tb_assSale )
		
		if(isnull(@count2,0)>isnull(@count1,0))
		begin
			SET @returnId=-5  --库存不足
			SELECT @returnId
			return 
		end 
	end

  	/*---------验证库存--------------------------*/
	/*select  top 1 @productCountTemp=c.productId
	from tb_shoppingBag  a 
	inner join tb_saleProduct b on a.saleProductId=b.id
	inner join 
	 (
		select a.productId,a.colorId, a.metricsId,a.productCount+isnull(b.buyCount,0) as productCount from ERP.dbo.tb_productStock a
	left join 
	(
		select productId, colorId, metricsId, sum(b.buyCount) as buyCount  from erp. dbo.tb_buyProductList a
		inner join erp.dbo.tb_buyProductProtity b on a.id=b.buyProductId and a.buyStatus in(1,2,3) and isdeleted<>1 and isBuyStock=1
		group by productId, colorId, metricsId having(sum(b.buyCount)>0) 
	) as b on a.productId=b.productId and a.colorId=b.colorId and a.metricsId=b.metricsId

	) c 
	on b.productId=c.productId and a.colorId=c.colorId and a.metricsId=c.metricsId
	where memberId=@memberId and a.isNeedIn=0
	group by c.productId,c.colorId,c.metricsId having (sum(productCount)-sum(buyCount))<0
	
	IF(@productCountTemp>0)
		BEGIN
			SET @returnId=0  --库存不足
			SELECT @returnId
			return 
		END
	*/
	

	 /*---------判断账户余额是否够--------------------------*/
	SELECT  @account=account,@magSourceCodeFirst=magSourceCodeFirst FROM dbo.tb_member  WHERE id=@memberId --得到帐户余额
	IF(@useAccount>@account)
		BEGIN
			SET @returnId=-1  --帐户余额不够
			SELECT @returnId
			return 
		END
	
		
	/*----------得到销售商品应扣除的积分------------------------*/
		SELECT @score=SUM(a.payValue*c.buyCount)
		FROM tb_saleProductPay a
		INNER JOIN tb_payStyle b  ON a.payStyleId=b.id 
		INNER JOIN tb_shoppingBag c ON a.saleProductId=c.saleProductId
		WHERE   c.memberId=@memberId AND b.id=2 and type=1

		SET @tempScore=0 
		
		IF(@score IS NOT NULL)--存在积分商品
		BEGIN
			SELECT  @tempScore=score-@score FROM tb_member WHERE id=@memberId --判断积分
		END
		
		IF(@score  IS NULL)SET @score=0
		
		
		IF(@tempScore<0 and @score>0)--又积分商品并且积分不够
		BEGIN
			SET  @returnId=-2 --积分不够
			SELECT @returnId
			return 
		END

		declare @magInt int
		---计算加杂志
		delete from tb_shoppingBag where memberId=@memberId and (saleProductId=11183 or saleProductId=19245)
		declare @magSourceRemarklast varchar(10)
		set @magSourceRemarklast=subString(@magSourceRemark,4,len(@magSourceRemark))
		if(ISNUMERIC(@magSourceRemarklast)=1)
		begin
			
			set @magInt=cast(@magSourceRemarklast as  int)
			if(@magInt<278)
			begin
				insert into dbo.tb_shoppingBag(productCode,saleProductId,colorId,metricsId,buyCount,memberId)
				values('O111830101',11183,1564,1123,1,@memberId)
			end
		end
		else
		begin
			insert into dbo.tb_shoppingBag(productCode,saleProductId,colorId,metricsId,buyCount,memberId)
				values('O111830101',11183,1564,1123,1,@memberId)
		end


		declare @memberName varchar(50)--会员名称
		declare @doTime varchar(50)
		declare @dealHisId int
		declare @productPrice int
		set set @memberName=null
	  	set @dealHisId=0
	 	 select  top 1 @dealHisId=a.id,@memberName=b.name,@doTime=a.doTime  from dbo.tb_memberShoppingBagDealHis  a 
		inner join erp.dbo.tb_user  b on a.addManId=b.id where a.memberId=@memberId  and doTime>=dateAdd(day,-7,getDate())
 		and a.isBuy=0 order by a.doTime desc --是否有对于该会员的购物车回访记录

   		if(@dealHisId!=0)
		begin
			 set  @reMark='由'+@memberName+'与'+@doTime+'回访 '+@reMark
			  -- update tb_order set reMark='由'+@memberName+'与'+@doTime+'回访 '+reMark where id=@returnId
		          -- update dbo.tb_memberShoppingBagDealHis set isBuy=1,buyDate=getDate(),buyOrder=@code where id=@dealHisId
		end      
		
		/*----------下单条件满足------------------------*/
		
				if(@magSourceRemark is not null)
				begin
					set  @reMark=@magSourceRemark+'  '+@reMark --备注显示中添加 杂志编号
				end
				
				if(@useAccount is null) set @useAccount=0

				if(@giftPice is null) set @giftPice=0
				
				IF(@payType!=1)set @orderStatus=6 --待付款验证
				
			  
			  declare @freeType int
				set @freeType=0

		               --免运费计算
			  if(@isTransport=1)
				begin
			  		if(@isProxy=1)
			  			begin
							set @reMark=@reMark+'免快递费 免手续费'
							set @freeType=3
							
						end
						else
						begin
							set @reMark=@reMark+'免快递费' 
							set @freeType=1
						end
				end
				else
				begin
					if(@isProxy=1)
			  		begin
							set @reMark=@reMark+'免手续费' 
							set @freeType=2
					end
				end
				
				--计算会员订购数
				declare @buyCount int
					
				select @buyCount=count(*) from tb_order where isdelete<>1  and memberId  
					in(
						select id from tb_member where mobileNum 
						in
							(
								select mobileNum from tb_member where id=@memberId    and mobileNum <>'' and mobileNum is not null 
								union all 
								select phoneNum from tb_member where id=@memberId  and phoneNum <>'' and phoneNum is not null 
							)
						union all  
						select id from tb_member where phoneNum 
						in
							(
								select mobileNum from tb_member where id=@memberId    and mobileNum <>'' and mobileNum is not null 
								union all 
								select phoneNum from tb_member where id=@memberId  and phoneNum <>'' and phoneNum is not null 
							)
					) 
				set @buyCount=@buyCount+1
		--杂志RO208180101
				if(@buyCount=1)
				begin
					insert into dbo.tb_shoppingBag(productCode,saleProductId,colorId,metricsId,buyCount,memberId)
					values('RO208180101',20818,7493,6441,1,@memberId)
				end

				
				BEGIN TRAN 
				EXEC p_geOrderCodeNew 1,@code OUTPUT --得到订单号
				if(@magazineCode='taobao')
				begin
					set @magSourceRemark='taobao'
					set @payType=11
				end
				/*---------------------生成定单信息----------------------------------*/
				INSERT INTO dbo.tb_order(orderCode,payType,deliverType,deliverPrice,memberId,orderStatus,
							   doMan,reMark,orderSource,magazineCodeS,receviceMan,post,
							receviceAddr1,receviceAddr2,receviceMobile,addrId,useAccount,
						getScore,regionalId1,regionalId2,provinceId ,cityId,useGift,magSource,magSourceRemark,buyCountOrder,freeType)
				VALUES(@code,@payType,@deliverType,@deliverPrice,@memberId,@orderStatus,
					 @doMan,@reMark,@orderSource,@magazineCode,@receviceMan,@post,
				@receviceAddr1,@receviceAddr2,@receviceMobile,@addrId,@useAccount,
				@getScore,@regionalId1,@regionalId2,@provinceId ,@cityId,@giftPice, @magSource,@magSourceRemark,@buyCount,@freeType)
	
				SET @returnId=SCOPE_IDENTITY() --得到刚刚插入的定单id 
				
				insert into tb_orderstatusHis(orderId,orderstatus,doMan) values(@returnId,@orderStatus,@doMan)
				
				if(@magSourceCodeFirst is  null or  @magSourceCodeFirst='')
				begin
					set @magSourceCodeFirst=@magSourceRemark
				end
				
				
				
				DECLARE @sql VARCHAR(500)
				SET @sql='UPDATE tb_memberGift SET isUse=1,useOder='+CAST(@returnId AS VARCHAR(10))+' WHERE 
				giftId IN('+@useGift+'0)'
				EXEC(@sql)
				SET @sql='UPDATE tb_giftCard SET isUse=1,userTime=getDate(),useOder='
				+CAST(@returnId AS VARCHAR(10))+' WHERE id IN('+@useGift+'0)'
				EXEC(@sql)  --更新礼拳使使用过的礼券过期
					
				
				
				/*---------------------------插入定单单件商品-------------------------------------------*/
				INSERT INTO dbo.tb_orderSaleProduct(orderId,colorId,metricsId,saleProductCode,
				saleProductId,buyCount,isRand,stockPrice,productId,needInType,isRegister)			
	
			        SELECT @returnId,colorId,metricsId,productCode,saleProductId,sum(buyCount),isRand,c.stockPriceReal,b.productId,isNeedIn,isRegister
				FROM 	dbo.tb_shoppingBag a 
				inner join tb_saleProduct b on a.saleProductId=b.id
				inner join erp.dbo.tb_product c on b.productId=c.id
				WHERE memberId=@memberId AND type=1 and groupPh=0 and a.buyCount>0 and a.orderSaleId=0--2010-7-26 增加 a.buyCount>0
				group by colorId,metricsId,productCode,saleProductId,isRand,c.stockPriceReal ,b.productId,isNeedIn,isRegister
				order by productCode

				
				
				/*---------------------------插入定单组合商品-------------------------------------------*/
				INSERT INTO dbo.tb_orderSaleProduct(orderId,colorId,metricsId,saleProductCode,
				saleProductId,buyCount,isRand,groupPh,stockPrice,productId)
			        SELECT @returnId,colorId,metricsId,productCode,saleProductId,a.buyCount*b.buyCount,isRand,a.groupPh,d.stockPriceReal,c.productId
				FROM 	dbo.tb_shoppingBag a 
				inner join tb_groupPh b on a.groupPh=b.id
				inner join tb_saleProduct c on a.saleProductId=c.id
				inner join erp.dbo.tb_product d on c.productId=d.id
				WHERE a.memberId=@memberId AND type=1 and groupPh!=0 and a.buyCount>0--2010-7-26 增加 a.buyCount>0
				
				
				update tb_groupPh set isBuy=1 where memberId=@memberId --设置组合商品已下单
	
				
				
				--if(ISNUMERIC(@magInt)=1 and @magInt=262)
				--begin
				--	insert into dbo.tb_orderSaleProductPay(orderSaleProductId,payType,payValue)
				--	select a.id,payStyleId,(payValue*80/10000)*100
				--	from tb_orderSaleProduct a
				--	inner join dbo.tb_saleProductPay b on b.saleProductId=a.saleProductId
				--	where a.orderId=@returnId
				--end
				--else
				--begin
				/******************添加单件商品价格到tb_orderSaleProductPay***************************/
				insert into dbo.tb_orderSaleProductPay(orderSaleProductId,payType,payValue)
				select a.id,payStyleId,payValue
				from tb_orderSaleProduct a
				inner join dbo.tb_saleProductPay b on b.saleProductId=a.saleProductId
				where a.orderId=@returnId
				
				
				if exists (select 1 from tb_shoppingBag where orderSaleId>0 and memberId=@memberId)
				begin
					/*---------------------------插入定单单件商品包含orderSaleId》0-------------------------------------------*/
					INSERT INTO dbo.tb_orderSaleProduct(orderId,colorId,metricsId,saleProductCode,
					saleProductId,buyCount,isRand,stockPrice,productId,needInType,isRegister,backCause)			
		
				        SELECT @returnId,colorId,metricsId,productCode,saleProductId,sum(buyCount),isRand,c.stockPriceReal,b.productId,isNeedIn,isRegister,orderSaleId
					FROM 	dbo.tb_shoppingBag a 
					inner join tb_saleProduct b on a.saleProductId=b.id
					inner join erp.dbo.tb_product c on b.productId=c.id
					WHERE memberId=@memberId AND type=1 and groupPh=0 and a.buyCount>0 and a.orderSaleId>0--2010-7-26 增加 a.buyCount>0
					group by colorId,metricsId,productCode,saleProductId,isRand,c.stockPriceReal ,b.productId,isNeedIn,isRegister,orderSaleId
					order by productCode
					
					
					insert into dbo.tb_orderSaleProductPay(orderSaleProductId,payType,payValue)
					select a.id,payType,payValue
					from tb_orderSaleProduct a
					inner join dbo.tb_orderSaleProductPay b on b.ordersaleProductId=a.backCause
					where a.orderId=@returnId
									
					update tb_orderSaleProduct set backCause=0 where orderId=@returnId  and backCause>0

				end
				
				--end
				/*-------------------扣除积分-----------------------------*/
				if(@score>0)
				begin
					declare @getScoreX int
					set @getScoreX=(@score*(-1))
					exec  p_addScoreOpLog @memberId,@getScoreX,5,@code
				end
				
				IF(@useAccount>0)
				BEGIN
					declare @useAccount2 int
					set @useAccount2=@useAccount*-1
					exec dbo.p_addAccountOpLog @memberId,@useAccount2,1,@code
				end
				
				DELETE  FROM tb_shoppingBag WHERE memberId=@memberId  --删除购物车中单件商品 	

				/*set @magSourceRemarklast=subString(@magSourceRemark,4,len(@magSourceRemark))
				if(ISNUMERIC(@magSourceRemarklast)=1)
				begin
					set @magInt=cast(@magSourceRemarklast as  int)
					if(@magInt=800)
					begin
						if(@giftPice=0)
						begin
							exec p_minusOrderPrice @returnId --核算运费       
						end
					end
				end
				*/
			
				if(@magazineCode='CFT')
				begin
					exec p_computeOrderPriceCFT @returnId --核算运费    
				end
				else
				begin
					exec p_computeOrderPrice @returnId --核算运费         
				end
				
		COMMIT TRAN 			

		UPDATE tb_member SET payType=@payType,deliverType=@deliverType,magSourceCode=@magSourceRemark ,magSourceCodeFirst=@magSourceCodeFirst
				WHERE id=@memberId --设置用户最后一次的付费方式和送货方式

		--EXEC p_checkSameMemberOrder @returnId
		
		if(@dealHisId!=0)
		begin
			update dbo.tb_memberShoppingBagDealHis set isBuy=1,buyDate=getDate(),buyOrder=@code where id=@dealHisId
		end      
			
	
		declare @mobileNum varchar(50)     
		declare @content nvarchar(200)   
		declare @name varchar(50)
		
		/*if(@payType<>1)
		begin
				select @mobileNum=mobileNum from dbo.tb_member where id=@memberId and mobileNum 
				not in(select mobileNum from tb_blackNum)
				if(@mobileNum is not null )
			 	 begin
					if(len(@mobileNum)>=11 )
					begin
						declare @payName nvarchar(50)
						select @payName=name from dbo.tb_payType where id=@payType
						set @content='优邮提示：您的订单成功提交，金额：'+cast(cast(ROUND(((@productPrice+@deliverPrice-@useGift-@useAccount)*1.0/100.0),1) as  decimal(15,1))  as varchar(100))+'元。您选择的付款方式：'+@payName+'，为了尽快给您发货，请及时付费。谢谢您的支持'
				    		exec p_sendMsg @mobileNum,@content
					end
				 end
		end    */      
	set @mobileNum=null
	SELECT @name=name,@mobileNum=mobileNum  FROM tb_magAgentsMember   WHERE (@magSourceRemark LIKE magCode)
	
	if(@mobileNum is not null)
		begin
			select @deliverPrice=deliverPrice,@useGift=useGift,@useAccount=useAccount,@productPrice=productPrice from  dbo.tb_order where id=@returnId
			set @content='优邮提示：恭喜您有新订单产生！顾客：'+@receviceMan+'，单号'+@code+'，金额：'+cast(cast(ROUND(((@productPrice+@deliverPrice-@useGift-@useAccount)*1.0/100.0),1) as  decimal(15,1))  as varchar(100))+'元,感谢您的支持和努力！'
			exec p_sendMsgByClass @mobileNum,@content,99999,1
		end
	SELECT @returnId
	--end
	--else
	--begin
	--SELECT 0
	--end