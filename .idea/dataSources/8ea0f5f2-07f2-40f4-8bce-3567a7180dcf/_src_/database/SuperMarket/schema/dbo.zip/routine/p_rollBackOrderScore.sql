
CREATE  procedure p_rollBackOrderScore @orderCode varchar(50)
as
	declare @score int 
	declare @memberID  int
	select @score=sum(opAmount),@memberID=memberID from tb_scoreOpLog where orderCode = @orderCode and  opType in(1,4,6)  group by memberID --先取出当前用户现有积分，做日志记录用
	if(@score is not null and @score>0)
	begin
		set @score=@score*(-1)
		exec p_addScoreOpLog @memberID,@score,4,@orderCode
	end