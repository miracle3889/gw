CREATE procedure p_addShelfStock @shelfCode varchar(50),@productCode varchar(50),@count int,@dealManId int
as 
	begin tran
		if EXISTS(select 1 from tb_shelfProductCount where shelfCode=@shelfCode and productCode=@productCode)
		begin
			update tb_shelfProductCount set productCount=productCount+@count where shelfCode=@shelfCode and productCode=@productCode
		end
		else
		begin
			insert into tb_shelfProductCount(shelfCode,productCode,productCount) values(@shelfCode,@productCode,@count)
		end
		if(@@error<>0)
			rollback tran 
		insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,dealManId) values(@shelfCode,@productCode,@count,@dealManId)
		if(@@error<>0)
			rollback tran 
	commit tran
	