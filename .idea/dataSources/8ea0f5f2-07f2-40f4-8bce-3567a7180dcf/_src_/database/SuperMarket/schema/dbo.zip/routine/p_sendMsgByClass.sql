CREATE PROCEDURE p_sendMsgByClass @mobileNum VARCHAR(11),@content NVARCHAR(2000),@orderClass int,@sendManId int
AS
	DECLARE @msgContent NVARCHAR(70)
	WHILE(LEN(@content)>0)
	BEGIN
		SET @msgContent=SUBSTRING(@content,1,64)
		SET @content=SUBSTRING(@content,65,LEN(@content))
		INSERT INTO c3.dbo.tb_smsMission(sourceType,mobileNum,content,sendTime,orderByClass,sendManId) VALUES(0,@mobileNum,@msgContent,getDATE(),@orderClass,@sendManId)
	END