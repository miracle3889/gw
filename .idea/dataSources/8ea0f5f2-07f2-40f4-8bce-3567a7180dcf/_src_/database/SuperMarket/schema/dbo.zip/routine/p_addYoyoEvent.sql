CREATE procedure p_addYoyoEvent @eventTitle varchar(50),@eventContent varchar(2000),@addManId int,@candealMan varchar(50),@insertId int out
as
	begin tran 
		insert into dbo.tb_yoyoevent(eventTitle,eventContent,addManId,currentDealMan)
		values(@eventTitle,@eventContent,@addManId,@candealMan)
		set @insertId=scope_identity()
		insert into dbo.tb_yoyoeventDeal(eventId,giveManId,canDealMan,isFirst) values(@insertId,@addManId,@candealMan,1)
	commit tran 

