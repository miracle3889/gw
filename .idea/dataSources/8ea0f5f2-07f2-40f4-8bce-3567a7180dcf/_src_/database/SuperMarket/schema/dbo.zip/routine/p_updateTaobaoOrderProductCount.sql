CREATE PROCEDURE p_updateTaobaoOrderProductCount @orderSaleId INT,@productCount INT
AS
	UPDATE tb_ordersaleProduct set  buyCount=@productCount where id=@orderSaleId
	DECLARE @orderId int
	select @orderId=orderId  from tb_ordersaleProduct  where id=@orderSaleId 
	delete from tb_needUpdateProductCode where orderId =@orderId
	
	if exists(select 1   from tb_order where orderstatus =1 and isdelete<>1 and id=@orderId)
	begin
		delete from tb_temp_waitPhProduct where orderId=@orderId
		
		insert into tb_temp_waitPhProduct(orderId,saleProductId,buyCount,colorId,metricsId)
		SELECT a.orderId,a.productId AS saleProductId, a.buyCount AS buyCount, a.colorId AS colorId, 
		      a.metricsId AS metricsId
	        FROM dbo.tb_orderSaleProduct a 
		INNER JOIN   dbo.tb_order b ON b.id = a.orderId
		WHERE b.orderStatus =1 AND b.isDelete != 1 and a.orderId=@orderId
	
	end