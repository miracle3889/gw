/*------------------------------------------------------回滚定单------------------------------------------------------------------------------------*/
CREATE  PROCEDURE [dbo].[p_lockOrder] @orderId INT,@lockManId int,@reason VARCHAR(100)
AS	
	BEGIN TRAN 
		delete from tb_lockOrder where orderId=@orderId
		insert into tb_lockOrder(orderId,lockManId,reason) values(@orderId,@lockManId,@reason)
	COMMIT TRAN
