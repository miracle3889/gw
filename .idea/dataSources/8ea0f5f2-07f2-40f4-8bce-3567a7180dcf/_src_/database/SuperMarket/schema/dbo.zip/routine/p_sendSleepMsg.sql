CREATE       procedure p_sendSleepMsg
as 
	declare @memberId int
	declare @memberName varchar(200)
	declare @mobileNum varchar(50)
	declare @EMail varchar(200)
	declare @saleCode varchar(200)
	declare @saleCode0 varchar(200)
	declare @saleProductName varchar(200)
	declare @salePrice varchar(200)
declare @endTime varchar(200)
declare @oldsalePrice varchar(200)
	declare @nickname varchar(200)
	declare @i int
	set @i=0
	set @saleCode=''
	DECLARE authors_cursor0 CURSOR FOR
	--SELECT top 8 saleProductName,saleCode,salePrice FROM dbo.tb_searchSaleEntity a 
	--	inner join dbo.tb_newSale b on b.saleId=substring(a.saleCode,2,len(a.saleCode))
	--	where a.isGroup=0 order by newId()
	select   top 4 saleProductName,c.saleCode,a.price,b.salePrice,cast(DATEPART ( month , endTime ) as  varchar(10))+'月'+cast(DATEPART ( day , endTime ) as varchar(10))+'日' from dbo.tb_weekProduct a
inner join dbo.tb_saleProductOldPrice b on a.saleId=b.saleId
inner join dbo.tb_saleProduct c on a.saleId=c.id
inner join dbo.tb_searchSaleEntity d on a.saleId=d.saleId
 where startTime<=getDate() and endTime>=getDate()  order by newId()
	OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @saleProductName,@saleCode0,@salePrice,@oldsalePrice,@endTime
	WHILE @@FETCH_STATUS = 0
	BEGIN
		set @saleCode=@saleCode+@saleCode0+','
		FETCH NEXT FROM authors_cursor0 
		INTO @saleProductName,@saleCode0,@salePrice,@oldsalePrice,@endTime
	END
	CLOSE authors_cursor0
	DEALLOCATE authors_cursor0


	DECLARE authors_cursor CURSOR FOR
	
             select top 100 id,name,mobileNum,EMail,nickname from dbo.tb_member 
             where addDate < dateAdd(month,-1,getDate())
	and id not in (select memberId from tb_order where isSendSleep=0 and createTime>=dateAdd(month,-1,getDate())) 
             and mobileNum not in(select mobileNum from tb_blackNum)  and source<>'CFT' order by newId()
	
             OPEN authors_cursor
	FETCH NEXT FROM authors_cursor 
	INTO @memberId,@memberName,@mobileNum,@EMail,@nickname
	WHILE @@FETCH_STATUS = 0
	BEGIN
		declare @content nvarchar(500)
		
		
		--set @content='优邮新品上架，'+substring(@saleProductName,1,20)+'仅售'+@salePrice+'元，更多新品优惠请登录www.yoyo18.com' 
		set @content='本周特价：'+dbo.getRealProductName(@saleProductName)+'原价'+cast(   cast(ROUND((cast(@oldsalePrice as int)*1.0/100.0),1) as  decimal(15,1))  as varchar(100))+'元现仅需'+cast(   cast(ROUND((cast(@salePrice as int)*1.0/100.0),1) as  decimal(15,1))  as varchar(100))+'元 （截至'+@endTime+'），www.yoyo18.com' 
		 if(@mobileNum is not null )
			 begin
				if(len(@mobileNum)>=11 )
					begin
						 exec p_sendMsg @mobileNum,@content
						 declare @sendUrl varchar(500)
						  if(@EMail is not null and  @EMail<>'')
						  begin
							if not EXISTS  (select 1 from tb_unsubscribe where email=@EMail) 
							begin
							declare @title varchar(200)
							if(@memberName is null or @memberName ='')
							begin
							if(@nickname is null or @nickname ='')
							set @nickname=''
							else
							set @nickname=@nickname+'，'
							end
							else
							set @nickname=@memberName+'，'
							set @title=@nickname+'看看优邮刚刚上架的新品'
							 set @sendUrl='http://www.yoyo18.com/web/emailProductSearch.yoyo?saleCode='+@saleCode+'&email='+@EMail
	 						 exec p_sendEmail2 @sendUrl,@EMail,@title
						end
						  end
			                end
	                 end
		update tb_member set isSendSleep=1 where id=@memberId
		FETCH NEXT FROM authors_cursor 
		INTO @memberId,@memberName,@mobileNum,@EMail,@nickname
	END
	
	CLOSE authors_cursor
	DEALLOCATE authors_cursor