/*---------------------更改定状态--------------------------------------*/
CREATE  PROCEDURE p_changeOrderStatus @orderId INT,@orderStatus INT
AS 

   UPDATE dbo.tb_order SET orderStatus=@orderStatus WHERE id=@orderId

