CREATE PROCEDURE p_addExtendOrderRemark @orderId int,@remark VARCHAR(500)
AS
	if EXISTS(select 1 from tb_extendOrderRemark where orderId=@orderId)
	BEGIN
	     UPDATE tb_extendOrderRemark SET extendRemark=extendRemark+@remark WHERE orderId=@orderId
	END
	ELSE
	BEGIN
	     INSERT INTO tb_extendOrderRemark(orderId,extendRemark) VALUES(@orderId,@remark)
	END



