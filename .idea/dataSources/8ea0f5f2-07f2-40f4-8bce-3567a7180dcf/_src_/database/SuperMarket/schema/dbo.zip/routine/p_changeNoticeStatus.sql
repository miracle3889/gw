CREATE PROCEDURE p_changeNoticeStatus @id int, @doman int

AS
	declare @count int
	select @count=count(*) from tb_noticeStatus where noticeId=@id and doman=@doman
	if(@count=0)
	begin
	insert into tb_noticeStatus(noticeId,doman) values(@id,@doman)
	end