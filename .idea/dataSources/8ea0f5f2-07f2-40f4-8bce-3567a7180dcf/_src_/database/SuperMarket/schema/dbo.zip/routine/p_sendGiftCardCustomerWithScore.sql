

CREATE  PROCEDURE p_sendGiftCardCustomerWithScore @memberId INT,@actManId int   
AS
	declare @returnValue int
	set @returnValue=0
	DECLARE @giftId INT
	SET XACT_ABORT ON
		BEGIN TRAN
			if EXISTS (select 1 from tb_member where id=@memberId and score>=500)
			begin
			--选出当前可用的一张10元优惠券
			SELECT TOP 1 @giftId= id from tb_giftCard where createType=1 and price=1000 and isAct=0
			--将此券设置为已激活
			UPDATE dbo.tb_giftCard SET isAct=1,actTime=GETDATE(),actMan=@actManId,
			useLastTime=DATEADD(day,30,GETDATE()) WHERE id=@giftId

			--将此券赠予用户
			INSERT INTO dbo.tb_memberGift(giftId,memberId,giftType) VALUES(@giftId,@memberId,51)


			exec dbo.p_addScoreOpLog @memberId,-500,51,'积分换礼券'
			set @returnValue=1
			end
		COMMIT TRAN

		select @returnValue
