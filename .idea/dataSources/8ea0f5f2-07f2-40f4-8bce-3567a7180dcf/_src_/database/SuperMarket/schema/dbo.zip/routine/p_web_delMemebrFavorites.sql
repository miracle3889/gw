/*----------------------添加商品到购物车-------------------*/
create procedure p_web_delMemebrFavorites @memberId int,@productId int
as
	--declare @returnValeu int
	--set @returnValeu=0
	update tb_favorites set isdelete=1 where id=@productId and memberId=@memberId
	select 1