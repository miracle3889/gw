/*接收工行网银返回的信息存入数据库,以做处理是否付款处理*/
CREATE PROCEDURE p_web_setIcbcInfo @interfaceName VARCHAR(30),@interfaceVersion VARCHAR(15),@orderid VARCHAR(30),@TranSerialNo VARCHAR(30),@amount VARCHAR(10),@curType VARCHAR(3),@merID VARCHAR(20),@merAcct VARCHAR(19),@verifyJoinFlag VARCHAR(1),@JoinFlag VARCHAR(1),@UserNum VARCHAR(40),@resultType VARCHAR(1),@orderDate VARCHAR(14),@notifyDate VARCHAR(14),@tranStat VARCHAR(1),@comment VARCHAR(100),@remark1 VARCHAR(100),@remark2 VARCHAR(100),@signMsg VARCHAR(8000)
AS
	DECLARE @returnValue INT 
	DECLARE @isPayment INT
	SET @isPayment=0 
	SET @returnValue=0 
		INSERT INTO dbo.tb_orderWYInfo(interfaceName,interfaceVersion,orderid,TranSerialNo,amount,curType,merID,merAcct,verifyJoinFlag,JoinFlag,UserNum,resultType,orderDate,notifyDate,tranStat,comment,remark1,remark2,signMsg) 
		VALUES (@interfaceName,@interfaceVersion,@orderid,@TranSerialNo,@amount,@curType,@merID,@merAcct,@verifyJoinFlag,@JoinFlag,@UserNum,@resultType,@orderDate,@notifyDate,@tranStat,@comment,@remark1,@remark2,@signMsg) 
		SET @returnValue=SCOPE_IDENTITY() 
		IF(@@ERROR<>0) 
		BEGIN 
			SET @returnValue=0 
		END
		else
		begin
			UPDATE dbo.tb_order SET isPayment=CAST(@tranStat AS INT),paymentDate=getdate() WHERE orderCode=@orderid
		end
	SELECT @returnValue