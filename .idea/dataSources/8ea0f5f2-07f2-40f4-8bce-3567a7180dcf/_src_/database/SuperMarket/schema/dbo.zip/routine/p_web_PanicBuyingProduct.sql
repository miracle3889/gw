/*----------------------添加抢购商品-------------------------------*/
CREATE  PROCEDURE p_web_PanicBuyingProduct  @buyCount int, @panicBuyingDate VARCHAR(50),
						@panicBuyingPrice int, @saleProductId int 
AS
	DECLARE @newSaleProductId int --抢购商品销售编号 10000
	DECLARE @SaleCode VARCHAR(50) --原商品的编号 A90000
	DECLARE @newSaleTypeId int --抢购商品的saleTypeId 
	DECLARE @newProductId int --商品ProductId 编号
	DECLARE @twoPrice int --商品的YOYO价
	DECLARE @newSaleCode VARCHAR(50) --抢购商品的编号 S10000

		SET @newSaleTypeId=10 
        
		SELECT @newProductId=productId,@SaleCode=saleCode FROM tb_saleProduct WHERE id=@saleProductId 

		SELECT @twoPrice=payValue FROM tb_saleProductPay WHERE saleProductId=@saleProductId

		--准备事务回滚
		SET XACT_ABORT ON
			--申明事务 BEGIN TRAN
		BEGIN TRAN
		/***********COPY一份tb_saleProduct的记录*********/
		insert into tb_saleProduct(saleCode,productId,oldPrice,remark,saleCount,salePlanId,saleTypeId,addTime,isDeleted,htmlPath,KeyWords,disCript,realPrice,adminSetCount,viewCount,preKey,mRemark,webCategoryId,capabilityId,materialId,brandId,themeId,qhcllbId,groupId,validDate,specialPrice) 
		select saleCode,productId,oldPrice,remark,
		/*活动商品数量*/
		@buyCount,salePlanId,
		@newSaleTypeId,addTime,isDeleted,htmlPath,KeyWords,disCript,realPrice,adminSetCount,viewCount,preKey,mRemark,webCategoryId,capabilityId,materialId,brandId,themeId,qhcllbId,groupId,
		@panicBuyingDate,@twoPrice  
		from tb_saleProduct where id=@saleProductId 
		SET @newSaleProductId=@@IDENTITY 
		
		SET @newSaleCode=RTRIM(LTRIM('S'+CONVERT(char(8),@newSaleProductId)))  

		if (@newSaleProductId != 0)
		BEGIN
			update tb_saleProduct set saleCode=@newSaleCode where id=@newSaleProductId 

			insert into tb_saleProductPay (saleProductId,payStyleId,payValue) 
			VALUES (@newSaleProductId,1,@panicBuyingPrice) 

			insert into tb_webpic(productId,picPath,type,code)
			select @newSaleProductId,picPath,type,code 
			from tb_webpic where productId = @saleProductId
		END
		BEGIN
			if @@ERROR <> 0
				rollback tran
		END
		-- 执行事务 COMMIT TRAN
		COMMIT TRAN
			-- 如果出错 rollback tran 事务回滚
			if @@ERROR <> 0
				rollback tran