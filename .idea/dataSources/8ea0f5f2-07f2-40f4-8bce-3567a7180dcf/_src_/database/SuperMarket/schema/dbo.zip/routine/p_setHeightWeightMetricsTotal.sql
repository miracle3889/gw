create procedure p_setHeightWeightMetricsTotal
as 
declare @count int


SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height<=155 and weight<=80

update tb_heightWeightMetricsTotal set H155W80=@count 


SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height<=155 and weight>80 and weight<=90 

update tb_heightWeightMetricsTotal set H155W90=@count 



SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height<=155 and weight>90 and weight<=100 



update tb_heightWeightMetricsTotal set H155W100=@count 


 SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height<=155 and weight>100 and weight<=110 

update tb_heightWeightMetricsTotal set H155W110=@count 

 SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height<=155 and weight>110 and weight<=120 
update tb_heightWeightMetricsTotal set H155W120=@count 

 SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height<=155 and   weight>120 
update tb_heightWeightMetricsTotal set H155W130=@count 



 
SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height>155 and height<=160 and weight<=80

update tb_heightWeightMetricsTotal set H160W80=@count 


SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height>155 and height<=160 and weight>80 and weight<=90 

update tb_heightWeightMetricsTotal set H160W90=@count 



SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height>155 and height<=160 and weight>90 and weight<=100 



update tb_heightWeightMetricsTotal set H160W100=@count 


 SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height>155 and height<=160 and weight>100 and weight<=110 

update tb_heightWeightMetricsTotal set H160W110=@count 

 SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height>155 and height<=160 and weight>110 and weight<=120 
update tb_heightWeightMetricsTotal set H160W120=@count 

 SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height>155 and height<=160 and   weight>120 
update tb_heightWeightMetricsTotal set H160W130=@count 




 
SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height>160 and height<=165and weight<=80

update tb_heightWeightMetricsTotal set H165W80=@count 


SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height>160 and height<=165and weight>80 and weight<=90 

update tb_heightWeightMetricsTotal set H165W90=@count 



SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height>160 and height<=165and weight>90 and weight<=100 



update tb_heightWeightMetricsTotal set H165W100=@count 


 SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height>160 and height<=165and weight>100 and weight<=110 

update tb_heightWeightMetricsTotal set H165W110=@count 

 SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height>160 and height<=165and weight>110 and weight<=120 
update tb_heightWeightMetricsTotal set H165W120=@count 

 SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height>160 and height<=165and   weight>120 
update tb_heightWeightMetricsTotal set H165W130=@count 



 
SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height>165 and weight<=80

update tb_heightWeightMetricsTotal set H170W80=@count 


SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height>165 and weight>80 and weight<=90 

update tb_heightWeightMetricsTotal set H170W90=@count 



SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height>165 and weight>90 and weight<=100 



update tb_heightWeightMetricsTotal set H170W100=@count 


 SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height>160 and height<=165and weight>100 and weight<=110 

update tb_heightWeightMetricsTotal set H170W110=@count 

 SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height>160 and height<=165and weight>110 and weight<=120 
update tb_heightWeightMetricsTotal set H170W120=@count 

 SELECT @count=count(*) FROM tb_memberheightWeight
WHERE (height <> 0)  --and memberId in(select memberId from tb_order )
 and 
height>160 and height<=165and   weight>120 
update tb_heightWeightMetricsTotal set H170W130=@count 



