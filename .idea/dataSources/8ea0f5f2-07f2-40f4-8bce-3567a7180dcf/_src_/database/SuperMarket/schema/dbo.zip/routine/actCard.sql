/*-------------------激活卡号----------------------------------*/
CREATE  PROCEDURE  actCard @cardcode VARCHAR(50),@psw VARCHAR(50),@memberId INT
AS
	DECLARE @giftId INT
	DECLARE @returnValue INT
	SELECT @giftId=id FROM dbo.tb_giftCard WHERE cardCode=@cardcode AND psw=dbo.md5(@psw) AND isAct=0
	IF(@giftId IS NULL)
	BEGIN
		 SET @returnValue=0
	END
	ELSE
	BEGIN
		INSERT INTO dbo.tb_memberGift(giftId,memberId) VALUES(@giftId,@memberId)
		UPDATE dbo.tb_giftCard SET isAct=1,actTime=GETDATE(),
		useLastTime=DATEADD(day,30,GETDATE()) WHERE id=@giftId
		SET @returnValue=1
	END
	SELECT @returnValue