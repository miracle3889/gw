
CREATE procedure p_checkYorder 
as 
	declare @count int
	select @count=count(*) from tb_order where doman<0 and createTime>=dateAdd(minute,-60,getDate())
	if(@count=0)
		begin
			exec  p_sendMsgByClass '18668122055','60分钟内无网络订单生成',999,1
			exec  p_sendMsgByClass '15825516997','60分钟内无网络订单生成',999,1
		end