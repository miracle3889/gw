CREATE   procedure p_DistributOrderNew @doManId int,@distributeCount int,@userId int
as
	exec supermarket..p_setCanOrdernew 0
	declare @insertId int
	declare @code varchar(50)
	declare @sql varchar(2000)
	set @insertId=0
	if EXISTS  (select * from Supermarket.dbo.tb_order where orderstatus=1 and isDelete<>1 and id in(select orderId from   tb_canDistributeOrder where type=0))
	begin
	update tb_canDistributeOrder set type=1 where type=0
	exec p_getDistributOrder @code OUTPUT
	
	insert into tb_Distribute(pCode,doManId) values(@code,@doManId)
	set @insertId=SCOPE_IDENTITY( ) --批号的id
	begin tran 		
		/*---快照所有待配货订单信息*/
		set @sql='insert into tb_orderDistribute(distributeId,orderId,orderCode,payType,deliverType,
		deliverPrice,memberId,orderStatus,doMan,reMark,receviceMan,post,receviceAddr1,regionalId1,
		receviceAddr2,regionalId2,receviceMobile,addrId,useGift,useAccount,getScore,proCode,oldOrderCode,
		backCode,otherOrder,provinceId,cityId,productPrice,needGetPrice,transport,proxy)
		
		select top  '+cast(@distributeCount as varchar(10))+'  '+cast(@insertId as varchar(10))+',id,orderCode,payType,deliverType,
		deliverPrice,memberId,orderStatus,doMan,reMark,receviceMan,post,receviceAddr1,regionalId1,
		receviceAddr2,regionalId2,receviceMobile,addrId,useGift,useAccount,getScore,proCode,oldOrderCode,
		backCode,otherOrder,provinceId,cityId,productPrice,needGetPrice,transport,proxy from  Supermarket.dbo.tb_order a
		inner join tb_canDistributeOrder b on a.id=b.orderId 
		where orderstatus=1 and isDelete<>1  and isUpdate=0 and memberId<>73650  and isnull(magsourceRemark,'''')<>''taobao''  and  deliverManId='+cast(@userId as int)+'
		 order by b.orderByClass  desc, id'  -- and a.id not in(select orderId from   supermarket..tb_befor7daysOrder where isNeed=0)
		exec(@sql)
		/*---快照所有待配货订单商品信息*/
		insert into dbo.tb_orderSaleProductDistribute(distributeId,orderProductId,orderId,colorId,
		metricsId,saleProductCode,saleProductId,buyCount,groupPh)

		select @insertId,id,orderId,colorId,
		metricsId,saleProductCode,saleProductId,buyCount,groupPh from Supermarket.dbo.tb_orderSaleProduct where orderId in
		(select orderId from tb_orderDistribute where distributeId=@insertId)

		/*---快照所有待配货订单中组合信息*/
		insert into tb_groupPhDistribute(distributeId,id,groupId,buyCount,memberId,isBuy)
		
		select @insertId,id,groupId,buyCount,memberId,isBuy from Supermarket.dbo.tb_groupPh where id in
		(select groupPh from tb_orderSaleProductDistribute where distributeId=@insertId)

	
		update Supermarket.dbo.tb_order set orderstatus=20,isDelete=0 where id in(select orderId from tb_orderDistribute where distributeId=@insertId)
		
		delete from  erp..tb_canDistributeOrder where orderId  in(select orderId from tb_orderDistribute where distributeId=@insertId)
		
		insert into supermarket..tb_orderstatusHis(orderId,orderstatus,doMan,remark) 
		select orderId,20,@doManId,'配货' from tb_orderDistribute a
		inner join supermarket..tb_order b on a.orderId=b.id and isDelete=0
		 where distributeId=@insertId
		
		declare @count int
		select @count=count(*) from tb_orderDistribute where distributeId=@insertId
		update tb_Distribute set orderCount=@count where id=@insertId
		
		
		update tb_canDistributeOrder set type=0 where type=1
		
		exec p_addDistributeProductShelf  @insertId
		
		delete from supermarket..tb_temp_waitPhProduct where orderId in(select orderId from tb_orderDistribute where distributeId=@insertId)
	commit tran 
	end
	select @insertId