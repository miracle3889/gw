
/*-----------------修改购物车商品数量------------------------------------------*/
CREATE    PROCEDURE p_web_updateShoppingBag   @shopingBagId INT,@count INT,@memberId INT 
AS
    	DECLARE @hasMinPrice INT  --除去赠品后的商品价格
	DECLARE @realPrice INT	-- 除去修改商品的之外的商品价格
	DECLARE @realPrice2 INT	--修改后该商品的价格
        DECLARE @isGive  INT	--是否是赠品


	if (@count<=0)
	begin
		set @count=1
	end

	declare @returnCount int
	select @returnCount=count(*) from tb_shoppingBag a inner join tb_saleProduct b on a.saleProductId=b.id where (b.saleTypeId=17 or b.saleTypeId=18 or b.saleTypeId=19 or b.saleTypeId=20) and a.id=@shopingBagId
	if(@returnCount>0)
	begin
		RETURN
	end	

	SELECT @isGive=isPresent FROM tb_shoppingBag WHERE id=@shopingBagId --得到商品是否为赠品
	IF(@isGive!=0) --如果是赠品则退出
	BEGIN
		RETURN  
	END
	
	SELECT @hasMinPrice=minPrice FROM dbo.tb_shoppingBag a
	INNER JOIN dbo.tb_saleProduct b ON a.saleProductId=b.id
	INNER JOIN dbo.tb_saleType c ON b.saleTypeId=c.id 
	WHERE c.isGive=1
	AND c.minPrice>0 AND a.memberId=@memberId   --得到除去赠品后的商品价格
	
	IF(@hasMinPrice is null)
	BEGIN
		SET @hasMinPrice=0
	END
		
	SELECT @realPrice=SUM(b.payValue*a.buyCount) 
	FROM dbo.tb_shoppingBag a
	INNER JOIN dbo.tb_saleProductPay b ON a.saleProductId=b.saleProductId 
	WHERE b.payStyleId=1 AND a.memberId=@memberId  AND isPresent=0
	AND a.id!=@shopingBagId --得到除了该商品之外其他商品的价格

	SELECT @realPrice2=SUM(b.payValue*@count) 
	FROM dbo.tb_shoppingBag a
	INNER JOIN dbo.tb_saleProductPay b ON a.saleProductId=b.saleProductId 
	WHERE b.payStyleId=1 AND a.memberId=@memberId  AND isPresent=0
	AND a.id=@shopingBagId --得到除了该商品之外其他商品的价格
	
	IF(@realPrice IS NULL)
	BEGIN
		SET @realPrice=0
	END	
	IF(@realPrice+@realPrice2=0)  --如果商品价格等于0则删除所有的赠品
	BEGIN
	/*--------------删除原有的赠品-----------------------------*/
	DELETE FROM dbo.tb_shoppingBag WHERE memberId=@memberId 
	AND saleProductId IN 
	(
		 SELECT a.id FROM dbo.tb_saleProduct a 
		 INNER JOIN dbo.tb_saleType b ON a.saleTypeId=b.id 
		 WHERE b.isGive=1
       	)
	END
	ELSE
	BEGIN
		IF((@realPrice+@realPrice2)<@hasMinPrice)  --如果修改后商品价格小于赠品应满足的起用条件
		BEGIN
			/*--------------删除原有的满就送赠品-----------------------------*/
			DELETE FROM dbo.tb_shoppingBag WHERE memberId=@memberId 
			AND saleProductId IN 
			(
				 SELECT a.id FROM dbo.tb_saleProduct a 
				 INNER JOIN dbo.tb_saleType b ON a.saleTypeId=b.id
				 WHERE b.isGive=1 AND b.minPrice>0
		       	)
		END
	END
	IF(@count=0) --直接删除商品
	BEGIN
       		DELETE FROM dbo.tb_shoppingBag WHERE id=@shopingBagId AND memberId=@memberId 
	END
	ELSE --修改商品数量
	BEGIN
		UPDATE dbo.tb_shoppingBag SET buyCount=@count WHERE id=@shopingBagId AND memberId=@memberId 
	END