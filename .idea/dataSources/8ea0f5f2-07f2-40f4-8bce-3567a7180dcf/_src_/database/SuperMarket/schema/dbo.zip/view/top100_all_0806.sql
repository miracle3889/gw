--6月热销商品top 100
create view top100_all_0806 as 
select top 100 saleProductId,count(*) as allCount from tb_orderSaleProduct
where orderId in (
Select id from tb_order where isDelete <> 1 
and createTime > '2008-6-1' and createTime < '2008-7-1'
)
group by saleProductId
order by count(*) desc 
