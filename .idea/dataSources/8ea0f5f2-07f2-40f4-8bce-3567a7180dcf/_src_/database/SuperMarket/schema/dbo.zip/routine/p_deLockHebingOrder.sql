create procedure p_deLockHebingOrder @receviceMan varchar(50),@memberId int
as 
	update tb_needCheckhedanOrder set isLock=0 where memberId=@memberId and receviceMan=@receviceMan