CREATE procedure p_resetbackPrecent 
as 
delete from tb_temp_backPrecent

insert into tb_temp_backPrecent
select b.productid,d.name,sum(b.buyCount) as buyCount,sum(b.backCount) as backCount,sum(isnull(c.getCount,0)) as getCount
, (sum(b.backCount)+sum(isnull(c.getCount,0)))*1000/sum(b.buyCount)  as precent,min(b.saleProductid) as saleId
  from tb_order a
inner join  tb_orderSaleProduct b on a.id=b.orderId and a.orderstatus in(3,11,17,18) and visaTime>=dateAdd(day,-30,getDate())
left join 
(
	select ordersaleId,sum(getCount) as getCount from tb_backProduct group by ordersaleId
) as c on c.ordersaleId=b.id
inner join erp..tb_product d on d.id=b.productId
where isnull(a.magSourceRemark,'')='taobao'
group by b.productid,d.name having sum(b.buyCount)>10  
order by (sum(b.backCount)+sum(isnull(c.getCount,0)))*1000/sum(b.buyCount) desc