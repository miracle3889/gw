CREATE PROCEDURE p_sendGiftCard50 @memberId INT 
AS

	exec p_sendGiftCardByCardNum @memberId , 'mail_50gift'