
CREATE PROCEDURE "dbo"."p_caidan" @orderId int,@orderSaleIds varchar(50)  
as 
	declare @sql  varchar(500)
	
	if(len(@orderSaleIds)>0)
	begin
		set @orderSaleIds=@orderSaleIds+''''''
		declare @code varchar(50)
		declare @orderIdNew int 
		declare @oldCode varchar(50)
		declare @payType int
		declare @memberId int
		declare @doMan int
		declare @reMark varchar(300)
		declare @magazineCode varchar(50)
		declare @magazineCodeS varchar(50)
		declare @magSourceRemark varchar(50)
		declare @receviceMan varchar(50)
		declare @post varchar(50)
		declare @receviceAddr1 varchar(200)
		declare @receviceAddr2 varchar(200)
		declare @receviceMobile varchar(50)
		declare @useAccount int
		declare @regionalId1 int
		declare @regionalId2 int
		declare @provinceId int
		declare @cityId int
		declare @createTime varchar(50)
		declare @paymentDate varchar(50)
		declare @productPrice int
		declare @productPriceOld int
		declare @nickname varchar(50)
		declare @tid varchar(50)
		declare @newProvinceId int ,@newCityId int, @newDistrictId int 
					
		select @oldCode=orderCode,@payType=payType,@memberId=memberId,
					@doMan=doMan,@reMark=reMark ,@magazineCode=magazineCode,@magazineCodeS=magazineCodeS,
					@magSourceRemark=magSourceRemark,@receviceMan=receviceMan,@post=post,@receviceAddr1=receviceAddr1,
					@receviceAddr2=receviceAddr2,@receviceMobile=receviceMobile,@useAccount=useAccount,@regionalId1=regionalId1
					,@regionalId2=regionalId2,@provinceId=provinceId ,@cityId=cityId ,
					@createTime=createTime,@paymentDate=paymentDate,@nickname=nickName,@tid=outCode,
					@newProvinceId=newProvinceId,@newCityId=newCityId,@newDistrictId=newDistrictId
					from tb_order  
					 where id=@orderId 
					and orderStatus=1 and isDelete=0
					
		if(@oldCode is not null and len(@oldCode)>0)
		
		begin
		
		--EXEC p_geOrderCodeNew 1,@code OUTPUT --得到订单号
		
		insert into supermarket..tb_orderstatusHis(orderId,orderstatus,doMan,remark) 
		select @orderId,1,0,'客服拆单'  
				
		INSERT INTO dbo.tb_order(orderCode,payType,deliverType,deliverPrice,memberId,orderStatus,
					doMan,reMark,magazineCode,magazineCodeS,magSourceRemark,receviceMan,post,receviceAddr1,
					receviceAddr2,receviceMobile,addrId,useAccount,getScore,regionalId1,regionalId2,useGift,
					orderSource,provinceId ,cityId ,createTime,paymentDate,outCode,nickName,newProvinceId,newCityId,newDistrictId)
		values('',@payType,1,0,@memberId,1,@doMan,@reMark,@magazineCode,@magazineCodeS,@magSourceRemark,@receviceMan,
			 @post,@receviceAddr1,@receviceAddr2,@receviceMobile,1,@useAccount,isnull(@productPrice,0),@regionalId1,@regionalId2,0
			 ,2,@provinceId,@cityId,@createTime,@paymentDate,@tid,@nickname,@newProvinceId,@newCityId,@newDistrictId)
		
		 ---新单号
		set @orderIdNew=SCOPE_IDENTITY()
		
		if(@orderIdNew is not null and  @orderIdNew<>0)
		begin
			--设置合并订单编号
			set  @code  =supermarket.[dbo].[f_getOrderCodePre](@orderIdNew,'00',@nickname,'s')
			update tb_order set orderCode=@code,lastUpdate=GETDATE()  where id=@orderIdNew 
			insert into supermarket..tb_orderstatusHis(orderId,orderstatus,doMan,remark) 
			select @orderIdNew,1,0,'客服拆单新单号' 
			begin try  		
				begin tran 
				
				set @sql='update   tb_orderSaleProduct set orderId='+cast(@orderIdNew as varchar(10))
				 +' where orderId='+cast(@orderId as varchar(10))+ ' and id in('+@orderSaleIds+')'
				exec(@sql)	
				
				update tb_orderSaleOutOfStock set orderId=@orderIdNew where orderSaleId 
				in(select id from tb_orderSaleProduct where orderId=@orderIdNew)
				
				
				update reportruhnn.dbo.tb_orderNoDelivered set orderId=@orderIdNew,orderCode=@code where orderSaleId 
				in(select id from tb_orderSaleProduct where orderId=@orderIdNew)
				
				commit tran 
			end try 
			begin catch 
				 rollback tran 
				 update tb_order set isDelete=1,delCause='拆单失败回滚' where orderCode=@code
				 declare @msg varchar(2000)
				 set @msg=error_message()
				 RAISERROR(@msg,16,1)
			end catch
		end 
			
			select @productPrice=SUM(buyCount*b.payValue) from tb_orderSaleProduct a
			inner join tb_orderSaleProductPay b on a.id=b.orderSaleProductId where a.orderId=@orderIdNew 
			if(@productPrice is null)
				set @productPrice=0
			
			if(@useAccount>0)
			set @useAccount=@productPrice
			update tb_order set productPrice=@productPrice,useAccount=@useAccount,lastUpdate=GETDATE() where id=@orderIdNew
			update tb_order set productPrice=productPrice-@productPrice,lastUpdate=GETDATE() where id=@orderId
		
		end
	end