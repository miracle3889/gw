
/*-------------------激活卡号----------------------------------*/
CREATE  PROCEDURE  actMember_ByPsw @cardCode VARCHAR(50),@cardPsw VARCHAR(50),@memberId INT,@userId INT
AS
	DECLARE @returnValue INT
	SET @returnValue=0
	BEGIN TRAN 
			DECLARE @giftId INT 
			DECLARE @type INT 
			DECLARE @giftCountLimit INT
			DECLARE @memberGift int
			/*******09.03.25修改 到exec p_sendGiftCard结束*********/
		SELECT @giftId=id, @giftCountLimit=countLimit,@type=type FROM tb_publicCard WHERE cardNum = @cardCode AND validDate > getDate()
		if (@giftId is not null or @giftId>0 )
		begin
			exec p_sendGiftCardByCardNum @memberId, @cardCode
			/*******判断用户是否已有此卡,没有就送***
			SELECT @memberGift=COUNT(*) FROM tb_memberGift WHERE giftType = @giftId AND memberId=@memberId 
			if (@memberGift=0 or @memberGift<@giftCountLimit)
			begin
				if(@type=0)
				begin
					exec p_sendGiftCard @memberId,@giftId 
				end
				else
				begin
					exec p_sendGiftCard20 @memberId,@giftId 
				end
				set @returnValue=1
			end***/
		end
		else
		begin
			SELECT TOP 1 @giftId=id FROM dbo.tb_giftCard WHERE cardCode=@cardCode AND psw=dbo.md5(@cardPsw)  AND  isAct=0
						
			IF(@giftId IS NULL OR @giftId<=0)
			BEGIN
				SET @returnValue=0
			END
			ELSE
			BEGIN
				INSERT INTO dbo.tb_memberGift(giftId,memberId) VALUES(@giftId,@memberId)
				UPDATE dbo.tb_giftCard SET isAct=1,actTime=GETDATE(),actMan=@userId,
				useLastTime=DATEADD(day,30,GETDATE()) WHERE id=@giftId 
				SET @returnValue=1
			END
		end

			
		
	IF(@@ERROR<>0)
	BEGIN
		ROLLBACK TRAN 
	END
	COMMIT TRAN 
	SELECT @returnValue