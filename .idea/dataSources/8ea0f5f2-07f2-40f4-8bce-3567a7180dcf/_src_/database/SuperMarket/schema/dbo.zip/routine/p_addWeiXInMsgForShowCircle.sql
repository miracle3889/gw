CREATE procedure [dbo].[p_addWeiXInMsgForShowCircle] 
	@msgcontent varchar(2000),
	@needResponseUser varchar(100) 
as	
	declare @userId int
 BEGIN
    --定义游标.
   DECLARE c_userId CURSOR FAST_FORWARD FOR
     SELECT a FROM dbo.f_strSplit(@needResponseUser,',')
   -- 打开游标.
   OPEN c_userId
   --填充数据.
   FETCH NEXT FROM c_userId INTO @userId;
   --假如检索到了数据，才处理.
   WHILE @@fetch_status = 0
	   BEGIN
		  insert into SuperMarket..tb_weiXinMsg(userId,msgType,msgcontent)
			select id,'news',REPLACE(@msgcontent,'ruhnn_openId',openId) from ERP..tb_user where id = @userId
			print @msgcontent
		 --填充下一条数据.
		 FETCH NEXT FROM c_userId INTO @userId
	   END
	   -- 关闭游标
	   CLOSE c_userId
	   --释放游标.
	   DEALLOCATE c_userId
 END