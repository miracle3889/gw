/*-------------- 获取验证码-----------------------------*/
CREATE   PROCEDURE [dbo].[p_checkWangWangName] @wangwangName VARCHAR(32)
AS
	DECLARE @memberId INT
	Set @memberId=0
	DECLARE @returnValue INT
	DECLARE @mobileNum VARCHAR(500)
	
	SET @returnValue=0
	select @memberId=b.id , @mobileNum=b.mobileNum from supermarket..tb_taobaoMember a, supermarket..tb_member b 
		where a.memberId=b.id and a.taobaoNickName=@wangwangName
	IF(@memberId!=0 and @mobileNum is not null)
	BEGIN
	    DECLARE @checkCode INT
	    DECLARE @msg VARCHAR(500)
	    SET @checkCode=rand() * 1000000
	    UPDATE dbo.tb_member  SET checkCode=@checkCode WHERE id=@memberId
	    SET @msg='亲，你在莉家验证码是'+CAST(@checkCode AS VARCHAR(10))+'，如有疑问请联系VIP卡客服，谢谢'
	    --EXEC p_sendMsgReal @mobileNum,@msg
		EXEC p_sendMsgByClass @mobileNum,@msg,99999,0
	    SET @returnValue=1
	END
	ELSE
	BEGIN
		SET @returnValue=-1
	END
	SELECT @returnValue