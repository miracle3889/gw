/*--------------更新外呼记录---------------------------------*/
CREATE PROCEDURE p_updateCallJava @doMan INT,@MemberId INT,@callCause INT,@isOldMember INT,@callId INT
AS
	/*DECLARE @class1 INT
	DECLARE @class2 INT	
	DECLARE @callCauseResult INT	
	BEGIN TRAN 
		SELECT @callCauseResult=callCauseId FROM dbo.tb_callHis WHERE id=@callId
		IF(@callCauseResult=0)
		BEGIN
			SET @callCauseResult=@callCause
		END
		ELSE
		BEGIN 
			SELECT @class1=class FROM dbo.tb_callCause WHERE id=@callCause
			SELECT @class2=class FROM dbo.tb_callCause WHERE id=@callCauseResult
			IF(@class1>@class2)
			BEGIN
				SET @callCauseResult=@callCause
			END
		END
		UPDATE dbo.tb_callHis SET userId=@MemberId,doMan=@doMan,isOlderMember=@isOldMember,callCauseId=@callCauseResult WHERE id=@callId
	COMMIT TRAN*/
	UPDATE dbo.tb_callHis SET userId=@MemberId,doMan=@doMan,isOlderMember=@isOldMember,callCauseId=@callCause WHERE id=@callId