/*---------------登记退回商品-----------------------------*/
CREATE PROCEDURE p_UpdateBackProduct @backCount INT ,@id INT
AS 
	--DECLARE @saleProductId INT --销售编号
	--DECLARE @salePrice INT --销售价格
	--DECLARE @orderId INT --定单id
	--BEGIN TRAN 
	--SELECT @saleProductId=saleProductId,@orderId=orderId
	--FROM Supermarket.dbo.tb_orderSaleProduct WHERE id=@id --得到定单商品对应的定单号和销售号

	--SELECT @salePrice=payValue  FROM Supermarket.dbo.tb_saleProductPay 
	--WHERE payStyleId=1 AND saleProductId=@saleProductId --得到销售价格
	
	--IF(@salePrice IS NULL)	
	--BEGIN
	--	SET @salePrice=0
	--END

	--UPDATE Supermarket.dbo.tb_order SET backPrice=backPrice+(@salePrice*@backCount) 
	--WHERE id=@orderId --更新定单返回金额

	UPDATE SuperMarket.dbo.tb_orderSaleProduct SET backCount=@backCount WHERE id=@id --更新商品退回数量

	--COMMIT TRAN