 CREATE   PROCEDURE   p_updateGroupPay
      @groupProductId   int,   
      @payStyleId   int,   
      @payValue   int   
  AS   
  begin   
      delete from SuperMarket.dbo.tb_saleGroupPay where groupProductId =@groupProductId
      insert into SuperMarket.dbo.tb_saleGroupPay values (@groupProductId,@payStyleId,@payValue)
  end