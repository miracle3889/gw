/*---------------------设定销售组合状态为完成---------------------*/
create procedure p_setGroupOK @groupId int
as 
	update dbo.tb_saleGroup set isOK=1,okTime=getDate() where id=@groupId
