CREATE procedure p_setCanOrder 
as 
	DECLARE @totalCount INT
	
	delete from tb_tempComputeDistributeOrderBy	
	update 	erp..tb_canDistributeOrder set orderByClass=0

	insert into tb_tempComputeDistributeOrderBy(productCode,buyCount)	
	select b.productShelfCode,sum(cast(buyCount as int)) as buyCount   from supermarket..tb_order a
	inner join supermarket..tb_tempSaleProduct b on a.id=b.orderId
	 where orderstatus=1 and isDelete<>1 and  id in(select orderId from   erp..tb_canDistributeOrder) and isUpdate=0  and magazineCodeS<>'CFT' 
	and b.productShelfCode<>'RO111830101'
	group by b.productShelfCode order by sum(cast(buyCount as int)) desc
	
	select @totalCount=sum(buyCount) from tb_tempComputeDistributeOrderBy

	--update tb_tempComputeDistributeOrderBy set buyCount=0 where productCode not in(select top 21 productCode from tb_tempComputeDistributeOrderBy order by buyCount desc )
	
	update erp..tb_canDistributeOrder set orderByClass=b.precent from erp..tb_canDistributeOrder a,(

	select orderId,sum(a.buyCount*(b.buyCount*1.0/@totalCount)*10000) as precent from supermarket..tb_tempSaleProduct a
	inner join tb_tempComputeDistributeOrderBy b on a.productShelfCode=b.productCode and a.productShelfCode<>'RO111830101'
	inner join supermarket..tb_order c on c.id=a.orderId and c.orderstatus=1 and c.isDelete<>1 and  magazineCodeS<>'CFT' 
	group  by orderId 

	) as b  where a.orderId=b.orderId

