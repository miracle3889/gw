/*----------------------添加销售组合---------------------------*/
CREATE procedure p_addGroupSale @name varchar(50),
				@code varchar(50),
				@salePrice varchar(50),
				@groupRemark varchar(500),
				@picPath varchar(500),
				@totalCount int,
				@requireCount int,
				@saleType int
as
  declare @returnId int
  insert into  dbo.tb_saleGroup(name,code,salePrice,groupRemark,picPath,totalCount,requireCount,saleType)
		values(@name,@code,@salePrice,@groupRemark,@picPath,@totalCount,@requireCount,@saleType)
  set @returnId=scope_identity()
  if(@code='')
  begin
	update dbo.tb_saleGroup set code='GA'+cast(@returnId as varchar(4)) where id=@returnId
  end
  select @returnId