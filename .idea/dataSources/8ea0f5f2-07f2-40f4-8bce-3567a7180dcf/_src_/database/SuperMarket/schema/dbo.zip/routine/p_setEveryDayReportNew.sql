CREATE procedure p_setEveryDayReportNew
as 
declare @mydate varchar(50)
declare @orderCount int
declare @salePrice int
declare @huanhuoPrice int 

DECLARE authors_cursor0 CURSOR FOR
select convert(varchar(10),createTime,120) as  addDate,count(*) as orderCount,
sum(case when isnull(backCode,'')<>'' then 0 else (a.productPrice+deliverPrice-useAccount-useGift) end) as saleprice,
sum(case when isnull(backCode,'')='' then 0 else (a.productPrice+deliverPrice-useAccount-useGift) end) as huanhuoPrice
from tb_order a
where orderStatus in(1,2,3,11,13,17,18,20)  
AND isDelete!=1 
and createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),createTime,120) order by convert(varchar(10),createTime,120)


OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@orderCount,@salePrice,@huanhuoPrice
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_saleReport where addDate=@mydate)
		begin
			update tb_saleReport set orderCount=@orderCount,salePrice=@salePrice,huanhuoPrice=@huanhuoPrice where addDate=@mydate
		end
	else
		begin
			insert into tb_saleReport(orderCount,salePrice,huanhuoPrice,addDate) values(@orderCount,@salePrice,@huanhuoPrice,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@orderCount,@salePrice,@huanhuoPrice
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0






DECLARE authors_cursor0 CURSOR FOR
--成本
/*select  convert(varchar(10),createTime,120) as  addDate,
sum((buyCount-backCount)*cast(case stockPrice when 0 then isnull(c.payValue,0) else stockPrice end  as bigInt)) as orderStockPrice 
from tb_order a
inner join tb_orderSaleProduct b on a.id=b.orderId  
left  join (
select productId,b.payValue/2 as payValue  from tb_saleProduct a
inner join tb_saleProductPay b on a.id=b.saleProductId
 where saleTypeId=1 and b.payStyleId=1 
) c on c.productId=b.productId 

where orderStatus in(1,2,3,11,13,17,18,20)   and  isnull(backCode,'')='' 
AND isDelete!=1 
and createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),createTime,120) order by convert(varchar(10),createTime,120)

*/

select  convert(varchar(10),createTime,120) as  addDate,
sum((buyCount-backCount)*cast( c.stockPriceReal   as bigInt)) as orderStockPrice 
from tb_order a
inner join tb_orderSaleProduct b on a.id=b.orderId  
inner  join erp..tb_product  c on c.id=b.productId 

where orderStatus in(1,2,3,11,13,17,18,20)   and  isnull(backCode,'')='' 
AND isDelete!=1 
and createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),createTime,120) order by convert(varchar(10),createTime,120)

OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@salePrice
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_saleReport where addDate=@mydate)
		begin
			update tb_saleReport set costPrice=@salePrice where addDate=@mydate
		end
	else
		begin
			insert into tb_saleReport(costPrice,addDate) values(@salePrice,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@salePrice
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0






DECLARE authors_cursor0 CURSOR FOR

--退货 
SELECT convert(varchar(10),b.createTime,120) as  addDate,sum(case when isnull(c.id,0)>0 then 0 else a.payPrice end ) as payPrice 
FROM tb_backOder a
inner join tb_order b on a.ordeId=b.id 
left join tb_order c on isnull(c.backCode,'')=a.code
 where backStatusId in(3,4) and  b.createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),b.createTime,120) order by convert(varchar(10),b.createTime,120) 


OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@salePrice
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_saleReport where addDate=@mydate)
		begin
			update tb_saleReport set backPrice=@salePrice where addDate=@mydate
		end
	else
		begin
			insert into tb_saleReport(backPrice,addDate) values(@salePrice,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@salePrice
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0






DECLARE authors_cursor0 CURSOR FOR

--退货 
SELECT convert(varchar(10),b.createTime,120) as  addDate,sum(case when isnull(c.id,0)>0 then 0 else f.stockPriceReal*d.getCount end ) as payPrice 
FROM tb_backOder a
inner join tb_order b on a.ordeId=b.id 
inner join tb_backProduct d on d.backid =a.id 
inner join tb_saleProduct e on e.id=d.saleId
inner join erp..tb_product f on f.id=e.productId 
left join tb_order c on isnull(c.backCode,'')=a.code
 where backStatusId in(3,4) and  b.createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),b.createTime,120) 
order by convert(varchar(10),b.createTime,120) 


OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@salePrice
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_saleReport where addDate=@mydate)
		begin
			update tb_saleReport set backPrice=backPrice-@salePrice where addDate=@mydate
		end
	else
		begin
			insert into tb_saleReport(backPrice,addDate) values(@salePrice*-1,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@salePrice
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0





DECLARE authors_cursor0 CURSOR FOR

--出库情况

select convert(varchar(10),setTime,120),count(*) as orderCount,
sum(case when isnull(backCode,'')<>'' then 0 else (a.productPrice+deliverPrice-useAccount-useGift) end) as saleprice from tb_order a

where orderStatus in(1,2,3,11,13,17,18,20)  
AND isDelete!=1 
and setTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),setTime,120) order by convert(varchar(10),setTime,120)


OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@orderCount,@salePrice
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_saleReport where addDate=@mydate)
		begin
			update tb_saleReport set sendCount=@orderCount,sendPrice=@salePrice where addDate=@mydate
		end
	else
		begin
			insert into tb_saleReport(sendCount,sendPrice,addDate) values(@orderCount,@salePrice,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@orderCount,@salePrice
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0








DECLARE authors_cursor0 CURSOR FOR

--出库成本
/*select  convert(varchar(10),setTime,120),sum((buyCount-backCount)*cast(case stockPrice when 0 then isnull(c.payValue,0) else stockPrice end  as bigInt)) as orderStockPrice 
from tb_order a
inner join tb_orderSaleProduct b on a.id=b.orderId  
left  join (
select productId,b.payValue/2 as payValue  from tb_saleProduct a
inner join tb_saleProductPay b on a.id=b.saleProductId
 where saleTypeId=1 and b.payStyleId=1 
) c on c.productId=b.productId 

where orderStatus in(1,2,3,11,13,17,18,20)   and  isnull(backCode,'')=''
AND isDelete!=1 
and setTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),setTime,120) order by convert(varchar(10),setTime,120)

*/
select  convert(varchar(10),setTime,120),sum((buyCount-backCount)*cast(c.stockPriceReal as bigInt)) as orderStockPrice 
from tb_order a
inner join tb_orderSaleProduct b on a.id=b.orderId  
inner  join erp..tb_product c on c.id=b.productId 

where orderStatus in(1,2,3,11,13,17,18,20)   and  isnull(backCode,'')=''
AND isDelete!=1 
and setTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),setTime,120) order by convert(varchar(10),setTime,120)

OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@salePrice
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_saleReport where addDate=@mydate)
		begin
			update tb_saleReport set  sendCost=@salePrice where addDate=@mydate
		end
	else
		begin
			insert into tb_saleReport(sendCost,addDate) values(@salePrice,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@salePrice
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0





DECLARE authors_cursor0 CURSOR FOR
select convert(varchar(10),createTime,120) as  addDate,count(*) as orderCount,
sum(case when isnull(backCode,'')<>'' then 0 else (a.productPrice+deliverPrice-useAccount-useGift) end) as saleprice,
sum(case when isnull(backCode,'')='' then 0 else (a.productPrice+deliverPrice-useAccount-useGift) end) as huanhuoPrice
from tb_order a
where orderStatus in(1,2,3,11,13,17,18,20)  
AND isDelete!=1 
and createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120) and  magSourceRemark='taobao'
group by convert(varchar(10),createTime,120) order by convert(varchar(10),createTime,120)


OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@orderCount,@salePrice,@huanhuoPrice
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_saleReport where addDate=@mydate)
		begin
			update tb_saleReport set taobaoorderCount=@orderCount,taobaosalePrice=@salePrice,taobaohuanhuoPrice=@huanhuoPrice where addDate=@mydate
		end
	else
		begin
			insert into tb_saleReport(taobaoorderCount,taobaosalePrice,taobaohuanhuoPrice,addDate) values(@orderCount,@salePrice,@huanhuoPrice,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@orderCount,@salePrice,@huanhuoPrice
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0






DECLARE authors_cursor0 CURSOR FOR
--成本
select  convert(varchar(10),createTime,120) as  addDate,
sum((buyCount-backCount)*cast(case stockPrice when 0 then isnull(c.payValue,0) else stockPrice end  as bigInt)) as orderStockPrice 
from tb_order a
inner join tb_orderSaleProduct b on a.id=b.orderId  
left  join (
select productId,b.payValue/2 as payValue  from tb_saleProduct a
inner join tb_saleProductPay b on a.id=b.saleProductId
 where saleTypeId=1 and b.payStyleId=1 
) c on c.productId=b.productId 

where orderStatus in(1,2,3,11,13,17,18,20)   and  isnull(backCode,'')='' 
AND isDelete!=1 
and createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)  and  magSourceRemark='taobao'
group by convert(varchar(10),createTime,120) order by convert(varchar(10),createTime,120)


OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@salePrice
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_saleReport where addDate=@mydate)
		begin
			update tb_saleReport set taobaocostPrice=@salePrice where addDate=@mydate
		end
	else
		begin
			insert into tb_saleReport(taobaocostPrice,addDate) values(@salePrice,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@salePrice
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0






DECLARE authors_cursor0 CURSOR FOR

--退货 
SELECT convert(varchar(10),b.createTime,120) as  addDate,sum(case when isnull(c.id,0)>0 then 0 else a.payPrice end ) as payPrice 
FROM tb_backOder a
inner join tb_order b on a.ordeId=b.id 
left join tb_order c on isnull(c.backCode,'')=a.code
 where backStatusId in(3,4) and  b.createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)  and  b.magSourceRemark='taobao'
group by convert(varchar(10),b.createTime,120) order by convert(varchar(10),b.createTime,120) 


OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@salePrice
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_saleReport where addDate=@mydate)
		begin
			update tb_saleReport set taobaobackPrice=@salePrice where addDate=@mydate
		end
	else
		begin
			insert into tb_saleReport(taobaobackPrice,addDate) values(@salePrice,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@salePrice
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0







DECLARE authors_cursor0 CURSOR FOR
select convert(varchar(10),createTime,120) as  addDate,count(*) as orderCount,
sum(case when isnull(backCode,'')<>'' then 0 else (a.productPrice+deliverPrice-useAccount-useGift) end) as saleprice,
sum(case when isnull(backCode,'')='' then 0 else (a.productPrice+deliverPrice-useAccount-useGift) end) as huanhuoPrice
from tb_order a
where orderStatus in(1,2,3,11,13,17,18,20)  
AND isDelete!=1 
and createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120) and  magSourceRemark='cft'
group by convert(varchar(10),createTime,120) order by convert(varchar(10),createTime,120)


OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@orderCount,@salePrice,@huanhuoPrice
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_saleReport where addDate=@mydate)
		begin
			update tb_saleReport set cftorderCount=@orderCount,cftsalePrice=@salePrice,cfthuanhuoPrice=@huanhuoPrice where addDate=@mydate
		end
	else
		begin
			insert into tb_saleReport(cftorderCount,cftsalePrice,cfthuanhuoPrice,addDate) values(@orderCount,@salePrice,@huanhuoPrice,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@orderCount,@salePrice,@huanhuoPrice
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0






DECLARE authors_cursor0 CURSOR FOR
--成本
select  convert(varchar(10),createTime,120) as  addDate,
sum((buyCount-backCount)*cast(case stockPrice when 0 then isnull(c.payValue,0) else stockPrice end  as bigInt)) as orderStockPrice 
from tb_order a
inner join tb_orderSaleProduct b on a.id=b.orderId  
left  join (
select productId,b.payValue/2 as payValue  from tb_saleProduct a
inner join tb_saleProductPay b on a.id=b.saleProductId
 where saleTypeId=1 and b.payStyleId=1 
) c on c.productId=b.productId 

where orderStatus in(1,2,3,11,13,17,18,20)   and  isnull(backCode,'')='' 
AND isDelete!=1 
and createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)  and  magSourceRemark='cft'
group by convert(varchar(10),createTime,120) order by convert(varchar(10),createTime,120)


OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@salePrice
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_saleReport where addDate=@mydate)
		begin
			update tb_saleReport set cftcostPrice=@salePrice where addDate=@mydate
		end
	else
		begin
			insert into tb_saleReport(cftcostPrice,addDate) values(@salePrice,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@salePrice
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0






DECLARE authors_cursor0 CURSOR FOR

--退货 
SELECT convert(varchar(10),b.createTime,120) as  addDate,sum(case when isnull(c.id,0)>0 then 0 else a.payPrice end ) as payPrice 
FROM tb_backOder a
inner join tb_order b on a.ordeId=b.id 
left join tb_order c on isnull(c.backCode,'')=a.code
 where backStatusId in(3,4) and  b.createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)  and  b.magSourceRemark='cft'
group by convert(varchar(10),b.createTime,120) order by convert(varchar(10),b.createTime,120) 


OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@salePrice
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_saleReport where addDate=@mydate)
		begin
			update tb_saleReport set cftbackPrice=@salePrice where addDate=@mydate
		end
	else
		begin
			insert into tb_saleReport(cftbackPrice,addDate) values(@salePrice,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@salePrice
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0






DECLARE authors_cursor0 CURSOR FOR
select convert(varchar(10),createTime,120) as  addDate,count(*) as orderCount,
sum(case when isnull(backCode,'')<>'' then 0 else (a.productPrice+deliverPrice-useAccount-useGift) end) as saleprice,
sum(case when isnull(backCode,'')='' then 0 else (a.productPrice+deliverPrice-useAccount-useGift) end) as huanhuoPrice
from tb_order a
where orderStatus in(1,2,3,11,13,17,18,20)  
AND isDelete!=1 
and createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120) and   memberId  in(7327,691356,873561,884612,1736)
group by convert(varchar(10),createTime,120) order by convert(varchar(10),createTime,120)


OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@orderCount,@salePrice,@huanhuoPrice
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_saleReport where addDate=@mydate)
		begin
			update tb_saleReport set kcorderCount=@orderCount,kcsalePrice=@salePrice,kchuanhuoPrice=@huanhuoPrice where addDate=@mydate
		end
	else
		begin
			insert into tb_saleReport(kcorderCount,kcsalePrice,kchuanhuoPrice,addDate) values(@orderCount,@salePrice,@huanhuoPrice,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@orderCount,@salePrice,@huanhuoPrice
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0






DECLARE authors_cursor0 CURSOR FOR
--成本
select  convert(varchar(10),createTime,120) as  addDate,
sum((buyCount-backCount)*cast(case stockPrice when 0 then isnull(c.payValue,0) else stockPrice end  as bigInt)) as orderStockPrice 
from tb_order a
inner join tb_orderSaleProduct b on a.id=b.orderId  
left  join (
select productId,b.payValue/2 as payValue  from tb_saleProduct a
inner join tb_saleProductPay b on a.id=b.saleProductId
 where saleTypeId=1 and b.payStyleId=1 
) c on c.productId=b.productId 

where orderStatus in(1,2,3,11,13,17,18,20)   and  isnull(backCode,'')='' 
AND isDelete!=1 
and createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)  and memberId  in(7327,691356,873561,884612,1736)
group by convert(varchar(10),createTime,120) order by convert(varchar(10),createTime,120)


OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@salePrice
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_saleReport where addDate=@mydate)
		begin
			update tb_saleReport set kccostPrice=@salePrice where addDate=@mydate
		end
	else
		begin
			insert into tb_saleReport(kccostPrice,addDate) values(@salePrice,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@salePrice
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0






DECLARE authors_cursor0 CURSOR FOR

--退货 
SELECT convert(varchar(10),b.createTime,120) as  addDate,sum(case when isnull(c.id,0)>0 then 0 else a.payPrice end ) as payPrice 
FROM tb_backOder a
inner join tb_order b on a.ordeId=b.id 
left join tb_order c on isnull(c.backCode,'')=a.code
 where backStatusId in(3,4) and  b.createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)  and  b.memberId  in(7327,691356,873561,884612,1736)
group by convert(varchar(10),b.createTime,120) order by convert(varchar(10),b.createTime,120) 


OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@salePrice
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_saleReport where addDate=@mydate)
		begin
			update tb_saleReport set kcbackPrice=@salePrice where addDate=@mydate
		end
	else
		begin
			insert into tb_saleReport(kcbackPrice,addDate) values(@salePrice,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@salePrice
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0

