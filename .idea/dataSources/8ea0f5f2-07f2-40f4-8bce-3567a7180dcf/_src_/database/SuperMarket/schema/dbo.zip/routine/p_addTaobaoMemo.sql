
CREATE procedure p_addTaobaoMemo @orderCode varchar(50),@memo varchar(200)
as 
	
	declare @code varchar(50)

	select @code=orderCode  from tb_taobaoCode where taobaoTid=@orderCode 
	if(@code is null) set @code =''
	if not exists(select 1 from tb_taobaoMemo where orderCode=@code )
	begin
	if(len(@memo)>0)
		update tb_order set  remark=remark+'买家留言：'+@memo where orderCode=@code
		insert into tb_taobaoMemo(orderCode,memo) values(@code,isnull(@memo,''))
	end