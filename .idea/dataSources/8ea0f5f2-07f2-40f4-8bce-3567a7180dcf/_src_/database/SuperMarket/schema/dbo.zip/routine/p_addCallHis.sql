/*--------------添加外呼记录---------------------------------*/
CREATE PROCEDURE p_addCallHis @callcallerCode VARCHAR(50),--主叫
				       @callcalledCode VARCHAR(50),--被叫
		                                  @wavFile VARCHAR(100),--录音文件
				       @callStartTime VARCHAR(50),--开始时间
				       @callType INT --通话类型
AS
	DECLARE @returnValue INT
	SET @returnValue=0
		
	BEGIN TRAN 
		INSERT INTO dbo.tb_callHis(callcallerCode,callcalledCode,wavFile,callTime,callType)
		VALUES(@callcallerCode,@callcalledCode,@wavFile,@callStartTime,@callType)
		SET @returnValue=SCOPE_IDENTITY()
	COMMIT TRAN
	SELECT @returnValue