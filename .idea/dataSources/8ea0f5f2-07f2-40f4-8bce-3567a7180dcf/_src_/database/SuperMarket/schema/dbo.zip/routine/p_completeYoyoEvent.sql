
CREATE  procedure p_completeYoyoEvent @eventDealId int,@dealManId int ,@eventContent varchar(2000)
as
	begin tran 
		declare @eventId int
		update SuperMarket.dbo.tb_yoyoeventDeal set dealStatus=3,replyContent=@eventContent,
			dealManId=@dealManId,dealTime=getDate() where id=@eventDealId
		
		select @eventId=eventId  from SuperMarket.dbo.tb_yoyoeventDeal where id=@eventDealId
		
		update SuperMarket.dbo.tb_yoyoevent set eventStatus=3,completeTime=getDate(),cumpleteManId=@dealManId where id=@eventId
	commit tran 
