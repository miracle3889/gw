/*------------------------------------------------------修改定单信息将新旧定单号关联------------------------------------------------------*/
CREATE PROCEDURE [dbo].[p_updateOldOrderCode]  @oldOrderCode VARCHAR(50),@newOrderId INT
AS 
	BEGIN TRAN 
		DECLARE @oderStatus INT 
		SELECT @oderStatus=orderStatus FROM dbo.tb_order WHERE orderCode=@oldOrderCode
		UPDATE tb_order set oldOrderCode=@oldOrderCode where id=@newOrderId
		--IF(@oderStatus=13)
		--BEGIN 
		--	UPDATE tb_order set oldOrderCode=@oldOrderCode where id=@newOrderId
		--	UPDATE tb_order SET isUpdate=0,isDelete=1 WHERE orderCode=@oldOrderCode
		--END
		--ELSE
		--BEGIN 
		--       	UPDATE tb_order SET isUpdate=0,isDelete=1 WHERE orderCode=@oldOrderCode
		--END
	COMMIT TRAN