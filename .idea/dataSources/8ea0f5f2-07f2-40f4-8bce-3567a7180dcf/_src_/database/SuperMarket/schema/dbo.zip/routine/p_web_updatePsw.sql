/*------------------修改密码----------------------------*/
CREATE PROCEDURE p_web_updatePsw @memberId INT,@oldPsw VARCHAR(50),@newPsw VARCHAR(50)
AS
	DECLARE @returnValue INT
	DECLARE @count INT
	SELECT @count=COUNT(*) FROM dbo.tb_member WHERE id=@memberId AND psw=dbo.md5(@oldPsw) --得到满足条件的会员数量
	IF(@count=0) --如果没有则退出(主要是为了判断会员登陆过期的时候容错)
	BEGIN
		SET @returnValue=0
	END
	ELSE
	BEGIN
		UPDATE dbo.tb_member SET psw=dbo.md5(@newPsw) WHERE id=@memberId --修改密码
		SET @returnValue=1
	END
	SELECT @returnValue