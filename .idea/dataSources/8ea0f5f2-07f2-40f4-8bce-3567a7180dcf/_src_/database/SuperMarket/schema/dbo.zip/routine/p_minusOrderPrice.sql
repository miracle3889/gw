CREATE procedure p_minusOrderPrice @orderId int
as 
	
	DECLARE @realPrice INT --实际价格
	DECLARE @realPriceGroup INT --实际价格
	DECLARE @multiple INT
	DECLARE @minusOrderPrice INT
	DECLARE @precent INT
	DECLARE @realPriceNew INT --实际价格
	DECLARE @diffPrice INT
	DECLARE @memberId INT

	SELECT @realPrice=SUM(b.payValue*a.buyCount) 
	FROM dbo.tb_orderSaleProduct a
	INNER JOIN dbo.tb_orderSaleProductPay b ON a.id=b.orderSaleProductId 
	WHERE b.payType=1 AND a.orderId=@orderId  and groupPh=0



	select  @realPriceGroup=sum(a.salePrice*b.buyCount) from tb_saleGroup a
	 inner join tb_groupPh b on b.groupId=a.id
	 where b.isBuy=1 and b.id in 
	(select distinct groupPh from tb_orderSaleProduct where orderId=@orderId and groupPh!=0 )
	
	--insert into tb_mysql(mysql) values('realPriceGroup'+cast(@realPriceGroup as varchar(10)))
	if(@realPriceGroup>0)
	begin
		--礼券
		if(@realPrice is null) set @realPrice=0
		select @memberId=memberId from tb_order where id=@orderId 
		set @realPrice=@realPrice+@realPriceGroup
		set @multiple=@realPrice/20000 --200的倍数 
		--insert into tb_mysql(mysql) values('multiple'+cast(@multiple as varchar(10)))
		if(@multiple>=1)
		begin
			set @multiple=@multiple*2
			declare @sql varchar(200)
			set @sql='insert into tb_memberGift(giftId,memberId,isUse,useOder) SELECT TOP '+cast(@multiple as varchar(10))+'  id,'+cast(@memberId as varchar(10))+',1,'+cast(@orderId as varchar(10))+' from tb_giftCard where createType=1 and price=2000 and isAct=0'
			--insert into tb_mysql(mysql) values(@sql)
			exec(@sql)

			UPDATE tb_giftCard SET isUse=1,userTime=getDate(),useOder=@orderId where id in(
			select giftId from  tb_memberGift where memberId=@memberId and useOder=@orderId) 
		end
	end
	else
	begin
		set @multiple=@realPrice/20000 --200的倍数
		
		if(@multiple>=1)
		begin
		set @minusOrderPrice=@multiple*4000--减免金额
		
		set @precent=@minusOrderPrice*100/@realPrice--减免金额比例
		
		set @precent=100-@precent--剩余金额比例
		

		update dbo.tb_orderSaleProductPay set payValue=(payValue*@precent)/100 from tb_orderSaleProduct a,tb_orderSaleProductPay b 
		WHERE a.id=b.orderSaleProductId  and b.payType=1 AND a.orderId=@orderId  and groupPh=0
		--同比更新金额
	
		SELECT @realPriceNew=SUM(b.payValue*a.buyCount) 
		FROM dbo.tb_orderSaleProduct a
		INNER JOIN dbo.tb_orderSaleProductPay b ON a.id=b.orderSaleProductId 
		WHERE b.payType=1 AND a.orderId=@orderId  and groupPh=0
		--新定单金额	

		set @diffPrice=@realPrice-@realPriceNew --判断差额

		
		set @diffPrice=@minusOrderPrice-@diffPrice --与应该减免的差额 由于存在小数点

		if(@diffPrice<>0)--有差额
		begin
			declare @id int 
			declare @ordersaleId int
			declare @ordersaleId2 int
			declare @payValue int 
			declare @buyCount int 			
			
			SELECT top 1 @id=b.id,@ordersaleId=orderSaleProductId,@payValue=payValue,@buyCount=buyCount
			FROM dbo.tb_orderSaleProduct a
			INNER JOIN dbo.tb_orderSaleProductPay b ON a.id=b.orderSaleProductId 
			WHERE b.payType=1 AND a.orderId=@orderId  and groupPh=0 order by payValue desc  --提取金额最大商品
			
			
			if(@buyCount>1)--数量大于1 
			begin
				--
				update tb_orderSaleProduct set buyCOunt=buyCount-1 where id=@ordersaleId
				

				INSERT INTO dbo.tb_orderSaleProduct(orderId,colorId,metricsId,saleProductCode,
				saleProductId,buyCount,isRand,groupPh,stockPrice,productId)
				
				select orderId,colorId,metricsId,saleProductCode,
				saleProductId,1,isRand,groupPh,stockPrice,productId from tb_orderSaleProduct where id=@ordersaleId
				
				set @ordersaleId2=SCOPE_IDENTITY()

				insert into dbo.tb_orderSaleProductPay(orderSaleProductId,payType,payValue) 
				select @ordersaleId2,payType,payValue-@diffPrice from tb_orderSaleProductPay  where orderSaleProductId=@ordersaleId and  id=@id 

			end
			else
			begin
				update tb_orderSaleProductPay set payValue=payValue-@diffPrice where orderSaleProductId=@ordersaleId and  id=@id and payType=1			
			end

		end
		end
		
	end
	
	
