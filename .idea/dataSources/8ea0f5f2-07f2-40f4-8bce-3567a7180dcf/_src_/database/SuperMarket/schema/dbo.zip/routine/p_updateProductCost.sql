CREATE PROCEDURE [dbo].p_updateProductCost
		@saleId int,@userId int 
    AS
		declare @productId int 
		select  @productId=productId from  SuperMarket..tb_saleProduct a
		inner join erp..tb_product b on a.productId=b.id and b.stockStatus=0 
		  where  a.id=@saleId
		  if(@productId is not null and @productId>0)
		  begin
			begin tran 
				declare @tprice int 
				select @tprice =SUM(price*ratio)/100 from SuperMarket..[tb_costCompositionProduct] where productId=@productId
				update erp..tb_product set stockPriceReal=@tprice,stockStatus=1,stockUserId=@userId,stockDate=GETDATE()
				 where  id=@productId
			commit tran 
		end