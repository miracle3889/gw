
CREATE procedure p_checkNoAnsew
as 
declare @count1 int
select @count1=count(*) from dbo.tb_noAnswerCall where isCallBack=0
if(@count1>50)
begin
	exec  p_sendMsgByClass '18668122055','未接数量大于50',999,1
	exec  p_sendMsgByClass '15924186993','未接数量大于50',999,1
end
if exists (select 1 from dbo.tb_noAnswerCall where isCallBack=0 and callInTime <=dateadd(hour,-1,getDate())  and callType=0)
begin
	exec  p_sendMsgByClass '18668122055','一小时前的未接还有',999,1
	exec  p_sendMsgByClass '15924186993','一小时前的未接还有',999,1
end

select @count1=count(*) from dbo.tb_noAnswerCall where callInTime>= dateAdd(minute,-60,getDate())  
if(@count1=0)
begin
	exec  p_sendMsgByClass '18668122055','最近60分钟无未接',999,1
end