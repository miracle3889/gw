
CREATE  procedure p_transferEYoyoevent @eventDealId int,@eventContent varchar(2000),@dealManId int,@otherMan varchar(50)
as
	begin tran 
		if exists(select 1 from SuperMarket.dbo.tb_yoyoeventDeal where id=@eventDealId and dealStatus=0)
		begin
			update SuperMarket.dbo.tb_yoyoeventDeal set dealStatus=2,replyContent=@eventContent,
			dealManId=@dealManId,dealTime=getDate() where id=@eventDealId
			
			declare @eventId int
			select @eventId=eventId from SuperMarket.dbo.tb_yoyoeventDeal where id=@eventDealId
			
			insert into SuperMarket.dbo.tb_yoyoeventDeal(eventId,giveManId,canDealMan) values(@eventId,@dealManId,@otherMan)
				
			update SuperMarket.dbo.tb_yoyoevent set currentDealMan=@otherMan where id=@eventId
		end
	commit tran
