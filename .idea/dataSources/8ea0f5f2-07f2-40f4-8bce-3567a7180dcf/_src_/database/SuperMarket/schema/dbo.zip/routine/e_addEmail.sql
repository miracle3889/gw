/*------------------------------------------------------------添加邮件实体------------------------------------------------------------------------------------*/
CREATE  PROCEDURE e_addEmail   @emailName varchar(320)

AS
	declare @returnId int
	
	insert into yye_email (emailName)
	values(@emailName)
	set @returnId=@@identity
	select @returnId