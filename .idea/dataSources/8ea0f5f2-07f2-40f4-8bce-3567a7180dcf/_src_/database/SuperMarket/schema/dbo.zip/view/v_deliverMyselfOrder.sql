
CREATE  VIEW dbo.v_deliverMyselfOrder
AS
SELECT *
FROM tb_order
WHERE (isUpdate = 0) AND (isDelete != 1) AND regionalId1 IN (1, 2, 4, 5) AND 
      addrId = 1 AND orderStatus = 13 AND orderType = 1
UNION ALL
SELECT *
FROM tb_order
WHERE (isUpdate = 0) AND (isDelete != 1) AND regionalId2 IN (1, 2, 4, 5) AND 
      addrId = 2 AND orderStatus = 13 AND orderType = 1

