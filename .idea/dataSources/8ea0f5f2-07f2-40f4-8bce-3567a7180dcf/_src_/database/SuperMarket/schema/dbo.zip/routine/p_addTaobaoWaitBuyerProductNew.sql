CREATE procedure p_addTaobaoWaitBuyerProductNew @taobaoCode varchar(50),@skuCode varchar(50),@buyCount int,@nickName varchar(50),@taobaoId varchar(50),@createTime varchar(50)
as
	delete from tb_taobaoWaitBuyerProduct where taobaoCode=@taobaoCode
	insert into tb_taobaoWaitBuyerProduct(taobaoCode,skuCode,buyCount,nickName,taobaoId,createTime) values(@taobaoCode,@skuCode,@buyCount,@nickName,@taobaoId,@createTime)