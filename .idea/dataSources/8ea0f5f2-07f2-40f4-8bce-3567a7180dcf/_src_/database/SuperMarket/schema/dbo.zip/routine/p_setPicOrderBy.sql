CREATE PROCEDURE p_setPicOrderBy @codeOld INT,@orderby INT
AS
	DECLARE @code INT
	DECLARE @i INT
	DECLARE @count INT
	DECLARE @productId INT
	
	if(@orderby<1) return 

	
	SELECT @productId=productId from tb_webPic where  code=@codeOld and type=1 --商品id	

	SELECT @count=count(*) FROM tb_webPic WHERE  type=1 and productId=@productId  --取总数
	if(@orderby>@count)
	set @orderby=@count
	
	--全部重新排序
	SET @i=1
	DECLARE authors_cursor CURSOR FOR
	SELECT  code,productId FROM tb_webPic WHERE  type=1 and productId=@productId  and code <>@codeOld order by orderbyClassPic
	OPEN authors_cursor
	FETCH NEXT FROM authors_cursor 
	INTO @code,@productId
		WHILE @@FETCH_STATUS = 0
		BEGIN
			UPDATE  tb_webPic SET  orderbyClassPic=@i WHERE code=@code
			SET @i=@i+1
			FETCH NEXT FROM authors_cursor 
			INTO @code,@productId
		END
		
		CLOSE authors_cursor
		DEALLOCATE authors_cursor

	
	
	--计算大于此序号的
	SET @i=@count+1
	DECLARE authors_cursor CURSOR FOR
	SELECT code,productId FROM tb_webPic WHERE  type=1 and productId=@productId  and orderbyClassPic>=@orderby  and code <>@codeOld order by orderbyClassPic 
	OPEN authors_cursor
	FETCH NEXT FROM authors_cursor 
	INTO @code,@productId
	WHILE @@FETCH_STATUS = 0
	BEGIN
		UPDATE  tb_webPic SET  orderbyClassPic=@i WHERE code=@code
		SET @i=@i+1
		FETCH NEXT FROM authors_cursor 
		INTO @code,@productId
	END
	
	CLOSE authors_cursor
	DEALLOCATE authors_cursor
	
	UPDATE  tb_webPic SET  orderbyClassPic=@orderby WHERE code=@codeOld

