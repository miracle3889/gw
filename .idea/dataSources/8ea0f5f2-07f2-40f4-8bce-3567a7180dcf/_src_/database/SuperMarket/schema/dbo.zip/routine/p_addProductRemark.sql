CREATE procedure [dbo].[p_addProductRemark] @productShelfCode varchar(50),@reMark varchar(500)
AS
	declare @returnValue int
	SET @returnValue=0
	declare @prId int
	set @prId=0
	select @prId=id from [tb_productRemark] where productShelfCode=@productShelfCode
	
	if(@prId=0)
	begin
		INSERT INTO tb_productRemark(reMark, productShelfCode) values (@reMark, @productShelfCode)
		SET @returnValue=SCOPE_IDENTITY()
	end
	else
	begin
		UPDATE tb_productRemark SET reMark=reMark+@reMark WHERE productShelfCode=@productShelfCode
		SET @returnValue=@prId
	end
	select @returnValue