/************生成榜单临时表*************/
CREATE    procedure p_sendBang 
as
	begin tran
	delete dbo.tb_bang
	--删除榜单表

-- 1，1  代表大类里的美容护肤排行榜
insert into tb_bang (productName,htmlPath,oldPrice,salePrice,saleId,typeI,typeII) 
select  top 10 a.saleProductName,a.htmlPath,a.oldPrice,a.salePriceInt,a.saleId,1,1  
	from dbo.tb_searchSaleEntity as a  
	inner join tb_hotSale b on a.saleId=b.saleId 
	inner join tb_searchSaleEntityProtity c on a.saleId = c.saleId 
	where a.isGroup=0 and c.webCategoryId = 12 ORDER BY b.score DESC
if (@@error<>0)
	ROLLBACK tran
-- 1，2  代表大类里的家居日用排行榜
insert into tb_bang (productName,htmlPath,oldPrice,salePrice,saleId,typeI,typeII) 
select  top 10 a.saleProductName,a.htmlPath,a.oldPrice,a.salePriceInt,a.saleId,1,2  
	from dbo.tb_searchSaleEntity as a  
	inner join tb_hotSale b on a.saleId=b.saleId 
	inner join tb_searchSaleEntityProtity c on a.saleId = c.saleId 
	where a.isGroup=0  and c.webCategoryId != 7 and c.webCategoryId != 12 ORDER BY b.score DESC
if (@@error<>0)
	ROLLBACK tran


-- 1，3  代表大类里的时尚服饰排行榜
insert into tb_bang (productName,htmlPath,oldPrice,salePrice,saleId,typeI,typeII) 
select  top 10 a.saleProductName,a.htmlPath,a.oldPrice,a.salePriceInt,a.saleId,1,3  
	from dbo.tb_searchSaleEntity as a  
	inner join tb_hotSale b on a.saleId=b.saleId 
	inner join tb_searchSaleEntityProtity c on a.saleId = c.saleId 
	where a.isGroup=0  and c.webCategoryId = 7 ORDER BY b.score DESC
if (@@error<>0)
	ROLLBACK tran

-- 1，4  代表大类里的美妆经典排行榜
insert into tb_bang (productName,htmlPath,oldPrice,salePrice,saleId,typeI,typeII) 
select top 10 b.saleProductName,b.htmlPath,b.oldPrice,b.salePriceInt,b.saleId,1,4  
				from tb_classicProduct a 
				 inner join tb_searchSaleEntity b on a.saleProductId=b.saleId 
				 inner join tb_searchSaleEntityProtity c on a.saleProductId=c.saleId	
				 where 1=1	order by a.seqNum asc
if (@@error<>0)
	ROLLBACK tran

-- 1，5  代表大类里的收藏排行榜
insert into tb_bang (productName,htmlPath,oldPrice,salePrice,saleId,typeI,typeII) 
select top 10 b.saleProductName,b.htmlPath,b.oldPrice,b.salePriceInt,b.saleId,1,5 
				from (select saleCode,count(saleCode) as saleCount from tb_favorites where isdelete=0 and saleCode is not null group by saleCode ) a 
				 inner join tb_searchSaleEntity b on a.saleCode=b.saleCode 
				 inner join tb_searchSaleEntityProtity c on a.saleCode=c.saleCode	
				 where 1=1	order by a.saleCount desc
if (@@error<>0)
	ROLLBACK tran

-- 2，5  代表中间小类里的排行榜 第二个数字代表传入值（capabilityCategoryId or capabilityId）-- f.capabilityId = ? 
insert into tb_bang (productName,htmlPath,oldPrice,salePrice,saleId,typeI,typeII) 
select top 6 e.saleProductName,e.htmlPath,e.oldPrice,e.salePriceInt,e.saleId,2,2  
				from dbo.tb_orderSaleProduct a 
					inner join dbo.tb_orderSaleProductPay b on a.id=b.orderSaleProductId
					inner join dbo.tb_SaleProduct c on a.saleProductId=c.id
					inner join dbo.tb_order d on a.orderId=d.id
					inner join tb_searchSaleEntity e on c.id=e.saleId 
					--inner join tb_searchSaleEntityProtity f on c.id=f.saleId
					where b.payType=1 and e.saleId in (select saleId from tb_saleCapabilityCategory where saleId != 0 and capabilityCategoryId=2)
		 and d.createTime>=dateADD(day,-15,getdate()) and d.orderstatus!=19 and d.isdelete!=1 and  a.saleProductId  in (select saleId from dbo.tb_searchSaleEntity where isqh=0)
		group by a.saleProductId,c.viewCount,c.adminSetCount,e.saleProductName,e.salePriceInt,e.htmlPath,e.oldPrice,e.saleId 
		order by  (c.viewCount+c.adminSetCount)+sum(a.buyCount-a.backCount)*15+sum((a.buyCount-a.backCount)*b.payValue)*50 desc

if (@@error<>0)
	ROLLBACK tran
insert into tb_bang (productName,htmlPath,oldPrice,salePrice,saleId,typeI,typeII) 
select top 6 e.saleProductName,e.htmlPath,e.oldPrice,e.salePriceInt,e.saleId,2,8  
				from dbo.tb_orderSaleProduct a 
					inner join dbo.tb_orderSaleProductPay b on a.id=b.orderSaleProductId
					inner join dbo.tb_SaleProduct c on a.saleProductId=c.id
					inner join dbo.tb_order d on a.orderId=d.id
					inner join tb_searchSaleEntity e on c.id=e.saleId 
					--inner join tb_searchSaleEntityProtity f on c.id=f.saleId
					where b.payType=1 and e.saleId in (select saleId from tb_saleCapabilityCategory where saleId != 0 and capabilityCategoryId=8)
		 and d.createTime>=dateADD(day,-15,getdate()) and d.orderstatus!=19 and d.isdelete!=1 and  a.saleProductId  in (select saleId from dbo.tb_searchSaleEntity where isqh=0)
		group by a.saleProductId,c.viewCount,c.adminSetCount,e.saleProductName,e.salePriceInt,e.htmlPath,e.oldPrice,e.saleId 
		order by  (c.viewCount+c.adminSetCount)+sum(a.buyCount-a.backCount)*15+sum((a.buyCount-a.backCount)*b.payValue)*50 desc

if (@@error<>0)
	ROLLBACK tran
insert into tb_bang (productName,htmlPath,oldPrice,salePrice,saleId,typeI,typeII) 
select top 6 e.saleProductName,e.htmlPath,e.oldPrice,e.salePriceInt,e.saleId,2,3  
				from dbo.tb_orderSaleProduct a 
					inner join dbo.tb_orderSaleProductPay b on a.id=b.orderSaleProductId
					inner join dbo.tb_SaleProduct c on a.saleProductId=c.id
					inner join dbo.tb_order d on a.orderId=d.id
					inner join tb_searchSaleEntity e on c.id=e.saleId 
					--inner join tb_searchSaleEntityProtity f on c.id=f.saleId
					where b.payType=1 and e.saleId in (select saleId from tb_saleCapabilityCategory where saleId != 0 and capabilityCategoryId=3)
		 and d.createTime>=dateADD(day,-15,getdate()) and d.orderstatus!=19 and d.isdelete!=1 and  a.saleProductId  in (select saleId from dbo.tb_searchSaleEntity where isqh=0)
		group by a.saleProductId,c.viewCount,c.adminSetCount,e.saleProductName,e.salePriceInt,e.htmlPath,e.oldPrice,e.saleId 
		order by  (c.viewCount+c.adminSetCount)+sum(a.buyCount-a.backCount)*15+sum((a.buyCount-a.backCount)*b.payValue)*50 desc


if (@@error<>0)
	ROLLBACK tran
insert into tb_bang (productName,htmlPath,oldPrice,salePrice,saleId,typeI,typeII) 
select top 6 e.saleProductName,e.htmlPath,e.oldPrice,e.salePriceInt,e.saleId,2,7  
				from dbo.tb_orderSaleProduct a 
					inner join dbo.tb_orderSaleProductPay b on a.id=b.orderSaleProductId
					inner join dbo.tb_SaleProduct c on a.saleProductId=c.id
					inner join dbo.tb_order d on a.orderId=d.id
					inner join tb_searchSaleEntity e on c.id=e.saleId 
					--inner join tb_searchSaleEntityProtity f on c.id=f.saleId
					where b.payType=1 and e.saleId in (select saleId from tb_saleCapabilityCategory where saleId != 0 and capabilityCategoryId=7)
		 and d.createTime>=dateADD(day,-15,getdate()) and d.orderstatus!=19 and d.isdelete!=1 and  a.saleProductId  in (select saleId from dbo.tb_searchSaleEntity where isqh=0)
		group by a.saleProductId,c.viewCount,c.adminSetCount,e.saleProductName,e.salePriceInt,e.htmlPath,e.oldPrice,e.saleId 
		order by  (c.viewCount+c.adminSetCount)+sum(a.buyCount-a.backCount)*15+sum((a.buyCount-a.backCount)*b.payValue)*50 desc



if (@@error<>0)
	ROLLBACK tran
insert into tb_bang (productName,htmlPath,oldPrice,salePrice,saleId,typeI,typeII) 
select top 6 e.saleProductName,e.htmlPath,e.oldPrice,e.salePriceInt,e.saleId,2,11  
				from dbo.tb_orderSaleProduct a 
					inner join dbo.tb_orderSaleProductPay b on a.id=b.orderSaleProductId
					inner join dbo.tb_SaleProduct c on a.saleProductId=c.id
					inner join dbo.tb_order d on a.orderId=d.id
					inner join tb_searchSaleEntity e on c.id=e.saleId 
					--inner join tb_searchSaleEntityProtity f on c.id=f.saleId
					where b.payType=1 and e.saleId in (select saleId from tb_saleCapabilityCategory where saleId != 0 and capabilityCategoryId=11)
		 and d.createTime>=dateADD(day,-15,getdate()) and d.orderstatus!=19 and d.isdelete!=1 and  a.saleProductId  in (select saleId from dbo.tb_searchSaleEntity where isqh=0)
		group by a.saleProductId,c.viewCount,c.adminSetCount,e.saleProductName,e.salePriceInt,e.htmlPath,e.oldPrice,e.saleId 
		order by  (c.viewCount+c.adminSetCount)+sum(a.buyCount-a.backCount)*15+sum((a.buyCount-a.backCount)*b.payValue)*50 desc



if (@@error<>0)
	ROLLBACK tran
insert into tb_bang (productName,htmlPath,oldPrice,salePrice,saleId,typeI,typeII) 
select top 6 e.saleProductName,e.htmlPath,e.oldPrice,e.salePriceInt,e.saleId,2,33  
				from dbo.tb_orderSaleProduct a 
					inner join dbo.tb_orderSaleProductPay b on a.id=b.orderSaleProductId
					inner join dbo.tb_SaleProduct c on a.saleProductId=c.id
					inner join dbo.tb_order d on a.orderId=d.id
					inner join tb_searchSaleEntity e on c.id=e.saleId 
					inner join tb_searchSaleEntityProtity f on c.id=f.saleId
					where b.payType=1 and f.capabilityId in (33)
		 and d.createTime>=dateADD(day,-15,getdate()) and d.orderstatus!=19 and d.isdelete!=1 and  a.saleProductId  in (select saleId from dbo.tb_searchSaleEntity where isqh=0)
					group by a.saleProductId,c.viewCount,c.adminSetCount,e.saleProductName,e.salePriceInt,e.htmlPath,e.oldPrice,e.saleId 
					order by  (c.viewCount+c.adminSetCount)+sum(a.buyCount-a.backCount)*15+sum((a.buyCount-a.backCount)*b.payValue)*50 desc

if (@@error<>0)
	ROLLBACK tran

update tb_bang set picPath=b.picPath
 from tb_bang a, tb_webPic b where b.type=5 and b.productId = a.saleId and b.id in (
	select top 1 id from tb_webPic where type=5 and productId = a.saleId order by orderbyClassPic
)

if (@@error<>0)
	ROLLBACK tran


	commit tran

	exec p_sendBangCFT