CREATE  VIEW dbo.v_alldeliverOrder
AS


SELECT a.orderCode, 
(case c.pId when 0 then  c.name  else d.name end ) as  deliverName,

c.name AS deliverName2,(case c.pId when 0 then  c.id  else c.pId end ) as  deliverId, a.receviceMan, a.setTime, 
      a.payType, 
      (CASE payType WHEN 1 THEN (productPrice + deliverPrice - useGift - useAccount-backPrice) 
      ELSE 0 END) AS price1, 
      (CASE payType WHEN 1 THEN 0 ELSE (productPrice + deliverPrice - useGift - useAccount-backPrice)
       END) AS price2
FROM dbo.tb_order a 
INNER JOIN      ERP.dbo.tb_user c ON a.deliverManId = c.id
left join ERP.dbo.tb_user d ON d.id = c.pId
WHERE  (a.orderStatus = 2 or (orderstatus in(3,11,17,18) and isNotgetPrice=1))  AND (a.isDelete <> 1)  and  c.id not in(select transportId from erp..tb_transport)

union all

SELECT a.orderCode, 
c.name as  deliverName,

c.name AS deliverName2,c.id as  deliverId, a.receviceMan, a.setTime, 
      a.payType, 
      (CASE payType WHEN 1 THEN (productPrice + deliverPrice - useGift - useAccount-backPrice) 
      ELSE 0 END) AS price1, 
      (CASE payType WHEN 1 THEN 0 ELSE (productPrice + deliverPrice - useGift - useAccount-backPrice)
       END) AS price2
FROM dbo.tb_order a 
INNER JOIN      ERP.dbo.tb_user c ON a.deliverManId = c.id
left join ERP.dbo.tb_user d ON d.id = c.pId
WHERE  (a.orderStatus = 2 or (orderstatus in(3,11,17,18) and isNotgetPrice=1))   AND (a.isDelete <> 1)  and  c.id  in(select transportId from erp..tb_transport)



