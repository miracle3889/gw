/*-------------------------------------CFT生成CFT特价--------------------------------*/
CREATE   procedure p_web_setSpecialPoductCFT 
AS
	declare @id int
	declare @productId int
	declare @CFTid int

	--财付通特价
	delete tb_saleSpecialPriceCFT
	declare tjCFT cursor for select saleId from dbo.tb_saleSpecialPrice 
	open tjCFT
	fetch NEXT from tjCFT into @id
	
	while @@fetch_status<>-1 
	begin
		--首先取tb_saleProduct的productId.如果tb_saleProduct表里没有saleTypeId=16的商品记录
		set @productId=0
		select @productId=productId from tb_saleProduct where id=@id
		set @CFTid=0
		select @CFTid=id from tb_saleProduct where productId=@productId and saleTypeId=16
		if(@CFTid is not null)
		begin
			insert into tb_saleSpecialPriceCFT (saleId,productPrice) select @CFTid,productPrice from tb_saleSpecialPrice where saleId=@id
		end
		fetch NEXT from tjCFT into @id 
	end 

	close tjCFT
	deallocate tjCFT