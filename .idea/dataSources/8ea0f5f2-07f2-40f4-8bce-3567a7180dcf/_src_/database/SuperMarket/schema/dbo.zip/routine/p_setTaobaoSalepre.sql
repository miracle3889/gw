create  procedure [dbo].[p_setTaobaoSalepre]
as
--更新首次购买时间
update supermarket..ck_newProduct set  firstBuyTime=b.createTime
from  supermarket..ck_newProduct a,(

select  a.productCode,nDate,MIN(d.createTime) as  createTime from supermarket..ck_newProduct  a
inner join supermarket..tb_saleProduct b on a.productCode=b.saleCode
inner join supermarket..tb_orderSaleProduct c on c.saleProductId=b.id 
inner join supermarket..tb_order d on d.id=c.orderId and d.orderStatus in(1,2,20,13,3)  and d.isDelete<>1
and d.createTime>=SUBSTRING(nDate,1,4)+'-'+SUBSTRING(nDate,5,2)+'-'+SUBSTRING(nDate,7,2) 
and d.paymentDate is not null group by a.productCode,nDate) b where a.productCode=b.productCode
and a.nDate=b.nDate

update supermarket..ck_newProduct set firstBuyTime=dateadd(day,-7,firstBuyTime)

--更新销售数量
update supermarket..ck_newProduct set oneMonthCount=b.oneMonthCount,oneMonthSalePrice=b.oneMonthSalePrice
from supermarket..ck_newProduct a,(
select  a.productCode,nDate,SUM(c.buyCount-c.backCount) as oneMonthCount,
SUM((e.payValue-c.giftPrice)*(c.buyCount-c.backCount))  as oneMonthSalePrice
 from supermarket..ck_newProduct  a
inner join supermarket..tb_saleProduct b on a.productCode=b.saleCode
inner join supermarket..tb_orderSaleProduct c on c.saleProductId=b.id 
inner join supermarket..tb_orderSaleProductPay e on e.orderSaleProductId=c.id and e.payType=1
inner join supermarket..tb_order d on d.id=c.orderId and d.orderStatus in(1,2,20,13,3) and d.isDelete<>1
and d.createTime>=a.firstBuyTime and d.createTime<=DATEADD(MONTH,1,DATEADD(day,7,a.firstBuyTime))
and d.paymentDate is not null  group by a.productCode,nDate) b 
where a.productCode=b.productCode
and a.nDate=b.nDate



--更新销售数量ALL
update supermarket..ck_newProduct set totalSaleCount=b.totalSaleCount,totalSalePrice=b.totalSalePrice
from supermarket..ck_newProduct a,(
select  a.productCode,nDate,SUM(c.buyCount-c.backCount) as totalSaleCount,
SUM((e.payValue-c.giftPrice)*(c.buyCount-c.backCount))  as totalSalePrice
 from supermarket..ck_newProduct  a
inner join supermarket..tb_saleProduct b on a.productCode=b.saleCode
inner join supermarket..tb_orderSaleProduct c on c.saleProductId=b.id 
inner join supermarket..tb_orderSaleProductPay e on e.orderSaleProductId=c.id and e.payType=1
inner join supermarket..tb_order d on d.id=c.orderId and d.orderStatus in(1,2,20,13,3) and d.isDelete<>1
and d.createTime>=a.firstBuyTime --and d.createTime<=DATEADD(MONTH,1,a.firstBuyTime)
and d.paymentDate is not null  group by a.productCode,nDate) b 
where a.productCode=b.productCode
and a.nDate=b.nDate


update supermarket..ck_newProduct set onDaySaleCount=b.onDaySaleCount,onedaySalePrice=b.onDaySalePrice
from supermarket..ck_newProduct a,(
select  a.productCode,nDate,SUM(c.buyCount-c.backCount) as onDaySaleCount,
SUM((e.payValue-c.giftPrice)*(c.buyCount-c.backCount))  as onDaySalePrice
 from supermarket..ck_newProduct  a
inner join supermarket..tb_saleProduct b on a.productCode=b.saleCode
inner join supermarket..tb_orderSaleProduct c on c.saleProductId=b.id 
inner join supermarket..tb_orderSaleProductPay e on e.orderSaleProductId=c.id and e.payType=1
inner join supermarket..tb_order d on d.id=c.orderId and d.orderStatus in(1,2,20,13,3) and d.isDelete<>1
and d.createTime>=SUBSTRING(nDate,1,4)+'-'+SUBSTRING(nDate,5,2)+'-'+SUBSTRING(nDate,7,2)  and d.createTime<=SUBSTRING(nDate,1,4)+'-'+SUBSTRING(nDate,5,2)+'-'+SUBSTRING(nDate,7,2) +' 23:59:59'
and d.paymentDate is not null  group by a.productCode,nDate) b 
where a.productCode=b.productCode
and a.nDate=b.nDate

--三日销量
update supermarket..ck_newProduct set threeDaySaleCount=b.threeDaysCount,threeDaySalePrice=b.threeDaysSalePrice
from supermarket..ck_newProduct a,(
select  a.productCode,nDate,SUM(c.buyCount-c.backCount) as threeDaysCount,
SUM((e.payValue-c.giftPrice)*(c.buyCount-c.backCount))  as threeDaysSalePrice
 from supermarket..ck_newProduct  a
inner join supermarket..tb_saleProduct b on a.productCode=b.saleCode
inner join supermarket..tb_orderSaleProduct c on c.saleProductId=b.id 
inner join supermarket..tb_orderSaleProductPay e on e.orderSaleProductId=c.id and e.payType=1
inner join supermarket..tb_order d on d.id=c.orderId and d.orderStatus in(1,2,20,13,3) and d.isDelete<>1
and d.createTime>=a.firstBuyTime and d.createTime<=DATEADD(day,3,DATEADD(day,7,a.firstBuyTime))
and d.paymentDate is not null  group by a.productCode,nDate) b 
where a.productCode=b.productCode
and a.nDate=b.nDate


--一周销量
update supermarket..ck_newProduct set oneWeekSaleCount=b.oneWeekCount,oneWeekSalePrice=b.oneWeekSalePrice
from supermarket..ck_newProduct a,(
select  a.productCode,nDate,SUM(c.buyCount-c.backCount) as oneWeekCount,
SUM((e.payValue-c.giftPrice)*(c.buyCount-c.backCount))  as oneWeekSalePrice
 from supermarket..ck_newProduct  a
inner join supermarket..tb_saleProduct b on a.productCode=b.saleCode
inner join supermarket..tb_orderSaleProduct c on c.saleProductId=b.id 
inner join supermarket..tb_orderSaleProductPay e on e.orderSaleProductId=c.id and e.payType=1
inner join supermarket..tb_order d on d.id=c.orderId and d.orderStatus in(1,2,20,13,3) and d.isDelete<>1
and d.createTime>=a.firstBuyTime and d.createTime<=DATEADD(week,1,DATEADD(day,7,a.firstBuyTime))
and d.paymentDate is not null  group by a.productCode,nDate) b 
where a.productCode=b.productCode
and a.nDate=b.nDate
