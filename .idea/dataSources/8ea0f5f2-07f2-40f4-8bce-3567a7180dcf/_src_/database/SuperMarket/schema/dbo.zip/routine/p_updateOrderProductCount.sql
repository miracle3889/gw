
/*------------------------更改定单商品数量------------------------------*/
CREATE      PROCEDURE p_updateOrderProductCount @orderProductId INT,@count INT
AS
	DECLARE @isGive INT
	DECLARE @orderId INT
	DECLARE @needInType INT
	DECLARE @returnValue INT
	SET @isGive=0
	SET @returnValue=0
	SELECT @isGive=c.isGive,@orderId=a.orderId,@needInType=a.needInType FROM dbo.tb_orderSaleProduct a
	INNER JOIN dbo.tb_saleProduct b ON a.saleProductId=b.id
	INNER JOIN dbo.tb_saleType c ON b.saleTypeId=c.id WHERE a.id=@orderProductId
	IF(@needInType=1)
	BEGIN
		if(@count=0)
		BEGIN
			DELETE FROM dbo.tb_orderSaleProduct  WHERE id=@orderProductId
			SET @returnValue=1
		END
		ELSE
		BEGIN
			UPDATE dbo.tb_orderSaleProduct SET buyCount=@count WHERE id=@orderProductId
			SET @returnValue=1		
		END
	END
	ELSE
	BEGIN
		IF(@isGive=1)
		BEGIN
			if(@count=0)
			BEGIN
				DELETE FROM dbo.tb_orderSaleProduct  WHERE id=@orderProductId
				SET @returnValue=1
			END
			ELSE
			BEGIN
				SET @returnValue=-1 --不能修改赠品的数量
			END
			
		END
		ELSE
		BEGIN
			delete from  erp..tb_canDistributeOrder where orderId =@orderId
			DECLARE @hasMinPrice INT
			DECLARE @realPrice INT	
			DECLARE @realPrice2 INT		
	
			SELECT @hasMinPrice=minPrice FROM dbo.tb_orderSaleProduct a
			INNER JOIN dbo.tb_saleProduct b ON a.saleProductId=b.id
			INNER JOIN dbo.tb_saleType c ON b.saleTypeId=c.id 
			WHERE c.isGive=1
			AND c.minPrice>0 AND a.orderId=@orderId
			
			IF(@hasMinPrice is null)
			BEGIN
				SET @hasMinPrice=0
			END
			
			SELECT @realPrice=SUM(b.payValue*a.buyCount) 
			FROM dbo.tb_orderSaleProduct a
			INNER JOIN dbo.tb_orderSaleProductPay b ON a.id=b.orderSaleProductId 
			WHERE b.payType=1 AND a.orderId=@orderId  AND    a.id!=@orderProductId --得到除了该商品之外其他商品的价格
				
			IF(@realPrice IS NULL)
			BEGIN
				SET @realPrice=0
			END	
			
			SELECT @realPrice2=SUM(b.payValue*@count) 
			FROM dbo.tb_orderSaleProduct a
			INNER JOIN dbo.tb_orderSaleProductPay b ON a.id=b.orderSaleProductId 
			AND a.id=@orderProductId  --得到该商品的价格
			
			SET @realPrice=@realPrice+@realPrice2
			print cast(@orderId as varchar(20))
			IF(@realPrice<@hasMinPrice)
			BEGIN
				
				SET @returnValue=-2 --赠品价格不准确请删除赠品或修改商品数量
			END
			ELSE
			BEGIN
				IF(@count=0)
				BEGIN
					
					DELETE FROM dbo.tb_orderSaleProduct  WHERE id=@orderProductId
					SET @returnValue=1
				END
				ELSE
				BEGIN
					DECLARE @realCount INT
					DECLARE @DDlCount INT
					DECLARE @oldCount INT
					DECLARE @productId INT
					DECLARE @colorId INT
					DECLARE @metricsId INT
		
					
					SELECT @productId=c.id,@colorId=a.colorId,@metricsId=a.metricsId
					FROM dbo.tb_orderSaleProduct a
					INNER JOIN dbo.tb_saleProduct b ON a.saleProductId=b.id
					INNER JOIN ERP.dbo.tb_product c ON b.productId=c.id AND a.id=@orderProductId
		
					SELECT @realCount=SUM(productCount) FROM ERP.dbo.tb_productStock 
					WHERE productId=@productId AND colorId=@colorId AND metricsId=@metricsId   
					
			    		SELECT @DDlCount=SUM(a.buyCount) FROM dbo.v_allBuyProductNew a 
					--INNER JOIN tb_saleProduct b ON a.saleProductId=b.id 
				             WHERE a.saleProductId=@productId AND a.colorId=@colorId 
					AND a.metricsId= @metricsId   
					
					SELECT @oldCount=SUM(buyCount) FROM tb_orderSaleProduct WHERE id=@orderProductId
	
					 IF(@DDlCount IS NULL)
			                	 BEGIN 
						SET @DDlCount=0
			              	 END
					
					IF((@realCount-@DDlCount)>=(@count-@oldCount))
					BEGIN
			  			UPDATE dbo.tb_orderSaleProduct SET buyCount=@count WHERE id=@orderProductId
						SET @returnValue=1
					END
					ELSE
					BEGIN
						SET @returnValue=-3
					END
				END
			END
		END

	/*-----------核算运费-------------------------*/
			/*DECLARE @deliverPrice INT
			DECLARE @provinceId INT 
			DECLARE @payType INT 
			DECLARE @cityId INT 
			SELECT @provinceId=provinceId,@payType=payType,@cityId=cityId FROM tb_order WHERE  id=@orderId
			IF(@provinceId=1 OR @provinceId=2 OR @provinceId=3)
			BEGIN
				IF(@realPrice>=9800)
				BEGIN
					SET @deliverPrice=0
				END
				ELSE
				BEGIN
					IF(@cityId = 1)
						BEGIN
							IF(@payType = 1)
								SET @deliverPrice=500 
							ELSE
								SET @deliverPrice=0 
						END
					ELSE
					BEGIN
	                    				IF(@payType = 1)
							SET @deliverPrice=1000
						ELSE
							SET @deliverPrice=500 

					END

				END
			END
			ELSE
			BEGIN

				IF(@realPrice>=19800)
				BEGIN
					SET @deliverPrice=0
				END
				ELSE
				BEGIN
					IF(@payType = 1)
						SET @deliverPrice=1500 
					ELSE
						SET @deliverPrice=1000 
				END
			END
			SELECT @realPrice=SUM(b.payValue*a.buyCount) 
			FROM dbo.tb_orderSaleProduct a
			INNER JOIN dbo.tb_orderSaleProductPay b ON a.id=b.orderSaleProductId 
			WHERE b.payType=1 AND a.orderId=@orderId  

			UPDATE tb_order SET getScore=@realPrice/100,deliverPrice=@deliverPrice,productPrice=@realPrice WHERE id=@orderId */
			--SET @returnValue=1 --修改成功
	END
	exec p_computeOrderPrice @orderId
	if(@returnValue=1)
	begin
		if EXISTS(select 1 from tb_order where orderstatus in(20,13) and id=@orderId)
		begin
			update tb_order set isdelete=2 where  id=@orderId
		end
	end
	
	SELECT @returnValue