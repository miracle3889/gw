
CREATE   PROCEDURE p_updateSaleProduct @saleProductId INT,@oldPrice INT,
					   @saleCount INT,@remark VARCHAR(5000)
AS
	DECLARE @returnValue INT
	SET @returnValue=0
	BEGIN TRAN 
		UPDATE  dbo.tb_saleProduct SET oldPrice=@oldPrice,remark=@remark,
		saleCount=@saleCount WHERE id=@saleProductId
		SET @returnValue=1
	COMMIT TRAN
	SELECT @returnValue