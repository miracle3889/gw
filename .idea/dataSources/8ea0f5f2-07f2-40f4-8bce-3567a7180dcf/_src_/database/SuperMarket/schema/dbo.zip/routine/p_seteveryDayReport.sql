CREATE   procedure p_seteveryDayReport
as 
declare @mydate varchar(50)
declare @price int 


DECLARE authors_cursor0 CURSOR FOR

--select convert(varchar(10),a.okTime,120) as mydate,sum(b.buyCount*c.stockPriceReal) as outPrice
--from erp..tb_transfer a 
--inner join erp..tb_orderOutProduct b on a.id=b.outId 
--inner join erp..tb_product c on b.productId=c.id   
--where a.okTime >=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
--group by convert(varchar(10),a.okTime,120)
--出库记录


select  convert(varchar(10),setTime,120) as mydate,sum(a.buyCount*cast(stockPrice as bigInt)) as outPrice  from tb_orderSaleProduct a
 inner join tb_order b on a.orderId=b.id and b.orderstatus in(2,3,11,17,18) and b.setTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)

group by   convert(varchar(10),setTime,120) order by convert(varchar(10),setTime,120)

OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_everyDayReport where addDate=@mydate)
		begin
			update tb_everyDayReport set outPrice=@price where addDate=@mydate
		end
	else
		begin
			insert into tb_everyDayReport(outPrice,addDate) values(@price,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0


DECLARE authors_cursor0 CURSOR FOR
select convert(varchar(10),b.inTime,120) as mydate,sum(a.buyCount*c.stockPriceReal)  as  inPrice
from erp..tb_buyProductProtity a 
inner join erp..tb_buyProductList b on a.buyProductId=b.id and a.isIn=1 
inner join erp..tb_product c on b.productId=c.id
where b.inTime >=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),b.inTime,120)
--入库记录
OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_everyDayReport where addDate=@mydate)
		begin
			update tb_everyDayReport set inPrice=@price where addDate=@mydate
		end
	else
		begin
			insert into tb_everyDayReport(inPrice,addDate) values(@price,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0




DECLARE authors_cursor0 CURSOR FOR
select convert(varchar(10),addDate,120) as mydate,sum(productStock*productPrice)  as stockPrice
from erp..tb_productStockPrice where addDate>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),addDate,120) order by convert(varchar(10),addDate,120)
--库存商品价值

OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_everyDayReport where addDate=@mydate)
		begin
			update tb_everyDayReport set onStock=@price where addDate=@mydate
		end
	else
		begin
			insert into tb_everyDayReport(onStock,addDate) values(@price,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0





DECLARE authors_cursor0 CURSOR FOR

select  convert(varchar(10),getdate(),120),sum(b.stockPriceReal*(clippingCount-outCount)) from erp..tb_clipping a
 inner join erp..tb_Product b on a.productId=b.id where  a.status in(1,2) and isDelete=0 and clippingCount-outCount>0

--采购中商品

OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_everyDayReport where addDate=@mydate)
		begin
			update tb_everyDayReport set inTransit=@price where addDate=@mydate
		end
	else
		begin
			insert into tb_everyDayReport(inTransit,addDate) values(@price,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0


declare @orderCount int
declare @useGift int
declare @useaccount int
declare @transport int
declare @proxy int
declare @backPrice int
declare @rejectPrice int

DECLARE authors_cursor0 CURSOR FOR
SELECT  convert(varchar(10),createTime,120) as mydate,
count(*) as orderCount,sum(productPrice-backPrice) as orderPrice,
sum(useGift) as useGift,sum(useaccount) as useaccount ,sum(transport) as transport,sum(proxy)  as  proxy ,sum(backPrice) as rejectPrice
FROM tb_order
WHERE 
orderStatus in(1,2,3,11,13,17,18,20)  
AND isDelete!=1 
and createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),createTime,120) order by convert(varchar(10),createTime,120)
--销售额
OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@orderCount,@price,@useGift,@useaccount,@transport,@proxy,@rejectPrice
WHILE @@FETCH_STATUS = 0
BEGIN
	--select @backPrice=sum(backPrice) from tb_backOder where isdeleted<>1 and 
	-- ordeId in(select id from tb_order where convert(varchar(10),createTime,120)=@mydate)
	--if(@backPrice is null) 
	--set @backPrice=0
	--set @price=@price-@backPrice
	if EXISTS(select 1 from tb_everyDayReport where addDate=@mydate)
		begin
			update tb_everyDayReport set rejectPrice=@rejectPrice,orderCount=@orderCount,orderPrice=@price,
			useGift=@useGift,useAccount=@useaccount,transport=@transport,proxy=@proxy where addDate=@mydate
		end
	else
		begin
			insert into tb_everyDayReport(rejectPrice,orderCount,orderPrice,useGift,useAccount,transport,proxy,addDate) 
			values(@rejectPrice,@orderCount,@price,@useGift,@useaccount,@transport,@proxy,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@orderCount,@price,@useGift,@useaccount,@transport,@proxy,@rejectPrice
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0


DECLARE authors_cursor0 CURSOR FOR
select convert(varchar(10),createTime,120) as mydate,sum((buyCount-backCount)*cast(case stockPrice when 0 then isnull(c.payValue,0) else stockPrice end  as bigInt)) as orderStockPrice  from tb_orderSaleProduct a
inner join tb_order b on a.orderId=b.id
left  join (
select productId,b.payValue/2 as payValue  from tb_saleProduct a
inner join tb_saleProductPay b on a.id=b.saleProductId
 where saleTypeId=1 and b.payStyleId=1 
) c on c.productId=a.productId 
where isDelete!=1 
and orderStatus in(1,2,3,11,13,17,18,20) 
and createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),createTime,120) order by convert(varchar(10),createTime,120)
--成本

OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_everyDayReport where addDate=@mydate)
		begin
			update tb_everyDayReport set orderStockPrice=@price where addDate=@mydate
		end
	else
		begin
			insert into tb_everyDayReport(orderStockPrice,addDate) values(@price,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0



--没有采购价的
DECLARE authors_cursor0 CURSOR FOR
select convert(varchar(10),createTime,120) as mydate,sum((buyCount-backCount)*cast(c.payValue/2 as bigInt)) as orderStockPrice  from tb_orderSaleProduct a
inner join tb_order b on a.orderId=b.id and a.stockPrice=0
inner join tb_orderSaleProductPay c on c.ordersaleProductId=a.id and c.payType=1  
where isDelete!=1 
and orderStatus in(1) 
and createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),createTime,120) order by convert(varchar(10),createTime,120)
--成本

OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	
			update tb_everyDayReport set orderStockPrice=orderStockPrice+@price where addDate=@mydate
	
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0






update tb_everyDayReport set needCheck=0 where addDate>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
and addDate not in(SELECT  convert(varchar(10),createTime,120) as mydate  FROM tb_order
WHERE  orderStatus=5 AND isDelete!=1 
and createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),createTime,120) )

DECLARE authors_cursor0 CURSOR FOR
SELECT  convert(varchar(10),createTime,120) as mydate,sum(productPrice-backPrice) as needCheck FROM tb_order
WHERE  orderStatus=5 AND isDelete!=1 
and createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),createTime,120) order by convert(varchar(10),createTime,120)
--待审核商品
OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_everyDayReport where addDate=@mydate)
		begin
			update tb_everyDayReport set needCheck=@price where addDate=@mydate
		end
	else
		begin
			insert into tb_everyDayReport(needCheck,addDate) values(@price,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0




update tb_everyDayReport set needPay=0 where addDate>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
and addDate not in(SELECT  convert(varchar(10),createTime,120) as mydate  FROM tb_order
WHERE  orderStatus=6 AND isDelete!=1 
and createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),createTime,120) )



DECLARE authors_cursor0 CURSOR FOR
SELECT  convert(varchar(10),createTime,120) as mydate,sum(productPrice-backPrice) as needPay FROM tb_order
WHERE  orderStatus=6 AND isDelete!=1 
and createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),createTime,120) order by convert(varchar(10),createTime,120)
--待收款
OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_everyDayReport where addDate=@mydate)
		begin
			update tb_everyDayReport set needPay=@price where addDate=@mydate
		end
	else
		begin
			insert into tb_everyDayReport(needPay,addDate) values(@price,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0


DECLARE authors_cursor0 CURSOR FOR
SELECT  convert(varchar(10),createTime,120) as mydate,sum(productPrice-backPrice) as isOk FROM tb_order
WHERE  orderStatus in(3,11,17,18) AND isDelete!=1 
and createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120) and isnull(magsourceRemark,'')<>'taobao'
group by convert(varchar(10),createTime,120) order by convert(varchar(10),createTime,120)

--已录回

OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_everyDayReport where addDate=@mydate)
		begin
			update tb_everyDayReport set isOk=@price where addDate=@mydate
		end
	else
		begin
			insert into tb_everyDayReport(isOk,addDate) values(@price,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0



DECLARE authors_cursor0 CURSOR FOR
SELECT  convert(varchar(10),createTime,120) as mydate,sum(productPrice-backPrice) as isOk FROM tb_order
WHERE  orderStatus in(3,11,17,18) AND isDelete!=1 
and createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120) and magsourceRemark='taobao'
group by convert(varchar(10),createTime,120) order by convert(varchar(10),createTime,120)

--已录回淘宝

OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_everyDayReport where addDate=@mydate)
		begin
			update tb_everyDayReport set isOkTaobao=@price where addDate=@mydate
		end
	else
		begin
			insert into tb_everyDayReport(isOkTaobao,addDate) values(@price,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0




DECLARE authors_cursor0 CURSOR FOR
SELECT  convert(varchar(10),setTime,120) as mydate,
count(*) as orderCount,sum(productPrice+transport+proxy-useGift-useaccount) as orderPrice
FROM tb_order
WHERE  isDelete<>1 
and setTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),setTime,120) order by convert(varchar(10),setTime,120)
--发货
OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@orderCount,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_everyDayReport where addDate=@mydate)
		begin
			update tb_everyDayReport set sendCount=@orderCount,sendPrice=@price where addDate=@mydate
		end
	else
		begin
			insert into tb_everyDayReport(sendCount,sendPrice,addDate) values(@orderCount,@price,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@orderCount,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0



DECLARE authors_cursor0 CURSOR FOR
SELECT  convert(varchar(10),visaTime,120) as mydate,
count(*) as orderCount,sum((CASE orderstatus WHEN 11 THEN 0 WHEN 18 THEN 0 ELSE (productPrice + deliverPrice - useGift - useAccount-backPrice) END)) as orderPrice
FROM tb_order
WHERE  isDelete<>1  and orderStatus IN (3, 17, 11, 18)  and payType=1
and visaTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),visaTime,120) order by convert(varchar(10),visaTime,120)

--收款
OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@orderCount,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_everyDayReport where addDate=@mydate)
		begin
			update tb_everyDayReport set getCount=@orderCount,getPrice=@price where addDate=@mydate
		end
	else
		begin
			insert into tb_everyDayReport(getCount,getPrice,addDate) values(@orderCount,@price,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@orderCount,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0






DECLARE authors_cursor0 CURSOR FOR
SELECT  convert(varchar(10),payMentDate,120) as mydate,
count(*) as orderCount,sum(productPrice + deliverPrice - useGift - useAccount) as orderPrice
FROM tb_order
WHERE    payMentDate>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),payMentDate,120) order by convert(varchar(10),payMentDate,120)


--收款
OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@orderCount,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_everyDayReport where addDate=@mydate)
		begin
			update tb_everyDayReport set payCount=@orderCount,payValue=@price where addDate=@mydate
		end
	else
		begin
			insert into tb_everyDayReport(payCount,payValue,addDate) values(@orderCount,@price,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@orderCount,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0




DECLARE authors_cursor0 CURSOR FOR
SELECT  convert(varchar(10),createTime,120) as mydate,sum(productprice+deliverprice-useAccount-useGift) as useaccount FROM tb_order WHERE orderStatus in(1,2,3,13,11,17,18,20)  AND isDelete!=1 
and createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120) and magsourceRemark ='taobao'
group by convert(varchar(10),createTime,120) order by convert(varchar(10),createTime,120) 

--淘宝账户余额
OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_everyDayReport where addDate=@mydate)
		begin
			update tb_everyDayReport set useAccountTaobao=@price  where addDate=@mydate
		end
	else
		begin
			insert into tb_everyDayReport(useAccountTaobao,addDate) values(@price ,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0





DECLARE authors_cursor0 CURSOR FOR
SELECT  convert(varchar(10),opTime,120) ,sum(opamount)
FROM tb_accountOpLog
WHERE (opType = 4)  and  opTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)  group by convert(varchar(10),opTime,120) order by convert(varchar(10),opTime,120) 
--淘宝账户余额
OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_everyDayReport where addDate=@mydate)
		begin
			update tb_everyDayReport set useAccountBackPay=@price  where addDate=@mydate
		end
	else
		begin
			insert into tb_everyDayReport(useAccountBackPay ,addDate) values(@price ,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0




DECLARE authors_cursor0 CURSOR FOR
SELECT  convert(varchar(10),createTime,120) as mydate,sum(useaccount) as useaccount FROM tb_order WHERE orderStatus in(1,2,3,13,11,17,18,20)  AND isDelete!=1 
and createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120) and  backCode is not null and len(backCode)=12
group by convert(varchar(10),createTime,120) order by convert(varchar(10),createTime,120) 

--换货单账户余额
OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_everyDayReport where addDate=@mydate)
		begin
			update tb_everyDayReport set useAccountBack=@price  where addDate=@mydate
		end
	else
		begin
			insert into tb_everyDayReport(useAccountBack,addDate) values(@price ,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0



DECLARE authors_cursor0 CURSOR FOR

SELECT convert(varchar(10),b.createTime,120),sum(a.payPrice) as payPrice
FROM tb_backOder a
inner join tb_order b on a.ordeId=b.id 
 where backStatusId in(3,4) and  b.createTime>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),b.createTime,120) order by convert(varchar(10),b.createTime,120) 

--退货单
OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_everyDayReport where addDate=@mydate)
		begin
			update tb_everyDayReport set backPrice=@price  where addDate=@mydate
		end
	else
		begin
			insert into tb_everyDayReport(backPrice,addDate) values(@price ,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0



DECLARE @newCountCall int
DECLARE @newCountY int 



DECLARE authors_cursor0 CURSOR FOR

SELECT convert(varchar(10),adddate,120),sum(case source when 'CALLIN' then 1 else 0 end),sum(case source when 'CALLIN' then 0 else 1 end)
FROM tb_member  where id in(select memberId from tb_order where isdelete<>1)  and adddate >=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
and isnull(source,'')<>'CFT' and id not in(select memberId from tb_memberCard  where memberClass=2)
group by convert(varchar(10),adddate,120) order by convert(varchar(10),adddate,120) 
--新会员
OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@newCountCall,@newCountY
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_everyDayReport where addDate=@mydate)
		begin
			update tb_everyDayReport set  newMemberCall=@newCountCall,newMemberY=@newCountY  where addDate=@mydate
		end
	else
		begin
			insert into tb_everyDayReport(newMemberCall,newMemberY,addDate) values(@newCountCall,@newCountY ,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@newCountCall,@newCountY
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0




DECLARE authors_cursor0 CURSOR FOR
select convert(varchar(10),createTime,120) ,count(*) from (
SELECT  memberId,min(b.createTime) as createTime
FROM tb_member a
inner join tb_order b on a.id=b.memberId and b.isDelete<>1   and b.buyCountOrder>1
  where  adddate >=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
and isnull(source,'')<>'CFT' and a.id  in(select memberId from tb_memberCard  where memberClass=2)
group by memberId) as b group by convert(varchar(10),createTime,120) 
--新会员
OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@newCountCall
WHILE @@FETCH_STATUS = 0
BEGIN
	update tb_everyDayReport set  newMemberY=newMemberY+@newCountCall  where addDate=@mydate
		
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@newCountCall
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0




update tb_everyDayReport set orderPrice=orderPrice-backPrice,useAccount=useAccount-useAccountBack-useAccountBackPay  where addDate>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)


update tb_everyDayReport set profits=orderPrice+transport+proxy-orderStockPrice-useGift- useAccount  where addDate>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)





