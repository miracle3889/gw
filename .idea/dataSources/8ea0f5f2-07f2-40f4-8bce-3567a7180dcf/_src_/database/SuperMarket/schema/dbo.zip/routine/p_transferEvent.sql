CREATE procedure p_transferEvent @eventId int,@eventContent varchar(2000),@dealManId int,@departId int,@otherDepart int
as
	begin tran 
		update SuperMarket.dbo.tb_eventDeal set dealStatus=2,replyContent=@eventContent,
		dealManId=@dealManId,dealTime=getDate() where eventId=@eventId and departId=@departId and dealStatus=0
		insert into SuperMarket.dbo.tb_eventDeal(eventId,giveManId,departId) values(@eventId,@dealManId,@otherDepart)
		update SuperMarket.dbo.tb_event set currentDepartId=@otherDepart where id=@eventId
	commit tran