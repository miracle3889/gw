create procedure p_addOrderRecevice @orderId int,@receviceTime varchar(50),@receviceType int
as
   if exists (select 1 from supermarket..tb_orderRecevice where orderId=@orderId)
	begin
		update supermarket..tb_orderRecevice set receviceTime=@receviceTime,receviceType=@receviceType,addDate=getDate() where orderId=@orderId
	end
	else
	begin
		insert into supermarket..tb_orderRecevice(orderId,receviceTime,receviceType) values(@orderId,@receviceTime,@receviceType)
	end

