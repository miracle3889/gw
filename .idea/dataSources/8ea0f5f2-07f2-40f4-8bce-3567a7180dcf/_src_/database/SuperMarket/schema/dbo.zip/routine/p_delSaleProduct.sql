
/*---------------------------------删除销售商品-------------------------------------------------*/
CREATE   PROCEDURE p_delSaleProduct @saleProductId INT,@type INT 
AS 
   DECLARE @returnValue INT 
   SET @returnValue=0
	declare @isSystem int
	set @isSystem=0
   BEGIN TRAN 
--系统删除 设置isSystem=0  手动删除 设置isSystem=1
	if (@type=1)
	begin
		set @isSystem=1
	end
	UPDATE  dbo.tb_saleProduct SET  isDeleted=@type,delTime=getDate(),isSystem=@isSystem WHERE id=@saleProductId
	SET @returnValue=1
   COMMIT TRAN
 SELECT @returnValue