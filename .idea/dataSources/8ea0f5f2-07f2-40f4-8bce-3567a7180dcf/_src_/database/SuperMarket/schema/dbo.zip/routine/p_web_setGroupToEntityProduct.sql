


/*-------------------------------------生成临时表的组合商品--------------------------------*/
CREATE      procedure p_web_setGroupToEntityProduct 
AS
	delete tb_searchSaleEntity where isGroup=1
	
	insert into tb_searchSaleEntity (saleProductName,saleCode,salePrice,salePriceInt,keyWords,htmlPath,picPath,viewCount,adminSetCount,oldPrice,addDate,isGroup,keyWordOnly,saleId,isQh) 
	select name,code,convert(varchar(10),(salePrice/100))+'.0',salePrice,name+'|'+code,'saleGroup.yoyo?groupId='+convert(varchar(10),id),picPath,10000,10000,0,addTime,1,null,0,0 from tb_saleGroup where salePrice>0 and isOK!=0-- and id not in(1029,1041,1047,1044)

	delete tb_searchSaleEntity where saleCode in ('GA1044','GA1047','GA1069')