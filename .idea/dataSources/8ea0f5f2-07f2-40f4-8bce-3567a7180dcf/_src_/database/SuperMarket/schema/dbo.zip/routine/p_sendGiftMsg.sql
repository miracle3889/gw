

CREATE   procedure p_sendGiftMsg
as 
	declare @memberId int
	declare @memberName varchar(200)
	declare @mobileNum varchar(50)
	declare @EMail varchar(200)
	declare @giftId int
	declare @giftCode varchar(200)
             declare @content nvarchar(500)
	declare @emailTitle nvarchar(500)

	DECLARE authors_cursor CURSOR FOR
	
	select  c.id,c.name,a.id,a.cardCode,c.EMail,c.mobileNum from  dbo.tb_giftCard  a
       	 inner join dbo.tb_memberGift b on b.giftId=a.id
	inner join dbo.tb_member c on b.memberId=c.id
	where DATEDIFF(day,  getdate(),useLastTime)=5 and a.isAct=1 and a.isUse=0
	and c.mobileNum not in(select mobileNum from tb_blackNum) and c.source<>'CFT'
	OPEN authors_cursor
	FETCH NEXT FROM authors_cursor 
	INTO @memberId,@memberName,@giftId,@giftCode,@EMail,@mobileNum
	WHILE @@FETCH_STATUS = 0
	BEGIN
		set @emailTitle = '您在优邮网的礼券'+@giftCode+'即将过期'		
		set @content='优邮提示：尊敬的用户'+@memberName+'，您在优邮网的礼券'+@giftCode+'即将过期，请及时使用。www.yoyo18.com' 
		 if(@mobileNum is not null )
			 begin
				if(len(@mobileNum)>=11 )
					begin
						  exec p_sendMsg @mobileNum,@content
						 
						 declare @sendUrl varchar(500)
						 set @sendUrl=('http://www.yoyo18.com/web/emailGiftTimeOver.yoyo?giftId='++cast(@giftId as varchar(50))+'&memberId='+cast(@memberid as varchar(50)))
 						-- exec p_sendEmail @sendUrl,@EMail,@emailTitle
			                end
	                 end
		FETCH NEXT FROM authors_cursor 
		INTO @memberId,@memberName,@giftId,@giftCode,@EMail,@mobileNum
	END
	
	CLOSE authors_cursor
	DEALLOCATE authors_cursor