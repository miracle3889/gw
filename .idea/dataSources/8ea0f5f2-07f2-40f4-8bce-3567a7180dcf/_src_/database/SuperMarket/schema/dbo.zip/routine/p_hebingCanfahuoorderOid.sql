CREATE procedure [dbo].[p_hebingCanfahuoorderOid] @orderSaleIds varchar(200),@doman int
as  
	declare @orderId int
	declare @id  int
	declare @temp  int
	declare @orderIdNew int
	declare @tdeliverprice int
	declare @code varchar(50)
	declare @sql nvarchar(300)
	declare @tuseAccount int--合并后的订单余额
	declare @tuseGift int --合并后的订单礼券
	declare @tPrice int
	declare @memberId varchar(50)
	declare @receviceMan varchar(50)
	
	set @tPrice=0
	set @tuseAccount=0
	set @tuseGift=0
	set @tdeliverprice=0
	
	
	
	set @sql='select top 1  @orderIdx =orderId from tb_orderSaleProduct where id in('+@orderSaleIds+')'
	
	execute sp_executesql @sql,N'@orderIdx int output', @orderId output
    
    
    begin tran  
    EXEC p_geOrderCodeNew 1,@code OUTPUT --得到订单号
    
	INSERT INTO dbo.tb_order(orderCode,payType,deliverType,deliverPrice,memberId,orderStatus,
						doMan,reMark,magazineCode,magazineCodeS,magSourceRemark,receviceMan,post,receviceAddr1,
						receviceAddr2,receviceMobile,addrId,useAccount,getScore,regionalId1,regionalId2,useGift,
						orderSource,provinceId ,cityId ,createTime,paymentDate,deliverManId)
		
	select @code,11,1,0,memberId,1,@doman,'合并订单',magazineCode,magazineCodeS,magSourceRemark,receviceMan,post,receviceAddr1,
					receviceAddr2,receviceMobile,addrId,useAccount,getScore,regionalId1,regionalId2,useGift,
					orderSource,provinceId,cityId,GETDATE(),paymentDate   ,deliverManId
	from tb_order where orderstatus=1  and isdelete<>1 and  id=@orderId

	set @orderIdNew= SCOPE_IDENTITY() --得到刚刚插入的定单id 
	
	
	select @memberId=memberId,@receviceMan=receviceMan from tb_order where id=@orderIdNew
	----以上取得订单收件人等相关信息
	
	set @sql='insert into tb_taobaoCode(orderCode,taobaoTid) select orderCode,taobaoTid from tb_taobaoCode where orderCode in(
		select orderCode from tb_order where id in(select orderId from tb_orderSaleProduct where id in('+@orderSaleIds+')))'
	
	--合并关联关系
	----开始遍历需要合并的商品信息
	
	declare @i int 
	set @sql='DECLARE authors_cursor CURSOR FOR	 select id,orderId from tb_orderSaleProduct where id in('+@orderSaleIds+')'
	exec(@sql)
	OPEN authors_cursor
	FETCH NEXT FROM authors_cursor 
	INTO @id,@orderId
	WHILE @@FETCH_STATUS = 0
	BEGIN	
		
			declare @userAccount int
			declare @useGift int
			declare @productPrice int 
			declare @deliverPrice int 
			declare @thisPrice int
			
		
			select @userAccount=useaccount,@useGift=useGift,@productPrice=productPrice,@deliverPrice=deliverPrice from 
			tb_order where id=@orderId and isDelete<>1 
			
			select @thisPrice=SUM(a.buyCount*b.payValue) from tb_orderSaleProduct a
			inner join tb_orderSaleProductPay b on a.id=b.orderSaleProductId where a.id=@id and a.orderId=@orderId
			and b.payType=1
			print cast(@orderIdNew as varchar(10))
			
			print cast(@id as varchar(10))
			print cast(@orderId as varchar(10))
			print '总价格'+cast(@productPrice as varchar(10))
			print '商品价格'+cast(@thisPrice as varchar(10))
			if(@thisPrice is null) set @thisPrice=0
			set @tPrice=@tPrice+@thisPrice
		
			set @tuseAccount=@tuseAccount+@userAccount*@thisPrice/@productPrice
			
			set @tuseGift=@tuseGift+@useGift*@thisPrice/@productPrice
			
			set @tdeliverprice=@tdeliverprice+@deliverPrice*@thisPrice/@productPrice
			
			set @temp=@productPrice-@thisPrice
			
			
			
			if(@temp<=0)
			   update tb_order set isDelete=0,delCause='订单金额为0' where id=@orderId
			
			update tb_order set productPrice=productPrice-@thisPrice,useAccount=useAccount-@userAccount*@thisPrice/@productPrice,useGift=useGift-@useGift*@thisPrice/@productPrice,
			deliverPrice=deliverPrice-@deliverPrice*@thisPrice/@productPrice  where id=@orderId
			
			FETCH NEXT FROM authors_cursor 
		INTO @id,@orderId
	END
	CLOSE authors_cursor
	DEALLOCATE authors_cursor
	
	
	set @sql='update tb_orderSaleProduct set orderId='+cast(@orderIdNew as varchar(10))+' where id in('+@orderSaleIds+')'
	execute sp_executesql @sql 
	update tb_order set productPrice=@tPrice,useAccount=@tuseAccount,useGift=@tuseGift,
			deliverPrice=@tdeliverPrice  where id=@orderIdNew
	
	
	update tb_needCheckhedanOrder set isLock=0 where memberId=@memberId and receviceman=@receviceMan
	commit tran 