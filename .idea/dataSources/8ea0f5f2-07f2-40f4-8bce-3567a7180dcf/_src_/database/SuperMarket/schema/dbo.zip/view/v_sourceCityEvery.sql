CREATE VIEW dbo.v_sourceCityEvery
AS
SELECT TOP 100 PERCENT 日期, SUM(CASE 城市id WHEN 1 THEN 订单数 ELSE 0 END) 
      AS 杭州订单, SUM(CASE 城市id WHEN 1 THEN 销售额 ELSE 0 END) AS 杭州金额, 
      SUM(CASE 城市id WHEN 2 THEN 订单数 ELSE 0 END) AS 宁波订单, 
      SUM(CASE 城市id WHEN 2 THEN 销售额 ELSE 0 END) AS 宁波金额, 
      SUM(CASE 城市id WHEN 3 THEN 订单数 ELSE 0 END) AS 南京订单, 
      SUM(CASE 城市id WHEN 3 THEN 销售额 ELSE 0 END) AS 南京金额, 
      SUM(CASE 城市id WHEN 4 THEN 订单数 ELSE 0 END) AS 上海订单, 
      SUM(CASE 城市id WHEN 4 THEN 销售额 ELSE 0 END) AS 上海金额, 
      SUM(CASE 城市id WHEN 5 THEN 订单数 ELSE 0 END) AS 温州订单, 
      SUM(CASE 城市id WHEN 5 THEN 销售额 ELSE 0 END) AS 温州金额
FROM dbo.tb_temp_sourceSaleCityEvery
GROUP BY 日期
ORDER BY 日期
