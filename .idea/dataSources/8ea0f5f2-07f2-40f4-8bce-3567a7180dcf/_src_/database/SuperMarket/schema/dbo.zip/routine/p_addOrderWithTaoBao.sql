/*---------------网---------------------------------------------------------*/
CREATE   PROCEDURE [dbo].[p_addOrderWithTaoBao] @memberId INT,@deliverPrice INT,
				@reMark VARCHAR(500),
				@state VARCHAR(50),@city VARCHAR(50),@regional VARCHAR(50),
				@addr VARCHAR(200),@receviceMan varchar(50),@mobileNum varchar(50),@phoneNum varchar(50),
				@post VARCHAR(50),@giftPrice INT,@taobaotid varchar(50),@addDate varchar(50),@payTime varchar(50)
AS

	DECLARE @provinceId INT
	DECLARE @cityId INT
	DECLARE @regionalId INT	
	DECLARE @orderId INT
	DECLARE @buyCount  INT
	DECLARE  @code VARCHAR(50)
	DECLARE  @mobileNumSend VARCHAR(11)
	
	-- 11
	begin tran 
			set @mobileNumSend=@mobileNum
			if exists(select 1 from supermarket..tb_taobaoCode(TABLOCKX) where taobaoTid= @taobaotid   )
			begin
				select 0 
			end
			else
			begin
				select @buyCount=count(*)   from tb_order where memberId=@memberId  and isdelete<>1
				--if(isnull(@orderId,0)>0)
				--begin 
				--	insert into tb_taobaoCode(orderCode,taobaoTid) values(@code,@taobaotid)
				--	update tb_order set useGift=useGift+@giftPrice where id=@orderId
				--	select @orderId
				--end 
				--else
				--begin
					if(len(@remark)>80)
						set @remark=subString(@remark,1,80)

					
					EXEC p_geOrderCodeNew 1,@code OUTPUT --得到订单号
					
					if(len(isnull(@phoneNum,''))>0)
					    set @mobileNum=isnull(@mobileNum,'')+'/'+isnull(@phoneNum,'')
		
					
					select @provinceId=pId,@cityId=id from tb_city  where name =@city
					if(@provinceId is null )
					set @provinceId=0
					
					if(@provinceId=0)
					begin
						set @provinceId=4
						set @cityId=26
						set @regionalId=236
					end
					else
					begin
						select @regionalId=id  from tb_regional where regional=@regional and pid=@cityId
						if(@regionalId is null )
						set @regionalId=0
						if(@regionalId=0)
							select top 1 @regionalId=id  from tb_regional where pid=@cityId
						if(@regionalId is null )
						set @regionalId=0
					end
					
					set @addr=@state+'|'+@city+'|'+isnull(@regional,'')+'|'+@addr
					
					set @remark='淘宝单号：'+@taobaotid+isnull(@reMark,'')
					
					 declare @deliverRemarkId int
					select @deliverRemarkId=deliverManId  from tb_taobaoNickDeliver where  nickName in(select taobaoNickName from  tb_taobaomember where memberId=@memberId)
					 				
					if(isnull(@deliverRemarkId,0)>0)
					 begin
						declare @deliverRemark varchar(50)
						set @deliverRemark=''
						if(@deliverRemarkId=1)
							set @deliverRemark='申通'
						if(@deliverRemarkId=2)
							set @deliverRemark='圆通'
						if(@deliverRemarkId=3)
							set @deliverRemark='EMS'
						set @remark=@remark+isnull(@deliverRemark,'')
					 end 
					
					
					/*--------------------------生成定单信息----------------------------------------------*/
					INSERT INTO dbo.tb_order(orderCode,payType,deliverType,deliverPrice,memberId,orderStatus,
								   doMan,reMark,magazineCode,magazineCodeS,magSourceRemark,receviceMan,post,receviceAddr1,
							               receviceAddr2,receviceMobile,addrId,useAccount,getScore,regionalId1,regionalId2,useGift,orderSource,provinceId ,cityId ,createTime,paymentDate,buyCountOrder)
					VALUES(@code,11,1,@deliverPrice,@memberId,1,-100,isnull(@reMark,''),1,'taobao','taobao',@receviceMan,@post,isnull(@addr,''),
					
					'',@mobileNum,1,0,0,@regionalId,@regionalId,@giftPrice,2,@provinceId ,@cityId,@addDate,@payTime,@buyCount)
					
					
					
					set @orderId= SCOPE_IDENTITY() --得到刚刚插入的定单id 
					
					insert into tb_taobaoCode(orderCode,taobaoTid) values(@code,@taobaotid)
					delete from erp..tb_nickVisit where nickname in(select taobaoNickName from  tb_taobaomember where memberId=@memberId)
					delete from supermarket..tb_taobaoWaitBuyerProduct where taobaoId=@taobaotid
					declare @deliverManName  varchar(50)
					select  top 1 @deliverManName=b.userName from tb_order a  inner join erp..tb_user b on a.deliverManId=b.id  where memberId=@memberId and  deliverManId>0 order by a.id desc 
					if(@deliverManName is not null)
						update tb_order set remark=remark+'#'+@deliverManName where id=@orderId 
					declare @msgContent varchar(500)
						set @msgContent ='【注意】近期有诈骗团伙针对淘宝买家进行电话诈骗，莉家客服旺旺主号是"爱runa",电话：0571-28110689,QQ：800035600。除此之外，不会以任何其他方式与客户联系。请大家提高警惕，谨防诈骗！如有疑问，请马上与莉家QQ客服联系！'
					--if(len(isnull(@mobileNumSend,''))=11)
					--begin
					--	if not exists(select 1 from c3.dbo.tb_smsMission where mobileNum=@mobileNum and content=@msgContent)
					--	begin
					--		INSERT INTO c3.dbo.tb_smsMission(sourceType,mobileNum,content,sendTime,orderByClass,sendManId) VALUES(0,@mobileNum,@msgContent,getDATE(),9999,1)
					--	end
						
					--end 
					select @orderId
				end
			 -- end
	COMMIT TRAN