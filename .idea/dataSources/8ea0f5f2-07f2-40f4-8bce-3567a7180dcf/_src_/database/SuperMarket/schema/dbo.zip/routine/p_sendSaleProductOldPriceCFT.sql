/************生成本tb_saleProductOldPriceCFT临时表CFT*************/
CREATE    procedure p_sendSaleProductOldPriceCFT 
as

	delete dbo.tb_saleProductOldPriceCFT --删除tb_saleProductOldPrice

--财付通tb_saleProductOldPrice
	declare @CFTid int
	declare @id int
	declare @productId int
	
	declare tjCFT cursor for select saleId from tb_saleProductOldPrice
	open tjCFT
	fetch NEXT from tjCFT into @id
	
	while @@fetch_status<>-1 
	begin
		--首先取tb_saleProduct的productId.如果tb_saleProduct表里没有saleTypeId=16的商品记录
		set @productId=0
		select @productId=productId from tb_saleProduct where id=@id
		set @CFTid=0
		select @CFTid=id from tb_saleProduct where productId=@productId and saleTypeId=16
		if (@CFTid!=0 and @id!=0)
		begin
			insert into tb_saleProductOldPriceCFT (saleId,salePrice,isSet) 
			select @CFTid,salePrice,isSet from tb_saleProductOldPrice where saleId=@id
		end

		fetch NEXT from tjCFT into @id 
	end 

	close tjCFT
	deallocate tjCFT