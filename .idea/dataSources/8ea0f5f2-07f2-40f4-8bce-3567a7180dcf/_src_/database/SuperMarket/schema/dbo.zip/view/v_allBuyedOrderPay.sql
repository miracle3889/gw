CREATE VIEW dbo.v_allBuyedOrderPay
AS
SELECT b.id AS deliverId, b.name AS deliverName, CONVERT(varchar(10), a.paymentDate, 
      120) AS visaTime, SUM(a.productPrice + a.deliverPrice - a.useGift - a.useAccount) 
      AS productPrice, SUM(a.backPrice) AS backPrice, 0 AS price3, a.payType
FROM dbo.tb_order a INNER JOIN
      dbo.tb_payType b ON a.payType = b.id
WHERE  (a.paymentDate IS NOT NULL)
GROUP BY b.name, CONVERT(varchar(10), a.paymentDate, 120), a.payType, b.id

