/*---------------- 上新增加 -------------------------------*/
CREATE PROCEDURE [dbo].[p_addShangxinNewProduct] @nickName varchar(24), @nDate varchar(32), @userId int  
AS
	DECLARE @returnValue int
	set @returnValue=0
	
	
	IF EXISTS (select top 1 id from tb_shangxinNewProduct where nickName = @nickName and nDate=@nDate)
	BEGIN
		set @returnValue=-1
	END
	ELSE
	BEGIN
		insert into tb_shangxinNewProduct (nickName, nDate, addManId) values (@nickName, @nDate, @userId)
		set @returnValue=SCOPE_IDENTITY()		
	END

	SELECT @returnValue