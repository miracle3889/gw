create procedure p_addEvent @eventTitle varchar(50),@eventContent varchar(2000),@addManId int,@currentDepartId int,@insertId int out
as
	begin tran 
		insert into SuperMarket.dbo.tb_event(eventTitle,eventContent,addManId,currentDepartId)
		values(@eventTitle,@eventContent,@addManId,@currentDepartId)
		set @insertId=scope_identity()
		insert into SuperMarket.dbo.tb_eventDeal(eventId,giveManId,departId) values(@insertId,@addManId,@currentDepartId)
	commit tran 

