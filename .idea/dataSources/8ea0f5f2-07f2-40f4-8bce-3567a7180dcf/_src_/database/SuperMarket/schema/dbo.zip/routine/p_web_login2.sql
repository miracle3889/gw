/*------------------------登陆-----------------------------*/
CREATE PROCEDURE p_web_login2 @userName VARCHAR(50),@psw VARCHAR(50)
AS
	DECLARE @returnValue INT
	SELECT top 1 @returnValue=id  FROM  dbo.tb_member WHERE EMail=@userName AND psw=@psw  
	IF(@returnValue is NULL)
	BEGIN
		SELECT top 1 @returnValue=id FROM dbo.tb_member WHERE nickname=@userName AND psw=@psw  
		IF(@returnValue is NULL)
		BEGIN
			SET @returnValue=0
		END
	END
	SELECT @returnValue