
CREATE     procedure p_computeOrderPriceCFT @orderId int
as 
DECLARE @userAccount int  --使用帐户余额
declare @useGift int --使用礼券
declare @deliverPrice int --送货费用
declare @payType int  --付款类型
DECLARE @realPrice INT --实际价格
DECLARE @realPriceGroup INT --实际价格
DECLARE @realPriceReal INT --实际价格
declare @memberId int --会员Id
declare @type int
declare @provinceId int
declare @cityId int 
declare @regionalId1 int
declare @regionalId2 int 
declare @addId int
declare @isUse int
declare @freeType int

select @isUse=isUse,@payType=payType,@deliverPrice=deliverPrice,@useGift=useGift,@userAccount=useAccount,@memberId=memberId,
@provinceId=provinceId,@cityId=cityId,@regionalId1=regionalId1,@regionalId2=regionalId2,@addId=addrId,@freeType=freeType
 from tb_order where id=@orderId 

if(@addId=2)
begin
	set @regionalId1=@regionalId2
end
--1.杭州2.宁波3.温州4.嘉兴
--if(@cityId=1 or @cityId=4  or @cityId=2 or @cityId=18)--杭州
--begin
--	set @type=1
--end
--else
--begin
	if(@provinceId=1 or @provinceId=2 or @provinceId=3 )--江浙沪
	begin
		set @type=1
	end
	else
	begin
		set @type=2 --其他
	end
--end

SELECT @realPrice=SUM(b.payValue*a.buyCount) 
FROM dbo.tb_orderSaleProduct a
INNER JOIN dbo.tb_orderSaleProductPay b ON a.id=b.orderSaleProductId 
WHERE b.payType=1 AND a.orderId=@orderId  and groupPh=0



select  @realPriceGroup=(a.salePrice*b.buyCount) from tb_saleGroup a
 inner join tb_groupPh b on b.groupId=a.id
 where b.isBuy=1 and b.id in 
(select distinct groupPh from tb_orderSaleProduct where orderId=@orderId and groupPh!=0 )

if(@realPriceGroup is null)
	set @realPriceGroup=0

if(@realPrice is null)
	set @realPrice=0
if(@useGift is null)
	set @useGift=0
if(@userAccount is null)
	set @userAccount=0

set @realPrice=@realPrice+@realPriceGroup
set @realPriceReal=@realPrice-@useGift
declare @cardClass int
select  top 1 @cardClass=memberClass from tb_memberCard where memberId=@memberId
if(@cardClass is null)
set @cardClass=0


declare @transport int
declare @proxy int



	declare @useGiftXXX int
	declare @getScore INT  --所得积分
	
	--如果包含新优惠券
	if exists(select 1 from tb_memberGift a inner join tb_giftCard b on a.giftId=b.id  where a.useOder=@orderId and b.giftType=1) -- and @userAccount=0
	begin
			declare @useGift2 INT	
			declare @needPrice INT	
			--最大使用限额
			select @useGift2=sum(b.price),@needPrice=sum(needprice) from tb_memberGift a 
			inner join tb_giftCard b on a.giftId=b.id
			 where a.useOder=@orderId and b.giftType=1 and memberId=@memberId
			
			if(@needPrice<=@realPrice)
			begin
				set @useGift=@useGift2
				UPDATE tb_order SET useGift=@useGift  WHERE id=@orderId
				if((@useGift2%10000)=0)
				begin
					if(@provinceId=1 or @provinceId=2 or @provinceId=3)
					SET @freeType=3
					else
					SET @type =5
				end
				else
				begin
					SET @freeType=3
				end
				if(@payType=1)
				begin
					update tb_order set payType=4,orderstatus=6 where  id=@orderId
				end
			end
			else
			begin
				set @useGift=0
				UPDATE tb_order SET useGift=0  WHERE id=@orderId
			end			
	end
	else--使用原礼券
	begin	
		select @useGiftXXX=sum(b.price) from tb_memberGift a 
		inner join tb_giftCard b on a.giftId=b.id
		 where a.useOder=@orderId and b.giftType=0
		
		if(@useGiftXXX is null ) set @useGiftXXX=0
			UPDATE tb_order SET useGift=@useGiftXXX  WHERE id=@orderId --更新使用礼券情况
		
		set @useGift=@useGiftXXX --更新使用礼券信息
		
		
		declare @maxUseGift INT --最多使用的礼券
		SET @maxUseGift=@realPrice/5000*1000
		
		
		SET @getScore=@realPrice/100
	
	
	
		if(@cardClass=1 or  @cardClass=2)--如果是优卡用户双倍积分
		begin

			SET @getScore=@getScore*2
			
			UPDATE tb_order SET useGift=useGift+@realPrice/10000*500  WHERE id=@orderId
			
			set @useGift=@useGift+@realPrice/10000*500 --使用了优卡
			--update tb_order set remark=remark+'优卡用户免运费 优惠'+cast((@realPrice/10000*500)/100 as varchar(10))+'元' where id=@orderId
			
			if(@maxUseGift<@useGift)
			BEGIN
				UPDATE tb_order SET useGift=@maxUseGift  WHERE id=@orderId
				SET @useGift=@maxUseGift
			END
			
		end
	end

if(@type=1 or @payType<>1)--如果不是杭州地区切货到付款待收款手续费加8元
begin
	set  @proxy=0
end
else
begin
	set  @proxy=800
end

if(@cardClass=1)--如果是优卡用户运费为0
begin
	set  @transport=0
end
else
begin

	if(@realPriceReal<5000)
	begin
		
		if(@type=1)--核算杭州地区的运费
		begin
			if(@realPriceReal<9800)
			begin
				set  @transport=500
			end
			else
			begin
				set  @transport=0
			end
		end
		if(@type=2)--核算江浙沪地区的运费
		begin
			if(@realPriceReal<19800)
			begin
				set  @transport=800
			end
			else
			begin
				set  @transport=0
			end
		end
		
	end
	else
	begin
		set  @transport=0
	end
end


--财付通活动调整运费
declare @returnCount int
select @returnCount=count(*) from tb_ordersaleProduct a inner join tb_saleProduct b on a.saleProductId=b.id where b.saleTypeId=17 and a.orderid=@orderId
if(@returnCount>0)
begin
	set @transport=0
	set @proxy=0
end


select @returnCount=count(*) from tb_ordersaleProduct a where a.saleProductId=21315 and a.orderid=@orderId
if(@returnCount>0)
begin
	set @returnCount=0
	select @returnCount=count(*) from tb_ordersaleProduct a where a.saleProductId!=21315 and a.orderid=@orderId
	if (@returnCount=0)
	begin
		set @transport=0
		set @proxy=0
	end
end

select @returnCount=count(*) from tb_ordersaleProduct a inner join tb_saleProduct b on a.saleProductId=b.id where b.saleTypeId=19 and a.orderid=@orderId
if(@returnCount>0)
begin
	set @transport=1500
	
	set @proxy=0
end
select @returnCount=count(*) from tb_ordersaleProduct a inner join tb_saleProduct b on a.saleProductId=b.id where b.saleTypeId=18 and a.orderid=@orderId
if(@returnCount>0)
begin
	set @transport=2000
	
	set @proxy=0
end
select @returnCount=count(*) from tb_ordersaleProduct a inner join tb_saleProduct b on a.saleProductId=b.id where b.saleTypeId=20 and a.orderid=@orderId
if(@returnCount>0)
begin
	set @transport=2300
	
	set @proxy=0
end


select @returnCount=count(*) from tb_orderSaleProduct a 
inner join tb_groupPh b on a.groupPh=b.id and a.groupPh>0  and b.groupId=1069 and  a.orderid=@orderId
if(@returnCount>0)
begin
	set @transport=2300
	set @proxy=0
end


--免运费
if @freeType=1
	set @transport=0
--免手续费
if @freeType=2
	set @proxy=0
--全免
if @freeType=3
	begin
		set @proxy=0
		set @transport=0
	end

if(@payType=1)
begin
	update tb_order set needGetPrice=@realPrice+@transport+@proxy-@useGift-@userAccount,getScore=@realPrice/100,productPrice=@realPrice,deliverPrice=@transport+@proxy,proxy=@proxy,
	transport=@transport  where id=@orderId
end
else
begin
	update tb_order set needGetPrice=0,getScore=@realPrice/100,productPrice=@realPrice,deliverPrice=@transport+@proxy,proxy=@proxy,
	transport=@transport  where id=@orderId
end 


if exists(select 1   from tb_order where orderstatus =1 and isdelete<>1 and id=@orderId)
begin
	delete from tb_temp_waitPhProduct where orderId=@orderId
	
	insert into tb_temp_waitPhProduct(orderId,saleProductId,buyCount,colorId,metricsId)
	SELECT a.orderId,a.productId AS saleProductId, a.buyCount AS buyCount, a.colorId AS colorId, 
	      a.metricsId AS metricsId
        FROM dbo.tb_orderSaleProduct a 
	INNER JOIN   dbo.tb_order b ON b.id = a.orderId
	WHERE b.orderStatus =1 AND b.isDelete != 1 and a.orderId=@orderId

end
--update tb_order set useGift=useGift+(@realPrice-(cast(ROUND(((@realPrice)/100.0*1.0),1)*100 as int))) where id=@orderId