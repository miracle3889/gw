/*---------------后台生成礼券----------------------------*/
CREATE PROCEDURE p_HZ_addGift @memberId INT
AS
	DECLARE @giftId INT
	/*-------------以下是赠送礼券---------------------*/
	SET ROWCOUNT 1
		
	UPDATE dbo.tb_giftCard SET isAct=-10 WHERE  isAct=0  and createType=1
			
	SELECT TOP 1 @giftId=id FROM dbo.tb_giftCard WHERE isAct=-10 
				
	SET ROWCOUNT 0
				
	INSERT INTO dbo.tb_memberGift(giftId,memberId) VALUES(@giftId,@memberId)
				
	UPDATE dbo.tb_giftCard SET isAct=1,actTime=GETDATE(), 
	useLastTime=DATEADD(day,30,GETDATE()) WHERE id=@giftId