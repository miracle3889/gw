/*-----------------------------根据渠道记录浏览记录-------------------------------------*/
CREATE PROCEDURE p_web_addViewSiteHisByChannel @myUrl  VARCHAR(50),@memberId INT,
					   @memberName VARCHAR(50),@channelCode VARCHAR(50),
					   @ip VARCHAR(50),@client VARCHAR(16),
			@title VARCHAR(64),@htmlName VARCHAR(64),@smtp VARCHAR(32)
AS
	INSERT INTO dbo.tb_viewSiteHisByChannel (viewUrl,memberId,memberName,channelCode,ip,client,title,htmlName,smtp)
	VALUES(@myUrl,@memberId,@memberName,@channelCode,@ip,@client,@title,@htmlName,@smtp)