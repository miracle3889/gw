CREATE procedure p_addRates @nickName varchar(50),@taobaoId varchar(50),@numId varchar(50),@result varchar(50),@content varchar(200),@created varchar(50),@title varchar(50),@oId varchar(50)
as 
	if not exists(select 1 from tb_taobaoRates where nickName=@nickName and oId=@oId and taobaoId=@taobaoId)
	begin
		insert into  tb_taobaoRates(nickName,taobaoId,numId,result,content,created,title,oId) values(@nickName,@taobaoId,@numId,@result,@content,@created,@title,@oId)
	end


