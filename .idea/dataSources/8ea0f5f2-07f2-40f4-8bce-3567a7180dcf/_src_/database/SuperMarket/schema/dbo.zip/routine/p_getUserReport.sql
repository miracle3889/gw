/*-------------查询客服销售报表---------------------------*/

CREATE PROCEDURE p_getUserReport @startTime VARCHAR(50),@endTime VARCHAR(50)
AS
	select b.name,SUM((c.buyCount-c.backCount)*d.payValue) from tb_order a 
	inner join ERP.dbo.tb_user b on a.doMan=b.id
	inner join dbo.tb_orderSaleProduct c on a.id=c.orderId
	inner join dbo.tb_orderSaleProductPay d on c.id=d.orderSaleProductId
	where a.magazineCodeS='A' and d.payType=1 
	and a.createTime>=@startTime and a.createTime<=@endTime
	
	group by b.name,b.id

