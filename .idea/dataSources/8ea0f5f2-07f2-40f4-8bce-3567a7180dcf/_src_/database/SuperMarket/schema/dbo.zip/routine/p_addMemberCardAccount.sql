
/*----------充值卡---------------------*/
CREATE  procedure p_addMemberCardAccount @cardCode varchar(50),@psw varchar(50),@memberId int,@doMan int
as 
	declare @returnValue int
	declare @price int
	declare @isOnly int
	
	--会员卡验证有效
	if EXISTS(select 1 from tb_cardCodeAccount where cardCode=@cardCode and psw=@psw and isCheck=0)
	begin
		select @price=price,@isOnly=isOnly from  tb_cardCodeAccount where cardCode=@cardCode and psw=@psw and isCheck=0
		
		--冲20元
		declare @type int
		set @type=2
		exec  p_addAccountOpLogBySystem @memberId,@price,999,'充值卡',@doMan
                              
		--exec p_addAccountOpLog @memberId,@price,999,'充值卡'
		
		if(@isOnly=0)
		begin
			--是否VIP
			if not EXISTS(select 1 from  tb_memberCard where memberId=@memberId)
			begin
				set @type=1
				exec p_addMemberCard @memberId,@cardCode,2,1
			end
		end
		
		
		update tb_cardCodeAccount set isCheck=1,checkTime=getDate(),checkMember=@memberId,doman=@doMan,type=@type where  cardCode=@cardCode and psw=@psw and isCheck=0 
		set @returnValue=1
	end
	else
	begin
		set @returnValue=0
	end
	
	select  @returnValue