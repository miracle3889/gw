CREATE procedure [dbo].[p_addWeiXInMsg] @type  int,@msgcontent varchar(2000),@userId int,@nickId int --,@msgTyoe varchar(20)
as
	insert into tb_weiXinMsg(userId,msgType,msgcontent)
	select  b.id,'news',REPLACE(@msgcontent,'ruhnn_openId',b.openId) from tb_weiXinMsgUser a
	inner join erp..tb_user b on a.userId=b.id  --and b.id!=@userId
	inner join erp..tb_userBrand c on c.userId=b.id and c.brandId=@nickId and c.isNotify=1
	 where weiXinMsgType=@type  and b.id not in(
		select userId  from tb_weiXinMsg where msgcontent=@msgcontent
		 and sendTime>=DATEADD(DAY,-1,GETDATE())
	 )  --and b.id=1
	 group by  b.id,REPLACE(@msgcontent,'ruhnn_openId',b.openId)