CREATE procedure p_addCardAccount @area varchar(10),@cardCount int
as 
declare @cardCode varchar(10)
declare @psw varchar(10)
declare @cardInt int




while(@cardCount>0)
begin

	select @cardInt=max([sequence])+1 from  tb_accountCardInserted where area=@area	

	insert into tb_accountCardInserted(area,[sequence] ) values(@area,@cardInt)
	
	set @cardCode=cast(@cardInt as varchar(10))
	while(len(@cardCode)<4)
	begin
		set @cardCode='0'+@cardCode
	end
	
	set @cardCode=@area+@cardCode
	
	
	
	set @psw=cast(cast(rand()*1000000 as int) as  varchar(10))
	while(len(@psw)<6)
	begin
		set @psw='0'+@psw
	end
	
	insert into tb_cardCodeAccount(cardCode,psw) values(@cardCode,@psw)

	set @cardCount=@cardCount-1 
end


