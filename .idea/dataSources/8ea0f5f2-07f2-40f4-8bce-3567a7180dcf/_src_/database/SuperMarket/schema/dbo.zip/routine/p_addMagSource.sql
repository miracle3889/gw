CREATE PROCEDURE p_addMagSource @magSource VARCHAR(50),@issueCount INT,
					  @issueTime VARCHAR(50),@cost INT,@remark VARCHAR(500)
AS
	IF NOT EXISTS(SELECT  1 FROM tb_magSourceRemark WHERE magSource=@magSource)
	BEGIN
		INSERT INTO tb_magSourceRemark(magSource,issueCount,issueTime,cost,remark) VALUES(@magSource,@issueCount,@issueTime,@cost,@remark)
		SELECT SCOPE_IDENTITY(),'添加成功'
	END
	ELSE
	BEGIN
		SELECT -1,'编号已存在'
	END
