CREATE PROCEDURE p_sendGiftCard @memberId INT,@giftType int  
AS

	DECLARE @giftId INT
	SET XACT_ABORT ON
		BEGIN TRAN
			--选出当前可用的一张10元优惠券
			SELECT TOP 1 @giftId= id from tb_giftCard where createType=1 and price=1000 and isAct=0
	
			--将此券设置为已激活
			UPDATE dbo.tb_giftCard SET isAct=1,actTime=GETDATE(),actMan=0,
			useLastTime=DATEADD(day,30,GETDATE()) WHERE id=@giftId
			IF (@@ERROR<>0)
			BEGIN
				rollback tran
			END
			--将此券赠予用户
			INSERT INTO dbo.tb_memberGift(giftId,memberId,giftType) VALUES(@giftId,@memberId,@giftType)
			IF (@@ERROR<>0)
			BEGIN
				rollback tran
			END
		COMMIT TRAN