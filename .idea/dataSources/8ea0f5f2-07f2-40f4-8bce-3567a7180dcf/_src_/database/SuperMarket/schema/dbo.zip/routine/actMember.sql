/*------------------邮箱激活用户帐号----------------------------------*/
CREATE  PROCEDURE  actMember @checkCode VARCHAR(50),@memberId INT
AS
		DECLARE @giftId INT 
		DECLARE @isReg INT
		DECLARE @returnValue INT
	BEGIN TRAN 
		SELECT @isReg=isRegedit FROM dbo.tb_member WHERE id=@memberId AND checkCode=@checkCode
		IF(@isReg is NULL)
		BEGIN
			SET @returnValue=-1
			SELECT @returnValue

			IF(@@ERROR<>0)
			BEGIN
				ROLLBACK TRAN 
			END
			COMMIT TRAN 
			RETURN 
		END
		IF(@isReg=0)
		BEGIN
			/*-------------以下是赠送礼券---------------------*/
			--SET ROWCOUNT 1
	
			--UPDATE dbo.tb_giftCard SET isAct=-10 WHERE  isAct=0  and createType=1
		
			--SELECT TOP 1 @giftId=id FROM dbo.tb_giftCard WHERE isAct=-10 
			
			--SET ROWCOUNT 0
			
			--INSERT INTO dbo.tb_memberGift(giftId,memberId) VALUES(@giftId,@memberId)
			
			--UPDATE dbo.tb_giftCard SET isAct=1,actTime=GETDATE(), 
			--useLastTime=DATEADD(day,30,GETDATE()) WHERE id=@giftId 

			/*--------------------推荐送积分---------------------*/
			DECLARE @recommendId INT
			SELECT @recommendId=recommendId FROM  tb_member WHERE id=@memberId
			IF(@recommendId!=0)
			BEGIN
				--UPDATE tb_member SET score=score+20 WHERE id= @recommendId
				exec p_addScoreOpLog @recommendId,20,2,''
			END
			
			UPDATE dbo.tb_member SET isRegedit=1,regeditTime=getDATE() WHERE id=@memberId--激活账户
			SET @returnValue=1
		END
		ELSE
		BEGIN
			SET @returnValue=0
		END
	IF(@@ERROR<>0)
	BEGIN
		ROLLBACK TRAN 
	END
	COMMIT TRAN 
	SELECT @returnValue