/*---------------- 为指定上新增加宝贝 -------------------------------*/
CREATE PROCEDURE [dbo].[p_addShangxinNewProductList] @shangxinId int, @saleCode varchar(6) 
AS
	DECLARE @returnValue int
	set @returnValue=0
	
	
	IF EXISTS (select top 1 id from tb_saleProduct where saleCode = @saleCode )
	BEGIN
		insert into tb_shangxinNewProductList(shangxinId, saleCode) values (@shangxinId, @saleCode) 
		set @returnValue=SCOPE_IDENTITY()
	END
	

	SELECT @returnValue