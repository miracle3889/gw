CREATE procedure p_updateOrderBackProductDeal @orderBackProductId int,
							@dealMan int,
							@dealResult int,
							@dealRemark VARCHAR(200)
as
	declare @productId int
			declare @saleId int
			declare @dealResult2  int
			declare @colorId int
			declare @metricsId int
			select @dealResult2=dealResult,@saleId=saleId,@colorId=colorId,@metricsId=metricsId from tb_orderBackProduct where  id=@orderBackProductId
	begin
		update tb_orderBackProduct set dealTime=getDate(),dealman=@dealMan,
		dealResult=@dealResult,dealRemark=@dealRemark where id=@orderBackProductId
		if(@dealResult=1 and @dealResult2=0)
		begin
			select @productId=productId from tb_saleProduct where id=@saleId
			update erp.dbo.tb_productStock set productCount=productCount+1 
			where productId=@productId and colorId=@colorId and metricsId=@metricsId
		end
		if(@dealResult=2 and @dealResult2=0)
		begin
			insert into tb_changeProduct(orderBackProductId) values(@orderBackProductId)
		end 
	end
