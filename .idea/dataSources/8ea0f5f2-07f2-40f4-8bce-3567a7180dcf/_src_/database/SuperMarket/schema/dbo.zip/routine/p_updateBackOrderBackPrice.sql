/*-------------退回商品核算并给以积分-------------------------------*/

CREATE  PROCEDURE p_updateBackOrderBackPrice @orderId INT
AS 
	DECLARE @realPrice INT,
		    @backPrice INT,
		    @memberID INT,
		      @payPrice INT,
	    	    @payType INT,
		       @domanId INT,
		      @code  varchar(50),
		    @SCOREMONEY INT --积分换算标准
	
	SET @SCOREMONEY=100
		 
	
	SELECT @realPrice=SUM(b.payValue*a.backCount),@backPrice=SUM(b.payValue*a.getCount) 
	FROM dbo.tb_backProduct a
	INNER JOIN dbo.tb_orderSaleProductPay b ON a.orderSaleId=b.orderSaleProductId 
	WHERE b.payType=1 AND a.backId=@orderId 
	
	
	IF(@backPrice IS NULL)
	SET @backPrice=0
	IF(@realPrice IS NULL)
	SET @realPrice=0
	

	SELECT @memberID=a.memberId,@payType=b.backPriceTypeId,@payPrice=payPrice,@code=b.code,@domanId=b.doman  FROM tb_order a
	INNER JOIN dbo.tb_backOder b ON a.id=b.ordeId
	WHERE b.id=@orderId

	UPDATE tb_member SET score=score-(@backPrice)/@SCOREMONEY WHERE id=@memberID
		
	INSERT INTO dbo.tb_memberScoreHis(score,memberId,addOrSub,source,orderId)
	 VALUES ((@realPrice-@backPrice)/@SCOREMONEY,@memberID,2,1,@orderId)
	
	
	if(@payType=2)
	begin
		if not exists(select 1 from supermarket..tb_accountOpLog where optype=5 and orderCode=@code)
		begin
			exec supermarket..p_addAccountOpLogBySystem @memberID  ,@payPrice,5,@code,0
			update tb_backOder set  ispay=1,payTime=getDate(),payManId=@domanId where id=@orderId
		end
	end