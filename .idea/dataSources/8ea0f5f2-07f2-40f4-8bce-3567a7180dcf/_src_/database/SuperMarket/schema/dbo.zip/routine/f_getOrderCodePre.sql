
CREATE  function [dbo].[f_getOrderCodePre]( @id int,@Suffix varchar(3),@nickName varchar(50),@pre varchar(2))
RETURNS VARCHAR(50)
as 
begin
	--e 换货单  v 内购订单   m 合并订单 s 拆单 r 退款拦截订单
	declare @ordercode varchar(50)
	set @ordercode=supermarket.[dbo].[f_getOrderCode](@id,@Suffix,@nickName)
	set @ordercode=@pre+@ordercode
	return @orderCode
end 