CREATE procedure p_completeEvent @eventId int,@dealManId int,@departId int ,@eventContent varchar(2000)
as
	begin tran 
		insert into SuperMarket.dbo.tb_eventDeal(eventId,giveManId,departId,dealStatus,replyContent,dealManId,dealTime) values(@eventId,@dealManId,@departId,3,@eventContent,@dealManId,getDate())
		update SuperMarket.dbo.tb_event set eventStatus=3,completeTime=getDate(),cumpleteManId=@dealManId where id=@eventId
	commit tran 

