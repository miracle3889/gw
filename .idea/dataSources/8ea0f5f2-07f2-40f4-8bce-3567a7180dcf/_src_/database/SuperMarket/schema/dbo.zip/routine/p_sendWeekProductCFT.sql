/************生成本周特价临时表CFT*************/
CREATE    procedure p_sendWeekProductCFT 
as

	delete dbo.tb_weekProductCFT --删除本周特价表

--财付通本周特价
	declare @CFTid int
	declare @id int
	declare @productId int
	declare @saleId int
	
	declare tjCFT cursor for select id from tb_weekProduct
	open tjCFT
	fetch NEXT from tjCFT into @id
	
	while @@fetch_status<>-1 
	begin
		--首先取tb_saleProduct的productId.如果tb_saleProduct表里没有saleTypeId=16的商品记录
		set @saleId=0
		select @saleId=saleId from tb_weekProduct where id=@id
		set @productId=0
		select @productId=productId from tb_saleProduct where id=@saleId
		set @CFTid=0
		select @CFTid=id from tb_saleProduct where productId=@productId and saleTypeId=16 and id not in (20484)
		if (@CFTid!=0 and @saleId!=0)
		begin
			insert into tb_weekProductCFT (startTime,endTime,saleId,price,isdeal,dealTime) 
			select startTime,endTime,@CFTid,price,isdeal,dealTime from tb_weekProduct where id=@id
		end

		fetch NEXT from tjCFT into @id 
	end 

	close tjCFT
	deallocate tjCFT