CREATE   procedure p_circleIndexProduct
as
	declare @maxDate datetime
	declare @maxDatebefore2 datetime
	select @maxDate=max(createTime) from tb_tempProductIndex 
	if(@maxDate is null)
	begin
		set @maxDate=dateadd(day,-2,getDate())
	end
	else
	begin
		set @maxDatebefore2=dateadd(day,-2,@maxDate)
	end
	
	delete tb_tempProductIndex  where createTime < @maxDatebefore2

	insert into tb_tempProductIndex select a.saleProductName,a.htmlPath,c.receviceMan,
convert(varchar(20),c.createTime,120) as createTime,
(case c.addrId when 1 then receviceAddr1 else receviceAddr2 end) as addr ,3 as ptype
 from dbo.tb_searchSaleEntity a 
inner join dbo.tb_orderSaleProduct b  on substring(a.saleCode,2,len(a.saleCode)-1)=b.saleProductId 
 inner join tb_order c on b.orderId=c.id where a.isGroup=0 and c.isdelete!=1 and c.orderstatus!=19 and c.createTime >@maxDate

	
insert into tb_tempProductIndex 
	select  a.saleProductName,a.htmlPath,
(case c.name when '' then EMail else c.name end) as receviceMan,b.addDate as createTime,
(case c.complanyAddr  when NULL then c.homeAddr else c.complanyAddr end) as addr,2 as ptype
from   dbo.tb_searchSaleEntity a 
inner join  dbo.tb_favorites b on a.saleCode=b.saleCode 
inner join tb_member c on b.memberId=c.id where a.isGroup=0 and b.isdelete=0
and b.addDate >@maxDate

insert into tb_tempProductIndex 
	select  a.saleProductName,a.htmlPath,
(case c.name when '' then EMail else c.name end) as receviceMan,b.addDate as createTime,
(case c.complanyAddr  when NULL then c.homeAddr else c.complanyAddr end) as addr,1 as ptype
from   dbo.tb_searchSaleEntity a 
inner join  dbo.tb_shoppingBag b on substring(a.saleCode,2,len(a.saleCode)-1)=b.saleProductId 
inner join tb_member c on b.memberId=c.id where a.isGroup=0 and b.addDate >@maxDate