
/*-------------添加赠品到购物车----------- -----------*/
CREATE  PROCEDURE p_addShoppingPresent  	@memberId int, @saleProductId int,
						@colorId int, @metricsId int
AS
	DECLARE @realCount INT 
              DECLARE @DDlCount INT 
	 DECLARE @productId INT

	 SELECT @productId=productId FROM tb_saleProduct WHERE id=@saleProductId

	--库存
	SELECT @realCount=SUM(productCount) FROM ERP.dbo.tb_productStock     WHERE productId=@productId AND colorId=@colorId AND metricsId=@metricsId   
	--订单占
	 SELECT @DDlCount=SUM(a.buyCount) FROM v_allBuyProductNew a  
	  WHERE a.saleProductId=@productId AND a.colorId=@colorId AND a.metricsId=  @metricsId   
  	
	
  	 IF(@DDlCount IS NULL) SET @DDlCount=0 
	
	
	if (@realCount-@DDlCount>=1)
	begin
		INSERT INTO tb_shoppingBag(productCode,buyCount,saleProductId,colorId,metricsId,memberId,isRand) 
		select saleCode,1,@saleProductId,@colorId,@metricsId,@memberId,1
		from tb_saleProduct where  id=@saleProductId
		select 1		
	end
	else
	begin
		select 0
	end