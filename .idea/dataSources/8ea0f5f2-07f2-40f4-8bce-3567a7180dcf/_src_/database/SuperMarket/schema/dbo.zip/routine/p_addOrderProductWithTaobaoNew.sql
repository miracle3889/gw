CREATE  procedure p_addOrderProductWithTaobaoNew @orderId int,@productCode varchar(50),@price int,@count int ,@gift int,@lable varchar(50),@taobaoOId varchar(50)
as 
	declare @productId int
	declare @saleId int
	declare @colorId int
	declare @metricsId int
	declare @stockPrice int
	declare @orderSaleProductId int	
	declare @productCount int
	begin tran 
		
		select @productId=productId,@colorId=colorId,@metricsId=metricsId from erp..tb_productStock where productShelfCode=@productCode
		
		if(@productId is null)
		begin
			select  top 1  @productId=a.productId,@colorId=a.colorId,@metricsId=a.metricsId  
			from erp..tb_productStock a
			inner join  supermarket..tb_saleProduct b on a.productId=b.productId and saleTypeId=1 and b.saleCode=@productCode 
			if not  exists (select 1  from tb_needUpdateProductCode where orderId=@orderId)
				insert into tb_needUpdateProductCode(orderId) values(@orderId)
		end
		
		
		select @saleId=id from supermarket..tb_saleProduct where saleTypeId=1 and productid=@productId
		
		select @stockPrice=stockPriceReal from erp..tb_product where id=@productId
				
		
		INSERT INTO dbo.tb_orderSaleProduct(orderId,colorId,metricsId,saleProductCode,
					saleProductId,buyCount,stockPrice,productId,giftPrice)	
		values(@orderId,@colorId,@metricsId,@productCode,@saleId,@count,isnull(@stockPrice,0),@productId,@gift)
			
		set @orderSaleProductId=SCOPE_IDENTITY() 
		
		insert into dbo.tb_orderSaleProductPay(orderSaleProductId,payType,payValue) values(@orderSaleProductId,1,@price)
		
		insert into tb_taobaoOId(orderSaleId,taobaoOId) values(@orderSaleProductId,@taobaoOId)
		if(@lable<>'')
		begin
			set @lable=replace(@lable,'月','.')
			set @lable='预售 '+@lable+'开始发货'
			declare @lableId int
			select @lableId=id from tb_productLable where productId =@productId and lable=@lable and needDate>'2013-01-01'
			if (@lableId is null or @lableId=0)			
				begin
					insert into tb_productLable(productId,lable) values(@productId,@lable)
					set @lableId=SCOPE_IDENTITY() 
				end

			insert into tb_orderSaleLable(ordersaleId,lableId) values(@orderSaleProductId,@lableId)

			
		end
		
	commit tran