
CREATE     procedure p_addOrderScoreHt @orderCode varchar(50)
as 
	declare @memberId int --会员号
	declare @orderId int --订单ID
	declare @getScore  int --积分
	declare @result int

	set @result=0
	select @orderId=id,@memberId=memberId,@getScore=getScore from tb_order where  isDelete!=1
	and isSetScore=0  and orderCode=@orderCode
	if(@orderId is null or @orderId=0)
	begin
		set @result=1 --定单已经删除 或则已经给过积分
	end
	else
	begin
		begin tran 
			exec  p_rollBackOrderScore @orderCode --删除上次积分
			exec  p_addScoreOpLog @memberID,@getScore,1,@orderCode --添加积分
			update tb_order set isSetScore=1 where @orderId=@orderId
		commit tran 
	end
	select @result