CREATE procedure p_addRates2 @nickName varchar(50),@taobaoId varchar(50),@oId varchar(50),@result varchar(50),@content varchar(200),@created varchar(50),@title varchar(50)
as 
	if not exists(select 1 from tb_taobaoRates where nickName=@nickName and oId=@oId and taobaoId=@taobaoId)
	begin
		insert into  tb_taobaoRates(nickName,taobaoId,oId,result,content,[created],title) values(@nickName,@taobaoId,@oId,@result,@content,@created,@title)
	end

