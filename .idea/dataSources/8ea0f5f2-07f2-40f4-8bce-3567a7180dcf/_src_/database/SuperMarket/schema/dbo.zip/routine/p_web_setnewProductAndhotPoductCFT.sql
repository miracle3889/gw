

/*-------------------------------------CFT提取新品和热卖商品CFT--------------------------------*/
CREATE   procedure p_web_setnewProductAndhotPoductCFT 
AS

	--财付通新品
	delete tb_newSaleCFT
	declare @CFTid int
	declare @id int
	
	declare @productId int
	declare newSoCFT cursor for select saleId from dbo.tb_newSale
	open newSoCFT
	fetch NEXT from newSoCFT into @id
	
	while @@fetch_status<>-1 
	begin
		--首先取tb_saleProduct的productId.如果tb_saleProduct表里没有saleTypeId=16的商品记录
		set @productId=0
		select @productId=productId from tb_saleProduct where id=@id
		set @CFTid=0
		select @CFTid=id from tb_saleProduct where productId=@productId and saleTypeId=16
		if(@CFTid is not null)
		begin
			insert into tb_newSaleCFT (saleId,addMan) select @CFTid,addMan from tb_newSale where saleId=@id
		end
		fetch NEXT from newSoCFT into @id 
	end 

	close newSoCFT
	deallocate newSoCFT
	set @id=0
	
	delete tb_hotSaleCFT
	--财付通热卖
	declare hotSoCFT cursor for select saleId from dbo.tb_hotSale order by score desc
	open hotSoCFT
	fetch NEXT from hotSoCFT into @id
	
	while @@fetch_status<>-1 
	begin
		--首先取tb_saleProduct的productId.如果tb_saleProduct表里没有saleTypeId=16的商品记录
		set @productId=0
		select @productId=productId from tb_saleProduct where id=@id
		set @CFTid=0
		select @CFTid=id from tb_saleProduct where productId=@productId and saleTypeId=16
		if(@CFTid is not null)
		begin
			insert into tb_hotSaleCFT (saleId,addManId,dir,score) select @CFTid,addManId,dir,score from tb_hotSale where saleId=@id
		end
		fetch NEXT from hotSoCFT into @id 
	end 

	close hotSoCFT
	deallocate hotSoCFT