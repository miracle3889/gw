CREATE VIEW dbo.v_allBuyProductCheckOrder
AS

SELECT a.productId AS saleProductId, a.buyCount AS buyCount, a.colorId AS colorId, 
      a.metricsId AS metricsId, 1 AS type
FROM dbo.tb_orderSaleProduct a INNER JOIN
      dbo.tb_order b ON b.id = a.orderId
WHERE (b.orderStatus IN (1, 6)  or (b.orderStatus =5 and isPayment=1)) AND b.isDelete != 1
UNION ALL
SELECT c.productId AS saleProductId, buyCount, colorId, metricsId, 2 AS type
FROM tb_shoppingBag a INNER JOIN
      dbo.tb_SaleProduct c ON a.saleProductId = c.id
WHERE resource = 0 AND isStock = 1



