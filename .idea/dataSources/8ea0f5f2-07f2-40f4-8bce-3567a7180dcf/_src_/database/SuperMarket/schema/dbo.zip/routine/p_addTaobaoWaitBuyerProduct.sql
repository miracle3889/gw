CREATE procedure p_addTaobaoWaitBuyerProduct @taobaoCode varchar(50),@skuCode varchar(50),@buyCount int

as

	delete from tb_taobaoWaitBuyerProduct where taobaoCode=@taobaoCode
	insert into tb_taobaoWaitBuyerProduct(taobaoCode,skuCode,buyCount) values(@taobaoCode,@skuCode,@buyCount)