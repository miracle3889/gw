/*------------------------------------------------------回滚定单------------------------------------------------------------------------------------*/
CREATE  PROCEDURE [dbo].[p_delOrderTaobaoByCodeNew] @orderCode varchar(50) ,@skuId varchar(50)
AS	
	BEGIN TRAN 
		declare @orderId int 
		declare @orderstatus  int 
		select @orderId=a.id,@orderstatus=orderstatus from supermarket..tb_order a
		inner join supermarket..tb_orderSaleProduct b on a.id=b.orderId where orderCode=@orderCode
		  and orderstatus in(1,20,13,2) and b.saleProductCode=@skuId
		
		if(isnull(@orderId,0)>0)
		begin
			update supermarket..tb_order set isdelete=1,deleteManId=0,delCause=getDate() where id=@orderId 
			delete from supermarket..tb_taobaoCode where orderCode  in(select orderCode from tb_order where id=@orderId)
			delete from tb_temp_waitPhProduct where orderId=@orderId
			if(@orderstatus in(20,2,13))
				
				insert into erp..tb_dealUpdateOrder(orderId,orderstatus,dealType,dealManId)  values(@orderId,@orderstatus,1,1)
		end
		delete from supermarket..tb_temp_waitPhProduct where orderId =@orderId
	COMMIT TRAN