CREATE PROCEDURE p_addbackProductEvery 
AS 
declare @date varchar(10)

set @date=dateAdd(day,-30,getDate())
delete from   tb_temp_backProductEvery where 日期>=@date
insert into tb_temp_backProductEvery(日期,商品名称,退回数量,退回金额,类型,颜色,规格)
select 日期,商品名称,退回数量,退回金额,类型,颜色,规格   from (
select convert(varchar(10),a.visaTime,120) as 日期,m.name as 商品名称, 
sum(b.backCount) as 退回数量,sum(b.backCount*d.payValue)  as 退回金额,n.codeName as 颜色,p.codename as 规格,
'拒收' as 类型

 from tb_order a
inner join tb_orderSaleProduct b on a.id=b.orderId and a.isdelete<>1 and b.backCount>0
inner join tb_orderSaleProductPay d on d.orderSaleProductId=b.id and d.payType=1
inner join tb_saleProduct c on c.id=b.saleProductid  
inner join erp..tb_product m on m.id=c.productId 
inner join erp.dbo.tb_productColorCode n on n.id=b.colorId
inner join erp.dbo.tb_productMetricsCode p on p.id=b.metricsId
 where visaTime>=@date
group by convert(varchar(10),a.visaTime,120),m.name,n.codeName,p.codename

union all

select convert(varchar(10),a.visaTime,120) as 日期,m.name as 商品名称
,sum(X.getCount) as 退回数量,sum(X.getCount*d.payValue)  as 退回金额,n.codeName as 颜色,p.codename as 规格,
'退货' as 类型
 from tb_backOder a
inner join tb_backProduct X on a.id=X.backId and a.isDeleted<>1 and X.getCount>0
inner join tb_orderSaleProduct b on X.orderSaleId=b.id 
inner join tb_orderSaleProductPay d on d.orderSaleProductId=b.id and d.payType=1
inner join tb_saleProduct c on c.id=b.saleProductid 
inner join erp..tb_product m on m.id=c.productId 
inner join erp.dbo.tb_productColorCode n on n.id=b.colorId
inner join erp.dbo.tb_productMetricsCode p on p.id=b.metricsId
 where a.visaTime>=@date
group by convert(varchar(10),a.visaTime,120),m.name,n.codeName,p.codename
) as b
