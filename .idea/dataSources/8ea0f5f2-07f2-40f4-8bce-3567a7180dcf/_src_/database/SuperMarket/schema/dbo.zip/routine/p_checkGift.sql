/*--------------------------------验证合法性--------------------------------*/
CREATE PROCEDURE p_checkGift @giftL VARCHAR(200),@memberId INT,@totalPrice INT OUTPUT
AS
	if exists 
	(select * from tempdb.dbo.sysobjects where id =object_id('tempdb.dbo.#T1'))
			drop table #T1
	CREATE TABLE #T1(giftId int NULL)
	DECLARE @end INT
	SET @end=-1
	WHILE(@end!=0)
	BEGIN
		DECLARE @giftId INT
		SET @end=charindex(',',@giftL)
		IF(@end=0)
		break
		SET @giftId=SUBSTRING(@giftL,1,@end-1)
		SET @giftL=SUBSTRING(@giftL,@end+1,LEN(@giftL)-@end)
		INSERT INTO #T1(giftId) VALUES(@giftId)
	END

	--SELECT * FROM  #T1 
	
	SELECT @totalPrice=SUM(b.price) FROM dbo.tb_memberGift a 
	INNER JOIN dbo.tb_giftCard b ON a.giftId=b.id 
	 WHERE a.memberId=@memberId  AND b.isUse=0 AND b.useLastTime>=getDATE()
	AND b.id IN(SELECT giftId FROM #T1)

