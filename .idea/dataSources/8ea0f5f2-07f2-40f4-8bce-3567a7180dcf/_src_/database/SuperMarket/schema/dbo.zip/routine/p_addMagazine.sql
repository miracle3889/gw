
CREATE  procedure p_addMagazine  @issuesCode varchar(10),
				@magCode varchar(10),
				@issueTime varchar(20),
				@coverPic varchar(50) ,
			      	@pageNum int
as 
	declare @insertId int 
	/*if EXISTS (select 1 from  dbo.tb_MagazineIs where issuesCode= @issuesCode)
		set @insertId=-1 
	else
	begin*/
		insert into dbo.tb_MagazineIs(issuesCode,magCode,issueTime,coverPic,pageNum)
		values(@issuesCode,@magCode,@issueTime,@coverPic,@pageNum)
		set @insertId=SCOPE_IDENTITY( )
	--end
	select @insertId