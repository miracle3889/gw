CREATE   procedure p_addAccountOpLogBySystem @memberID  int,
				 @amount int,
                                 @opType int,/*1圣诞返现金* -2 过年奖金 2 代理商充值 */
				 @orderCode varchar(50),@addUserId int
as
	begin tran
		declare @account int
		
		select @account=account from tb_member where id = @memberID  --先取出当前用户现有积分，做日志记录用
		
		if(@account is null) set @account=0
		update tb_member set account = @account+@amount where id = @memberID  --修改用户积分

		insert tb_accountOpLog(memberID,originAccount,opAmount,opType,orderCode,addUserId) 
		Values(@memberId,@account,@amount,@opType,@orderCode,@addUserId)
	commit tran