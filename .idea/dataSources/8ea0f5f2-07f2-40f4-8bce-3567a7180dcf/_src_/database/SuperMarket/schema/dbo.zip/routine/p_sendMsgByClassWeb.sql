CREATE PROCEDURE p_sendMsgByClassWeb @mobileNum VARCHAR(11),@content NVARCHAR(2000)
as
	DECLARE @msgContent NVARCHAR(70)
	WHILE(LEN(@content)>0)
	BEGIN
		SET @msgContent=SUBSTRING(@content,1,64)
		SET @content=SUBSTRING(@content,65,LEN(@content))
		INSERT INTO c3.dbo.tb_smsMission(sourceType,mobileNum,content,sendTime,orderByClass) VALUES(-1,@mobileNum,@msgContent,getDATE(),999)
	END
