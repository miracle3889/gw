CREATE procedure [dbo].[p_addMag] @magName varchar(100),@magTime varchar(50)
as 
  declare @magId int 
  select @magId=id from  dbo.tb_weitaoMag  where name=@magName and  magTime=@magTime
  if(@magId is null)
	set @magId=0
	
   if(@magId=0)
		begin
		insert into tb_weitaoMag(name,magTime) values(@magName,@magTime)
		set  @magId=SCOPE_IDENTITY()
		end
	select @magId
	