/*------------------修改密码----------------------------*/
CREATE PROCEDURE p_addNoAnswerCallNew @callcallerCode VARCHAR(50),@callType INT 
AS
	if(@callcallerCode='28888770')
		begin
			INSERT INTO tb_noAnswerCall(callcallerCode,callType) VALUES(@callcallerCode,@callType)
		end
	else
		begin
			 if not exists(select 1 from tb_noAnswerCall where isCallBack=0 and callcallerCode=@callcallerCode)
				begin
					INSERT INTO tb_noAnswerCall(callcallerCode,callType) VALUES(@callcallerCode,@callType)
				end
			else
				begin
					update tb_noAnswerCall set callInTime=getDate()  where callcallerCode=@callcallerCode and isCallBack=0
				end
		end