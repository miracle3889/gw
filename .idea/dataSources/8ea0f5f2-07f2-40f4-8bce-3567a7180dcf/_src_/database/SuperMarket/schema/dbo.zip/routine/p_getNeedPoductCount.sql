CREATE PROCEDURE p_getNeedPoductCount 
AS
/*
DECLARE @tCount INT
DECLARE @nCount INT

SELECT @tCount=COUNT(DISTINCT memberId) FROM dbo.tb_needProdcut WHERE isReturnCall!=3

*/
/*SELECT @nCount=COUNT(DISTINCT a.memberId) FROM dbo.tb_needProdcut a
INNER JOIN ERP.dbo.tb_productStock b ON a.productId=b.productId
WHERE a.isReturnCall!=3
AND ((b.productCount)-(select SUM(buyCount) FROM v_allBuyProductNew WHERE saleProductId= a.productId))<=a.needCount

*/

--SET @tCount=@tCount---@nCount
SELECT 0