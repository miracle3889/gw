/*---------------------------------随机颜色-----------------------------------*/
CREATE PROCEDURE p_setRandomColorId @groupProductId int 
	
AS
	begin tran
	select c.colorId
	from tb_groupProduct a
	inner join tb_saleProduct b on b.id=a.saleProductId
	inner join ERP.dbo.tb_productStock c on b.productId=c.productId
	where a.id =@groupProductId
	group by c.colorId,c.productCount
	order by sum(c.productCount) desc
	commit tran