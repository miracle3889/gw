CREATE VIEW dbo.v_backOrderEveryDay
AS

	select * from tb_temp_backOrderEvery