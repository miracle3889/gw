create procedure p_delPrecentProduct	
	as
	DECLARE  @orderId  int
	DECLARE  @memberId  int
	DECLARE  @orderSaleId  int	
	DECLARE  @mobileNum   varchar(50)	
	DECLARE  @productName   varchar(50)	
	
	DECLARE authors_cursor0 CURSOR FOR
	
	select b.id,b.orderId from tb_order a
	inner join tb_orderSaleProduct b on a.id=b.orderId 
	and a.isdelete<>1 and a.useAccount=0 and  createTime<=dateadd(day,-5,getDate()) and a.payType=1
	and b.productId in(select productId from tb_temp_backPrecent where buyCount>100 and precent>=600)
	and a.id  in(select orderId from erp..tb_notCanDistributeProduct)
	
	OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0 
	INTO @orderSaleId,@orderId 
	WHILE @@FETCH_STATUS = 0
	BEGIN		
		delete from tb_orderSaleProduct where id=@orderSaleId
		
		exec p_computeOrderPrice @orderId

		FETCH NEXT FROM authors_cursor0 
		INTO @orderSaleId,@orderId 
	END
	CLOSE authors_cursor0
	DEALLOCATE authors_cursor0
	
	update tb_order set isdelete=1 where productPrice=0 and orderstatus=1 and isdelete<>1
