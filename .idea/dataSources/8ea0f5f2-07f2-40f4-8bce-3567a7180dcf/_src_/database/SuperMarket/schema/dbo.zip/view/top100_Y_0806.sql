create view top100_Y_0806 as
select top 100 saleProductId,count(*) YCount from tb_orderSaleProduct
where orderId in (
Select id from tb_order where isDelete <> 1 
and createTime > '2008-6-1' and createTime < '2008-7-1'
and magazineCodeS = 'Y'
)
group by saleProductId
order by count(*) desc 
