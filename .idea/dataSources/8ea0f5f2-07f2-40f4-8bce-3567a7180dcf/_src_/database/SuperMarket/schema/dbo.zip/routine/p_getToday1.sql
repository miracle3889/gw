CREATE  procedure p_getToday1
AS 
	--待处理订单	
	DECLARE @count1 INT
	DECLARE @price1 INT
	DECLARE @count2 INT
	DECLARE @price2 INT
	DECLARE @count3 INT
	DECLARE @price3 INT
	DECLARE @count4 INT
	DECLARE @price4 INT
	DECLARE @count5 INT
	DECLARE @price5 INT
	DECLARE @count6 INT
	DECLARE @price6 INT
	DECLARE @count7 INT
	DECLARE @price7 bigInt
	DECLARE @count8 INT
	DECLARE @price8 INT
	DECLARE @count9 INT
	DECLARE @price9 INT
	DECLARE @count10 INT
	DECLARE @price10 INT
	DECLARE @count11 INT
	DECLARE @price11 INT
	DECLARE @count12 INT
	DECLARE @price12 INT
	
	DECLARE @isCall INT --是否完成全部呼叫任务
	DECLARE @needCallCount INT --需要呼叫数量
	DECLARE @callCount INT --时间得到号码数量
	
	select 	@isCall=isCall ,@needCallCount=needCallCount,@callCount=callCount from tb_everyDayCallmission 
	where convert(varchar(10),callDate,120)=convert(varchar(10),getDate(),120)

	select 
	@count1=sum (case orderstatus when 1 then 1 else 0 end), --等待配货
	
	@price1=sum (case orderstatus when 1 then productPrice+deliverPrice-useAccount-useGift else 0 end), 
	
	
	@count2=sum (case orderstatus when 5 then 1 else 0 end) , --等待审核
	
	@price2=sum (case orderstatus when 5 then productPrice+deliverPrice-useAccount-useGift else 0 end) , 
	
	
	@count3=sum (case orderstatus when 6 then 1 else 0 end) , --等待收款
	@price3=sum (case orderstatus when 6 then productPrice+deliverPrice-useAccount-useGift else 0 end)  , 
	
	@count4=sum (case orderstatus when 13 then 1 else 0 end) , --等待发货
	@price4=sum (case orderstatus when 13  then productPrice+deliverPrice-useAccount-useGift else 0 end) , 
	
	@count5=sum (case orderstatus when 20 then 1 else 0 end) ,--配货
	@price5=sum (case orderstatus when 20  then productPrice+deliverPrice-useAccount-useGift else 0 end)
	
	
	
	 FROM tb_order  where orderstatus in(1,20,13,5,6 ) and isdelete<>1
	
	
	--今日发货
	
	
	select 
	@count6=count(*),@price6=sum(productPrice+deliverPrice-useAccount-useGift) 
	from tb_order where convert(varchar(10),setTime,120)=convert(varchar(10),getDate(),120)  
	
	
	select   @count9=sum(case payType when 1 then 1 else 0 end),
		@price9=sum(case payType when 1   then productPrice+deliverPrice-useAccount-useGift else 0 end)
	from tb_order where convert(varchar(10),setTime,120)=convert(varchar(10),getDate(),120)  
	
	
	
	--收款
	
	select  @count7=count(*),
	@price7=sum (case orderstatus when 11 then  0   when 18 then 0 else cast(productPrice+deliverPrice-useAccount-useGift-backPrice as bigInt)  end )
	from tb_order where convert(varchar(10),visatime,120)=convert(varchar(10),getDate(),120)   and payType=1
	
	

	--预付款
	
	--select  @count8=count(*),count(*),
	--@price8=sum (productPrice+deliverPrice-useAccount-useGift)
	--from tb_order where convert(varchar(10),paymentDate,120)=convert(varchar(10),getDate(),120)   
	
	
	--可以配货数量
	--select @count10=count_,@price10=price_ from (
	--select count(*) as count_, sum(productPrice+deliverPrice-useAccount-useGift) as price_  from tb_order  
	-- where isdelete<>1 and id in(select orderId from erp..tb_canDistributeOrder)) as c
	
	
	--缺货数量
	--select  @count11=count(*),@price11=sum(productPrice+deliverPrice-useAccount-useGift)  from tb_order where isdelete<>1 and id in(select orderId from erp..tb_notCanDistributeProduct)
	
	
	--缺货登记
	--select  @count12= count(*),@price12=sum(needCount*payValue)  from  tb_registProduct a
	--inner join tb_saleProductPay b on a.saleId=b.saleProductId and payStyleId=1
	 --where convert(varchar(10), addTime,120)=convert(varchar(10),getDate(),120)   and isdeleted<>1 
	
	
	declare @hasCount int 
	declare @buyCount int 
	declare @TCount int 

	select @hasCount=sum(hasCount),@buyCount=sum(buyCount),@TCount=count(*) from (
	select saleId,
	(case when isnull(b.productCount,0)>0 then 1 else 0 end)  as hasCount,
	
	(case when isnull(b.productCount,0)<=0 then case when isnull(c.buyCount,0) >0 then 1 else 0 end  else 0 end) as buyCOunt 
	from (
	select * from tb_magProduct 
	  where magId in(
	select max(id) from tb_magSourceRemark
	)
	
	) as a
	inner join tb_saleProduct x on a.saleId=x.id
	left join 
	(
	select productId,sum(productCount) as productCount from erp..tb_productStock group by productId  having sum(productCount)>0
	) as b  on x.productId=b.productId
	left join
	(
	select productId,sum(buyCount) as buyCount from  erp.dbo.tb_buyProductList where isdeleted<>1 and  buyStatus in(1,2,3)
	group by productId) as c  on x.productId=c.productId
	) as x


	select @count1 as 待配货数量,@price1 as 待配货金额,
		@count2  as 待审核数量 ,@price2 as 待审核金额,
		@count3 as 待收款数量,@price3 as 待收款金额,
		@count4 as 待发货数量 ,@price4  as 待发货金额,
		@count5 as 配货中数量,@price5 as 配货中金额,
		@count6 as 发货数量,@price6 as  发货金额,
		@count7 as 收款数量,@price7 as 收款金额,
		@count8  as 预收款数量,@price8 as 预收款金额,
		@count9  as 货到付款数量,@price9 as 货到付款金额,
		@count10  as 可配货数量,@price10 as 可配货金额,
		@count11  as 缺货数量,@price11 as 缺货金额,
		@count12  as 缺货登记数量,@price12 as  缺货登记金额,
		@isCall as 是否完毕 ,@needCallCount 总计呼叫,@callCount 得到号码,@hasCount as 有库存,@buyCount as 采购单,@TCount 全部