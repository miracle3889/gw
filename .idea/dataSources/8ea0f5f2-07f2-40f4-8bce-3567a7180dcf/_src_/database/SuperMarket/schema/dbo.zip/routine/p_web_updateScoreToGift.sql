/*-------------------500积分换10元礼券----------------------------------*/
CREATE  PROCEDURE  p_web_updateScoreToGift @memberId int,@updateInt int
AS
	DECLARE @score INT
	DECLARE @returnValue INT
	DECLARE @n int
	SELECT @score=score FROM dbo.tb_member WHERE id=@memberId
	IF(@score IS NULL)
	BEGIN
		 SET @score=0
	END
	if(@score/500 >= @updateInt)
	BEGIN
		set @returnValue=0-(@updateInt*500)
		exec p_addScoreOpLog @memberId, @returnValue, 51, '500积分换10元礼券'
		set @n = 0
		while @n<@updateInt
		begin
			exec p_sendGiftCard @memberId,51
			set @n = @n+1
		end
	END
	SELECT @n