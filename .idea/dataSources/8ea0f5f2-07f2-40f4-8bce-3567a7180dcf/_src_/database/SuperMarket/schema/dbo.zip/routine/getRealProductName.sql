CREATE  FUNCTION [dbo].[getRealProductName] (@productName varchar(500))  
RETURNS varchar(500)  AS  
BEGIN 
	declare @productNameReal varchar(500)
	declare @char varchar(10)
	set @productNameReal=''
 	while(len(@productName)>0)
		begin
			set @char=subString(@productName,1,1)
			if(len(unicode(@char)) >=5)
			   set @productNameReal=@productNameReal+@char
			else
			   begin
				if(ISNUMERIC(@char)=1)
					  set @productNameReal=@productNameReal+@char
			   end
			set @productName=subString(@productName,2,len(@productName))
		end 
	return @productNameReal
END

