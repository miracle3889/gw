CREATE procedure p_addCimHis @nickname varchar(50),@userNick  varchar(50)
as 
     set @userNick=replace(@userNick,'--客服工作台','')    
	if exists(select 1 from tb_cimHis where nickName=@nickname and userNick=@userNick and lastDate>=convert(varchar(10),getDate(),120))
	begin
		update tb_cimHis set lastDate=getDate() where nickName=@nickname and userNick=@userNick  and lastDate>=convert(varchar(10),getDate(),120)
	end
   else
	begin
		insert into tb_cimHis(nickName,userNick) values(@nickname,@userNick)
	end
  	insert into tb_cimHisLog(nickName,userNick) values(@nickname,@userNick)