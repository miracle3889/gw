CREATE VIEW dbo.v_allBuyedOrdertransport
AS


SELECT
 b.id  as  deliverId,
 b.name as  deliverName,
 a.orderCode, a.orderStatus, 
      CONVERT(varchar(10), a.visaTime, 120) AS visaTime, 
      (CASE orderstatus WHEN 11 THEN 0 WHEN 18 THEN 0 ELSE (SUM(a.productPrice + a.deliverPrice
       - a.useGift - a.useAccount) - SUM(a.backPrice)) END) AS productPrice, 
      SUM(a.backPrice) AS backPrice, 0 AS price3, a.payType
FROM dbo.tb_order a INNER JOIN
      ERP.dbo.tb_user b ON a.deliverManId = b.id
WHERE (a.isDelete <> 1) AND (a.orderStatus IN (3, 17, 11, 18)) AND   isNotgetPrice=0 and 
      (a.visaTime IS NOT NULL) and   b.id  in(select transportId from erp..tb_transport)
GROUP BY b.id,b.name, 
CONVERT(varchar(10), a.visaTime, 120), a.orderCode, a.payType, 
      a.orderStatus





