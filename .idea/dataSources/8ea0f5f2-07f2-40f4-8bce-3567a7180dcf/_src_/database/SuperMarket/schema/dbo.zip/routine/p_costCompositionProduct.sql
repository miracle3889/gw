CREATE PROCEDURE [dbo].[p_costCompositionProduct]
		@saleId int,
        @costId int,
        @price int,
        @userId int,
        @ratio int 
    AS
    BEGIN		
		declare @productId int 
		select  @productId=productId from  SuperMarket..tb_saleProduct  where  id=@saleId
		
				if(@ratio=0)
					set @ratio=100 
       if exists (SELECT 1 FROM SuperMarket..[tb_costCompositionProduct] where  costId = @costId and  productId  = @productId )
		begin
					
                UPDATE SuperMarket..[tb_costCompositionProduct] SET price=@price,
                userId=@userId,lastSetTime=GETDATE(),ratio=@ratio
                WHERE productId=@productId and costId = @costId 
        end 
        ELSE 
            BEGIN
                INSERT INTO SuperMarket..[tb_costCompositionProduct](costId,productId,price,userId,ratio)
                VALUES (@costId,@productId,@price,@userId,@ratio)
             END
    END