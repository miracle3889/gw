CREATE PROCEDURE p_addsourceCitySaleevery
AS 
declare @date varchar(10)

set @date=dateAdd(day,-30,getDate())

delete from tb_temp_sourceSaleCityEvery where 日期>=@date

insert into tb_temp_sourceSaleCityEvery

select convert(varchar(10),createTime,120) as 日期,count(*)  as 订单数,
sum(productPrice+deliverPrice-useAccount-useGift) as   销售额,sum(isnull(c.payPrice,0)) as 退货,sum(a.backPrice) as 拒收,b.name 城市,b.id 城市id 
from tb_order  a
inner join tb_marketCode b on a. magSourceRemark like b.code

left join (
	select ordeId,sum(payPrice) as payPrice  from tb_backOder where payPrice>0 and isDeleted<>1 group by ordeId 
	) as c  on a.id=c.ordeId

where orderstatus in(1,2,3,17,20,13) and isdelete<>1
and  createTime>=@date and magazineCodeS<>'Y'   
group by convert(varchar(10),createTime,120),b.name,b.id
 order by convert(varchar(10),createTime,120),b.name,b.id