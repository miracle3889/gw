/*----------------添加定单--------*/
CREATE        PROCEDURE p_addOrderProductTaobao     @productCode VARCHAR(50),
							@productCount int, 						 
							@orderId int
AS
	if EXISTS(  select 1 from tb_orderSaleProduct where saleProductCode=@productCode and orderId=@orderId )
	begin
		update tb_orderSaleProduct set buyCount=buyCount+@productCount where  saleProductCode=@productCode and orderId=@orderId
	end
	else
	begin
		INSERT INTO dbo.tb_orderSaleProduct(orderId,colorId,metricsId,saleProductCode,
					saleProductId,buyCount,isRand,stockPrice,productId)
		SELECT top 1 @orderId,a.colorId,a.metricsId,@productCode,c.id,@productCount,0,b.stockPriceReal,a.productId from erp..tb_productStock a
		inner join erp..tb_product b on a.productId=b.id
		inner join tb_saleProduct c on c.productId=a.productId    where a.productShelfCode= @productCode
		order by c.id 
	end