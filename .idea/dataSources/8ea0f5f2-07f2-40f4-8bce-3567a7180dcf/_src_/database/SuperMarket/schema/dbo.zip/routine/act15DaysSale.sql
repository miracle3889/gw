CREATE  PROCEDURE  act15DaysSale @productCode varchar(50),@saleCount INT,@rejectCount INT,@backCount INT,@productCount INT
AS
	IF EXISTS (SELECT 1 FROM tb_15DaysAvgSaleCount WHERE productCode =@productCode)
	BEGIN
		UPDATE tb_15DaysAvgSaleCount SET saleCount=@saleCount,rejectCount=@rejectCount,
		backCount=@backCount,productCount=@productCount,updateTime=getDATe() WHERE   productCode =@productCode
	END
	ELSE
	BEGIN
		INSERT INTO tb_15DaysAvgSaleCount(productCode,saleCount,rejectCount,backCount,productCount) 
		VALUES(@productCode,@saleCount,@rejectCount,@backCount,@productCount)
	END

	INSERT INTO tb_15DaysAvgSaleCountHis(productCode,saleCount,rejectCount,backCount,productCount) 
		VALUES(@productCode,@saleCount,@rejectCount,@backCount,@productCount)
