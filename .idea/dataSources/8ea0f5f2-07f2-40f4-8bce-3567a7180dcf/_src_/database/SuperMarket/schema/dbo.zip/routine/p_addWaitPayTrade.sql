
CREATE PROCEDURE [dbo].[p_addWaitPayTrade]  @taobaoId varchar(50) ,@taobaoCode varchar(50),@skuCode varchar(50),@buyCount int,@nickName varchar(50),@createTime varchar(50)
as 
	if not exists(select 1 from supermarket..tb_taobaoWaitBuyerProduct where taobaoId =@taobaoId and taobaoCode=@taobaoCode and skuCode=@skuCode)
	begin
		insert into supermarket..tb_taobaoWaitBuyerProduct(taobaoCode,skuCode,buyCount,nickName,taobaoId,createTime) 
		values(@taobaoCode,@skuCode,@buyCount,@nickName,@taobaoId,@createTime)
	end