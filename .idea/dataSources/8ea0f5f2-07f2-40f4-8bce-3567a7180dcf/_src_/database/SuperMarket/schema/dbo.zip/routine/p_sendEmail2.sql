
CREATE  procedure p_sendEmail2 @EmailUrl varchar(200),@DestEmailAddr varchar(200),@title varchar(200)
as 
	insert into dbo.tb_EmailMission(EmailHtml,title,EmailAddr,sendEmailType) 
	values(@EmailUrl,@title,@DestEmailAddr,1)