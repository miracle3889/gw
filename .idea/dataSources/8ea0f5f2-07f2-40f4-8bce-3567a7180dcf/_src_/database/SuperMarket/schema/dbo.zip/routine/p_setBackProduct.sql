CREATE procedure p_setBackProduct 
as
declare @maxCount int
declare @maxCountTmp int
select @maxCount=max(b.getCount) from tb_backOder a
inner join dbo.tb_backProduct b on a.id=b.backId
where a.backStatusId in(3,4) and b.getCount >0 and b.isGetTobackProduct=0

while(@maxCount>=1)
begin
	set @maxCountTmp=@maxCount
	begin tran
		update tb_backProduct  set isGetTobackProduct=-1  from tb_backOder a,tb_backProduct b
                       where  a.backStatusId in(3,4) and b.getCount =@maxCount and  b.isGetTobackProduct=0
		if @@rowcount>0
		begin
		while(@maxCountTmp>=1)
		begin
			insert into tb_orderBackProduct(orderCode,orderType,saleId,saleCode,colorId,metricsId,deliverManId)
			select a.code,2,c.saleProductId,c.saleProductCode,b.colorId,b.metricsId,d.deliverManId  from tb_backOder a
			inner join dbo.tb_backProduct b on a.id=b.backId
			inner join tb_orderSaleProduct c on b.orderSaleId=c.id
			inner join tb_order d on a.ordeId=d.id
			where  b.isGetTobackProduct=-1
			set @maxCountTmp=@maxCountTmp-1
		end
		
		update tb_backProduct set isGetTobackProduct=1 where isGetTobackProduct=-1
		end
	commit tran
	set @maxCount=@maxCount-1
end

select @maxCount=max(b.backCount) from tb_order a
inner join dbo.tb_orderSaleProduct b on a.id=b.orderId
where a.orderStatus in(11,17,18) and b.backCount >0 and isGetTobackProduct=0

while(@maxCount>=1)
begin
	set @maxCountTmp=@maxCount
	begin tran
		update tb_orderSaleProduct  set isGetTobackProduct=-1  from tb_order a,tb_orderSaleProduct b
                       where  a.orderStatus in(11,17,18) and b.backCount =@maxCount and isGetTobackProduct=0
		if @@rowcount>0
		begin
		while(@maxCountTmp>=1)
		begin
			insert into tb_orderBackProduct(orderCode,orderType,saleId,saleCode,colorId,metricsId,deliverManId)
			select a.orderCode,1,b.saleProductId,b.saleProductCode,b.colorId,b.metricsId,a.deliverManId  from tb_order a
			inner join dbo.tb_orderSaleProduct b on a.id=b.orderId
			where  isGetTobackProduct=-1
			set @maxCountTmp=@maxCountTmp-1
		end
		
		update tb_orderSaleProduct set isGetTobackProduct=1 where isGetTobackProduct=-1
		end
	commit tran
	set @maxCount=@maxCount-1
end