CREATE VIEW dbo.v_allNeedBuyProduct
AS
SELECT DISTINCT productId, colorId, metricsId
FROM (SELECT c.productId, a.colorId, a.metricsId
        FROM tb_orderSaleProduct a INNER JOIN
              tb_order b ON a.orderId = b.id AND b.orderStatus IN (5, 6) AND 
              b.isDelete != 1 INNER JOIN
              tb_saleProduct c ON a.saleProductId = c.id
        UNION ALL
        SELECT productId, colorId, metricsId
        FROM tb_needProdcut a
        WHERE a.isReturnCall != 3) tb1
