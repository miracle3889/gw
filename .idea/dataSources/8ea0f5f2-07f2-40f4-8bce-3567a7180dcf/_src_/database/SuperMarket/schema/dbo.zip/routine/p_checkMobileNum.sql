/*--------------已电话订购用户获取验证码-----------------------------*/
CREATE   PROCEDURE p_checkMobileNum @mobileNum VARCHAR(11)
AS
	DECLARE @myCount INT
	DECLARE @memberId INT
	DECLARE @returnValue INT
	 DECLARE @name VARCHAR(500)
	SET @returnValue=0
	SELECT @myCount=COUNT(*) FROM  dbo.tb_member WHERE mobileNum=@mobileNum -- AND (checkCode IS NULL OR checkCode='')
	IF(@myCount=1)
	BEGIN
	    SELECT @memberId=id,@name=name FROM  dbo.tb_member WHERE mobileNum=@mobileNum --AND (checkCode IS NULL OR checkCode='')
	    DECLARE @checkCode INT
	    DECLARE @msg VARCHAR(500)
	    SET @checkCode=rand()*1000000
	    UPDATE dbo.tb_member  SET checkCode=@checkCode WHERE id=@memberId
	    SET @msg='尊敬的yoyo会员'+@name+'您好！您的网站激活码为'+CAST(@checkCode AS VARCHAR(10))+' 感谢您对yoyo的支持！'
	    --EXEC p_sendMsgReal @mobileNum,@msg
		EXEC p_sendMsgByClass @mobileNum,@msg,99999,0
	    SET @returnValue=1
	END
	ELSE
	BEGIN
		IF(@myCount>1)
		BEGIN
			SET @returnValue=-1
		END
	END
	SELECT @returnValue