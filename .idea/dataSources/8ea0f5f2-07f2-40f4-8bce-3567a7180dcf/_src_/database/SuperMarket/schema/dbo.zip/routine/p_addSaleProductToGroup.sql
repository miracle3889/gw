/*----------------添加商品到组合中-----------------*/
CREATE procedure p_addSaleProductToGroup  @groupId int,@productString varchar(500),@memberId int
as
  declare @identityCode int 
  insert into tb_groupCheckIdentityCode(addDate) values (getDate())
  set @identityCode= scope_identity()

declare @charId int
while(len(@productString)>4)
begin
	set  @charId= charindex('^',@productString)
	declare @tmp1 varchar(50) --截出以逗号分割的部分
	declare @a varchar(50)--saleId
	declare @b varchar(50)--colorId
	declare @c varchar(50)--MetricsId
            declare @d varchar(50)--buyCount
	if(@charId=0)
	begin
		set @tmp1= @productString
		set @productString=''
	end
	else
	begin	
		set @tmp1= subString(@productString,1, @charId-1)
		set @productString=subString(@productString, @charId+1, len(@productString)-@charId+1)
	end
	
		declare @i int 
		declare @mydesvalue varchar(50) 
		set @i=1

		while(len(@tmp1)>0)
		begin
			declare  @index int
			set @index= charindex(',',@tmp1)
			if(@index=0)
			begin
				set @mydesvalue=@tmp1
				set @tmp1=''
			end
			else
			begin
				set @mydesvalue=subString(@tmp1,1, @index-1)
				set @tmp1=subString(@tmp1, @index+1, len(@tmp1)-@index+1)
			end
			 if(@i=1)
			begin
				set @a=@mydesvalue
			end
			 if(@i=2)
			begin
				set @b=@mydesvalue
			end
			 if(@i=3)
			begin
				set @c=@mydesvalue
			end
			 if(@i=4)
			begin
				set @d=@mydesvalue
				
			end
		            set @i=@i+1
		end 
		insert into tb_tmpGroupProductCheck(saleId,colorId,MetricsId,buyCount,code) values(@a,@b,@c,@d,@identityCode)
end



declare @returnValue int
declare @requireCount int
declare @userselectCount int
declare @saleType int 
select @requireCount=requireCount,@saleType=saleType from tb_saleGroup where id=@groupId
if(@saleType=1)
begin
	if EXISTS(select 1 from tb_saleProduct where groupId=@groupId and id not in(select saleId from tb_tmpGroupProductCheck where code=@identityCode ))
	begin
		set @returnValue=-1--所选数量不一
		select @returnValue
		return
	end
end

select  @userselectCount=sum(buyCount) from tb_tmpGroupProductCheck where code=@identityCode

if(@requireCount!=@userselectCount)
	begin
		set @returnValue=-1--所选数量不一
	end
else
	begin
		declare @saleId int ,@colorId int ,@MetricsId int ,@buyCount int ,@iscanBuy int
		set @iscanBuy=1
		declare authors_cursor cursor for
	            select  saleId,colorId,MetricsId,buyCount  from tb_tmpGroupProductCheck where code=@identityCode
		open authors_cursor
		fetch next from  authors_cursor 
		into @saleId,@colorId,@MetricsId,@buyCount
		
		while @@FETCH_STATUS = 0
		begin
			declare  @productId int
			select  @productId=productId from  tb_saleProduct where  id=@saleId
			declare @realCount int,@DDlCount int
			select @realCount=SUM(productCount) from ERP.dbo.tb_productStock 
				 where  productId=@productId AND colorId=@colorId AND metricsId=@metricsId   
			select  @DDlCount=SUM(a.buyCount) FROM v_allBuyProductNew a 
			inner  JOIN tb_saleProduct b ON a.saleProductId=b.id 
			where b.productId=@productId AND a.colorId=@colorId AND a.metricsId=  @metricsId   
			 if(@realCount IS NULL)
				 begin
					set @realCount=0
				 end
			  if(@DDlCount IS NULL)
			                begin 
					set @DDlCount=0
			                 end
			  if(@realCount-@DDlCount<@buyCount)
			  begin
				set  @iscanBuy=0 
			  end
			fetch next from  authors_cursor 
			into @saleId,@colorId,@MetricsId,@buyCount
		end
		close authors_cursor
		deallocate authors_cursor
		
		if(@iscanBuy=0)
			begin
				set @returnValue=0--库存不够
			end
		else
			begin
				
				insert into tb_groupPh(groupId,memberId) values(@groupId,@memberId)
				declare @groupph int
				set @groupph=scope_identity()
				 
				INSERT INTO tb_shoppingBag(productCode,buyCount,saleProductId,colorId,metricsId,memberId,isRand,groupph) 
				select b.saleCode,a.buyCount,a.saleId,a.colorId,a.metricsId,@memberId,0,@groupph from 
				tb_tmpGroupProductCheck a inner join tb_saleProduct b on a.saleId=b.id and a.code=@identityCode
				
				
				set @returnValue=1 
			end
	end
	delete from tb_tmpGroupProductCheck where code=@identityCode
	select @returnValue