/*-------------------储值卡用户-------------------------*/
CREATE PROCEDURE p_web_addMemberCardAccount @EMail VARCHAR(200),@psw VARCHAR(50),
	@cardId INT,@name VARCHAR(50),@phoneNum VARCHAR(50),@mobileNum VARCHAR(50),
	@complanyAddr VARCHAR(200),@homeAddr VARCHAR(200),@post VARCHAR(50),@ip VARCHAR(50),
	@QQ VARCHAR(16),@MSN VARCHAR(50),@nickname VARCHAR(32),@source VARCHAR(16),@remark VARCHAR(50),@provinceId int,@cityId int,@homeAddrRegional int 
AS
	DECLARE @COUNT INT
	DECLARE @returnValue INT
	DECLARE @cardCode varchar(10)
	SET @returnValue=0
	SELECT @COUNT=COUNT(*) FROM dbo.tb_member WHERE EMail=@EMail
	IF(@COUNT>0)
	BEGIN
		SET @returnValue=-1
	END
	ELSE
	BEGIN
		SELECT @COUNT=COUNT(*) FROM dbo.tb_member WHERE source=@source and remark=@remark and mobileNum=@mobileNum 
		IF(@COUNT>0)
		BEGIN
			SET @returnValue=-2
		END
		ELSE
		BEGIN
			SELECT @COUNT=COUNT(*) FROM dbo.tb_cardCodeAccount WHERE id=@cardId and isCheck=1
			IF(@COUNT>0)
			BEGIN
				SET @returnValue=-2
			END
			ELSE
			BEGIN
				SELECT @COUNT=COUNT(*) FROM dbo.tb_member WHERE nickname=@nickname 
				IF(@COUNT>0)
				BEGIN
					SET @nickname=@nickname+'1'
				END
				
				INSERT INTO dbo.tb_member(EMail,psw,type,checkCode,name,phoneNum,mobileNum,complanyAddr,homeAddr,post,regIp,QQ,MSN,nickname,remark,provinceId,cityId,homeAddrRegional,complanyAddrRegional)
				VALUES (@EMail,dbo.md5(@psw),1,dbo.md5(CAST(rand()*10000 AS INT)),@name,@phoneNum,@mobileNum,@complanyAddr,@homeAddr,@post,@ip,@QQ,@MSN,@nickname,@remark,@provinceId,@cityId,@homeAddrRegional,@homeAddrRegional)
				SET @returnValue=scope_identity()
				IF(@@ERROR<>0)
				BEGIN	
					SET @returnValue=0
					rollback tran 
				END
				
				select @cardCode=cardCode from tb_cardCodeAccount where id=@cardId
				exec p_addAccountOpLog @returnValue,2000,999,'充值卡'
				exec p_addScoreOpLog @returnValue,100,99,'充值卡注册送100分'
				exec p_addMemberCard @returnValue,@cardCode,2,1
				
				update tb_cardCodeAccount set isCheck=1,checkTime=getDate(),checkMember=@returnValue where  id=@cardId
				update tb_member set nickname=@cardCode where id=@returnValue
			END
		END
	END
	SELECT @returnValue