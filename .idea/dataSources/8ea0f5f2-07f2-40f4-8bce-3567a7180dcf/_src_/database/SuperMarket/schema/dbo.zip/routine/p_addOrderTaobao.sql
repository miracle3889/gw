
/*----------------添加定单--------*/
CREATE        PROCEDURE p_addOrderTaobao       @reMark VARCHAR(200),
						@receviceMan VARCHAR(50), 
						@receviceAddr1 VARCHAR(200), 
						@receviceMobile VARCHAR(50),  
						@doMan int
AS
	DECLARE @code VARCHAR(50)
	DECLARE @returnId int

	SET @returnId=0

	BEGIN TRAN 
		EXEC p_geOrderCodeNew 1,@code OUTPUT --得到订单号
				
		/*---------------------生成定单信息----------------------------------*/
		INSERT INTO dbo.tb_order(orderCode,payType,deliverType,deliverPrice,memberId,orderStatus,
							   doMan,reMark,orderSource,magazineCodeS,receviceMan,post,
							receviceAddr1,receviceAddr2,receviceMobile,addrId,useAccount,
						getScore,regionalId1,regionalId2,provinceId ,cityId,useGift,magSource,magSourceRemark,buyCountOrder,freeType)
				VALUES(@code,1,1,0,73650,1, @doMan,@reMark,0,'@',@receviceMan,'',
				@receviceAddr1,'',@receviceMobile,1,0,
				0,0,0,4 ,26,0, 0,'',999999,0)
	
				SET @returnId=SCOPE_IDENTITY() --得到刚刚插入的定单id 
		
				
		COMMIT TRAN 			
	

	SELECT @returnId

