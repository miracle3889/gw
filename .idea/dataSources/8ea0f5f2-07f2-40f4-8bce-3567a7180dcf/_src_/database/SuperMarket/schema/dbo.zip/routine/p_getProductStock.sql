/*--------------------------得到可用的商品库存----------------------------------------------------------------------------------------*/
CREATE PROCEDURE p_getProductStock 	@productId int, @colorId int, @metricsId int
AS	
	declare @realCount int
	declare @DDlCount int
	declare @return int
	set @return=0

	SELECT @realCount=SUM(productCount) FROM ERP.dbo.tb_productStock WITH(TABLOCKX)  
 	WHERE productId=@productId AND colorId=@colorId AND metricsId=@metricsId

	SELECT @DDlCount=SUM(buyCount) FROM v_allBuyProduct a WITH(TABLOCKX) 
	inner join tb_saleProduct b on b.id=a.saleProductId 
  	WHERE b.productId=@productId AND a.colorId=@colorId AND a.metricsId=@metricsId   
  	IF(@DDlCount IS NULL)
             BEGIN 
	     SET @DDlCount=0
             END
	set @return=@realCount-@DDlCount
select @return