create procedure p_addAssSaleProduct @mainSaleId int,@assSaleId int
as 

   if not exists(select 1 from tb_assSale where mainSaleId=@mainSaleId)
     begin
	insert into tb_assSale(mainSaleId,assSaleId) values(@mainSaleId,@assSaleId)
     end
