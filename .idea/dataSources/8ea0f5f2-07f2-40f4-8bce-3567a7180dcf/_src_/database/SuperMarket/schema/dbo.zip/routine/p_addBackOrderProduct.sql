/*-----------------------------------------------------退货单退回商品----------------------------------------------------------------*/
CREATE PROCEDURE p_addBackOrderProduct @backOrderId int, @orderSaleId int, @backCount int 

AS
	begin tran 

	insert into tb_backProduct(backId,orderSaleId,saleId,colorId,metricsId,backCount,type) 
	select @backOrderId,@orderSaleId,saleProductId,colorId,metricsId,@backCount,1 
	from tb_orderSaleProduct where id=@OrderSaleId  
	
	update tb_backOder set BackPrice=BackPrice+b.payValue*c.backCount 
	from tb_orderSaleProduct a 
	inner join tb_orderSaleProductPay b on b.orderSaleProductId=a.id and b.payType=1 
	inner join tb_backProduct c on c.orderSaleId=a.id 
	where tb_backOder.id=@backOrderID and a.id=@orderSaleId

	commit tran