CREATE   procedure p_sendBrMsg
as 
	declare @memberid int
	declare  @EMail varchar(200)
	declare @mobileNum varchar(50)
	declare @name varchar(50)
	declare @neekname varchar(50)
	DECLARE authors_cursor CURSOR FOR
	select id,EMail,mobileNum,name, nickname from  tb_member 
	where DATEPART(month, GETDATE())=DATEPART(month,birth) and DATEPART(day, GETDATE())=DATEPART(day,birth)  and isSendBirth=0 and  mobileNum not in(select mobileNum from tb_blackNum)
	and DATEPART(year,birth)>1900
	OPEN authors_cursor
	FETCH NEXT FROM authors_cursor 
	INTO @memberid,@EMail,@mobileNum,@name,@neekname
	WHILE @@FETCH_STATUS = 0
	BEGIN
		declare @content nvarchar(500)
		if(@name is null)
			set @name=''
		set @content='尊敬的用户'+@name+'，优邮网祝你生日快乐！20元生日礼券已送到你的注册邮箱'+@EMail+'。' 
		 if(@mobileNum is not null )
			 begin
				if(len(@mobileNum)>=11 )
					begin
						exec p_sendGiftCard20  @memberid,0
						  exec p_sendMsg @mobileNum,@content
						  update tb_member set isSendBirth=1 where mobileNum=@mobileNum
						 declare @sendUrl varchar(500)
						declare @title varchar(200)
						if(@name is null or @name ='')
						begin
							if(@neekname is null or @neekname ='')
							set @neekname=''
							else
							set @neekname=@neekname+'，'
						end
						else
						set @neekname=@name+'，'
						set @title=@neekname+'生日快乐，开信有惊喜哦'
						 set @sendUrl=('http://www.yoyo18.com/web/emailHappyBirth.yoyo?memberId='+cast(@memberid as varchar(50)))
 						if(@EMail is not null)
						begin
						   exec p_sendEmail @sendUrl,@EMail,@title
						end
			                end
	                 end
		FETCH NEXT FROM authors_cursor 
		INTO @memberid,@EMail,@mobileNum,@name,@neekname
	END
	
	CLOSE authors_cursor
	DEALLOCATE authors_cursor