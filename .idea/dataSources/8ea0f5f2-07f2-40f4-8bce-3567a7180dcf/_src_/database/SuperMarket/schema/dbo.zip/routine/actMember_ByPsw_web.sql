
/*-------------------激活卡号网站----------------------------------*/
CREATE  PROCEDURE  actMember_ByPsw_web @cardPsw VARCHAR(50),@cardCode VARCHAR(50),@memberId INT
AS
	DECLARE @returnValue INT
	SET @returnValue=0
	BEGIN TRAN 
			DECLARE @giftId INT 
			DECLARE @type INT 
			DECLARE @giftCountLimit INT
			DECLARE @memberGift int

		SELECT TOP 1 @giftId=id FROM dbo.tb_giftCard WHERE cardCode=@cardCode AND psw=dbo.md5(@cardPsw)  AND  isAct=0
						
			IF(@giftId IS NULL OR @giftId<=0)
			BEGIN
				SET @returnValue=0
			END
			ELSE
			BEGIN
				INSERT INTO dbo.tb_memberGift(giftId,memberId) VALUES(@giftId,@memberId)
				UPDATE dbo.tb_giftCard SET isAct=1,actTime=GETDATE(),
				useLastTime=DATEADD(day,30,GETDATE()) WHERE id=@giftId 
				SET @returnValue=1
			END
			
		
	IF(@@ERROR<>0)
	BEGIN
		ROLLBACK TRAN 
	END
	COMMIT TRAN 
	SELECT @returnValue