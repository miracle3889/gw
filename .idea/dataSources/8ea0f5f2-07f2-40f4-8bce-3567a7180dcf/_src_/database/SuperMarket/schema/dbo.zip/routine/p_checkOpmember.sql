



create    procedure p_checkOpmember
as 
	declare @userrid int
	declare @opcont int
	declare @userName  varchar(200)
	declare @content  varchar(2000)
	DECLARE authors_cursor CURSOR FOR
	
	select userId,b.name, count(*)  from erp.dbo.tb_OperationHis a
	inner join erp.dbo.tb_user b on a.userId=b.id 
	 where
	 myUrl=  '/web/searchMember.action' and DATEDIFF ( day ,getDate() ,addDate ) =0
	group by userId,b.name having count(*)>10
	
	OPEN authors_cursor
	FETCH NEXT FROM authors_cursor 
	INTO @userrid,@userName,@opcont
	WHILE @@FETCH_STATUS = 0
	BEGIN
		set @content='帐号'+@userName+'今天操作'+cast(@opcont as varchar(10))+'次 帐号id是:'+cast(@userrid as varchar(10))
		exec  p_sendMsgByClass '13773490003',@content ,100,0
		FETCH NEXT FROM authors_cursor 
		INTO @userrid,@userName,@opcont
	END
	
	CLOSE authors_cursor
	DEALLOCATE authors_cursor
