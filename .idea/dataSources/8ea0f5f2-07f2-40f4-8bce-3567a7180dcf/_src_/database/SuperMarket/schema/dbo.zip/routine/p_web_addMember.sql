/*-------------------添加注册会员-------------------------*/
CREATE PROCEDURE p_web_addMember @EMail VARCHAR(200),@psw VARCHAR(50),@recommendId INT,@name VARCHAR(50),@mobileNum VARCHAR(50),@homeAddr VARCHAR(200),@post VARCHAR(50),@ip VARCHAR(50),@QQ VARCHAR(16),@MSN VARCHAR(50),@nickname VARCHAR(32),@source VARCHAR(16),@remark VARCHAR(50),@comeFrom VARCHAR(32),@provinceId int,@cityId int,@homeAddrRegional int,@zheShang varchar(200)    
AS
	DECLARE @COUNT INT
	DECLARE @REGCOUNT INT
	DECLARE @returnValue INT
	SET @returnValue=0
	set @REGCOUNT=0
	SELECT @COUNT=COUNT(*) FROM dbo.tb_member WHERE EMail=@EMail and EMail!=''
	IF(@COUNT>0)
	BEGIN
		SET @returnValue=-1
	END
	ELSE
	BEGIN
		SELECT @COUNT=COUNT(*) FROM dbo.tb_member WHERE nickname=@nickname and nickname is not null and nickname !='' 
		IF(@COUNT>0)
		BEGIN	
			SET @returnValue=-2
		END
		ELSE
		BEGIN
			INSERT INTO dbo.tb_member(EMail,psw,type,checkCode,recommendId,name,mobileNum,homeAddr,post,regIp,QQ,MSN,nickname,source,remark,comeFrom,provinceId,cityId,homeAddrRegional,complanyAddrRegional,zheShang)
			VALUES (@EMail,dbo.md5(@psw),1,dbo.md5(CAST(rand()*10000 AS INT)),@recommendId,@name,@mobileNum,@homeAddr,@post,@ip,@QQ,@MSN,@nickname,@source,@remark,@comeFrom,@provinceId,@cityId,@homeAddrRegional,@homeAddrRegional,@zheShang)
			SET @returnValue=scope_identity()
			if (@returnValue>0)
			begin
				exec p_addScoreOpLog @returnValue, 100, 55, '注册送积分'
			end
			if(@name!='')
			begin
				IF NOT EXISTS(SELECT * FROM  dbo.tb_memberMagazine WHERE memberId=@returnValue)
				BEGIN
					INSERT INTO  dbo.tb_memberMagazine(magazineId,memberId,doMan) VALUES(1,@returnValue,-1)
				END
			end
			if(@recommendId!=0)
			begin
				select @REGCOUNT=count(*) from tb_member where recommendId=@recommendId and regIp=@ip 
				if (@REGCOUNT<3)
				begin
					exec p_addScoreOpLog @recommendId,20,2,'推荐好友'
				end
			end
			
			IF(@@ERROR<>0)
			BEGIN	
				SET @returnValue=0
			END
		END	
	END
	
	SELECT @returnValue