CREATE procedure [dbo].[p_addTaobaoNickDeliver] @nickName varchar(50),@deliverManId int
as 
	
	if not exists (select 1 from tb_taobaoNickDeliver where nickName=@nickName)
	begin
		insert into tb_taobaoNickDeliver(nickName,deliverManId) values(@nickName,@deliverManId)
		declare @deliverRemark varchar(50)
		if(@deliverManId=1)
			set @deliverRemark='申通'
		if(@deliverManId=2)
			set @deliverRemark='圆通'
		if(@deliverManId=3)
			set @deliverRemark='EMS'
			
		update tb_order set remark=remark+'务必'+@deliverRemark where orderstatus=1 and isdelete<>1 
		and memberId in(select memberId from tb_taobaoMember where taobaoNickName=@nickName)
	end
	else
	begin
		update tb_taobaoNickDeliver set deliverManId=@deliverManId where nickName=@nickName
	end

