
/*---------------修改资讯标题------------------------------------------------*/
CREATE  PROCEDURE info_updateInfo @id int,@title varchar(128), @dir1Id int, @dir2Id int, @keywords varchar(32), 
				@editorName varchar(32), @provenance varchar(32), @recommentTypeId int, 
				@smallImg varchar(128),
				@product1 varchar(12),@product2 varchar(12),@product3 varchar(12)
AS
	declare @returnValue int
	set @returnValue=0
	BEGIN TRAN 
		if (@id != 0)
		begin
			update info_title set title=@title, dir1Id=@dir1Id, dir2Id=@dir2Id, keywords=@keywords, editorName=@editorName, provenance=@provenance, recommentTypeId=@recommentTypeId, smallImg=@smallImg where id=@id 
			if (@@error<>0)
			begin
				rollback tran
			end
			if (@recommentTypeId!=0)
			begin
				update info_title set recommentDate=getdate() where id=@id
				if (@@error<>0)
				begin
					rollback tran
				end
			end
			if (@product1 is not null or @product2 is not null or @product3 is not null)
			begin
				delete info_saleCode where titleId=@id
				if (@@error<>0)
				begin
					rollback tran
				end
			end
			if (@product1!='')
			begin
				insert into info_saleCode (saleCode,titleId) values (@product1,@id)
				if (@@error<>0)
				begin
					rollback tran
				end
			end
			if (@product2!='')
			begin
				insert into info_saleCode (saleCode,titleId) values (@product2,@id)
				if (@@error<>0)
				begin
					rollback tran
				end
			end
			if (@product3!='')
			begin
				insert into info_saleCode (saleCode,titleId) values (@product3,@id)
				if (@@error<>0)
				begin
					rollback tran
				end
			end
		end
	commit tran
	if (@@error=0)
	begin
		set @returnValue=1
	end
	
	select @returnValue