/*-----------------添加商品到购物车------------------------------------------*/
CREATE   PROCEDURE p_addShoppingBagWithNeedIn @saleCode VARCHAR(20),@buyCount INT,
				  @saleProductId INT,@colorId INT,
                                  @metricsId INT,@memberId INT,@addType INT
AS
     DECLARE @returnValue INT
     DECLARE @colorCode VARCHAR(2)
     DECLARE @metricsCode VARCHAR(2)
     SET @returnValue=0   
	     DECLARE @productId INT
                   DECLARE @realCount INT 
                   DECLARE @DDlCount INT 
	     DECLARE @isRand INT
	     DECLARE @saleType INT
                  DECLARE @Count1 INT 
                  DECLARE @Count2 INT 

	     SET @isRand=0
	     SELECT @productId=productId,@saleType=saleTypeId FROM tb_saleProduct WHERE id=@saleProductId
	     if(@saleType=23)
	     begin
		       select  @Count1=count(*)  from tb_shoppingBag where saleProductId in(  select mainSaleId from tb_assSale where assSaleId = @saleProductId) and memberId=@memberId --主商品数量
		          select  @Count2=count(*)  from tb_shoppingBag where saleProductId in( select  assSaleId from  tb_assSale where  mainSaleId in( select mainSaleId from tb_assSale where assSaleId = @saleProductId)) and memberId=@memberId --主商品数量
			if(@buyCount>(@Count1-@Count2))
				begin
					select 0
					return 
				end
	     end

	     IF(@colorId=0)
	     BEGIN
	             IF EXISTS (SELECT *
	             FROM dbo.sysobjects
	             WHERE id = object_id(N'.[dbo].[tb_randColor]') AND 
	                  OBJECTPROPERTY(id, N'IsUserTable') = 1) 
		DROP TABLE dbo.tb_randColor 
	
		  SELECT TOP 1 SUM(productCount) AS myCount, colorId
		  INTO dbo.tb_randColor
		  FROM ERP.dbo.tb_productStock
		  WHERE (productId = @productId)
		  GROUP BY colorId
		  ORDER BY myCount DESC
		  SELECT TOP 1 @colorId=colorId FROM tb_randColor 
  		  SET @isRand=1
	     END
         
	     IF(@addType=0)
	  	BEGIN
			DECLARE @saleCodeC VARCHAR(20)
			set @saleCodeC=@saleCode --存储 saleCode

		 	SELECT @realCount=productCount,@saleCode=productShelfCode FROM ERP.dbo.tb_productStock   WHERE productId=@productId AND colorId=@colorId AND metricsId=@metricsId   
			SELECT @DDlCount=SUM(a.buyCount) FROM v_allBuyProductNew a     WHERE a.saleProductId=@productId AND a.colorId=@colorId AND a.metricsId=  @metricsId   
		   	if (@saleCode is null) set @saleCode=@saleCodeC --存储 saleCode 如果商品号 is null 
			IF(@realCount IS NULL) SET @realCount=0 
		    	IF(@DDlCount IS NULL) SET @DDlCount=0
	
			     if(@saleType=23) set @saleCode=@saleCodeC 
		    	IF(@realCount-@DDlCount>=@buyCount)
	                 	BEGIN           
				     INSERT INTO tb_shoppingBag(productCode,buyCount,saleProductId,colorId,metricsId,memberId,isRand,isStock,isNeedIn) 
					VALUES(@saleCode,@buyCount,@saleProductId,@colorId,@metricsId,@memberId,@isRand,1,0)
			   	     SET @returnValue=1
	               		END
		END
	    ELSE
		BEGIN
			 INSERT INTO tb_shoppingBag(productCode,buyCount,saleProductId,colorId,metricsId,memberId,isRand,isStock,isNeedIn) 
					VALUES(@saleCode,@buyCount,@saleProductId,@colorId,@metricsId,@memberId,@isRand,1,1)
			  SET @returnValue=1
		END

    SELECT @returnValue