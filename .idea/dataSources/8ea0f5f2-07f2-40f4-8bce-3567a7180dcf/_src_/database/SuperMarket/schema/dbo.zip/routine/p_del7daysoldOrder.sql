CREATE procedure p_del7daysoldOrder
	as 
	insert into tb_tempDel7daysOrder(orderId)
        select id from tb_order where id in(
	select orderId from erp..tb_notCanDistributeProduct)
	and payType=1  and orderstatus=1 and doMan>0
	and createTime<=dateadd(day,-10,getDate())
	and isdelete<>1 and useAccount=0

	update tb_order set isdelete=1 ,delcause='超过十日订单删除' where id in(select orderId from tb_tempDel7daysOrder)


	update  tb_memberGift set isUse=0 where useOder in(select orderId from tb_tempDel7daysOrder)


	update  tb_GiftCard set isUse=0 where useOder  in(select orderId from tb_tempDel7daysOrder)

	delete from tb_tempDel7daysOrder