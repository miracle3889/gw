/*--------------------得到会员卡编号---------------------------------*/
CREATE  PROCEDURE  p_geCardTypeCode  @cardType int,@code VARCHAR(50) OUTPUT
AS
	EXEC ERP.dbo.p_getNowDate @code OUTPUT
	begin tran 
		DECLARE @temp INT
		SELECT  @temp=MAX(intCode) FROM tb_cardTypeCode WITH(HOLDLOCK)   WHERE cardType=@cardType
		
		IF( @temp=0 OR  @temp IS NULL)
		BEGIN
			SET @temp=1
		END
		ELSE
		BEGIN
			SET @temp=@temp+1
		END
		
		DECLARE @CharTemp VARCHAR(10)
		DECLARE @pre VARCHAR(10)
		SET @CharTemp=CAST(@temp AS VARCHAR(10))
		
		WHILE(LEN(@CharTemp)<3)
		BEGIN
			SET @CharTemp='0'+@CharTemp
		END
		select @pre=pre from tb_cardType where cardType=@cardType
		SET @code=@pre+@code+@CharTemp
		
		INSERT INTO tb_cardTypeCode (intCode,cardType) VALUES(@temp,@cardType)
	commit tran
