
/*------------------------------------------------------回滚定单------------------------------------------------------------------------------------*/
CREATE  PROCEDURE p_rollBackOrderNew @orderId INT
AS
	DECLARE @returnValue INT
	DECLARE @memberId INT
	SELECT @memberId=memberId FROM dbo.tb_order WHERE id=@orderId
	SET @returnValue=0
	BEGIN TRAN 
		INSERT INTO dbo.tb_shoppingBag(productCode,saleProductId,colorId,metricsId,buyCount,memberId,type)
		SELECT saleProductCode,saleProductId,colorId,metricsId,buyCount,@memberId,1 FROM dbo.tb_orderSaleProduct WHERE orderId=@orderId
        	DECLARE @account INT
        	SELECT @account=useAccount FROM dbo.tb_order WHERE id=@orderId
	IF(@account IS NOT NULL)
	BEGIN
	UPDATE dbo.tb_member SET account=account+@account WHERE id=@memberId
	END
	UPDATE dbo.tb_order SET  isUpdate=1,isDelete=1  WHERE id=@orderId
	SET @returnValue=1
	COMMIT TRAN
        SELECT @returnValue