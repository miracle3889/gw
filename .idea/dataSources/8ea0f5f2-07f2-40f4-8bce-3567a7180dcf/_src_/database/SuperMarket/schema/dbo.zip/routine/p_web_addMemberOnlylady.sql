/*-------------------onlylady添加注册会员 送10元礼券-------------------------*/
CREATE PROCEDURE p_web_addMemberOnlylady @EMail VARCHAR(200),@psw VARCHAR(50),@recommendId INT,@name VARCHAR(50),@mobileNum VARCHAR(50),@homeAddr VARCHAR(200),@post VARCHAR(50),@ip VARCHAR(50),@QQ VARCHAR(16),@MSN VARCHAR(50),@nickname VARCHAR(32),@source VARCHAR(16),@remark VARCHAR(50),@comeFrom VARCHAR(32),@provinceId int,@cityId int,@homeAddrRegional int    
AS
	DECLARE @COUNT INT
	DECLARE @returnValue INT
	SET @returnValue=0
	SELECT @COUNT=COUNT(*) FROM dbo.tb_member WHERE EMail=@EMail
	IF(@COUNT>0)
	BEGIN
		SET @returnValue=-1
	END
	ELSE
	BEGIN
		SELECT @COUNT=COUNT(*) FROM dbo.tb_member WHERE nickname=@nickname 
		IF(@COUNT>0)
		BEGIN
			SET @returnValue=-2
		END
		ELSE
		BEGIN
			INSERT INTO dbo.tb_member(EMail,psw,type,checkCode,recommendId,name,mobileNum,homeAddr,post,regIp,QQ,MSN,nickname,source,remark,score,comeFrom,provinceId,cityId,homeAddrRegional,complanyAddrRegional)
			VALUES (@EMail,dbo.md5(@psw),1,dbo.md5(CAST(rand()*10000 AS INT)),@recommendId,@name,@mobileNum,@homeAddr,@post,@ip,@QQ,@MSN,@nickname,@source,@remark,100,@comeFrom,@provinceId,@cityId,@homeAddrRegional,@homeAddrRegional)
			SET @returnValue=scope_identity()
			
			if(@name!='')
			begin
				 IF NOT EXISTS(SELECT * FROM  dbo.tb_memberMagazine WHERE memberId=@returnValue)
				BEGIN
					INSERT INTO  dbo.tb_memberMagazine(magazineId,memberId,doMan) VALUES(1,@returnValue,-1)
				END
			end
			/*if(@recommendId!=0)
			begin
				exec p_addScoreOpLog @recommendId,20,2,''
			end*/
			IF(@@ERROR<>0)
			BEGIN	
				SET @returnValue=0
			END
			else
			begin
				exec p_sendGiftCard @returnValue,99
			end
		END	
	END
	
	SELECT @returnValue