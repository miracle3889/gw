
create procedure updateNeiGouStatus @orderId int
as 

	update SuperMarket..tb_neigouOrder  set status =1 where orderId=@orderId