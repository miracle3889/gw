CREATE     PROCEDURE  p_computeCanRegistProduct 
AS
	DECLARE @id INT
	DECLARE @productId INT
	DECLARE @colorId INT
	DECLARE @metricsId INT
	DECLARE @needCount INT
	DECLARE @totalCount INT
	DECLARE @orderCount INT
	DECLARE @shoppingBagCount INT
	DECLARE @registCount INT	
	DECLARE @memberId INT		
	
	delete from tb_tempInOrderCount
	insert into tb_tempInOrderCount(productid,colorId,metricsId,productCount)
	select saleProductId,colorId,metricsId,sum(buyCount) from dbo.v_allBuyProductNew  group by saleProductId,colorId,metricsId

	delete from tb_tempproductCount
	
	insert into tb_tempproductCount select productid,colorId,metricsId,sum(productCount) from erp..tb_productStock group by productid,colorId,metricsId
	
	UPDATE  dbo.tb_registProduct SET isQh=1 

	update dbo.tb_registProduct set isQh=2 where memberId in(

	select memberId from (
	select memberId,a.colorId,a.metricsId,sum(a.needCount) as needCount from  dbo.tb_registProduct a
	inner join tb_saleProduct b on a.saleId=b.id and a.isdeleted=0 and  b.isdeleted=0 group by memberId,a.colorId,a.metricsId) as a
	inner join erp..tb_productStock b on a.colorId=b.colorId and a.metricsId=b.metricsId and a.needCount<=b.productCount 
and memberId not in(
select memberId from (
	select memberId,a.colorId,a.metricsId,sum(a.needCount) as needCount from  dbo.tb_registProduct a
	inner join tb_saleProduct b on a.saleId=b.id and a.isdeleted=0 and  b.isdeleted=0 group by memberId,a.colorId,a.metricsId) as a
	inner join erp..tb_productStock b on a.colorId=b.colorId and a.metricsId=b.metricsId and a.needCount>b.productCount )
	)

	delete from tb_temp_hasOrderMember

	insert into tb_temp_hasOrderMember select memberId from tb_order where isdelete<>1 and orderstatus in(1,20,13)
	and memberId in(select distinct  memberId from tb_registProduct where isQh=2)
	 group by memberId
	DECLARE authors_cursor0 CURSOR FOR
	select memberId from tb_temp_hasOrderMember
	OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0 
	INTO @memberId
	WHILE @@FETCH_STATUS = 0
	BEGIN		
		
		UPDATE  dbo.tb_registProduct SET isQh=0 WHERE   isdeleted=0 and saleId in(SELECT ID FROM tb_saleProduct WHERE isdeleted=1) and memberId=@memberId
	
		UPDATE  dbo.tb_registProduct SET isQh=0  from dbo.tb_registProduct a,erp..tb_productStock b 
		where a.colorId=b.colorId and a.metricsId=b.metricsId and b.isUndercarriage=1 and memberId=@memberId
		
		UPDATE  dbo.tb_registProduct SET isQh=0  WHERE  isdeleted=1 and memberId=@memberId

		DECLARE authors_cursor CURSOR FOR
			select id,productId,colorId,metricsId,needCount from  tb_registProduct 
		 WHERE isDeleted=0  and isQH=2 and memberId =@memberId  order by addTime desc
		
		OPEN authors_cursor
		FETCH NEXT FROM authors_cursor 
		INTO @id,@productId,@colorId,@metricsId,@needCount
		
		WHILE @@FETCH_STATUS = 0
		BEGIN		
			SELECT @totalCount=productCount FROM tb_tempproductCount where productId=@productId and colorId=@colorId and metricsId=@metricsId
			
			SELECT @orderCount=SUM(productCount)    FROM tb_tempInOrderCount where  colorId=@colorId AND metricsId=@metricsId
	
		
	
			SELECT @registCount=sum(needCount) FROM tb_registProduct where productId=@productId and colorId=@colorId and metricsId=@metricsId and  isDeleted=0  and isQH=0
			and  memberId not in(select memberId from tb_registProduct where  ( isQh=1 or isQH=2)) and isDeleted=0 --不缺货商品  有缺货的订单不管
			
			if(@registCount is null) 
				set @registCount=0
			if(@orderCount is null) 
				set @orderCount=0
			
			
			if((@totalCount-@orderCount-@registCount-@needCount)>=0)			
				UPDATE  dbo.tb_registProduct SET isQh=0 WHERE id=@id
				
		
			FETCH NEXT FROM authors_cursor 
			INTO @id,@productId,@colorId,@metricsId,@needCount
		END
	
		CLOSE authors_cursor
		DEALLOCATE authors_cursor
		
		if EXISTS (SELECT 1 FROM  tb_registProduct WHERE (isQH=1 or  isQH=2) AND memberId=@memberId) --然有缺货的人全部释放库存
		BEGIN
			UPDATE tb_registProduct  SET  isQh=1  WHERE memberId= @memberId
		END
				
		FETCH NEXT FROM authors_cursor0 
		INTO @memberId
	END
	CLOSE authors_cursor0
		DEALLOCATE authors_cursor0
	

	delete from  tb_temp_notHasOrdermember 
	insert into tb_temp_notHasOrdermember  SELECT distinct memberId from tb_registProduct where memberId not in( select memberId from  tb_temp_hasOrderMember)
	and memberId in(select memberId from tb_registProduct where isQh=2)
	DECLARE authors_cursor0 CURSOR FOR
	select memberId from tb_temp_notHasOrdermember
	OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0 
	INTO @memberId
	WHILE @@FETCH_STATUS = 0
	BEGIN		

		UPDATE  dbo.tb_registProduct SET isQh=0 WHERE   isdeleted=0 and saleId in(SELECT ID FROM tb_saleProduct WHERE ( isdeleted=1 or qhcllbId=1 )) and memberId=@memberId
	
		UPDATE  dbo.tb_registProduct SET isQh=0  from dbo.tb_registProduct a,erp..tb_productStock b 
		where a.colorId=b.colorId and a.metricsId=b.metricsId and b.isUndercarriage=1 and memberId=@memberId
		

		UPDATE  dbo.tb_registProduct SET isQh=0  WHERE  isdeleted=1 and memberId=@memberId

		DECLARE authors_cursor CURSOR FOR
			select id,productId,colorId,metricsId,needCount from  tb_registProduct 
		 WHERE isDeleted=0  and isQH=2 and memberId =@memberId  order by addTime desc
		
		OPEN authors_cursor
		FETCH NEXT FROM authors_cursor 
		INTO @id,@productId,@colorId,@metricsId,@needCount
		
		WHILE @@FETCH_STATUS = 0
		BEGIN		
			SELECT @totalCount=productCount FROM tb_tempproductCount where productId=@productId and colorId=@colorId and metricsId=@metricsId
			
			SELECT @orderCount=SUM(productCount)    FROM tb_tempInOrderCount where  colorId=@colorId AND metricsId=@metricsId
	
	
	
			SELECT @registCount=sum(needCount) FROM tb_registProduct where productId=@productId and colorId=@colorId and metricsId=@metricsId and  isDeleted=0  and isQH=0
			and  memberId not in(select memberId from tb_registProduct where  ( isQh=1 or isQH=2) and isDeleted=0) and isDeleted=0
			
			if(@registCount is null) 
				set @registCount=0
			if(@orderCount is null) 
				set @orderCount=0
			 
			
			
			if((@totalCount-@orderCount-@registCount-@needCount)>0)			
				UPDATE  dbo.tb_registProduct SET isQh=0 WHERE id=@id
	
		
			FETCH NEXT FROM authors_cursor 
			INTO @id,@productId,@colorId,@metricsId,@needCount
		END
	
		CLOSE authors_cursor
		DEALLOCATE authors_cursor
		
		--if EXISTS (SELECT 1 FROM  tb_registProduct WHERE isQH=1 AND memberId=@memberId)
		--BEGIN
		--	UPDATE tb_registProduct  SET  isQh=1  WHERE memberId= @memberId
		--END
				
		FETCH NEXT FROM authors_cursor0 
		INTO @memberId
	END

	CLOSE authors_cursor0
		DEALLOCATE authors_cursor0
	

	UPDATE  dbo.tb_registProduct SET isQh=1  where isQH=2

	/*
	delete from  tb_temp_notHasOrdermember
	
	insert into  tb_temp_notHasOrdermember select  memberId   from tb_registProduct  a
		inner join tb_member b on a.memberId=b.id
		where memberId not in(select memberId from tb_registProduct where isQh=1 and isDeleted=0) and isDeleted=0 
		and memberId in(select memberId from tb_order where isDelete<>1 and payType=1 and deliverManId  not  in(select transportId  from erp..tb_transport ))  
		and memberId not in(select memberId from tb_order where orderstatus in(1,20,13) and isdelete<>1)
		and b.account<=0 and b.callRemark=''
		group by memberId,b.name,b.mobileNum having max(addTime)>=dateAdd(day,-5,getDate())

	declare @orderId int
	declare @code varchar(50)
	--自动下单
	DECLARE authors_cursor CURSOR FOR 
		select memberId from tb_temp_notHasOrdermember
	OPEN authors_cursor
		FETCH NEXT FROM authors_cursor 
		INTO @memberId
	WHILE @@FETCH_STATUS = 0
		BEGIN	
			if EXISTS (select sum(a.needCount*d.payValue) from   tb_registProduct a
			inner join erp..tb_productStock b on a.colorId=b.colorId and a.metricsId=b.metricsId and b.productCount>=a.needCount 
			inner join erp..tb_product c on b.productId=c.id 
			inner join tb_saleProductPay d on d.saleProductId=a.saleId and d.payStyleId=1
			where a.memberId=@memberId  having  sum(a.needCount*d.payValue)>=5000)
			begin
			--select * from tb_registProduct where memberId=@memberId and isdeleted=0 
			EXEC p_geOrderCodeNew 1,@code OUTPUT --得到订单号

			INSERT INTO dbo.tb_order(orderCode,payType,deliverType,deliverPrice,memberId,orderStatus,
							   doMan,reMark,orderSource,magazineCodeS,receviceMan,post,regionalId1,regionalId2,provinceId ,cityId,
							receviceAddr1,receviceAddr2,receviceMobile,addrId,useAccount,
						getScore,useGift,magSource,magSourceRemark,buyCountOrder,freeType)
			
			select  top 1 @code,1,deliverType,deliverPrice,@memberId,1,1,'货到通知系统自动下单',0,'@',receviceMan,post,regionalId1,regionalId2,provinceId ,cityId,
							receviceAddr1,receviceAddr2,receviceMobile,addrId,0,
			0,0,0,'regist',999999,3 from tb_order where memberId=@memberId and isdelete<>1 order by id desc
			
			
			SET   @orderId=SCOPE_IDENTITY() --得到刚刚插入的定单id 
			
			
			INSERT INTO dbo.tb_orderSaleProduct(orderId,colorId,metricsId,saleProductCode,
					saleProductId,buyCount,isRand,stockPrice,productId)
			
			SELECT   @orderId,a.colorId,a.metricsId,b.productShelfCode,saleId,needCount,0,c.stockPriceReal,c.id
			from tb_registProduct a
			inner join erp..tb_productStock b on a.colorId=b.colorId and a.metricsId=b.metricsId and b.productCount>=a.needCount 
			inner join erp..tb_product c on b.productId=c.id where a.memberId=@memberId
			group by a.colorId,a.metricsId,b.productShelfCode,a.saleId,a.needCount,c.stockPriceReal,c.id
			
			insert into dbo.tb_orderSaleProductPay(orderSaleProductId,payType,payValue)
				select a.id,payStyleId,payValue
				from tb_orderSaleProduct a
				inner join dbo.tb_saleProductPay b on b.saleProductId=a.saleProductId
				where a.orderId=@orderId
			
			
			exec p_computeOrderPrice @orderId

			insert into tb_orderstatusHis(orderId,orderstatus,doMan) values(@orderId,1,1)
			
			update tb_registProduct set isdeleted=1 where memberId=@memberId
			end
			FETCH NEXT FROM authors_cursor 
			INTO @memberId
		END
	
		CLOSE authors_cursor
		DEALLOCATE authors_cursor
*/