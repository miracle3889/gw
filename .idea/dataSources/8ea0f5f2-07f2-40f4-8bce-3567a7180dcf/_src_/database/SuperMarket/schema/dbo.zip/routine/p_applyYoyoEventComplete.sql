
CREATE   procedure p_applyYoyoEventComplete @eventDealId int,@eventContent varchar(2000),@dealManId int
as
	begin tran 
		if exists(select 1 from SuperMarket.dbo.tb_yoyoeventDeal where id=@eventDealId and dealStatus=0)
		begin
			update SuperMarket.dbo.tb_yoyoeventDeal set dealStatus=1,replyContent=@eventContent,
			dealManId=@dealManId,dealTime=getDate() where id=@eventDealId
			declare @eventId int
			declare @giveManId int
			declare @oldEventDealId int
			
			select @eventId=eventId  from SuperMarket.dbo.tb_yoyoeventDeal where id=@eventDealId
			
			select @oldEventDealId=min(id) from SuperMarket.dbo.tb_yoyoeventDeal where eventId=@eventId and dealManId=@dealManId	
			
			select @giveManId=giveManId from SuperMarket.dbo.tb_yoyoeventDeal where id=@oldEventDealId

			insert into SuperMarket.dbo.tb_yoyoeventDeal(eventId,giveManId,canDealMan,type) values(@eventId,@dealManId,cast(@giveManId as varchar(10))+',',1)
				
			update SuperMarket.dbo.tb_yoyoevent set currentDealMan=cast(@giveManId as varchar(10))+',' where id=@eventId
		end
	commit tran 

