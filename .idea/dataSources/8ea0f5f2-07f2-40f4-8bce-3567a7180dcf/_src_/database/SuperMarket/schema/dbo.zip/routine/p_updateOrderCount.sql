CREATE PROCEDURE [dbo].[p_updateOrderCount] @orderSaleId INT,@colorId INT,@metrcsId INT,@userId INT
AS
	--如果尺码没有任何变化不修改
	if exists (
		select 1 from  tb_order a 
			inner join tb_orderSaleProduct b on a.id=b.orderId  and b.id=@orderSaleId and a.isDelete=0 and b.packStatus = 1 
			and ISNULL(b.newRefundStatus,'') <> 'SUCCESS' and 
			colorId=@colorId and metricsId=@metrcsId
		)
	begin
		return 
	end
	else
	begin
			---5.27 新增判断订单状态为1才能修改
			if exists (select 1 from  tb_order a 
			inner join tb_orderSaleProduct b on a.id=b.orderId  and b.id=@orderSaleId and a.isDelete=0 and b.packStatus = 1 
			and ISNULL(b.newRefundStatus,'') <> 'SUCCESS')
			begin
				declare @productCount int  
				declare @productShelfCode varchar(50)
				declare @productId int 
				select @productCount=sum(a.quantity),@productShelfCode=MIN(b.productShelfCode) ,@productId=min(productId)
				from erp..tb_taobaoSku a
				inner join erp..tb_productStock b on a.skuCode=b.productShelfCode  
				where colorId=@colorId and metricsId=@metrcsId
				
				--淘宝库存》0 
				if(@productCount is not null and  @productCount>0 )
				begin
				begin tran 
				begin try
				declare @lableId int 
				declare @needDate datetime 
				declare @isYushou int
				set @isYushou = 1 
				
				select top 1 @lableId=id,@needDate = needDate  
				from supermarket..tb_productLable where productId=@productId  order by needDate desc 
				if(@lableId is  null or @lableId=0)
				begin 
				 set @lableId=0 
				 set @isYushou = 0
				 set @needDate=getdate()
				end		
				UPDATE tb_ordersaleProduct set colorId=@colorId , metricsId=@metrcsId ,saleProductCode=@productShelfCode,needDate =
				 @needDate,isYushou=@isYushou 
				where id=@orderSaleId and buyCount<=@productCount
					if(@@ROWCOUNT>0)
					begin
						
					--	--获取最晚的预售标签
					--	declare @lableId int 
					--	select top 1 @lableId=id  from supermarket..tb_productLable where productId=@productId  order by needDate desc 
					--	if(@lableId is not null and @lableId>0)
					--	begin
					--		delete from supermarket..tb_orderSaleLable where orderSaleId=@orderSaleId
					--		insert into supermarket..tb_orderSaleLable(orderSaleId,lableId) values(@orderSaleId,@lableId)
					--	end
						
					insert into supermarket..tb_orderstatusHis(orderId,orderstatus,doMan,remark) 
					select orderId,1,@userId,'修改尺码信息' from   tb_orderSaleProduct  where id=@orderSaleId
						 
					--	insert into supermarket..tb_updateTabaoProductCount(productCode,productCount,remark)
					--	select productShelfCode,a.buyCount,'改码' from tb_ordersaleProduct a
					--	inner join erp..tb_productStock b on a.colorId=b.colorId and a.metricsId=b.metricsId 
					--	and a.id=@orderSaleId 
						
					update supermarket..tb_orderSaleOutOfStock set productShelfCode=@productShelfCode,isCompute=0,assigned=0,createTime=@needDate,
					isYushou =@isYushou,needDate = @needDate
					where orderSaleId=@orderSaleId 
					end
				commit tran 
				end try 
				begin catch 
					 rollback tran 
					  declare @msg varchar(2000)
					 set @msg=error_message()
					 exec  ruhnnsystem.[dbo].[p_sendWeiXinMsg_title] '修改尺码信息出错',@msg,1
				end catch
			end
		end
	end