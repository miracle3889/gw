CREATE view v_productStock
as 
select a.productShelfCode,case when (a.productCount-isnull(b.productCount,0)-isnull(c.buyCount,0) -isnull(u.buyCount,0))  <0 then 0 else
   (a.productCount-isnull(b.productCount,0)-isnull(c.buyCount,0) -isnull(u.buyCount,0))   end as productCount ,
a.productCount as Tcount,isnull(b.productCount,0) as avgCount,isnull(c.buyCount,0)  as  inOrderCount,isnull(u.buyCount,0) as waitCount,a.colorId,a.metricsId,a.productId
from erp..tb_productStock a
left join 
(
--select productCode,(saleCount-saleCountTaobao)/15 as productCount from supermarket..tb_15DaysSaleReport where addDate>=dateAdd(day,-1,getDate()) 
	select productCode,0 as productCount from supermarket..tb_15DaysSaleReport where addDate>=dateAdd(day,-1,getDate()) 
	and productCode is not null and saleCount/15>0 
) as b on a.productShelfCode=b.productCode 
left join 
(
	SELECT a.productId, sum(a.buyCount) as buyCount, a.colorId , a.metricsId 
	FROM dbo.tb_orderSaleProduct a 
	INNER JOIN   dbo.tb_order b ON b.id = a.orderId
	WHERE-- (
 b.orderStatus IN (1)
  --  or (b.orderStatus in (20,2) and b.id in(
 
--select b.orderId from erp..tb_distribute a
--inner join  erp..tb_Orderdistribute b on a.id=b.distributeId
-- where isTransfer=0

	--)) )  
    AND b.isDelete != 1 and  payType<>1	group by  a.productId, a.colorId , a.metricsId 
	
) as c on  a.productId=c.productId and a.colorId=c.colorId and a.metricsId=c.metricsId

left join  
(
select skuCode as  productSHelfCode,sum(buyCount)  as buyCount from  tb_taobaoWaitBuyerProduct group by skuCode
) as u  on u.productSHelfCode=a.productSHelfCode 

where  a.productShelfCode is not null --and a.productCount-isnull(b.productCount,0)-isnull(buyCount,0) >0













