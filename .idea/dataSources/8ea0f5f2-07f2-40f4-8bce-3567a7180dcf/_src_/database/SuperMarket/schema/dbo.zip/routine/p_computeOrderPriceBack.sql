CREATE    procedure p_computeOrderPriceBack @orderId int
as 
DECLARE @userAccount int  --使用帐户余额
declare @useGift int --使用礼券
declare @deliverPrice int --送货费用
declare @payType int  --付款类型
DECLARE @realPrice INT --实际价格
DECLARE @realPriceGroup INT --实际价格
DECLARE @realPriceReal INT --实际价格
declare @memberId int --会员Id
declare @type int
declare @provinceId int
declare @cityId int 
declare @regionalId1 int
declare @regionalId2 int 
declare @addId int
declare @isUse int
declare @freeType int
declare @doman int

select @isUse=isUse,@payType=payType,@deliverPrice=deliverPrice,@useGift=useGift,@userAccount=useAccount,@memberId=memberId,
@provinceId=provinceId,@cityId=cityId,@regionalId1=regionalId1,@regionalId2=regionalId2,@addId=addrId,@freeType=freeType,@realPrice=productPrice-backPrice,@doman=doman
 from tb_order where id=@orderId 

---检查是否会员
declare @cardClass int
select  top 1 @cardClass=memberClass from tb_memberCard where memberId=@memberId
if(@cardClass is null)
	set @cardClass=0

declare @useGiftXXX int
select @useGiftXXX=sum(b.price) from tb_memberGift a 
inner join tb_giftCard b on a.giftId=b.id
 where a.useOder=@orderId --订单中使用的礼券 

if(@useGiftXXX is null ) set @useGiftXXX=0



declare @maxUseGift INT
SET @maxUseGift=@realPrice/5000*1000 --最多使用礼券金额

if(@cardClass=1 or  @cardClass=2)--如果是优卡用户运费为0
begin
	SET @useGiftXXX=@useGiftXXX+@realPrice/10000*500 --优卡可以使用礼券
	if(@maxUseGift<@useGiftXXX) --如果使用的礼券大于最多使用的 
	BEGIN
		INSERT INTO tb_oldUseGift(orderId,oldUseGift) VALUES(@orderId,@useGift) --记录历史
		UPDATE tb_order SET useGift=@maxUseGift  WHERE id=@orderId  --更新为最多使用的礼券
		SET @useGiftXXX=@maxUseGift --设定使用了的礼券
	END
	ELSE
	BEGIN
		INSERT INTO tb_oldUseGift(orderId,oldUseGift) VALUES(@orderId,@useGift) --记录历史
		UPDATE tb_order SET useGift=@useGiftXXX  WHERE id=@orderId  --更新为最多使用的礼券
	END
end
else
begin
	if(@maxUseGift<@useGiftXXX) 
	BEGIN
		INSERT INTO tb_oldUseGift(orderId,oldUseGift) VALUES(@orderId,@useGift)
		UPDATE tb_order SET useGift=@maxUseGift  WHERE id=@orderId
		SET @useGiftXXX=@maxUseGift
	END
	ELSE
	BEGIN
		INSERT INTO tb_oldUseGift(orderId,oldUseGift) VALUES(@orderId,@useGift) --记录历史
		UPDATE tb_order SET useGift=@useGiftXXX  WHERE id=@orderId  --更新为最多使用的礼券
	END
END





if(@memberId=696936)
	BEGIN
		if exists(select 1 FROM supermarket..tb_can400User where doman=@doman)
		begin
			declare @400Price int
			set @400Price=(@realPrice*20)/100
			set @400Price=(@400Price/100)*100
			update tb_order set useGift=@400Price,useaccount=0  where id=@orderId
		end
	END