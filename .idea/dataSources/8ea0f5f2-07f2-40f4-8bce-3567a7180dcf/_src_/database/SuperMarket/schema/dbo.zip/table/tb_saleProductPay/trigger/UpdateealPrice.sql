CREATE TRIGGER [UpdateealPrice] ON dbo.tb_saleProductPay 
FOR INSERT, UPDATE
AS
	DECLARE @realPrice INT
	DECLARE @saleId INT
	DECLARE @saleType INT
	SELECT @realPrice=payValue,@saleId=saleProductId,@saleType=payStyleId FROM inserted
	IF(@saleType=1)
	BEGIN
		UPDATE tb_saleProduct SET realPrice=@realPrice WHERE id=@saleId
	END
