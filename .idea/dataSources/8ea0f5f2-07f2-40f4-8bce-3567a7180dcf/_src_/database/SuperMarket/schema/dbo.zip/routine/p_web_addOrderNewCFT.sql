/*---------------网上下单---------------------------------------------------------*/
CREATE       PROCEDURE p_web_addOrderNewCFT 
				@memberId INT,
				@payType INT,
				@deliverType INT,
				@deliverPrice INT,
				@reMark VARCHAR(200),
				@receviceMan VARCHAR(50),
				@post VARCHAR(50),
				@receviceAddr VARCHAR(200),
				@receviceMobile VARCHAR(50),
				@recevicePhone VARCHAR(50),
				@addrId INT,@regionalId INT, 
				@useAccount INT,@getScore INT,
				@useGift VARCHAR(200),
				@giftPice INT,
				@provinceId INT,
				@cityId INT,
				@receviceAddr2 VARCHAR(200),
				@regionalId2 INT
AS
	DECLARE @account INT --帐户余额
	DECLARE @returnValue INT  --返回值
	DECLARE @score INT --应扣积分
	DECLARE @giftPrice INT --礼券金额
	DECLARE @shoppingCartI int
	set @shoppingCartI=0

	select @shoppingCartI=sum(buyCount) from tb_shoppingBag where memberId=@memberId
	if (@shoppingCartI>0)
	begin

	SELECT  @account=account FROM dbo.tb_member  WHERE id=@memberId --得到帐户余额
	IF(@useAccount>@account)
	BEGIN
		SET @returnValue=-1  --帐户余额不够
		SELECT @returnValue
		return 
	END
	
	/*---------------------------得到销售商品应扣除的积分----------------*/
	SELECT @score=SUM(a.payValue)
	FROM tb_saleProductPay a
	INNER JOIN tb_payStyle b  ON a.payStyleId=b.id 
  INNER JOIN tb_shoppingBag c ON a.saleProductId=c.saleProductId
	WHERE   c.memberId=@memberId AND b.id=2 and type=1
		
	IF(@score IS NULL)
	BEGIN
			SET  @score=0
	END
	DECLARE  @tempScore INT 
	SELECT  @tempScore=score FROM tb_member WHERE id=@memberId --判断积分
	IF(@tempScore<@score and @score>0)
	BEGIN
			SET @returnValue=-2  --积分不够
			SELECT @returnValue
		  return 
	END
/*----------下单条件满足------------------------*/
  BEGIN TRAN 
			DECLARE  @code VARCHAR(50)
			EXEC p_geOrderCodeNew 2,@code OUTPUT --得到订单号
			
			
			IF(@addrId=0)SET @addrId=1

			/*--------------------------生成定单信息----------------------------------------------*/
			if(@useAccount is null ) set @useAccount=0
			if(@giftPice is null ) set @giftPice=0
			
			declare @buyCount int
			select @buyCount=count(*)+1 from tb_order where memberId=@memberId and isdelete<>1 and orderstatus<>19
			INSERT INTO dbo.tb_order(orderCode,payType,deliverType,deliverPrice,memberId,orderStatus,
						   doMan,reMark,magazineCode,magazineCodeS,receviceMan,post,receviceAddr1,
					               receviceAddr2,receviceMobile,addrId,useAccount,getScore,regionalId1,regionalId2,useGift,orderSource,provinceId ,cityId ,buyCountOrder)
			VALUES(@code,@payType,@deliverType,@deliverPrice,@memberId,5,
				 -2,@reMark,1,'CFT',@receviceMan,@post,@receviceAddr,
			
			@receviceAddr2,@receviceMobile+'|'+@recevicePhone,@addrId,@useAccount,@getScore,@regionalId,@regionalId2,@giftPice,2,@provinceId ,@cityId,@buyCount)

			
			SET @returnValue=SCOPE_IDENTITY() --得到刚刚插入的定单id 
			
			insert into tb_orderstatusHis(orderId,orderstatus,doMan) values(@returnValue,5,-2)


			
			
			DECLARE @sql VARCHAR(500)
			SET @sql='UPDATE tb_memberGift SET isUse=1,useOder='+CAST(@returnValue AS VARCHAR(10))+' WHERE 
			giftId IN('+@useGift+'0)'
			EXEC(@sql)
			SET @sql='UPDATE tb_giftCard SET isUse=1,userTime=getDate(),useOder='
			+CAST(@returnValue AS VARCHAR(10))+' WHERE id IN('+@useGift+'0)'
			EXEC(@sql) --更新礼拳使使用过的礼券过期
			
			/*---------------------------插入定单单件商品-------------------------------------------*/
			

			INSERT INTO dbo.tb_orderSaleProduct(orderId,colorId,metricsId,saleProductCode,
				saleProductId,buyCount,isRand,stockPrice,productId)
			            SELECT @returnValue,colorId,metricsId,productCode,saleProductId,buyCount,isRand,c.stockPriceReal,b.productId
				FROM 	dbo.tb_shoppingBag a 
				inner join tb_saleProduct b on a.saleProductId=b.id
				inner join erp.dbo.tb_product c on b.productId=c.id
				WHERE memberId=@memberId AND type=1 and groupPh=0 and a.buyCount>0 

			/*---------------------------插入定单组合商品-------------------------------------------*/
		
			
	
			INSERT INTO dbo.tb_orderSaleProduct(orderId,colorId,metricsId,saleProductCode,
				saleProductId,buyCount,isRand,groupPh,stockPrice,productId)
			             SELECT @returnValue,colorId,metricsId,productCode,saleProductId,a.buyCount*b.buyCount,isRand,a.groupPh,d.stockPriceReal,c.productId
				FROM 	dbo.tb_shoppingBag a 
				inner join tb_groupPh b on a.groupPh=b.id
				inner join tb_saleProduct c on a.saleProductId=c.id
				inner join erp.dbo.tb_product d on c.productId=d.id
				WHERE a.memberId=@memberId AND type=1 and groupPh!=0


			update tb_groupPh set isBuy=1 where memberId=@memberId --设置组合商品已下单

	                /******************添加单件商品价格到tb_orderSaleProductPay***************************/
			insert into dbo.tb_orderSaleProductPay(orderSaleProductId,payType,payValue)

			select a.id,payStyleId,payValue
			from tb_orderSaleProduct a
			inner join dbo.tb_saleProductPay b on b.saleProductId=a.saleProductId
			where a.orderId=@returnValue			
			
			if(@score>0)
			begin
				declare @getScoreX int
				set @getScoreX=(@score*(-1))
				exec  p_addScoreOpLog @memberId,@getScoreX,5,@code
			end
			
			IF(@useAccount>0)
			BEGIN
				--UPDATE dbo.tb_member SET account=account-@useAccount WHERE id=@memberId --扣除帐户金额
				declare @useAccount2 int
				set @useAccount2=@useAccount*-1
				exec dbo.p_addAccountOpLog @memberId,@useAccount2,1,@code
			END
			
			
			
			DELETE  FROM tb_shoppingBag WHERE memberId=@memberId  --删除购物车中单件商品 
			
			
			exec p_computeOrderPriceCFT @returnValue --核算运费    

			
			COMMIT TRAN 
			
			DECLARE @myName VARCHAR(50)
			SELECT  @myName=name FROM dbo.tb_member WHERE id= @memberId
			IF(@myName IS NULL OR @myName='')
			BEGIN
				UPDATE dbo.tb_member SET  name=@receviceMan,homeAddr=@receviceAddr2,complanyAddr=@receviceAddr,
				homeAddrRegional=@regionalId2,complanyAddrRegional=@regionalId,mobileNum=@receviceMobile,phoneNum=@recevicePhone,payType=@payType,deliverType=@deliverType 
				WHERE  id=@memberId 
			END
			else
			begin
				
				UPDATE tb_member SET payType=@payType,deliverType=@deliverType WHERE id=@memberId --设置用户最后一次的付费方式和送货方式
			end

	end
	else
	begin
		set @returnValue=0
	end
	SELECT @returnValue