
create procedure p_updateTaobaoMember @memberId int,@mamberName varchar(50),@phoneNum  varchar(50),@mobileNum  varchar(50),@homeAddr  varchar(200),@bir  varchar(50),@rateType int,@isRapid int
as 
   update tb_member set name=@mamberName,phoneNum=@phoneNum,mobileNum=@mobileNum,birth=@bir,homeAddr=@homeAddr where id=@memberId
   update tb_taobaoMember set isRapid=@isRapid,rateType=@rateType where memberId=@memberId
