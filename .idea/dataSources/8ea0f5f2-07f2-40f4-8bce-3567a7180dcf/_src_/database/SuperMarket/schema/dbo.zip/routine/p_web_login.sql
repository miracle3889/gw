

/*------------------------登陆-----------------------------*/
CREATE   PROCEDURE [dbo].[p_web_login] @userName VARCHAR(50),@psw VARCHAR(50)
AS
	DECLARE @returnValue INT
	DECLARE @psw2 VARCHAR(50)
	select @returnValue=a.id,@psw2=a.psw from SuperMarket..tb_member a, SuperMarket..tb_taobaoMember b 
		where a.id=b.memberId and b.taobaoNickName=@userName and a.psw=dbo.md5(@psw)
	/*SELECT top 1 @returnValue=id,@psw2= psw   FROM  dbo.tb_member WHERE EMail=@userName and psw=dbo.md5(@psw)
	IF(@returnValue is NULL)
	BEGIN
		SELECT top 1 @returnValue=id,@psw2= psw FROM dbo.tb_member WHERE nickname=@userName and psw=dbo.md5(@psw) 
		IF(@returnValue is NULL)
		BEGIN
			SET @returnValue=0
		END
	END*/
	if(@returnValue is not null)
	begin
		if(@psw2<>dbo.md5(@psw))
		begin
			SET @returnValue=0
		end
	end
	insert into tb_web_loginHis(loginName,psw,returnValue) values(@userName,@psw,@returnValue)
	SELECT @returnValue