

CREATE   VIEW dbo.v_allBuy_noShoppingBag
AS
SELECT c.productId AS saleProductId, a.buyCount AS buyCount, a.colorId AS colorId, 
      a.metricsId AS metricsId
FROM dbo.tb_orderSaleProduct a INNER JOIN
      dbo.tb_order b ON b.id = a.orderId INNER JOIN
      dbo.tb_SaleProduct c ON a.saleProductId = c.id
WHERE b.orderStatus in(1,6,20)  AND b.isDelete != 1
UNION ALL
SELECT c.productId AS saleProductId, buyCount, colorId, metricsId
FROM tb_shoppingBag a INNER JOIN
      dbo.tb_SaleProduct c ON a.saleProductId = c.id WHERE resource=0 and isStock=1

