CREATE VIEW dbo.v_allBuyProductNewRemark
AS

--状态为等待配货的所有商品
select saleProductId,buyCount,  0 as allStockCount, colorId, metricsId, 1 AS type,  0 as   needInCount, 0 as tuiHuoCount  from tb_temp_waitPhProduct 
UNION ALL

---订单中 等待收款、待审核已付款
--SELECT a.productId AS saleProductId, a.buyCount AS buyCount,  0  AS allStockCount, a.colorId AS colorId, 
--      a.metricsId AS metricsId, 1 AS type, 0 AS needInCount
--FROM dbo.tb_orderSaleProduct a INNER JOIN
--      dbo.tb_order b ON b.id = a.orderId
--WHERE (b.orderStatus IN ( 6 ) OR
--      (b.orderStatus = 5 AND isPayment = 1)) AND b.isDelete != 1
--UNION ALL

---购物车中
SELECT c.productId AS saleProductId, buyCount,0  AS allStockCount, colorId, metricsId, 2 AS type, 
      0 AS needInCount, 0 as tuiHuoCount  
FROM tb_shoppingBag a INNER JOIN
      dbo.tb_SaleProduct c ON a.saleProductId = c.id
WHERE resource = 0 AND isStock = 1
UNION ALL

--计入库存的采购单
SELECT productId AS saleProductId, 0 AS buyCount,
       SUM(CASE isBuyStock WHEN 1 THEN b.buyCount ELSE 0 END) AS allStockCount, 
      colorId, metricsId, 3 AS type, 
      SUM(CASE isBuyStock WHEN 0 THEN b.buyCount ELSE 0 END) 
      AS needInCount, 0 as tuiHuoCount
FROM erp.dbo.tb_buyProductList a INNER JOIN
      erp.dbo.tb_buyProductProtity b ON a.id = b.buyProductId AND a.buyStatus IN (1, 2, 3) 
      AND isdeleted <> 1
GROUP BY productId, colorId, metricsId
HAVING (SUM(b.buyCount) > 0)

--拒收退货返库中
UNION ALL
select c.productId AS saleProductId, 0 as buyCount,0  AS allStockCount, colorId, metricsId, 4 AS type, 
      0 AS needInCount, isnull(sum(a.productCount),0) as tuiHuoCount 
	from erp..tb_orderInstockProduct a ,erp..tb_orderInstock b,erp..tb_productStock c 
		where b.status in (0,1) and b.id=a.instockId and a.productCode=c.productShelfCode 
GROUP BY c.productId, colorId, metricsId

--UNION ALL
--SELECT c.productId AS saleProductId, (SUM(backCount) * - 1) / 2 AS buyCount,0  AS allStockCount, c.colorId, 
--      c.metricsId, 4 AS type, 0 AS needInCount
--FROM tb_order a INNER JOIN
--      tb_rejectOrder b ON a.id = b.orderId INNER JOIN
--      tb_orderSaleProduct c ON c.orderid = a.id AND c.backCount > 0
--GROUP BY c.colorId, c.productId, c.metricsId







