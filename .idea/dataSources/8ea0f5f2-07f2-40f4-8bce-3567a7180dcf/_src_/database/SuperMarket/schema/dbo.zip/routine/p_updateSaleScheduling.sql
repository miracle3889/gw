
CREATE  procedure [dbo].[p_updateSaleScheduling] @ndate varchar(20),@id int
as
	if not exists(select 1 from [SuperMarket].[dbo].[tb_saleScheduling] where   ndate=@ndate and nickId in(select nickId from [SuperMarket].[dbo].[tb_saleScheduling] where id=@id))
	begin
	
		
		update [SuperMarket].[dbo].[tb_saleScheduling] set ndate=@ndate where id=@id
		select 1
	end
	else
		select 0 