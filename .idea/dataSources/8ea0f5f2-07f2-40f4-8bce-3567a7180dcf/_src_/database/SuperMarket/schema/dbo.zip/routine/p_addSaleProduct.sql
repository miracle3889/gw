CREATE PROCEDURE p_addSaleProduct @producyId INT,@oldPrice INT,
					   @saleCount INT,@remark VARCHAR(5000),
					   @salePlanId INT,@saleTypeId INT
AS
	DECLARE @pCode VARCHAR(20)
	DECLARE @returnValue INT
	SET @returnValue=0
	if not EXISTS(select 1 from tb_saleProduct where productId=@producyId and saleTypeId=@saleTypeId)
	begin
		BEGIN TRAN 
			SELECT @pCode=code FROM dbo.tb_saleType WHERE id=@saleTypeId
			INSERT INTO dbo.tb_saleProduct(saleCode,productId,oldPrice,remark,saleCount,salePlanId,saleTypeId)
			VALUES(@pCode,@producyId,@oldPrice,@remark,@saleCount,@salePlanId,@saleTypeId)
			SET @returnValue=SCOPE_IDENTITY()
			SET @pCode=LTRIM(RTRIM(@pCode))+CAST(@returnValue AS VARCHAR(20))
			UPDATE dbo.tb_saleProduct SET saleCode=@pCode WHERE id=@returnValue
		COMMIT TRAN
		declare @searchCount int --检查是否存在同一商品
	             declare @productId int--原始商品I
	             declare @Id int--saleId
	
		set @Id=@returnValue
		set @productId=@producyId
		      select @searchCount=count(*) from tb_saleProduct where productId=@productId and saleTypeId in(1,2)
		      if(@searchCount>0)
			begin
	
			declare @keyWords varchar(500)
			declare @disCript varchar(5000)
			declare @preKey varchar(50)
			declare @webCategoryId int
			declare @capabilityId int 
			declare @materialId int 
			declare @brandId  int 
			declare @minId  int 
			 declare @oldid   int 
			select top 1 @oldid=id,@remark=remark,@keyWords=keyWords,@disCript=disCript,@preKey=preKey,@webCategoryId=webCategoryId,
			@capabilityId=capabilityId,@materialId=materialId,@brandId=brandId from tb_saleProduct where productId=@productId and saleTypeId in(1,2) order by addTime 
			
			update tb_saleProduct set remark=@remark,keyWords=@keyWords,disCript=@disCript,preKey=@preKey,webCategoryId=@webCategoryId,
			capabilityId=@capabilityId,materialId=@materialId,brandId=@brandId where id=@Id
			
			if(@saleTypeId<>3 and  @saleTypeId<>5  and @saleTypeId<>6  and @saleTypeId<>7  and @saleTypeId<>21 )
			begin
			-- 以上更新商品描述等信息
			insert into tb_webPic(productId,picPath,type,code)  select @Id,picPath,type,code from tb_webPic where productId=@oldid
			--select @minId=min(id) from tb_webPic where  productId=@Id
			--update tb_webPic set code=@minId  where  productId=@Id
			
			update tb_webPic set code=b.minId from tb_webPic a,(select  min(id) as minId,code from tb_webPic where  productId=@Id group by code) as b
			where a.code=b.code
			end
			--以上更新图片信息
		end
	end
	SELECT @returnValue