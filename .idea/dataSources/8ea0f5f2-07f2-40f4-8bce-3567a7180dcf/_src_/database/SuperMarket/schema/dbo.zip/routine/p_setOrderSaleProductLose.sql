CREATE PROCEDURE p_setOrderSaleProductLose @oderSaleProductId INT,@loseCount INT,@dealManId int,@remark VARCHAR(100)
AS
	DECLARE @productCode VARCHAR(50)
	DECLARE @backCount INT
	SELECT @productCode=b.productShelfCode,@backCount=backCount FROM supermarket..tb_orderSaleProduct a 
	INNER JOIN erp..tb_productStock b ON a.colorId=b.colorId AND a.metricsId=b.metricsId WHERE a.id=@oderSaleProductId

	IF(@backCount<@loseCount)
	BEGIN
		 SELECT -1 --大于了拒收数量
		 RETURN 
	END

	BEGIN TRAN 
		UPDATE supermarket..tb_orderSaleProduct SET loseCount=@loseCount WHERE id=@oderSaleProductId
	
		EXEC p_addShelfStockByNotStock 'Y0000',@productCode,@loseCount,@dealManId,3,@remark
	COMMIT TRAN 
	SELECT 1

