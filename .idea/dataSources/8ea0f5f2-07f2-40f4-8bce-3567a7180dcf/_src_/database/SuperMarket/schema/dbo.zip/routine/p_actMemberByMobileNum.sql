/*--------------------------------激活电话用户网上登陆----------------------------*/
CREATE   PROCEDURE p_actMemberByMobileNum @mobileNum VARCHAR(11),@checkCode VARCHAR(6),
					  @Email VARCHAR(50),@psw VARCHAR(50)
AS
	DECLARE @myCount INT
	DECLARE @memberId INT
	DECLARE @returnValue INT
	SET @returnValue=0
	SELECT @myCount=COUNT(*) FROM  dbo.tb_member 
	WHERE mobileNum=@mobileNum AND checkCode=@checkCode AND psw IS NULL
	IF(@myCount=1)
	BEGIN
		SELECT @myCount=COUNT(*) FROM dbo.tb_member WHERE EMail=@EMail
		IF(@myCount>0)
		BEGIN
			SET @returnValue=0
		END
		ELSE
		BEGIN
		 	 SELECT @memberId=id FROM  dbo.tb_member 	
			WHERE mobileNum=@mobileNum AND checkCode=@checkCode AND psw IS NULL
			UPDATE dbo.tb_member SET Email=@Email,psw=dbo.md5(@psw) WHERE id=@memberId
			DECLARE @giftId INT
			BEGIN TRAN
			/*-------------以下是赠送礼券---------------------*/
			SET ROWCOUNT 1
	
			UPDATE dbo.tb_giftCard SET isAct=-10 WHERE  isAct=0  and createType=1
		
			SELECT TOP 1 @giftId=id FROM dbo.tb_giftCard WHERE isAct=-10 
			
			SET ROWCOUNT 0
			
			INSERT INTO dbo.tb_memberGift(giftId,memberId) VALUES(@giftId,@memberId)
			
			UPDATE dbo.tb_giftCard SET isAct=1,actTime=GETDATE(), 
			useLastTime=DATEADD(day,30,GETDATE()) WHERE id=@giftId 
			
			IF(@@ERROR<>0)
			BEGIN
				ROLLBACK TRAN 
			END
			COMMIT TRAN 
			
		 SET @returnValue=1
		END
	END
	SELECT  @returnValue