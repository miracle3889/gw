 create proc xp_UFRegRead 
 @root nvarchar(800), 
 @keyPos nvarchar(2000), 
 @key nvarchar(800) 
 as 
 exec master..xp_regread @root,@keyPos,@key 