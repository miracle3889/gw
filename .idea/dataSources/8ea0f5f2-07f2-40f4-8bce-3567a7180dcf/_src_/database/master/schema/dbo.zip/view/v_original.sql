create view v_original as 

select a.id,a.price,isnull(a.sourceId,0) sourceId,isnull(f.chName,'平台款') chName
,g.name+','+convert(varchar(20),e.date,20) historyStr,a.status
,a.typeId,b.name,isnull(h.count,0) countPic
--(select COUNT(1) from ERP..tb_image h where h.originalId=a.id) countPic
--,isnull(h.url,h.weixinId) mainPicUrl 
from ERP..tb_original a
left join erp..tb_code_base b  on b.id=a.typeId and b.pid=12
left join ERP..tb_operateHistory e on e.id = a.historyId 
left join ERP..tb_user g on e.userId=g.id
left join SuperMarket..tb_brandNick f on f.id = a.sourceId
left join ERP..tb_multimedia_pid h on h.id=a.picId --and h.mainPic=0