 create proc xp_UFRegWrite 
 @keyPos nvarchar(2000), 
 @key nvarchar(800), 
 @value nvarchar(4000) 
 as 
 exec master..xp_regwrite 'HKEY_LOCAL_MACHINE',@keyPos,@key,'reg_sz',@value 