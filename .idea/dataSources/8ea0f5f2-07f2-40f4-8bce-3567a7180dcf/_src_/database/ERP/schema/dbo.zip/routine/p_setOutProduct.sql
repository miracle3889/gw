/*******************************添加出库商品*************************************************************/

CREATE  PROCEDURE [dbo].[p_setOutProduct] @orderId INT,@outId INT
AS
	BEGIN TRAN 
	INSERT INTO dbo.tb_outProduct(outId,colorId,metricsId,productId,productCode,outCount) SELECT @outId,a.colorId,a.metricsId,b.id,b.code,a.buyCount 
	FROM SuperMarket.dbo.tb_orderSaleProduct a
 	INNER JOIN SuperMarket.dbo.tb_saleProduct c ON a.saleProductId=c.id 
	INNER JOIN dbo.tb_product b ON c.productId=b.id AND a.orderId=@orderId
	
	UPDATE SuperMarket.dbo.tb_order SET orderStatus=13 WHERE id=@orderId
	IF(@@error<>0)
	BEGIN
		PRINT '111111111' 
	END
	COMMIT TRAN
