CREATE PROCEDURE [dbo].[p_addProductStockColor] @productId INT,@colorName VARCHAR(50)
AS
	DECLARE @returnValue INT
	DECLARE @MaxINT INT
	DECLARE @VARCHARMAX VARCHAR(2)
	SET @returnValue=0
	SET @MaxINT=0
	BEGIN TRAN 
	SELECT @MaxINT=MAX(intCode) FROM tb_productColorCode WHERE productId=@productId
	IF(@MaxINT=0 OR @MaxINT IS NULL)
	BEGIN
		INSERT INTO tb_productColorCode(intCode,code,productId,codeName) VALUES(1,'01',@productId,@colorName)
		SET @returnValue=SCOPE_IDENTITY()
	END
	ELSE
	BEGIN
		SET @MaxINT=@MaxINT+1
		SET @VARCHARMAX=CAST(@MaxINT AS VARCHAR(2))
		WHILE(LEN(@VARCHARMAX)<2)
		BEGIN
			SET @VARCHARMAX='0'+@VARCHARMAX
		END
		INSERT INTO tb_productColorCode(intCode,code,productId,codeName) VALUES(@MaxINT,@VARCHARMAX,@productId,@colorName)
		
		SET @returnValue=SCOPE_IDENTITY()
	END
	COMMIT TRAN 
	SELECT @returnValue
