create PROCEDURE [dbo].[addCodeFabriMsgStatus_history]
 @styleId	int,
 @statusId	int,
 @userId	int
AS
DECLARE @returnValue INT --回滚事务
set @returnValue=1
DECLARE @bz	varchar(500)  --备注
DECLARE @userName	varchar(500)  --用户姓名
set @userName=null
DECLARE @countMaking INT --版式数

declare @shejishiname varchar(100)  --设计师
declare @shejizhuliname varchar(100) --设计师助理
declare @banshiname varchar(100)   --版师
declare @yangyigongname varchar(100)  --样衣工
set @countMaking=0
    --查出4个名字
	select @shejishiname=b.name,@banshiname=c.name,@yangyigongname=d.name,@shejizhuliname=f.name from ERP..mf_pCodeFabricMsg a
	  left join ERP..tb_user b on a.sheJiShiId=b.id 
	  left join ERP..tb_user c on a.banShiId=c.id 
	  left join ERP..tb_user d on a.yangyiId=d.id 
	  left join ERP..tb_designer_assistant e on e.userPid=a.sheJiShiId 
	  left join ERP..tb_user f on f.id=e.userPid 
	  where a.id=@styleId
	
	select @userName=name from ERP..tb_user where id=@userId
	select top 1 @countMaking=number from ERP..tb_pattern_making where styleId=@styleId order by date desc
	
	if(@statusId=1)
		begin
			set @bz=@userName+'确认开款'
		end
	if(@statusId=2)
		begin
			set @bz=@shejishiname+'交付设计稿给'+@banshiname
		end
	if(@statusId=3)
		begin
			set @bz = @banshiname + '交付版子给'+@username
			if(@countMaking<>1)
				set @bz = @bz+' /第'+CAST(@countMaking as varchar(2))+'版'
			--set @bz='第'+cast(@countMaking as varchar(20))+'版'+@userName+'制版完成'
		end
	if(@statusId=4)
		begin
			set @bz='第'+cast(@countMaking as varchar(20))+'版'+@userName+'样衣完成'
		end
	if(@statusId=5)
		begin
			set @bz=@banshiname+'交付样衣给'+@userName
			if(@countMaking<>1)
			begin
			 set @bz=@bz + ' /第'+cast(@countMaking as varchar(20))+'版'
			 end
		end
	if(@statusId=6)
		begin
			set @bz=@userName+'安排试穿时间'
			if(@countMaking<>1)
			begin
				set @bz=@bz+' /第'+cast(@countMaking as varchar(20))+'版'
			end
		end
	if(@statusId=7)
		begin
			set @bz='第'+cast(@countMaking as varchar(20))+'版'+@userName+'试穿通过'
		end
	if(@statusId=8)
		begin
			set @bz = @userName+'物料分解完成'
		end	
	insert into ERP..tb_status_history (styleId,statusId,userId,date,bz) values (@styleId,@statusId,@userId,getDate(),@bz)

     if @@ERROR<>0
       set @returnValue=0
