/*-------------------------------修正不正确的二级编码-------------------------------------------------*/
CREATE PROCEDURE  [dbo].[p_AmendcategoryTwoCode] 
AS
DECLARE @oneID INT
DECLARE @twoID INT
DECLARE authors_cursor CURSOR FOR
SELECT a.id,b.id FROM dbo.tb_categoryTwo a INNER JOIN dbo.tb_categoryOne b ON a.parentId=b.id 
WHERE SUBSTRING(a.code,1,1)!=b.code
OPEN authors_cursor
FETCH NEXT FROM authors_cursor 
INTO @oneID, @twoID
WHILE @@FETCH_STATUS = 0
BEGIN
	DECLARE @code VARCHAR(20)
	EXEC p_getCategoryTwoCode @twoID,@code OUTPUT
	UPDATE tb_categoryTwo SET code=@code WHERE id=@oneID
	FETCH NEXT FROM authors_cursor 
	INTO @oneID, @twoID
END
CLOSE authors_cursor
DEALLOCATE authors_cursor
