-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE  [dbo].[p_saveManuFacturer]
	@codeFabriMsgId int,
	@id int,
	@userid int,
	@returnDate varchar(100)
AS
   declare @username varchar(200)
   declare @facturername varchar(200)
   declare @patternCount int
   declare @patternId int 
   declare @yangyiId int
   declare @bz varchar(200)
     
	begin tran
	  update mf_pCodeFabricMsg set statusid=3 where id=@codeFabriMsgId and statusId=1
	  if(@@ROWCOUNT>0)
	   begin
	   --取版数量
	   select @patternCount = COUNT(id) from tb_pattern_making where styleId = @codeFabriMsgId
	   if(@patternCount is null) set @patternCount=0
	   
	   --取用户名
	   select @username=name from tb_user where id=@userid
	   
	   --取厂商名字
	   select @facturername=name from tb_other_manufacturer where id=@id
	   
	   --增加打版记录
		insert into tb_pattern_making (styleId,userId,date,needDesign,number)
			values(@codeFabriMsgId,@userId,GETDATE(),0,@patternCount+1)
		set @patternId = SCOPE_IDENTITY()
		select  @patternId
		--增加打样记录
		insert into ERP..tb_design(patternId,date)values(@patternId,GETDATE())
		set @yangyiId = SCOPE_IDENTITY()
		
		--更新打版中的当前样衣
		update tb_pattern_making set currentPattern=@yangyiId where id=@patternId
		
		--更新款中的当前版,更新当前版状态为3
		update ERP..mf_pCodeFabricMsg set mainPatternId=@patternId,yangyiId=@id,returndate=@returnDate where id=@codeFabriMsgId
		
		--更新样衣签收记录
		exec ERP..p_addDesignRecode @userid,@codeFabriMsgId,0
		
		--增加款式状态记录
		set @bz = @username+'签至'+@facturername+'制作样衣'
		if(@patternCount>0)
		 set @bz = @bz+'第'+CAST((@patternCount+1) as varchar(20))+'版'
		insert into tb_status_history (styleId,date,statusId,userId,bz)
		     values(@codeFabriMsgId,GETDATE(),3,@userid,@bz)
		
	   end
	   
	commit tran
	print @patternId
	
--select mainPatternId from ERP..mf_pCodeFabricMsg where id=@codeFabriMsgId
