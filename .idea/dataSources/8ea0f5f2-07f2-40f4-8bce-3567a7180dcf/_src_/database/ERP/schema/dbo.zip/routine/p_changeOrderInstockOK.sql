CREATE procedure [dbo].[p_changeOrderInstockOK] @instockId int,@doManId int 
as 
	if not exists (select 1 from tb_orderInstockProduct where instockId=@instockId and shelfCode not in(select code from  tb_goodsShelf where code not in('X0000','Y0000','A0000') ))
	begin
	begin tran 
		update tb_orderInstock set okTime=getdate(), status=2 where id=@instockId
		
		--记录历史
		insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,productOldCount,dealManId,type,optype)
		select a.shelfCode,a.productCode,sum(inStockCount),b.productCount,@doManId,0,2 from tb_orderInstockProduct  a
		INNER JOIN tb_shelfProductCount b  on a.productCode=b.productCode and a.shelfCode=b.shelfCode  where instockId=@instockId and inStockCount>0		
		group by a.shelfCode,a.productCode,b.productCount

		--上架
		update tb_shelfProductCount set productCount=a.productCount+b.inStockCount
		 from tb_shelfProductCount a,
		(select shelfCode,productCode,instockId,sum(inStockCount) as inStockCount from   tb_orderInstockProduct where instockId=@instockId group by shelfCode,productCode,instockId)
		 b where a.productCode=b.productCode and a.shelfCode=b.shelfCode and b.instockId=@instockId and b.inStockCount>0
		
		insert into   tb_shelfProductCount(shelfCode,productCode,productCount)  
		select  shelfCode,productCode, sum(inStockCount)  from tb_orderInstockProduct where  instockId=@instockId and  inStockCount>0 and    id not in(
		select a.id  from tb_orderInstockProduct  a
		inner join tb_shelfProductCount b on a.productCode=b.productCode and a.shelfCode=b.shelfCode
		where  instockId=@instockId 
		)   group  by shelfCode,productCode
		
		
		--记录库存操作历史
		insert into  dbo.tb_productStockOpHis(productId,colorId,metricsId,oldCount,newCount,doMan,opType,remark)
		
		select  b.productId,b.colorId,b.metricsId,b.productCount,b.productCount+sum(a.inStockCount),@domanId,4,'订单重新入库' from tb_orderInstockProduct a
			 inner join tb_productStock b on b.productShelfCode=a.productCode
			 where instockId=@instockId and inStockCount>0	 and a.shelfCode not in('X0000','Y0000')
		group by b.productId,b.colorId,b.metricsId,b.productCount


		--更新库存
		update tb_productStock set productCount=a.productCount+b.inStockCount
		from 	tb_productStock a,(select shelfCode,productCode,instockId,sum(inStockCount) as inStockCount from   tb_orderInstockProduct where instockId=@instockId group by shelfCode,productCode,instockId) as b where a.productShelfCode=b.productCode 
		and b.instockId=@instockId and b.inStockCount>0  and b.shelfCode not in('X0000','Y0000')
		
			

		--报损
		update tb_shelfProductCount set productCount=a.productCount+b.loseCount from tb_shelfProductCount a,
		(select shelfCode,productCode,instockId,sum(loseCount) as loseCount from   tb_orderInstockProduct where instockId=@instockId group by shelfCode,productCode,instockId) as  b  
		where a.productCode=b.productCode  and b.instockId=@instockId and b.loseCount>0 and a.shelfCode='X0000'

		
		insert into tb_shelfProductCount(shelfCode,productCode,productCount)  
		select 'X0000',productCode,sum(loseCount) from tb_orderInstockProduct where instockId=@instockId and  loseCount>0 
		and  productCode not in(select productCode from tb_shelfProductCount where shelfCode='X0000') 
		group by productCode

		
		insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,dealManId,type,optype)
		select 'X0000',productCode,sum(loseCount),@doManId,0,2 from tb_orderInstockProduct where instockId=@instockId and loseCount>0
		group by productCode
	
		
		
		--下架规格有库存后重新上架
		update tb_productStock set isUndercarriage=0 where productCount>0   and isUndercarriage=1
		update supermarket..tb_saleproduct set isdeleted=0 where isdeleted=1  and  isSystem=0 and productid in(
			
		select  b.productId  from tb_orderInstockProduct a
			 inner join tb_productStock b on b.productShelfCode=a.productCode
			 where instockId=@instockId and inStockCount>0	 and a.shelfCode not in('X0000','Y0000')
		group by b.productId 
			
		)

		--报失
		update tb_shelfProductCount set productCount=a.productCount+b.injureCount from tb_shelfProductCount a,
		(select shelfCode,productCode,instockId,sum(injureCount) as injureCount from   tb_orderInstockProduct where instockId=@instockId group by shelfCode,productCode,instockId) as  b   
		where a.productCode=b.productCode and a.shelfCode='Y0000' and b.instockId=@instockId and b.injureCount>0
		
		insert into tb_shelfProductCount(shelfCode,productCode,productCount)  
		select 'Y0000',productCode,sum(loseCount) from tb_orderInstockProduct where  instockId=@instockId and injureCount>0 
		and  productCode not in(select productCode from tb_shelfProductCount where shelfCode='Y0000') group by productCode
	
		insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,dealManId,type)
		select 'Y0000',productCode,sum(injureCount),@doManId,0 from tb_orderInstockProduct where instockId=@instockId and injureCount>0
		group by productCode

	commit tran
	end
