/*----------------增加淘宝首页广告--------------------------------*/
CREATE PROCEDURE [dbo].[p_addTaobaoIndex] @taobaoId int, @taobaoName varchar(320), @picUrl varchar(1024), @urlPath varchar(1024), 
				@picPath varchar(128), @type int, @daily varchar(8)

AS

	declare @taobaoNameCount int
	set @taobaoNameCount=0

	SELECT @taobaoNameCount=count(*) FROM ERP..tb_yiTaobaoName WHERE taobaoId=@taobaoId

	if (@taobaoNameCount=0)
	begin
		INSERT INTO ERP..tb_yiTaobaoName (taobaoId, taobaoName) VALUES (@taobaoId, @taobaoName)
	end

	INSERT INTO ERP..tb_yiTaobao (picUrl, urlPath, picPath, type, daily, taobaoId) 
			VALUES (@picUrl, @urlPath, @picPath, @type, @daily, @taobaoId)
	
	SELECT @taobaoNameCount
