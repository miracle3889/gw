/*  增加组合搭配  */

CREATE PROCEDURE [dbo].[mf_addMFpCodeFabricMsgGroup] @msgId INT, @groupMsgId Int, @doManId INT  
AS

	DECLARE @addOk INT
	SET @addOk=0

	BEGIN tran	
		
	IF (@msgId <> 0 and @groupMsgId <> 0 and @doManId <> 0)
	BEGIN
		-- 正反双加 
		IF NOT EXISTS (select * from dbo.mf_pCodeFabricMsgGroup WHERE pCodeFabricMsgId=@msgId and pCodeFabricMsgGroupId=@groupMsgId and isDelete=0)
		BEGIN
			INSERT INTO dbo.mf_pCodeFabricMsgGroup (pCodeFabricMsgId, pCodeFabricMsgGroupId, doManId) VALUES (@msgId, @groupMsgId, @doManId)
			SET @addOk = SCOPE_IDENTITY()  
				IF (@@error <> 0)
				BEGIN
					SET @addOk = -1
				END
		END	
		
		IF NOT EXISTS (select * from dbo.mf_pCodeFabricMsgGroup WHERE pCodeFabricMsgId=@groupMsgId and pCodeFabricMsgGroupId=@msgId and isDelete=0)
		BEGIN
			INSERT INTO dbo.mf_pCodeFabricMsgGroup (pCodeFabricMsgId, pCodeFabricMsgGroupId, doManId) VALUES (@groupMsgId, @msgId, @doManId)
			SET @addOk = SCOPE_IDENTITY()  
				IF (@@error <> 0)
				BEGIN
					SET @addOk = -1
				END
		END	
	END
	ELSE
	BEGIN
		SET @addOk = -2
	END	
	
	commit tran

	SELECT @addOk 
	RETURN @addOk
