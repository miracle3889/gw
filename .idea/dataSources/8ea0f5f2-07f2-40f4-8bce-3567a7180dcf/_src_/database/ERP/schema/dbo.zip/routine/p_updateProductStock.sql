CREATE procedure [dbo].[p_updateProductStock] @productId int,@colorId int,@metricsId int,
					@count int,@doManId int,@remark varchar(200)
as
	declare @oldCount int
	begin tran 
	select @oldCount=productCount from dbo.tb_productStock where productId=@productId
	and colorId=@colorId and metricsId=@metricsId
	
	insert into tb_productStockOpHis(productId,colorId,metricsId,oldCount,newCount,doman,remark)
	values(@productId,@colorId,@metricsId,@oldCount,@count,@doManId,@remark)


	update dbo.tb_productStock set productCount=@count where productId=@productId
	and colorId=@colorId and metricsId=@metricsId
	commit tran
