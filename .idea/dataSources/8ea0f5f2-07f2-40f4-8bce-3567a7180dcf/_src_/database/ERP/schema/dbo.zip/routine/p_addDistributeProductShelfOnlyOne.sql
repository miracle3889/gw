CREATE procedure [dbo].[p_addDistributeProductShelfOnlyOne] @distributeId int ,@productCode varchar(50),@shelfCode varchar(50),@productCount int
as 
	declare @returnValue int
	set @returnValue=0
	if not EXISTS(select 1 from tb_shelfProductCount where shelfCode=@shelfCode and productCode=@productCode)
	begin
		set @returnValue=-2 --商品不存在
	end
	else
	begin
		insert into tb_distributeProductShelf(distributeId,productCode,shelfCode,productCount) 
				values(@distributeId,@productCode,@shelfCode,@productCount)
		declare @title varchar(50)
		declare @eventContent varchar(200)
		declare @insertId int
		set @title= @productCode
		set @eventContent='编号为'+@productCode+'的商品在货位'+@shelfCode+'上发现异常'
		exec Supermarket.dbo.p_addEvent  @title,@eventContent,1,12,@insertId out
		set @returnValue=1
		
	end

	select @returnValue
