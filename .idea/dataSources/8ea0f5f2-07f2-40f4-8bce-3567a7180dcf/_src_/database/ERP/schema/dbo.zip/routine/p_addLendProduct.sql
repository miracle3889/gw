/*----------------------添加借出商品--------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[p_addLendProduct] @productId INT,@colorId INT,@metricsId INT,@count INT,@lendId INT
AS
	DECLARE @returnValue INT
	SET @returnValue=0
	BEGIN TRAN 
		DECLARE @realCount INT 
                DECLARE @DDlCount INT 
		DECLARE @saleProductId INT
		SELECT @saleProductId=id FROM SuperMarket.dbo.tb_saleProduct WHERE productId=@productId
		SELECT @realCount=SUM(productCount) FROM ERP.dbo.tb_productStock WITH(TABLOCKX)   WHERE productId=@productId AND colorId=@colorId AND metricsId=@metricsId   
		SELECT @DDlCount=SUM(a.buyCount) FROM SuperMarket.dbo.v_allBuyProduct a WITH(TABLOCKX) 
		WHERE a.saleProductId=@saleProductId AND a.colorId=@colorId AND a.metricsId=@metricsId   
	    	IF(@DDlCount IS NULL)
       		BEGIN 
			SET @DDlCount=0
                END
	   	IF(@realCount-@DDlCount<@count)--判断库存
		BEGIN 
			SET @returnValue=-1--库存不足
		END
		ELSE
		BEGIN
			UPDATE dbo.tb_productStock SET productCount=productCount-@count 
			WHERE productId=@productId AND colorId=@colorId AND metricsId=@metricsId
			INSERT INTO dbo.tb_lendProduct(lendId,productId,colorId,metricsId,lendCount)
			VALUES (@lendId,@productId,@colorId,@metricsId,@count)
			SET @returnValue=SCOPE_IDENTITY()
			
		END
	COMMIT TRAN
	SELECT @returnValue
