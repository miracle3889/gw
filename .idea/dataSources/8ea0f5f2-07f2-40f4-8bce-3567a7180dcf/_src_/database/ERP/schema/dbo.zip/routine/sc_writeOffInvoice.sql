/*********		同意核销发票		***********/
CREATE PROCEDURE [dbo].[sc_writeOffInvoice]
 @invoiceId	int,
 @userId int
AS

DECLARE @approvalType	INT  --审批类型
DECLARE @mediaId	INT  --多媒体id
DECLARE @amount	INT  --核销数量
set @amount=0;
DECLARE @invoiceCode varchar(30) --发票单号
DECLARE @purchaseId    int    --采购单号
DECLARE @updaterst	INT  --是否成功核销
set @updaterst=0;
DECLARE @ret	INT  --返回值
set @ret=0
if exists (select 1 from supplyCenter.materie.tb_invoice_main where id=@invoiceId)
BEGIN
select @approvalType=approvalType,@invoiceCode=invoiceCode,@mediaId=mediaId,@amount=amount from supplyCenter.materie.tb_invoice_main where id=@invoiceId
	begin tran
		if(@approvalType=5 and @mediaId>0)--部门主管审批
			begin
				update supplyCenter.materie.tb_invoice_main set approvalType=4 where id=@invoiceId
				set @updaterst=1;
			end
		if(@approvalType=6 and @mediaId>0)--分管领导审批
			begin
				update supplyCenter.materie.tb_invoice_main set approvalType=4 where id=@invoiceId
				set @updaterst=1;
			end
		if(@approvalType=4)--会计审批
			begin
				update supplyCenter.materie.tb_invoice_main 
				set approvalStatus=1,
					approvalDoneTime=GETDATE()
				where id=@invoiceId
				
				begin tran
					DECLARE  cs CURSOR FOR
					select amount,purchaseId from supplyCenter.materie.tb_invoice_next where invoiceCode=@invoiceCode
					OPEN cs
					FETCH NEXT FROM cs
					INTO @amount,@purchaseId
					WHILE @@FETCH_STATUS = 0
					BEGIN
					
						update supplyCenter.materie.tb_materiePurchase set amountOfInvoice=amountOfInvoice+@amount where id=@purchaseId
						FETCH NEXT FROM cs
						INTO @amount,@purchaseId
					END
					
						CLOSE cs
					DEALLOCATE cs
				
				if @@ERROR<>0
					begin
						set @updaterst=0;
						rollback tran
					end
				commit tran
				
			end
		
			insert into SuperMarket..pro_approval (documentId,documentType,approvalUserId,approvalTime,approvalResult,mediaRemark,configId)
			values 
			(
				(select invoiceCode from supplyCenter.materie.tb_invoice_main where id=@invoiceId),
				@approvalType,
				@userId,
				GETDATE(),
				1,
				0,
				(select id from SuperMarket..pro_approval_config where typeId = @approvalType and groupId = (select groupId from ERP..tb_user where id = @userId))
			)
			set @ret=1;
		
		
		
    if @@ERROR<>0
		begin
			set @ret=0;
			rollback tran
		end
	commit tran
END
select @ret as ret;

