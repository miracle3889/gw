-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[lockDownLoad] 
	@top int 
AS
declare @sql_ varchar(200)
declare @sql varchar(200)
BEGIN
--begin try
 
	if exists(select * from tempdb..sysobjects where id=object_id('tempdb..##weixindownload'))
		 drop table ##weixindownload
		 
	
	set @sql='select top '+ cast(@top as varchar(10))+' * into ##weixindownload from v_weixindownload '
	
	exec (@sql)
	
	declare @tablename varchar(200)
	DECLARE MyCursor CURSOR		
	FOR SELECT  tablename FROM ##weixindownload group  by tablename
	open  MyCursor
	FETCH NEXT FROM  MyCursor INTO @tablename
	begin tran
	WHILE @@FETCH_STATUS =0
		BEGIN		
		declare @column_set varchar(20)
		set @column_set = 'url'
		if(@tablename='erp..Mf_suppliderCardCodeMedia')
		begin
			set @column_set= 'mediaurl'
		end
		set @sql='update ' + @tablename+' set '+@column_set+'=''2'' where id in (select id from ##weixindownload where tablename='''+@tablename+''')'
		exec (@sql) 
		--print @sql
		FETCH NEXT FROM  MyCursor INTO @tablename	
		END
			--关闭游标
		CLOSE MyCursor
			--释放资源
		DEALLOCATE MyCursor
	commit tran
	select * from ##weixindownload
--end try
--begin catch
 --rollback   
--end catch
		
		--select null
END
