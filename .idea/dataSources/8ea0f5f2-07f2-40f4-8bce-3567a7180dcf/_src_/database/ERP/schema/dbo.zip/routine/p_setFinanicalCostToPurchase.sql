/*-----------------------------------将财务成本(（成品发票总金额+A发货数*A加权财务成本）/数量)塞入采购单表finanicalCost--------------------------------------------------------*/
CREATE PROCEDURE [dbo].[p_setFinanicalCostToPurchase]
AS
	
	BEGIN
	if exists(select * from tempdb..sysobjects where id=object_id('tempdb..#a')) drop table #a
	if exists(select * from tempdb..sysobjects where id=object_id('tempdb..#b')) drop table #b
	if exists(select * from tempdb..sysobjects where id=object_id('tempdb..#c')) drop table #c
		
		--最早审核的发票时间
		select c.purchaseId, CONVERT(varchar(7), min(a.approvalTime),120)+'-01' month into #a from  supplyCenter..pro_approval a
		inner join supplyCenter..pro_invoice_main b on a.documentId=b.invoiceCode
		inner join supplyCenter..pro_invoice_next c on b.invoiceCode = c.invoiceCode
		where 
		b.approvalStatus=1 
		group by c.purchaseId
		
		--采购单发票总金额
		select b.purchaseId, SUM(b.unitPrice*b.amount/100000000.0) invoiceMoney into #b from 
		supplyCenter..pro_invoice_main a
		inner join 
		supplyCenter..pro_invoice_next b on a.invoiceCode = b.invoiceCode
		where a.approvalStatus=1
		group by b.purchaseId
		
		--财务成本
		select 
			a.id, 
			round( (max(g.invoiceMoney)+SUM(isnull(c.amount,0)*isnull(e.cost,0)/10000000000.0))/max(a.amount),2) cwcb into #c 
		from supplyCenter..pro_purchase a 
		left join supplyCenter.materie.tb_materialDelivery b on a.id = b.purchaseId
		left join supplyCenter.materie.tb_materialDelivery_child c on b.id = c.deliveryId
		left join designCenter.materials.tb_materials_sku d on b.skuId=d.id
		left join finance.store.tb_materialsMonthCost e on d.materialsId=e.materials
		left join #a f on e.month = f.month and f.purchaseId = a.id
		inner join #b g on g.purchaseid = a.id
		group by a.id


		--更新财务成本
		update supplyCenter..pro_purchase set finanicalCost=b.cwcb
		from supplyCenter..pro_purchase a inner join #c b on a.id = b.id
	END
