-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-----------------------------得到图片父表id--------------------------------
CREATE PROCEDURE [dbo].[p_insertMultimediaPid]
@type int,
@returnValue numeric OUTPUT
AS
BEGIN
	insert into ERP..tb_multimedia_pid (type,count) values (@type,0);
	SET @returnValue=SCOPE_IDENTITY(); 
END
