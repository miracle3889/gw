/*  增加物料分解的面辅料  */

CREATE PROCEDURE [dbo].[mf_addmfpCodeFabricProtityGuiGe] @mfProductionPlanId int, @mfPCodeFabricProtityId int, @doManId int, @geige varchar(8), @remark varchar(320) 
AS

	DECLARE @returnValue INT
	SET @returnValue=0
	
	BEGIN tran
	
	IF( @mfProductionPlanId<>0 and @mfPCodeFabricProtityId<>0 and @doManId <> 0 )
	BEGIN
		
		DECLARE @mfpCodeFabricFormId INT
		SET @mfpCodeFabricFormId=0
		DECLARE @fabricNewId INT
		SET @fabricNewId=0
		DECLARE @newFabricNewId INT
		SET @newFabricNewId=0
	
		select @mfpCodeFabricFormId=a.mfpCodeFabricFormId, @fabricNewId=b.fabricNewId from mf_productionPlanTask a, mf_pCodeFabricProtity b 
			where a.mfpCodeFabricFormId=b.pCodeFabricFormId and a.mfProductionPlanId=@mfProductionPlanId and b.id=@mfPCodeFabricProtityId
		if(@mfpCodeFabricFormId<>0 and @fabricNewId<>0)
		begin
			
			DECLARE @colorCard varchar(32)
			SET @colorCard=''
			DECLARE @colorCardCount int
			SET @colorCardCount=0
		
			select @colorCard=colorCard from mf_fabricNew where id=@fabricNewId
			if(CHARINDEX('_', @colorCard)<>0)
			begin
				SET @colorCard = substring(@colorCard,0,CHARINDEX('_', @colorCard))
			end
			select @newFabricNewId=id from mf_fabricNew where CHARINDEX(@colorCard, colorCard)<>0 and fabricName=@geige
			
			if(@newFabricNewId=0)
			begin
				select @colorCardCount=COUNT(*) from mf_fabricNew where CHARINDEX(@colorCard, colorCard)<>0
				
				insert into mf_fabricNew (colorCard, fabricName, fabricColor, supplidersId, colorShelf, searchTag, remark, picUrl, type, doManId)
				select @colorCard+'_'+ cast(@colorCardCount as varchar(8)), @geige, fabricColor, supplidersId, colorShelf, searchTag, remark,picUrl, type, @doManId 
				from mf_fabricNew where isDelete=0 and id=@fabricNewId
				SET @newFabricNewId=SCOPE_IDENTITY()	
					if (@@error<>0)
					begin
						set @returnValue=-3
					end
			end
					
			if(@newFabricNewId<>0)
			begin

					DECLARE @newColorCard varchar(32)
					SET @newColorCard=''
					select @newColorCard=colorCard from mf_fabricNew where id=@newFabricNewId
					
					update mf_pCodeFabricForm set remark=remark+'<br>'+@newColorCard+':'+@remark where id=@mfpCodeFabricFormId
				
					insert into mf_pCodeFabricProtity (pCodeFabricFormId , fabricNewId, doManId)
					select a.mfpCodeFabricFormId,@newFabricNewId,@doManId  from mf_productionPlanTask a, mf_pCodeFabricProtity b 
					where a.mfpCodeFabricFormId=b.pCodeFabricFormId and a.mfProductionPlanId=@mfProductionPlanId and b.id=@mfPCodeFabricProtityId and fabricNewId<>@newFabricNewId
					SET @returnValue=SCOPE_IDENTITY()
					if (@@error<>0)
					begin
						set @returnValue=-2
					end
				

			end

		end
	END
	
	
	commit tran

	SELECT @returnValue
