/*------------------------------------------------更新商品品名------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[p_updateProductTag]  @id int,@pinming varchar(32), @leibie varchar(32), @biaozhun varchar(32) 
AS
	DECLARE @returnValue INT
	BEGIN TRAN 
		
			
			DECLARE @countTag INT
			SELECT @countTag=isnull(COUNT(*), 0) FROM dbo.tb_productTag WHERE productId=@id
			IF(@countTag!=0)
			BEGIN
				update tb_productTag set pinming=@pinming ,leibei=@leibie, biaozhun=@biaozhun where productId=@id
			END
			ELSE
			BEGIN
				insert into tb_productTag (pinming, leibei, biaozhun, productId) values (@pinming , @leibie , @biaozhun, @id)
			END

	COMMIT TRAN 
	SELECT @returnValue
