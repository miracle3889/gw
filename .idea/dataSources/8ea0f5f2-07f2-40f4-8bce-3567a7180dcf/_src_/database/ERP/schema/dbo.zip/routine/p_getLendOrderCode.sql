/*--------------------得到定单编号---------------------------------*/
CREATE  PROCEDURE  [dbo].[p_getLendOrderCode] @source int,@code VARCHAR(50) OUTPUT
AS
	
	EXEC ERP.dbo.p_getNowDate @code OUTPUT
	--begin tran 
	DECLARE @temp INT
	DECLARE @count INT
	set @temp=rand()*10000 
	
	/*SELECT  @count=count(*) FROM tb_lendCode WITH(HOLDLOCK)   
	WHERE CONVERT(VARCHAR(10),GETDATE(),120)=CONVERT(VARCHAR(10),addDate,120)  
	and intCode=@temp
	while(@count>0)
	begin
		set @temp=rand()*10000 
		SELECT  @count=count(*) FROM tb_lendCode WITH(HOLDLOCK)   
		WHERE CONVERT(VARCHAR(10),GETDATE(),120)=CONVERT(VARCHAR(10),addDate,120) 
		 and intCode=@temp
	 end*/

	select @temp=max(intCode) from tb_lendCode WHERE CONVERT(VARCHAR(10),GETDATE(),120)=CONVERT(VARCHAR(10),addDate,120)  
	if(isNull(@temp,0)=0)
		set  @temp=1
	else
		set @temp=@temp+1
	
	DECLARE @CharTemp VARCHAR(10)
	SET @CharTemp=CAST(@temp AS VARCHAR(10))
	WHILE(LEN(@CharTemp)<4)
	BEGIN
		SET @CharTemp='0'+@CharTemp
	END
	SET @code='LD'+@code+@CharTemp
	INSERT INTO tb_lendCode (intCode,source) VALUES(@temp,@source)
	--commit tran
