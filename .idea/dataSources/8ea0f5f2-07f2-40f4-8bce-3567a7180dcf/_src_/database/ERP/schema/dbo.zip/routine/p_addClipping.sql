-- 增加裁剪单
CREATE PROCEDURE [dbo].[p_addClipping] @productId int, @clippingTime varchar(32), @outTime varchar(32), @mfAddrId int, @status int, @doManId int,
				@reMark varchar(320), @batchNumber int, @protity varchar(320) 

AS
	if(@doManId<=0)
	begin
		select 0 
		return
	end 
	DECLARE @returnValue INT	
	DECLARE @clippColorId INT	

	SET @returnValue=0
	
	DECLARE @allClippingCount INT
	SET @allClippingCount=0
	
	begin tran

	IF (@productId!=0)
	BEGIN
		
		INSERT INTO ERP..tb_clipping (productId, clippingTime, outTime, mfAddrId, status, doManId, reMark, batchNumber, outCount,clippingCount) 
		VALUES (@productId, @clippingTime, @outTime, @mfAddrId, 1, @doManId, @reMark, @batchNumber, 0,0)
		SET @returnValue=SCOPE_IDENTITY()
		if (@@error<>0)
		begin
			ROLLBACK tran
		end
		
			insert into erp..tb_jstatusHis(pcode,jstatus)
			select pcode,5 from  erp..mf_pCodeFabricMsg  
			where pCode  in(select pCode from erp..tb_product where id=@productId )  and jstatus<5
			
		UPDATE erp..mf_pCodeFabricMsg set jstatus=5 where pCode in(
				select pCode from erp..tb_product where id=@productId
		) and jstatus <5
		
		  
		
		/*****增加裁剪单的裁剪数****/
	
		DECLARE @colorString VARCHAR(300)
		DECLARE @colorId int
		DECLARE @productIdProtity int
		DECLARE @metricsId int
		DECLARE @clippingCount int
		
		DECLARE @i INT
		while len(@protity)>0
		begin
	
			SET @colorString= SUBSTRING(@protity, 0,CHARINDEX(',',@protity))
			
			SET @i=1
			while @i<=3
			BEGIN
				IF @i=1
				SET @colorId= SUBSTRING(@colorString, 0,CHARINDEX('&',@colorString))
				IF @i=2
				SET @metricsId= SUBSTRING(@colorString, 0,CHARINDEX('&',@colorString))
				IF @i=3
				SET @clippingCount= SUBSTRING(@colorString, 0,CHARINDEX('&',@colorString))
	
				set @colorString=SUBSTRING(@colorString, CHARINDEX('&',@colorString)+1,len(@colorString))
				
				SET @i=@i+1
				
			END
			if(@clippingCount>0)
			begin
				select @productIdProtity=productId from erp..tb_productStock where colorId=@colorId and metricsId=@metricsId 
				if(@productIdProtity=@productId)
				begin
					INSERT INTO ERP..tb_clippingProtity (clippingId, colorId, metricsId,clippingCount, outCount)
					VALUES (@returnValue, @colorId, @metricsId, @clippingCount, 0)
					set @clippColorId=@colorId
				end 
			end
			if (@@error<>0)
			begin
				ROLLBACK tran
			end

			SET @allClippingCount=@allClippingCount+@clippingCount

			SET @protity= SUBSTRING(@protity, CHARINDEX(',',@protity)+1,len(@protity))
			
		end
		
	END
	commit tran
	--裁床为0 删除
	if(@allClippingCount=0)
		update ERP..tb_clipping set isDelete=1 where id=@returnValue 
	else
	begin
		UPDATE ERP..tb_clipping set clippingCount=@allClippingCount,clippColorId=@clippColorId where id=@returnValue
		UPDATE erp..tb_product set mfAddrId=@mfAddrId where id=@productId
	end
	SELECT @returnValue
