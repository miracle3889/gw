create PROCEDURE [dbo].[p_updateCodeBaseIsDelete]
		@id int
    AS
    BEGIN
		declare @isDelete int 
		select  @isDelete=isdelete from  ERP..tb_code_base  where  id=@id
		DECLARE @returnValue int
		if(@isDelete=0)
		begin
			update ERP..tb_code_base set isdelete=1 where id=@id
			set @returnValue=1		       
        end
        ELSE
        begin
			update ERP..tb_code_base set isdelete=0 where id=@id
			set @returnValue=0		       
        end
    END
select @returnvalue
