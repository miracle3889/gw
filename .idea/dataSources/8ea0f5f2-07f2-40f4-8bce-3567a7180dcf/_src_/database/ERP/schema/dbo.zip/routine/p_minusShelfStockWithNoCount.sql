/*-----------------------下架----------------------*/
CREATE procedure [dbo].[p_minusShelfStockWithNoCount] @shelfCode varchar(50),@productCode varchar(50),@count int,@dealManId int,@opType int,@remark varchar(200)
as 
	begin tran
		declare @oldCount int 
		select @oldCount=productCount from tb_shelfProductCount where shelfCode=@shelfCode and productCode=@productCode
		update tb_shelfProductCount set productCount=productCount-@count where shelfCode=@shelfCode and productCode=@productCode
		
		if(@@error<>0)
			rollback tran 

		insert into tb_shelfProductOpHis(shelfCode,productCode,productOldCount,productCount,dealManId,optype,remark,type) values(@shelfCode,@productCode,isnull(@oldCount,''),@count,@dealManId,@opType,@remark,-1)
		if(@@error<>0)
			rollback tran 
	commit tran
