-- =============================================
-- Author:		<runbin>
-- Create date: <2015-8-6>
-- Description:	<插入信息链接>
-- =============================================
CREATE PROCEDURE [dbo].[p_insertMsgLink]
	@msgId int,	--店铺圈消息id
	@type int,	--类型	1:原样 2：款式
	@typeName varchar(50),	--类型名称
	@code int,	--编号
	@brandName varchar(50)	--图片pid
AS
declare @linkId int	--插入链接id
BEGIN
	begin tran
		insert into ERP..tb_msgLink (type,typeName,code,brandName) 
			values (@type,@typeName,@code,@brandName)
		set @linkId = SCOPE_IDENTITY()
	if(@linkId>0)
		begin
			--更新店铺圈信息的链接id
			update ERP..tb_msg set linkId = @linkId where id = @msgId
		end
	commit tran
END
