/*-------------------得到日期--------------------------------------------*/
CREATE PROCEDURE [dbo].[p_getNowDate] @code VARCHAR(20) OUTPUT
AS
	SET @code=CONVERT(VARCHAR(20),GETDATE(),120)
	SET  @code=SUBSTRING(@code,3,2)+SUBSTRING(@code,6,2)+SUBSTRING(@code,9,2) --取得当前日期如070603
