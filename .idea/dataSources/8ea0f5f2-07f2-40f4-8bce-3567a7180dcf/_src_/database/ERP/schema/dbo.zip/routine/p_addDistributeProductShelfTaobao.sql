---货架位计算
CREATE procedure [dbo].[p_addDistributeProductShelfTaobao] @distributeId int
as
	declare @productCode varchar(50)--商品编号	
	declare @shelfCode varchar(50)--货架编号	
	declare @productCount int--商品数量
	declare @hasCount int
	declare @shelCount int
	delete from tb_distributeProductShelf where  distributeId=@distributeId
	DECLARE authors_cursor0 CURSOR FOR
		--取得所有的待取的商品列表
		select c.productShelfCode,sum(a.buyCount) from tb_orderSaleProductDistribute a
		inner join SuperMarket.dbo.tb_saleProduct  b on a.saleProductId=b.id
		inner join dbo.tb_productStock c on c.productid=b.productid and a.colorid=c.colorid and c.metricsId=a.metricsId
		where a.distributeId=@distributeId
		group by c.productShelfCode
	OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @productCode,@productCount
	WHILE @@FETCH_STATUS = 0
	BEGIN
		set @hasCount=@productCount --初始化剩余没有生成的货架商品数
		
		DECLARE authors_cursor1 CURSOR FOR
			--取该编号商品所在货架数量
			--select shelfCode,productCount from tb_shelfProductCount where productCode=@productCode and shelfCode not in('X0000','Y0000','A0000')
			--2009-11-26 11:18 加入配货占用掉货架数量 -isnull(b.productCount,0)
			select a.shelfCode,a.productCount  from tb_shelfProductCount  a
			--left  join 
			--(
			--	select x.productCode,shelfCode,sum(productCount) as productCount from tb_distributeProductShelf x			
			--	inner join tb_Distribute y on x.distributeId=y.id  and y.isTransfer=0
			--	group by x.productCode,x.shelfCode	
			--) as b  on a.shelfCode=b.shelfCode and a.productCode=b.productCode
			 where  a.productCode=@productCode and a.shelfCode not in('X0000','Y0000','A0000') 
			 and a.shelfCode not like 'X____'
			  and a.shelfCode not in(select code from tb_GoodsShelf where isLock=1)
			 order by case when a.shelfCode like 'E%' then 0  else 1 end 

		OPEN authors_cursor1
			FETCH NEXT FROM authors_cursor1
			INTO @shelfCode,@shelCount
		WHILE @@FETCH_STATUS = 0
		BEGIN
			if(@hasCount<=@shelCount)--如果待取数量小于等于货架上的商品 则退出
			begin
				insert into tb_distributeProductShelf(distributeId,productCode,shelfCode,productCount) 
				values(@distributeId,@productCode,@shelfCode,@hasCount)
				set @hasCount=0
				break
			end
			else
			begin
				if(@shelCount>0)
				begin
					insert into tb_distributeProductShelf(distributeId,productCode,shelfCode,productCount) 
					values(@distributeId,@productCode,@shelfCode,@shelCount)
					set @hasCount=@hasCount-@shelCount--更新剩余没有生成货架数量
				end
			end
			FETCH NEXT FROM authors_cursor1 
			INTO @shelfCode,@shelCount
		END
		CLOSE authors_cursor1
		DEALLOCATE authors_cursor1
		
		if(@hasCount>0)
		begin
			insert into tb_distributeProductShelf(distributeId,productCode,shelfCode,productCount) 
				values(@distributeId,@productCode,'Q0101',@hasCount)
			if not exists(select 1 from  tb_shelfProductCount where shelfCode='Q0101' and   productCode=@productCode)
			begin
				insert into tb_shelfProductCount(shelfCode,productCode,productCount) values('Q0101',@productCode,0)
			end
		end
		--bug 来源

		
		FETCH NEXT FROM authors_cursor0 
		INTO @productCode,@productCount
	END
	CLOSE authors_cursor0
	DEALLOCATE authors_cursor0

	exec p_setTransferDistribute  @distributeId,-100
