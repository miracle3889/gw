/*  设置服装款号的对应服装面料的编号  */

CREATE PROCEDURE [dbo].[mf_setMFfabricPcodeCode] @pCode VARCHAR(32)
AS	
	--DECLARE @returnValue INT
	--SET @returnValue=0	

	IF (@pCode is not null)
	BEGIN
		set @pCode= dbo.F_Ctofchar(@pCode,0)
		set @pCode=ltrim(rtrim(@pCode))
		set @pCode=UPPER(@pCode)

				
		--下面的游标操作  为mf_fabric 设定fabricCode
		DECLARE @allFabricCount int
		SET @allFabricCount=0
		select @allFabricCount=count(*) from erp..mf_pCodeFabric where pCode=@pCode

		DECLARE fabricCursor CURSOR  
		FOR select fabricId from erp..mf_pCodeFabric where pCode=@pCode ORDER BY fabricId asc 

		
		open fabricCursor --打开游标
		
		declare @fabricId int
		set @fabricId=0
		declare @ii int
		set @ii=1
		
		fetch next from fabricCursor into @fabricId
		while @@FETCH_STATUS=0
		begin
			update erp..mf_fabric set fabricCode=CAST(@allFabricCount as varchar(4))+'-'+CAST(@ii as varchar(4)) where id=@fabricId
			set @ii=@ii+1
			fetch next from fabricCursor into @fabricId
		end
		
		close fabricCursor  --关闭游标
		DEALLOCATE fabricCursor --释放游标

		
	END

	--SELECT @returnValue
