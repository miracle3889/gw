/*----------------增加淘宝商品--------------------------------*/
CREATE PROCEDURE [dbo].[p_addTaobaoProduct] @taobaoId int, @BorC varchar(8), @picPath varchar(120), @taobaoProductId bigint, 
		@productName varchar(320), @price int, @urlPath varchar(320),@viewCount int,@saleCount int, @saleDate varchar(10), @taobaoSort varchar(32)
AS
--@taobaoSortId int,
	declare @taobaoProductIdInt bigint
	set @taobaoProductIdInt=0
	declare @isViewSale int
	set @isViewSale=0
	
	declare @taobaoSortInt int
	set @taobaoSortInt=0
	SELECT @taobaoSortInt=id FROM tb_yiTaobaoSort WHERE sort=@taobaoSort
-- isNv=1 是否是女装类别
	if (@taobaoSortInt=0)
	begin
		INSERT INTO tb_yiTaobaoSort (sort,isNv) VALUES (@taobaoSort,1)
		set @taobaoSortInt=SCOPE_IDENTITY()
	end
	else
	begin
		UPDATE tb_yiTaobaoSort SET isNv=1 WHERE sort=@taobaoSort
	end

	--查询淘宝商品是否存在
	select @taobaoProductIdInt=taobaoProductId FROM tb_yiTaobaoProduct WHERE taobaoProductId=@taobaoProductId
	if (@taobaoProductIdInt=0)
	begin
		insert into tb_yiTaobaoProduct (taobaoId, BorC, picPath, taobaoProductId, productName, price, urlPath, taobaoSortId)
		values (@taobaoId, @BorC, @picPath, @taobaoProductId, @productName, @price, @urlPath, @taobaoSortInt)
		--set @taobaoProductIdInt=SCOPE_IDENTITY()
		set @taobaoProductIdInt=@taobaoProductId
	end
	update tb_yiTaobaoProduct set price=@price,taobaoId=@taobaoId,BorC=@BorC WHERE taobaoProductId=@taobaoProductIdInt
	
	SELECT @isViewSale=isnull(count(*),0) FROM tb_yiTaobaoViewSale WHERE taobaoProductId=@taobaoProductIdInt 
		and addDate>=@saleDate and addDate<=@saleDate


	--239已处理过浏览量
	if (@BorC<>'B')
	begin
		SELECT @viewCount=@viewCount-isnull(sum(viewCount),0) FROM tb_yiTaobaoViewSale WHERE taobaoProductId=@taobaoProductIdInt and 
		addDate<=CONVERT(VARCHAR(10),DATEADD(DAY,-1,@saleDate),120) 
	end
	
	if (@viewCount<0)
	begin
		set @viewCount=0
	end
	
	if (@isViewSale=0)
	begin
		insert into tb_yiTaobaoViewSale (viewCount,saleCount,price,taobaoProductId,addDate) 
			values (@viewCount,@saleCount,@price,@taobaoProductIdInt,@saleDate)
	end
	else
	begin
		update tb_yiTaobaoViewSale set saleCount=@saleCount,addDate=@saleDate,viewCount=@viewCount  
			where taobaoProductId=@taobaoProductIdInt and addDate>=@saleDate and addDate<=@saleDate
	end
	
	SELECT @taobaoProductIdInt
