CREATE procedure [dbo].[p_delCodeMsgForm]
 @comfimId int ,
 @userId int 
as
DECLARE @returnValue INT --回滚事务
set @returnValue = 0
	  begin
			begin tran
				update ERP..mf_pCodeFabricForm set isDelete=1,delManId=@userId,delDate=GETDATE() where id=@comfimId
				update ERP..mf_pCodeFabricProtity set isDelete = 1, delManId = @userId, delDate = GETDATE() where pCodeFabricFormId=@comfimId
				set @returnValue = 1
			commit tran
	  end
select @returnValue;
