/*---------------------------更新借出单信息<设置为完成>-----------------------------------------*/
CREATE PROCEDURE [dbo].[p_UpdateLendOk] @lendId INT,@lendMan VARCHAR(50),@reMark VARCHAR(200)
AS
	DECLARE @returnValue INT
	SET @returnValue=0
	BEGIN TRAN 
		UPDATE dbo.tb_Lend SET lendMan=@lendMan , reMark=@reMark,lendStatus=2 WHERE id=@lendId
		SET @returnValue=1
	COMMIT TRAN 
	SELECT @returnValue
