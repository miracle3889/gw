-- =============================================
-- Author:		<runbin>
-- Create date: <2015-08-24>
-- Description:	<商品入库>
-- =============================================
CREATE PROCEDURE [dbo].[p_putInStorage] 
	@userId int,--操作人
	@status int,--入库状态 0：入库 1：破损
	@wareHouseId int, --仓库编号
	@batchId varchar(14), --批次编号
	@amount int --数量
AS
declare @id int	--批次主表id
declare @retVal int
BEGIN
	begin tran
		--插入批次表
		insert into SuperMarket..Tb_saleStorageBatch (batchId,wareHouseId,amount,createTime,type,status,userId)
			values(@batchId,@wareHouseId,@amount,GETDATE(),@status,0,@userId)
		set @id = SCOPE_IDENTITY()
		--插入批次子表
		if @wareHouseId=0 --破损
			begin
				insert into SuperMarket..Tb_saleStorageBatchChild (batchId,productId,skuCode,amount)
					select @id,productId,skuCode,COUNT(skuCode) from supermarket..Tb_saleProductDeal 
					where status = 2 and storageStatus = 0
						and packageId in (select id from SuperMarket..Tb_salePackageDeal where userId = @userId )
						group by productId,skuCode
			end
		else
			begin
				insert into SuperMarket..Tb_saleStorageBatchChild (batchId,productId,skuCode,amount)
					select @id,productId,skuCode,COUNT(skuCode) from supermarket..Tb_saleProductDeal 
					where sellerNick in (select id from SuperMarket..tb_brandNick where wareHouseId = @wareHouseId )
						and status<>2 and status<>3 and status<>0 and storageStatus = 0
						and packageId in (select id from SuperMarket..Tb_salePackageDeal where userId = @userId )
						group by productId,skuCode
			end
		if @wareHouseId=0 --破损
			begin
				--更新商品处理表商品状态
				update supermarket..Tb_saleProductDeal set storageStatus = 1 ,batchId=@batchId
					where status = 2
					and packageId in (select id from SuperMarket..Tb_salePackageDeal where userId = @userId 
					and storageStatus = 0
					--and status <3
					)
			end
		else
			begin
				--更新商品处理表商品状态(没有此件和破损不入库)
				update supermarket..Tb_saleProductDeal set storageStatus = 1,batchId=@batchId
					where sellerNick in (select id from SuperMarket..tb_brandNick where wareHouseId = @wareHouseId ) and status<>2 and status<>3
					and packageId in (select id from SuperMarket..Tb_salePackageDeal where userId = @userId
					and storageStatus = 0
					-- and status <3
					 )
			end
	commit tran
	set @retVal = SCOPE_IDENTITY()
END
select @retVal