/*  增加面辅料  */

CREATE PROCEDURE [dbo].[mf_addMFfabric] @name varchar(32), @typeId INT, @unitId INT, @color varchar(32), 
			@productNumber varchar(64), @remark varchar(640),@oneCount INT, @pCode VARCHAR(32), @supplidersId int, @userId int
AS

	DECLARE @returnValue INT
	SET @returnValue=0
	
	IF NOT EXISTS ( select * from erp..mf_fabric where  name = @name and color=@color and isDelete=0)
	begin
		insert into ERP..mf_fabric (name, typeId, unitId, color, productNumber, remark, oneCount, supplidersId) 
			VALUES (@name, @typeId, @unitId, @color, @productNumber, @remark, @oneCount, @supplidersId)
		SET @returnValue=SCOPE_IDENTITY()

		-- 增加服装款号 和 面辅料的关联
		exec mf_addMFfabricPcode @returnValue, @pCode, @userId
	END
	ELSE
	BEGIN
		select @returnValue=id from erp..mf_fabric where  name = @name and color=@color and isDelete=0
		SET @returnValue = -1
	END
	
	
	SELECT @returnValue
