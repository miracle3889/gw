/*  删除物料清单里的面辅料  */

CREATE PROCEDURE [dbo].[mf_delMFfabricPcodeCode]  @pCode VARCHAR(32), @fabricId int 
AS

	DECLARE @returnValue INT
	SET @returnValue=1
	
	delete mf_pCodeFabric where pCode=@pCode and fabricId=@fabricId
	
	exec mf_setMFfabricPcodeCode @pCode
	
	SELECT @returnValue
