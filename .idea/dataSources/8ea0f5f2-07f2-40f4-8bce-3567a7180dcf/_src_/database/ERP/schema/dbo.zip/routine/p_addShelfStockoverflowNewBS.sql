CREATE PROCEDURE [dbo].[p_addShelfStockoverflowNewBS]  @shelfCode varchar(50),@productCode varchar(50),@count int,@dealManId int,@remark varchar(50)
AS 
	if EXISTS(select 1 from tb_goodsShelf  where code=@shelfCode )
		BEGIN
			if EXISTS(select 1 from tb_productStock  where productShelfCode=@productCode )
			BEGIN
				begin tran
					declare @oldCount int 
					set @oldCount=0
					if EXISTS(select 1 from tb_shelfProductCount where shelfCode=@shelfCode and productCode=@productCode)
					begin
						select @oldCount=productCount from tb_shelfProductCount where shelfCode=@shelfCode and productCode=@productCode
						update tb_shelfProductCount set productCount=productCount+@count where shelfCode=@shelfCode and productCode=@productCode
					end
					else
					begin
						insert into tb_shelfProductCount(shelfCode,productCode,productCount) values(@shelfCode,@productCode,@count)
					end
					 
					if(@@error<>0)
						rollback tran 
					insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,productOldCount,dealManId,optype,remark) values(@shelfCode,@productCode,@count,@oldCount,@dealManId,5,@remark)
					if(@@error<>0)
						rollback tran 
					declare @productId int
					declare @colorId int
					declare @metricsId int
					select @productId=productId ,@colorId=colorId,@metricsId=metricsId from tb_productStock where productshelfCode=@productCode
					
					SELECT 1
				commit tran
			END
			ELSE
			BEGIN	
				SELECT -2
			END
		END
		ELSE
		BEGIN
			SELECT -1
		END
