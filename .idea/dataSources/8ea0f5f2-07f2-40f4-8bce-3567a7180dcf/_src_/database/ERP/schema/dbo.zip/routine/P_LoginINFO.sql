/*******************登陆资讯*******************/
CREATE   PROCEDURE [dbo].[P_LoginINFO] @userName VARCHAR(50),@PSW VARCHAR(15),@departId INT,@ip VARCHAR(50),@sysName VARCHAR(50)
AS 
	SELECT a.id AS id,a.name AS name,a.post AS post,b.name AS departname,b.id AS departId FROM tb_user a 
	INNER JOIN tb_depart b ON a.departId=b.id 
	WHERE a.userName=@userName AND psw=dbo.md5(@PSW)
