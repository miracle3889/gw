-- =============================================
-- Author:		taojun
-- Create date: 2015-11-20
-- Description:	获取图片
-- =============================================
CREATE PROCEDURE [dbo].[p_getImgUrlForAll]
	@id int,
	@type int
AS
   declare @weixinId varchar(200) --微信多媒体ID
   declare @url varchar(200)  --地址url
   declare @imgurl varchar(500)
   declare @originalId int
   declare @picid int
   
	if @type=3	--取tb_img 表一条记录
	begin
		select @weixinId=weixinId,@url=url from ERP..tb_image where id = @id
	end
	if @type=5	--取tb_img 表第一条记录
	begin
		select top 1 @weixinId=weixinId,@url=url from ERP..tb_image where pid = @id
	end

	if @type=1  --获取原样图片
	begin
	select top 1 @weixinId=weixinId,@url=url 
	from ERP..tb_image where pid = (select picid from ERP..tb_original where id=@id) order by mainPic,id desc
	end

	--获取款式图片 
	if(@type in(2,4))
	begin
		--优先获取试穿图片
		select top 1 @weixinId=weixinId,@url=url from ERP..tb_image d 
				inner join (
					select wearMediaId from ERP..tb_pattern_making a 
						inner join ERP..tb_design b on a.id = b.patternId 
						inner join ERP..tb_design_qrcode c on c.id = b.qrcode
					where styleId = @id
				) e on d.pid in (e.wearMediaId) order by  mainPic,id desc	

		--试穿图片不存在
		if(@url is null or @url='')
		begin
			if(@type=2) --正常的款
			select @originalId =originalId,@picid=picId  from ERP..mf_pCodeFabricMsg where id=@id

			if(@type=4) --终止开发的款
			select @originalId =originalId,@picid=picId  from ERP..mf_pCodeFabricMsg_his where id=@id

			--获取参考图
			select top 1 @weixinId=weixinId,@url=url
			 from ERP..tb_image where pid=@picid and pid>0 order by mainPic,id desc
		end

		--参考图片不存在 用原样图片
		if(@url is null or @url='')
		begin
			select top 1 @weixinId=weixinId,@url=url from ERP..tb_image 
			where pid = (select  picId from ERP..tb_original where  id=@originalId) 
			order by mainPic,id desc
		end
	end
	
    select @weixinId as weixinId,@url as url
     



