CREATE PROCEDURE [dbo].[Find_Lock]
AS
BEGIN
SET NOCOUNT ON;
declare @spid int,@blk int
DECLARE cur CURSOR FOR
select 0 ,blocked
from (select * from sysprocesses where blocked>0 ) a
where not exists(select * from (select * from sysprocesses where blocked>0 ) b
where a.blocked=spid)
union select spid,blocked from sysprocesses where blocked>0
OPEN cur
FETCH NEXT FROM cur INTO @spid,@blk
WHILE @@FETCH_STATUS = 0
begin
if @spid =0
select '引起死锁的进程号是 :'+ CAST(@blk AS VARCHAR(10)) +', 其执行的 SQL 语法如下'
else
select '进程号 SPID ：'+ CAST(@spid AS VARCHAR(10))+ '被 '+ '进程号 SPID ：'+ CAST(@blk AS VARCHAR(10)) +'
阻塞 , 其当前进程执行的 SQL 语法如下'
DBCC INPUTBUFFER (@blk )
FETCH NEXT FROM cur INTO @spid,@blk
end
CLOSE cur
DEALLOCATE cur
END
