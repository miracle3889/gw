-- =============================================
-- Author:		<runbin>
-- Create date: <2015-08-26>
-- Description:	<截取字符串中所有数字>
-- =============================================
CREATE FUNCTION [dbo].[f_getNumberFromStr] 
(
	@No varchar(100)
)
RETURNS varchar(100)
AS
BEGIN
	WHILE PATINDEX('%[^0-9]%',@No)>0
		BEGIN
			SET @No=STUFF(@No,PATINDEX('%[^0-9]%',@No),1,'')
		END
RETURN CONVERT(varchar,@No)

END
