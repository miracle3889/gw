/*  增加物料分解  */

CREATE PROCEDURE [dbo].[mf_addmfpCodeFabricMsg] @pCode varchar(32), @doManId int, @sheJiShiId int, @banShiId int, @remark varchar(320), @pCodeStr varchar(32)
						, @picPath varchar(128), @newYear int, @newSeason varchar(8), @newCategory varchar(8),
						 @urlPath varchar(128) ,@brandId int
AS
	DECLARE @nickId  int
	DECLARE @MsgIdValue INT
	SET @MsgIdValue=0
	DECLARE @returnValue INT
	SET @returnValue=0

	declare @brand varchar(10)
	BEGIN tran	
	
	
	-- 设定服装款号
	IF (@pCode is null or @pCode='')
	BEGIN
		DECLARE @intV int
		
		select @brand=fircha from SuperMarket..tb_Brand where id=@brandId
		
		select @nickId=id  from SuperMarket..tb_brandNick where brandId=@brandId 
		
		SET @intV=0 --where yearId=@newYear and season=@newSeason and category=@newCategory
		select  @intV=max(intV) from tb_pCodeInt  where -- yearId=@newYear and season=@newSeason and category=@newCategory and 
		brand=@brand and brand is not null and season is not null and category is not null
		
		if @intV is null
		set  @intV=1
		SET @pCode=@brand+'_'+CONVERT(VARCHAR(8),@newYear)+@newSeason+@newCategory+right(str(CONVERT(VARCHAR(8),@intV+1) + 10000000 ),5)

	    
	
		INSERT INTO tb_pCodeInt (yearId, season, category,brand, intV) VALUES (@newYear, @newSeason, @newCategory,@brand, @intV+1)
	END
		
    set @pCode= dbo.F_Ctofchar(@pCode,0)
	set @pCode=ltrim(rtrim(@pCode))
	set @pCode=UPPER(@pCode)
		
	IF (@pCode<>'NULL')
	BEGIN
	select top 1 @MsgIdValue=id from erp..mf_pCodeFabricMsg where  pCode=@pCode order by addDate desc
	IF (@MsgIdValue=0)
	BEGIN			
		
		exec p_addProductPcodeNew '',@pCode -- 添加商品，为商品添加服装款号，让服装款号和商品关联起来

		INSERT INTO mf_pCodeFabricMsg (pCode, doManId, sheJiShiId, banShiId, remark, picPath, urlPath,ruhnnbrandId)
			VALUES (@pCode, @doManId, @sheJiShiId, @banShiId, @remark, @picPath, @urlPath,@nickId)
		SET @MsgIdValue=SCOPE_IDENTITY()  
			if (@@error<>0)
			begin
				set @MsgIdValue=-1
			end
		--IF(@pCodeStr<>null and @pCodeStr<>'')
		--BEGIN
		--	INSERT INTO mf_pCodeFabricForm (pCodeFabricMsgId, formName, mfTypeId, oneCount, mfUnitId, remark, doManId)
		--	SELECT @MsgIdValue, formName, mfTypeId, oneCount, mfUnitId, remark, doManId FROM mf_pCodeFabricForm
		--	WHERE pCodeFabricMsgId=(select top 1 id from erp..mf_pCodeFabricMsg where  pCode=@pCodeStr order by addDate desc) and isDelete=0
		--		if (@@error<>0)
		--		begin
		--			set @returnValue=-2
		--			ROLLBACK tran
		--		end
		--END	
	END
	END
	commit tran

	SELECT @MsgIdValue 
	RETURN @MsgIdValue
