/*----------------增加 面辅料 在途 在库 金额 --------------------------------*/
CREATE PROCEDURE [dbo].[mf_addMfTuKuPrice] 
AS
	DECLARE @returnValue int
	set @returnValue=0
	
	DECLARE @tuPrice int
	set @tuPrice=0
	DECLARE @kuPrice int
	set @kuPrice=0
	
	IF NOT EXISTS ( select * from erp..mf_tu_ku_price where  DateDiff(dd,datetime,getdate())=0 )
	begin
		
		select @tuPrice=SUM(price)/100 from mf_purchaseNew a
		where a.isDelete=0 and arrivalCount=0 --在途


		select @kuPrice=SUM((a.stockCount/100)*(c.unitPrice/100)) from dbo.mf_pCodeFabricShelf a 
		inner join mf_pCodeFabricProtity b on a.pCodeFabricProtityId=b.id 
		inner join (
		select mfpCodeFabricProtityId,unitprice from mf_purchaseNew where id in(
		 select MAX(id) as mfpId from mf_purchaseNew where isDelete=0 group by mfpCodeFabricProtityId)
		 
		  ) c on c.mfpCodeFabricProtityId=b.id 
		where a.stockCount>0     --在库

		INSERT INTO mf_tu_ku_price (tuPrice, kuPrice) VALUES (@tuPrice, @kuPrice)
		set @returnValue=SCOPE_IDENTITY()
	end
	else
	begin
		set @returnValue=-1
	end
	SELECT @returnValue
