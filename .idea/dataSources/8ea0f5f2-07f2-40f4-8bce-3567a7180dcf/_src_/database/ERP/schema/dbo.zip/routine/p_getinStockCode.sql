/*--------------------------------------------------------------------得到入库单单号-----------------------------------------------*/
CREATE    PROCEDURE [dbo].[p_getinStockCode] @code VARCHAR(20) OUTPUT
AS	
	DECLARE @maxInt INT
	SET @maxInt=0

	SELECT @maxInt=MAX(intcode) FROM tb_inStockCodeTemp WHERE CONVERT(VARCHAR(10),GETDATE(),120)=CONVERT(VARCHAR(10),addDate,120) 
	IF(@maxInt=0 OR @maxInt IS NULL)
	BEGIN
		INSERT INTO tb_inStockCodeTemp(intcode,addDate) VALUES (1,getDATE())
		EXEC p_getNowDate @code OUTPUT
		SET @code='CJ'+@code+'0001'
	END
	ELSE
	BEGIN
		DECLARE @codeTemp VARCHAR(10)
		SET @maxInt=@maxInt+1
		SET @codeTemp=CAST(@maxInt AS VARCHAR(10))
		WHILE(LEN(@codeTemp)<4)
		BEGIN
			SET @codeTemp='0'+@codeTemp
		END
		EXEC p_getNowDate @code OUTPUT
		SET @code='CJ'+@code+@codeTemp
		INSERT INTO tb_inStockCodeTemp(intcode,addDate) VALUES (@maxInt,getDATE())
	END
