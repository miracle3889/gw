CREATE  procedure [dbo].[p_addTransFer] @doManId int
as
	declare @insertId int
	declare @code varchar(50)
	set @insertId=0
	
	exec p_getTransFerCode @code OUTPUT
	
	insert into tb_transFer(pCode,doMan) values(@code,@doManId)
	set @insertId=SCOPE_IDENTITY( ) --批号的id
	
	select @insertId
