-- 设置采购单 总采购数量、总收货数量、是否到货
CREATE PROCEDURE [dbo].[mf_updateMFpurchaseNewCountSystem] @id int, @purchaseNewId int
AS

	begin tran

		IF (@id<>0)
		BEGIN
			select @purchaseNewId=purchaseNewId from mf_purchaseNewCount where id=@id
		END
		
		--设置 采购总数
		

		DECLARE @i INT
		SET @i=0
		DECLARE @j INT
		SET @j=0
		SELECT @i=count(*) FROM ERP..mf_purchaseNewCount WHERE purchaseNewId=@purchaseNewId and arrivalCount=0 and isDelete=0

		SELECT @j=count(*) FROM ERP..mf_purchaseNewCount WHERE purchaseNewId=@purchaseNewId and arrivalCount!=0 and isDelete=0

		IF(@i=0) -- 全部到货
		BEGIN
			UPDATE ERP..mf_purchaseNew SET isDaoHuo=2 WHERE id=@purchaseNewId
		END
		IF (@i!=0 and @j!=0) -- 部分到货
		BEGIN
			UPDATE ERP..mf_purchaseNew SET isDaoHuo=1 WHERE id=@purchaseNewId
		END
		IF (@i!=0 and @j=0) -- 未到货
		BEGIN
			UPDATE ERP..mf_purchaseNew SET isDaoHuo=0 WHERE id=@purchaseNewId
		END

		DECLARE @purchaseCount INT
		SET @purchaseCount=0
		DECLARE @arrivalCount INT
		SET @arrivalCount=0
		SELECT @purchaseCount=SUM(purchaseCount), @arrivalCount=SUM(arrivalCount) FROM mf_purchaseNewCount WHERE isDelete=0 and purchaseNewId=@purchaseNewId

		UPDATE mf_purchaseNew SET purchaseCount=@purchaseCount, arrivalCount=@arrivalCount WHERE id=@purchaseNewId		

	commit tran
