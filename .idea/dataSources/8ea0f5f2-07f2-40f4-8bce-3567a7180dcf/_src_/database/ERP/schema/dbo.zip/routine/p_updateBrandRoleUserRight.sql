-- 修改用户关联店铺角色
CREATE PROCEDURE [dbo].[p_updateBrandRoleUserRight]
@role int,
@brandId int,
@userId varchar(2000)

as 
    DECLARE @PointerPrev int 
    DECLARE @PointerCurr int 
    DECLARE @TId int
    DECLARE @return int
    set @return=0
    Set @PointerPrev=0 
begin
	begin tran 
	
	--删除勾选了该店铺的角色级别下的用户的关联店铺的指定店铺权限
	delete from erp..tb_userBrandRight where brandId=@brandId and userId in 
	(select a.userId from ERP..tb_userBrand a 
	inner join ERP..tb_userRole b on a.userId=b.userId
	where a.brandId=@brandId and b.roleId=@role)
	
	--删除该角色级别下的所有用户的关联该店铺的关联
	delete from ERP..tb_userBrand where brandId=@brandId and userId in (select userId from ERP..tb_userRole where roleId=@role)
	
   while (@PointerPrev < LEN(@userId)) 
    Begin 
        Set @PointerCurr=CharIndex(',',@userId,@PointerPrev) 
        if(@PointerCurr>0) 
        Begin 
            set @TId=cast(SUBSTRING(@userId,@PointerPrev,@PointerCurr-@PointerPrev) as int) 
            SET @PointerPrev = @PointerCurr+1 
            insert into ERP..tb_userBrand (userId,brandId) values (@TId,@brandId)
        End 
        else 
            Break 
    End 
    set @TId=cast(SUBSTRING(@userId,@PointerPrev,LEN(@userId)-@PointerPrev+1) as int) 
    insert into ERP..tb_userBrand (userId,brandId) values (@TId,@brandId)
    set @return=1
    if @@ERROR<>0
		begin
			set @return=0
			rollback tran
		end
	 commit tran
end
select @return
