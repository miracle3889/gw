--退货报失
CREATE PROCEDURE [dbo].[p_setBackOrderSaleProductLose] @oderSaleProductId INT,@loseCount INT,@dealManId int,@remark VARCHAR(100)
AS
	DECLARE @productCode VARCHAR(50)
	DECLARE @backCount INT
	SELECT @productCode=b.productShelfCode,@backCount=backCount FROM supermarket..tb_backProduct a 
	INNER JOIN erp..tb_productStock b ON a.colorId=b.colorId AND a.metricsId=b.metricsId WHERE a.id=@oderSaleProductId

	IF(@backCount<@loseCount)
	BEGIN
		 SELECT -1 --大于了拒收数量
		 RETURN 
	END
	
	DECLARE @orderCode varchar(10)
	select @orderCode=code from supermarket.dbo.tb_backOder a
	inner join supermarket..tb_backProduct b on a.id=b.backId where b.id=@oderSaleProductId
	if(@orderCode is null ) set @orderCode=''
	set @remark=@remark+@orderCode 
	
	BEGIN TRAN 
		UPDATE supermarket..tb_backProduct SET loseCount=loseCount+@loseCount,loseRemark=@remark WHERE id=@oderSaleProductId
	
		EXEC p_addShelfStockByNotStock 'Y0000',@productCode,@loseCount,@dealManId,3,@remark
	COMMIT TRAN 
	SELECT 1
