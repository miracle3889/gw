/*----------------添加采购单(最新)--------------------------------*/
CREATE PROCEDURE  [dbo].[p_addBuyProductBatchNumber] @billType INT,--定单类型
						@productId INT,--商品id
						@supplyId INT,--供应商id
						 @buyPrice INT,--采购价格
						@buyCount INT,--采购数量
						@transportTypeId INT,--托运方式
						@remittancesPice INT,--汇款金额
						@invoicesType INT,--发票方式
						 @invoicesPrice INT,--发票金额
						@buyRemark VARCHAR(500),--购买备注
						@remittancesTime VARCHAR(50),--汇款时间
						@buyUserId INT,--采购人
						@transportPrice  INT, --运费
						@expectedInTime VARCHAR(50),--预计到货时间
						@isBuyStock  INT, --运费,
						@mfAddrId  INT ,--运费
						@batchNumber  INT --运费
AS
   	INSERT INTO dbo.tb_buyProductList(billType,productId,supplyId,buyPrice,
				     buyCount,transportTypeId,remittancesPice,
				     invoicesType,invoicesPrice,buyRemark,remittancesTime,
					buyUserId,transportPrice,expectedInTime,isBuyStock,mfAddrId,batchNumber)
	
	VALUES(@billType,@productId,@supplyId,@buyPrice,
				     @buyCount,@transportTypeId,@remittancesPice,
				     @invoicesType,@invoicesPrice,@buyRemark,@remittancesTime,
					@buyUserId,@transportPrice,@expectedInTime,@isBuyStock,@mfAddrId,@batchNumber)

	
	UPDATE erp..tb_product set fillTimeRemark=@expectedInTime,mfAddrId=@mfAddrId where id=@productId
	
SELECT SCOPE_IDENTITY()
