/******  关联样衣二维码 ******/
CREATE PROCEDURE [dbo].[p_addDesign_Qrcode]
	 @userId int,
	 @codeFabriMsg int,
	 @qrcodeId int
   AS
  begin 
		declare @patternId int --版式ID
		declare @patternName varchar(10)
		declare @designId int --样式ID
		declare @designMediaId int --设计稿PID
		declare @useryangyi int --样衣工
		declare @useryangyiname varchar(10) --样衣工名字
		declare @number int    --版号
		declare @bz varchar(200)
		declare @type int
		declare @username varchar(200)
		declare @ifConnect int
		select  @type=a.developMode,@patternName=d.name ,@patternId=mainPatternId,@designId=currentPattern,@useryangyi=a.yangyiId,@number=b.number from ERP..mf_pCodeFabricMsg a 
			inner join ERP..tb_pattern_making b on a.mainPatternId=b.id 
			--left join erp..tb_user c on c.id= a.yangyiId
			inner join erp..tb_user d on d.id = a.banShiId
			where a.id=@codeFabriMsg
		 --取用户名
	   select @username=name from tb_user where id=@userid
		--begin tran
			--insert into ERP..tb_log  select CAST(@userId as varchar(2))
			--insert into ERP..tb_multimedia_pid(type,count)values(1,0)  --新增原样多媒体
			--set @designMediaId = SCOPE_IDENTITY();
			--update ERP..mf_pCodeFabricMsg set designWrittenId=@designMediaId where id=@codeFabriMsg 
			--update ERP..tb_design set qrcode = @qrcodeId,connectDate = GETDATE() where id = @designId
			select @ifConnect = COUNT(id) from ERP..tb_design where qrcode is null and id = @designId
			if @ifConnect <> 0
			 begin
				update ERP..tb_design set qrcode = @qrcodeId,connectDate = GETDATE() where id = @designId
			 end 
			update ERP..tb_design_qrcode set patternId = @patternId where id=@qrcodeId
			--print @type
			if(@type<>1)
			begin
			 update ERP..mf_pCodeFabricMsg set statusId = 5 where id=@codeFabriMsg
			 --增加款式状态记录
			 set @bz = @username+'签收了厂商制作好的样衣'
			if(@number>0)
			 set @bz = @bz+'第'+CAST(@number as varchar(20))+'版'
				insert into tb_status_history (styleId,date,statusId,userId,bz)
		     values(@codeFabriMsg,GETDATE(),3,@userid,@bz)
			end
			--insert into ERP..tb_status_history(statusId,userId,styleId,bz) 
			--values(3,@userId,@codeFabriMsg,@bz)
			--insert into ERP..tb_log  select '111'
			--if @@ERROR<>0 
			-- rollback tran 
	    --commit tran
			
	        select wearMediaId from ERP..tb_design_qrcode where id=@qrcodeId
	end
