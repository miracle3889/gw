/*----------------添加服装来源--------------------------------*/
CREATE PROCEDURE     [dbo].[p_addYiSource] @source varchar(120),@urlPath varchar(320),@productName varchar(64),@price int,@color varchar(640),@metrics varchar(640),
				@fabric varchar(640),@saleCount varchar(320),@yiSortId int,@season varchar(20),@explain varchar(640),@remark varchar(640),
				@userId int,@yiTraderId int,@saleProposal varchar(1200),@sortYiId int,@yiPorjectId int,@yiEndProjectId int,@viewCount int
AS
   insert into tb_yiSource (source,urlPath,productName,price,color,metrics,
fabric,saleCount,yiSortId,season,explain,remark,userId,yiTraderId,saleProposal,yiSortYiId,yiProjectId,yiEndProjectId,viewCount ) 
values (@source,@urlPath,@productName,@price,@color,@metrics,
@fabric,@saleCount,@yiSortId,@season,@explain,@remark,@userId,@yiTraderId,@saleProposal,@sortYiId,@yiPorjectId,@yiEndProjectId,@viewCount)
SELECT SCOPE_IDENTITY()
