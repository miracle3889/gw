-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[p_initOriginal] 
	-- Add the parameters for the stored procedure here
	@initCount int
AS
declare @index int
declare @id_image int
declare @id_media int
declare @id_qrcode int
declare @id_original int
declare @designQrecodes varchar(500) --二维码ID集合
 set @designQrecodes=''
 set @index = 0;
 while @index<@initCount
BEGIN
	insert into ERP..tb_multimedia_pid(type,count) values(1,0)
	set @id_image=@@IDENTITY
	insert into ERP..tb_multimedia_pid(type,count) values(3,0)
	set @id_media=@@IDENTITY
	
	insert into ERP..tb_original (price,sourceId,status,typeId,picId,bzId,fisionerId)
	  values('0',-1,'-1',-1,@id_image,@id_media,0)
	set @id_original=SCOPE_IDENTITY()
	
	insert into ERP..mf_suppliderCardCodeQrcode (type,url) 
	  values (1,'http://www.liblin.com.cn/layercake/original/'+cast(@id_original as varchar(20))); 
	set @id_qrcode=SCOPE_IDENTITY()
	
	if(@designQrecodes='')
		begin
			set @designQrecodes=cast(@id_original as varchar(20))
		end
	else
		begin
			set @designQrecodes=@designQrecodes+','+cast(@id_original as varchar(20))
		end
	 set @index = @index+1
END
select @designQrecodes
