CREATE procedure [dbo].[p_updateTaobaoroduct] @id int,@status int,@doManId int
as
	update   erp..tb_needUpdateTaobao set status=@status where id=@id
	insert into tb_updateTaobaoHis(status,domanId,updateId) values(@status,@doManId,@id)
	if(@status=0)
	begin
		update erp..tb_needUpdateTaobao  set isYuShou=1 where id=@id 
	end
	select 1
