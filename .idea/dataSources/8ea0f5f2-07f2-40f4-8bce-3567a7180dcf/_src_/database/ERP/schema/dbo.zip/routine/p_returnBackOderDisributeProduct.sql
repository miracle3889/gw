CREATE procedure [dbo].[p_returnBackOderDisributeProduct] @userId int,@distributeId int,@orderID int,@distributeProductId int ,@shelfCode varchar(50),@productCount int
as
	
            declare @shelfProductCode varchar(50)
               declare @orderCode varchar(50)
   
	  select @shelfProductCode=b.ProductshelfCode,@orderCode=c.orderCode from tb_orderSaleProductDistribute a
	  inner join tb_productStock b on a.colorId=b.colorId and a.metricsId=b.metricsId and a.orderProductId=@distributeProductId
	  inner join tb_orderDistribute c on c.orderId=a.orderId and c.distributeId=a.distributeId
	  
	  update  tb_orderSaleProductDistribute set backShelfCode=@shelfCode,backCount=@productCount where distributeId=@distributeId and orderId=@orderId
		 and orderProductId=@distributeProductId
	 
	  set @orderCode=@orderCode+'压单'
	
	  exec  p_addShelfStockoverflowNewByType @shelfCode,@shelfProductCode,@productCount,@userId,@orderCode,8,9
