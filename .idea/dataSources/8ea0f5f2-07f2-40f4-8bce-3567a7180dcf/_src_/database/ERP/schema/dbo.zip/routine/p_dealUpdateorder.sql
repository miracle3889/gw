CREATE procedure [dbo].[p_dealUpdateorder] @orderId int
as
declare @isdelete int
select @isdelete=isdelete from Supermarket.dbo.tb_order where orderStatus in(13,20) and id=@orderid
if(@isdelete is null) set @isdelete=0
if(@isdelete=1)
begin
	update Supermarket.dbo.tb_order set isSet=1,deliverManId=-1 where id=@orderid
end
if(@isdelete=2)
begin
	update Supermarket.dbo.tb_order set orderStatus=1 , isdelete=0 ,deliverManId=-1 where id=@orderid
	insert into tb_orderstatusHis(orderId,orderstatus,doMan,remark) values(@orderid,1,1,'修改后的订单重新配货')
end
