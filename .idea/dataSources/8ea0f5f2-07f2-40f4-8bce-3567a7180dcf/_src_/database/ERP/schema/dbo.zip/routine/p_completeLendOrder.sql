CREATE procedure [dbo].[p_completeLendOrder] @lendId int,@domanId int
as 
	begin tran 
	declare @count int
	
	select @count =sum(productCount) from tb_lendOrderProduct where lendId=@lendId

	update tb_lendOrder set productCount=@count,lendstatus=1 where id=@lendId
	
	
	insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,productOldCount,dealManId,type,opType)
	
	select a.shelfCode,a.productCode,sum(a.productCount)  ,b.productCount,@domanId,-1,10 from tb_lendOrderProduct a
	inner join tb_shelfProductCount b on  a.productCode=b.productCode and a.shelfCode=b.shelfCode  
	 where lendId=@lendId  group by a.shelfCode,a.productCode ,b.productCount
	
		
	update tb_shelfProductCount set productCount=a.productCount-b.productCount
	 from tb_shelfProductCount a,(select productCode,shelfCode,sum(productCount) as productCount from   tb_lendOrderProduct  where   lendId=@lendId group by  productCode,shelfCode) b 
		where a.productCode=b.productCode and a.shelfCode=b.shelfCode     --and b.inStockTransferId=@transferId


	insert into  dbo.tb_productStockOpHis(productId,colorId,metricsId,oldCount,newCount,doMan,opType,remark)
		
	select a.productId,a.colorId,a.metricsId,a.productCount,a.productCount-b.productCount,@domanId,11,'商品借出' from tb_productStock a
	inner join (
select lendId,productCode,sum(productCount) as productCount
 from erp..tb_lendOrderProduct group by lendId,productCode ) as  b on a.productShelfCode=b.productCode  where a.productCount-b.productCount>=0   and lendId=@lendId

		
	update  dbo.tb_productStock  set productCount=a.productCount-b.productCount from dbo.tb_productStock a,
	(select lendId,productCode,sum(productCount) as productCount
 from erp..tb_lendOrderProduct group by lendId,productCode) as  b 
	where a.productShelfCode=b.productCode  and a.productCount-b.productCount>=0  and lendId=@lendId


	
	insert into supermarket..tb_updateTabaoProductCount(productCode,productCount,reMark) 
	select  a.productCode,sum(a.productCount),'借出' from tb_lendOrderProduct a
	inner join tb_shelfProductCount b on  a.productCode=b.productCode and a.shelfCode=b.shelfCode  
	 where lendId=@lendId  group by  a.productCode 
	 
	 select  @count=max(productCount) from tb_lendOrderProduct where lendId=@lendId
	 if(@count>=5)
	 begin
	 INSERT INTO c3.dbo.tb_smsMission(sourceType,mobileNum,content,sendTime,orderByClass,sendManId)
						select 1,'18668122055','【如涵】信息中心提醒您，发生借出操作，最大数量为'+CAST(@count as varchar(10))+',请确认操作行为是否正确。',
						GETDATE(),9999,1
	 INSERT INTO c3.dbo.tb_smsMission(sourceType,mobileNum,content,sendTime,orderByClass,sendManId)
						select 1,'13606818964','【如涵】信息中心提醒您，发生借出操作，最大数量为'+CAST(@count as varchar(10))+',请确认操作行为是否正确。',
						GETDATE(),9999,1
	 end
	commit tran
