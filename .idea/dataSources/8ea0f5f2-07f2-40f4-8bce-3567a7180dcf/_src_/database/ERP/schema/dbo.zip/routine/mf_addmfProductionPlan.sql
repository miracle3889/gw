/*  增加生产计划  */

CREATE PROCEDURE [dbo].[mf_addmfProductionPlan] @pCode varchar(32), @productId int, @saleCode varchar(8), @productionPurchaseDate varchar(32), 
				@productionOverDate varchar(32), @productionCount int, @mfAddrId int, @status int, @doManId int, @remark varchar(320), 
				@userId int, @newPlanId int, @newPlanNameAdd varchar(32), @newTypeId int, @newYear int, @newMonth int, @newBatch int, @type int, @productionPlanDownId int 
AS

	DECLARE @returnValue INT
	SET @returnValue=0

	BEGIN tran	
		set @pCode= dbo.F_Ctofchar(@pCode,0)
		set @pCode=ltrim(rtrim(@pCode))
		set @pCode=UPPER(@pCode)
--如果物料构成完成的话 可以下生产工单

	IF EXISTS ( SELECT * FROM mf_pCodeFabricMsg WHERE pCode=@pCode and status=1)
	BEGIN
		--IF (@newPlanId=0)
		--BEGIN
		--	IF NOT EXISTS ( SELECT * FROM mf_newPlan WHERE planName=@newPlanNameAdd)
		--	BEGIN		
		--		insert into mf_newPlan (planName) values (@newPlanNameAdd)
		--			SET @newPlanId=SCOPE_IDENTITY()	
		--	END
		--	ELSE
		--	BEGIN
		--		SELECT @newPlanId=id FROM mf_newPlan WHERE planName=@newPlanNameAdd
		--	END
		--END
		
	
		IF (@newTypeId <> 0 and @newYear <> 0 and @newBatch <> 0)
		BEGIN
			DECLARE @pCodeFabricMsgId INT
			SET @pCodeFabricMsgId =0
			SELECT @pCodeFabricMsgId=id FROM mf_pCodeFabricMsg WHERE pCode=@pCode and status=1 	
			
			--设定生产工单编号
			DECLARE @productionPlanCode VARCHAR(32)
			DECLARE @dateCode VARCHAR(32)
			SET @dateCode=CONVERT(VARCHAR(20),GETDATE(),120)
			SET @dateCode=SUBSTRING(@dateCode,3,2)+SUBSTRING(@dateCode,6,2)+SUBSTRING(@dateCode,9,2) --取得当前日期如070603
			SELECT @productionPlanCode='SC'+@dateCode+ right(str(CONVERT(VARCHAR(8),COUNT(*)+1) + 100000 ),3) FROM mf_productionPlan 
				WHERE CONVERT(VARCHAR(10),GETDATE(),120)=CONVERT(VARCHAR(10),addDate,120) 
			
			

			insert into mf_productionPlan (productionPlanCode, pCodeFabricMsgId, pCode, productId, saleCode, productionPurchaseDate, productionOverDate, productionCount, 
				mfAddrId, status, doManId, remark, userId, newPlanId, newTypeId, newYear, newMonth, newBatch)
			values (@productionPlanCode, @pCodeFabricMsgId, @pCode, @productId, @saleCode, @productionPurchaseDate, @productionOverDate, @productionCount, 
				@mfAddrId, @status, @doManId, @remark, @userId, @newPlanId, @newTypeId, @newYear, @newMonth, @newBatch)
				SET @returnValue=SCOPE_IDENTITY()
				if (@@error<>0)
				begin
					set @returnValue=-1
					ROLLBACK tran
				end
				else
				begin
					insert into mf_productionPlanTask (mfProductionPlanId, mfpCodeFabricFormId, planTaskCount, userId)
						select @returnValue, id, 0, @userId from mf_pCodeFabricForm where isDelete=0 and pCodeFabricMsgId=@pCodeFabricMsgId
				end
				
				IF (@type=1) -- 如果 type=1 则是 在 生产计划导出 里增加的生产计划
				BEGIN
					INSERT INTO mf_productionPlanDownMsg (productionPlanDownId, productionPlanId, doManId) VALUES (@productionPlanDownId, @returnValue, @doManId)
				END
				
				if exists(select 1 from erp..tb_productRespons where productId=@productId) 
				begin 
					update erp..tb_productRespons set supplyUserId=@userId where productId=@productId
				end 
				else
				begin
					insert into erp..tb_productRespons(productId,supplyUserId) values(@productId,@userId)
				end
		END
	END
	ELSE
	BEGIN
		set @returnValue=-2
	END
	commit tran

	SELECT @returnValue
