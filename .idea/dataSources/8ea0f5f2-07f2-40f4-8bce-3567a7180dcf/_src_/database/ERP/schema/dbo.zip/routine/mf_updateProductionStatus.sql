-- 增加生产任务
CREATE PROCEDURE [dbo].[mf_updateProductionStatus] @id INT, @userId INT
AS

	DECLARE @returnValue INT
	SET @returnValue = 0
	DECLARE @status INT
	DECLARE @productionId INT
	DECLARE @typeId INT
	SET @typeId=0

	begin tran

		update ERP..mf_productionStatus set isGet=1, isGetTime=getdate() where id=@id and userId=@userId
		if (@@error<>0)
		begin
			SET @returnValue = 0
			ROLLBACK tran
		end
		ELSE
		BEGIN
			SELECT @returnValue=id,@productionId=productionId, @typeId=typeId FROM ERP..mf_productionStatus WHERE id=@id and userId=@userId
		END


		IF (@typeId!=0)
		BEGIN

			IF (@typeId = 1 or @typeId = 2)
			BEGIN
				SET @status = 1 -- 准备中
			END
			IF (@typeId = 3)
			BEGIN
				SET @status = 2 -- 准备完成
			END
			IF (@typeId = 4 or @typeId = 5)
			BEGIN
				SET @status = 3 -- 生产中
			END
	
			update ERP..mf_production set status=@status where id=@productionId
			if (@@error<>0)
			begin
				SET @returnValue = 0
				ROLLBACK tran
			end
		END
	
	commit tran

	SELECT @returnValue
