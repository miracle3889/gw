/*********		新增图文编辑		***********/
CREATE PROCEDURE [dbo].[p_insertItemPicWords]
 @id	int,
 @userId	int,
 @weixinId	varchar(500),
 @saleId   int
AS

DECLARE @imageId	INT  --返回图片id
set @imageId=0
DECLARE @orderById	INT  --顺序ID
set @orderById=0
DECLARE @returnId	INT  --返回图文ID
set @returnId=0

BEGIN
	 begin tran 
		 insert into ERP..tb_image (mainPic,pid,updateTime,userId,weixinId) values (0,-1,GETDATE(),@userId,@weixinId)
		 set @imageId=SCOPE_IDENTITY()
		 
		 if(@id=0)
			begin
				update ERP..tb_itemPicWords set orderBy=orderBy+1 where saleId=@saleId
				set @orderById=1
			end
		 else
			begin
				select @orderById=orderBy from ERP..tb_itemPicWords where id=@id
				
				update ERP..tb_itemPicWords set orderBy=orderBy+1 where saleId=@saleId and orderBy>@orderById
				
				set @orderById=@orderById+1
			end
			
		insert into ERP..tb_itemPicWords (imageId,isDel,orderBy,saleId) values (@imageId,0,@orderById,@saleId)
		set @returnId=SCOPE_IDENTITY()
		 
		 if @@ERROR<>0
			begin
				set @returnId=0;
				rollback tran
			end
	 commit tran
END
select @returnId;
