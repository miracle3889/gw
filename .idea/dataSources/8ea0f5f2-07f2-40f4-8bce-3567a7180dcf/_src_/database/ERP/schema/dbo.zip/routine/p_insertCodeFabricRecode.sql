-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- ==================插入调料记录===========================
CREATE PROCEDURE [dbo].[p_insertCodeFabricRecode]
	@fabricNewId int,	--色卡id
	@mCount int,	--米数
	@userId int,	--设计师id
	@codeFabriMsgId int	--款式id
AS
declare @returnValue int
BEGIN 
	begin tran
		insert into ERP..tb_pCodeFabricRecode(fabricNewId,statusId,suppliderTime,ShejishiId,CountMeter,styleId)
					values(@fabricNewId,1,getdate(),@userId,@mCount,@codeFabriMsgId)
		set @returnValue=SCOPE_IDENTITY();
		select @returnValue
	commit tran
END
