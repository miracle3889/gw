-- 修改调整物料库存
CREATE PROCEDURE [dbo].[mf_updateFabricNewStockUpdate] @pCodeFabricProtityId INT,@pCodeFabricFormId INT,@productionPlanId INT, @shelfCode varchar(32), 
	@pCodeFabricProtityId2 INT,@pCodeFabricFormId2 INT,@productionPlanId2 INT, @shelfCode2 varchar(32), @mfCount2 INT, @doManId int 
AS

	DECLARE @returnValue INT
	SET @returnValue=0

	begin tran
		
		if ( @pCodeFabricProtityId<>0 and @pCodeFabricFormId<>0 and @productionPlanId<>0 and @pCodeFabricProtityId2<>0 and @pCodeFabricFormId2<>0 and @productionPlanId2<>0 and @mfCount2<>0 and @doManId<>0)	
		begin
			-- 修改物料库存  
			DECLARE @mfCount1 INT
			SET @mfCount1= @mfCount2*-1
			exec mf_updateFabricNewStock @pCodeFabricProtityId ,@pCodeFabricFormId ,@productionPlanId , @mfCount1 , @shelfCode , @doManId , 2 
			exec mf_updateFabricNewStock @pCodeFabricProtityId2 ,@pCodeFabricFormId2 ,@productionPlanId2 , @mfCount2 , @shelfCode2 , @doManId , 1  
			set @returnValue = 1
		end
		else
		begin
			set @returnValue = -2
		end
		
	commit tran

	
	SELECT @returnValue
	return @returnValue
