/*  设置服装的物料构成名称  */

CREATE PROCEDURE [dbo].[mf_setMFpCodeFabricFormCode] @pCodeFabricMsgId int
AS	
	--DECLARE @returnValue INT
	--SET @returnValue=0	

	IF (@pCodeFabricMsgId<>0)
	BEGIN
		declare @pCode varchar(32)
		declare @mfTypeName varchar(8)
		declare @mfTypeId int
		declare @mfTypeCount int
		select @pCode=pCode from erp..mf_pCodeFabricMsg where id=@pCodeFabricMsgId
				
		--下面的游标操作  为mf_pCodeFabricProtity 设定fabricCode
		DECLARE @allFabricCount int
		SET @allFabricCount=0
		select @allFabricCount=count(*) from erp..mf_pCodeFabricForm where pCodeFabricMsgId=@pCodeFabricMsgId and isDelete=0

		DECLARE fabricCursor CURSOR  
		FOR select id from erp..mf_pCodeFabricForm where pCodeFabricMsgId=@pCodeFabricMsgId and isDelete=0 ORDER BY mfTypeId, addDate asc 

		
		open fabricCursor --打开游标
		
		declare @pCodeFabricFormId int
		set @pCodeFabricFormId=0
		declare @ii int
		set @ii=1
		
		fetch next from fabricCursor into @pCodeFabricFormId
		while @@FETCH_STATUS=0
		begin
			select @mfTypeId=mfTypeId from erp..mf_pCodeFabricForm where id=@pCodeFabricFormId and isDelete=0
			
			IF (@mfTypeId=1)
			BEGIN
				SET @mfTypeName='面'
			END
			IF (@mfTypeId=2)
			BEGIN
				SET @mfTypeName='辅'
			END
			IF (@mfTypeId=3)
			BEGIN
				SET @mfTypeName='里'
			END
			
			update erp..mf_pCodeFabricForm set formName=@pCode+@mfTypeName+CAST(@allFabricCount as varchar(4))+'-'+CAST(@ii as varchar(4)) 
					where id=@pCodeFabricFormId and isDelete=0
			
			
			set @ii=@ii+1
			fetch next from fabricCursor into @pCodeFabricFormId
		end
		
		close fabricCursor  --关闭游标
		DEALLOCATE fabricCursor --释放游标

		
	END

	--SELECT @returnValue
