/*******************************出货更新库存*************************************************************/

CREATE  PROCEDURE [dbo].[p_setOutStockCount] @orderId INT
AS
	BEGIN TRAN 
	
	UPDATE dbo.tb_productStock  SET productCount=productCount-a.buyCount  
	FROM SuperMarket.dbo.tb_orderSaleProduct a,SuperMarket.dbo.tb_saleProduct 

	c,dbo.tb_product b 
	WHERE a.saleProductId=c.id  AND c.productId=b.id  AND a.orderId=@orderId 
	AND dbo.tb_productStock.colorId=a.colorId AND dbo.tb_productStock.metricsId=a.metricsId 
	and dbo.tb_productStock.productId=b.id
	

	UPDATE dbo.tb_outProduct  SET outCount=a.buyCount
	FROM SuperMarket.dbo.tb_orderSaleProduct a,SuperMarket.dbo.tb_saleProduct 

c,dbo.tb_product b 
	WHERE a.saleProductId=c.id  AND c.productId=b.id  AND a.orderId=@orderId AND dbo.tb_outProduct.colorId=a.colorId AND dbo.tb_outProduct.metricsId=a.metricsId


	IF(@@error<>0)
	BEGIN
		PRINT '111111111' 
	END
	COMMIT TRAN
