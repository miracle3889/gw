/*  修改物料 可选供应商 是否优先  */

CREATE PROCEDURE [dbo].[mf_updateMFpCodeFabricProtityStatus] @pCodeFabricProtityId INT, @pCodeFabricFormId INT
AS

	DECLARE @returnValue INT
	SET @returnValue=1
	
	UPDATE dbo.mf_pCodeFabricProtity set status=1 WHERE id=@pCodeFabricProtityId
	
	UPDATE dbo.mf_pCodeFabricProtity set status=0 WHERE id<>@pCodeFabricProtityId and pCodeFabricFormId=@pCodeFabricFormId
	
	
	
	SELECT @returnValue
