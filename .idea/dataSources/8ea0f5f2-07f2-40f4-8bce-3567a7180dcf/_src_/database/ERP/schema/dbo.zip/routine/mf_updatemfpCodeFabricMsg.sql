/*  修改物料分解  */

CREATE PROCEDURE [dbo].[mf_updatemfpCodeFabricMsg] @id int, @sheJiShiId int, @banShiId int,
 @remark varchar(320), @picPath varchar(32), @status int, @urlPath varchar(128),@yangyiId int
AS

	DECLARE @returnValue INT
	SET @returnValue=0

	BEGIN tran
	
	
		UPDATE erp..mf_pCodeFabricMsg SET sheJiShiId = @sheJiShiId , banShiId=@banShiId, remark=@remark, picPath=@picPath, status=@status, urlPath=@urlPath,yangyiId=@yangyiId WHERE id=@id
		declare @jstatus int 
		set @jstatus=0
		if(@banShiId>0) set @jstatus=2
			begin
				insert into tb_jstatusHis(pcode,jstatus)  
				select pcode,2 from  erp..mf_pCodeFabricMsg where id=@id  and jstatus <2
				UPDATE erp..mf_pCodeFabricMsg set jstatus=@jstatus where id=@id and jstatus <2
				
			end
		if(@yangyiId>0) set @jstatus=3
			begin
			insert into tb_jstatusHis(pcode,jstatus)  
				select pcode,3 from  erp..mf_pCodeFabricMsg where id=@id  and jstatus <3
			UPDATE erp..mf_pCodeFabricMsg set jstatus=@jstatus where id=@id and jstatus <3
			
			end
		  

		set @returnValue=1
	
	commit tran

	SELECT @returnValue
