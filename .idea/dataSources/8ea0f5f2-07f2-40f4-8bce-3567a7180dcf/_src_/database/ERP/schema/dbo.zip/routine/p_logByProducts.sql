-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[p_logByProducts] 
	-- Add the parameters for the stored procedure here
	@toTableName varchar(100), 
	@fromTableName varchar(100)
AS
BEGIN
declare @sql nvarchar(500)
	--插入新表
		set @sql = 'insert into '+@toTableName+'
			(
				[ip],
				[method] ,
				[description] ,
				[userName],
				[parameters] ,
				[type],
				[addDate] ,
				[takeTime] ,
				[userId],
				[isResponse]
				) 
			select 
				[ip],
				[method] ,
				[description] ,
				[userName],
				[parameters] ,
				[type] [int],
				[addDate] ,
				[takeTime] ,
				[userId] ,
				[isResponse]
			from 
			erp..tb_invokeLog_'+@fromTableName+' where DateDiff(dd,addDate,getdate()) >=1'

			exec sp_executesql @sql
			
			set @sql = 'delete erp..tb_invokeLog_'+@fromTableName+' where DateDiff(dd,addDate,getdate()) >=1'
		
			exec sp_executesql @sql
END
