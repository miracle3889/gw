/*-------------------------------添加出库单---------------------------------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[p_addOutStock] @outType INT,@adaptCode VARCHAR(20),@outMan INT,
					@doMan INT,@remark VARCHAR(200)
AS
	DECLARE @returnValue INT
	DECLARE @code VARCHAR(50)
	EXEC dbo.p_getOutStockCode @code OUTPUT
	SET @returnValue=0
	BEGIN TRAN
		INSERT INTO dbo.tb_outStock(outStockCode,outType,adaptCode,outMan,doMan,remark) 
		VALUES(@code,@outType,@adaptCode,@outMan,@doMan,@remark)
		SET @returnValue=SCOPE_IDENTITY( )
	COMMIT TRAN  
	SELECT @returnValue
