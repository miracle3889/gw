-- 修改物料库存货架  
CREATE PROCEDURE [dbo].[mf_updateMFpCodeFabricShelfAdjustment] @pCodeFabricShelfId INT, @mfCount INT, @shelfCode varchar(32), @doManId int 
AS

	DECLARE @isUpdate INT
	SET @isUpdate = 1

	begin tran
	
	DECLARE @pCodeFabricProtityId INT
	DECLARE @oldShelfCode VARCHAR(32)
	SELECT @pCodeFabricProtityId=pCodeFabricProtityId, @oldShelfCode=shelfCode FROM mf_pCodeFabricShelf WHERE id=@pCodeFabricShelfId
				
		if ( @pCodeFabricProtityId<>0 and @shelfCode is not null)	
		begin
			DECLARE @oldMFcount INT
			SET @oldMFcount = @mfCount * -1
			
			exec mf_updateFabricNewStock @pCodeFabricProtityId, 0, 0, @oldMFcount, @oldShelfCode, @doManId, 5 -- 老货架减掉库存  5代表货架调整 mf_stockType
			
			exec mf_updateFabricNewStock @pCodeFabricProtityId, 0, 0, @mfCount, @shelfCode, @doManId, 5 -- 新货架增加库存
		END
		else
		begin
			set @isUpdate = 0
		end
	
	commit tran

	SELECT @isUpdate
