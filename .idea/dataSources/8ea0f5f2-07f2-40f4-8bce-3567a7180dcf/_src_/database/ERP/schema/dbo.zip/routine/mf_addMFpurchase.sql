-- 增加采购单
CREATE PROCEDURE [dbo].[mf_addMFpurchase] @saleCode varchar(6), @mfFabricId int, @unitPrice int, @onSalePrice int, @price int, @fabricCount int, @userId int,
				@mfSupplidersId int, @arrivalDate datetime, @isPayDate datetime, @fabricCountList varchar(128), @pCode varchar(32),@productId int,@mfCode int

				,@fabricName varchar(64), @fabricTypeId int, @fabricColor varchar(64), @fabricUnitId int, @fabricOneCount int, @fabricRemark varchar(320)
AS

	DECLARE @returnValue INT	
	SET @returnValue=0
	
	begin tran

	IF (@saleCode='' and @productId='')
	BEGIN
		select @productId=a.id, @saleCode=b.saleCode from tb_product a, SuperMarket..tb_saleProduct b where pCode=@pCode and b.productId=a.id and b.saleTypeId=1
	END
	
	INSERT INTO ERP..mf_purchase (saleCode, mfFabricId, unitPrice, onSalePrice, price, fabricCount, userId, mfSupplidersId, arrivalDate, isPayDate,pCode,productId,mfCode) 
	VALUES (@saleCode, @mfFabricId, @unitPrice, @onSalePrice, @price, @fabricCount, @userId, @mfSupplidersId, @arrivalDate, @isPayDate,@pCode,@productId,@mfCode)
	SET @returnValue=SCOPE_IDENTITY()
	if (@@error<>0)
	begin
		ROLLBACK tran
	end

	/*****加入实际采购的面料****/
		DECLARE @returnFabricValue INT	
		SET @returnFabricValue=0

		insert into ERP..mf_fabricPurchase (name, typeId, unitId, color, remark, oneCount) 
			VALUES (@fabricName, @fabricTypeId, @fabricUnitId, @fabricColor, @fabricRemark, @fabricOneCount)
		SET @returnFabricValue=SCOPE_IDENTITY()
		IF (@returnFabricValue!=0)
		BEGIN
			UPDATE ERP..mf_purchase SET mfFabricPurchaseId=@returnFabricValue WHERE id=@returnValue
			UPDATE ERP..mf_fabric SET supplidersId=@mfSupplidersId WHERE id=@mfFabricId --有新的供应商的话，重置更新设计师选定供应商为新下采购单ID
		END


	
	IF (@returnValue<>0)
	BEGIN
		/*****如果增加采购单的面料 没有与pCode关联，则增加关联****/
		IF NOT EXISTS ( select * from erp..mf_pCodeFabric where  pCode = @pCode and fabricId=@mfFabricId)
		BEGIN
			INSERT INTO ERP..mf_pCodeFabric (pCode, fabricId) VALUES (@pCode, @mfFabricId)
		END
	END

	
	/*****如果增加采购单的面料采购匹数****/
	DECLARE @i INT
	SET @i=1
	while @i<=@fabricCount
	begin
		INSERT INTO ERP..mf_fabricCount (piCount, purchaseId, unitCount)
		VALUES (@i, @returnValue, SUBSTRING(@fabricCountList, 0,CHARINDEX(',',@fabricCountList)))
		if (@@error<>0)
		begin
			ROLLBACK tran
		end
		SET @fabricCountList= SUBSTRING(@fabricCountList, CHARINDEX(',',@fabricCountList)+1,len(@fabricCountList))
		SET @i=@i+1
	end

	commit tran

	SELECT @returnValue
