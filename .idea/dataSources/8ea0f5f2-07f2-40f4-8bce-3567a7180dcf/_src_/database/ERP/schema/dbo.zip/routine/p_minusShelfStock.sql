/*-----------------------下架----------------------*/
CREATE procedure [dbo].[p_minusShelfStock] @shelfCode varchar(50),@productCode varchar(50),@count int,@dealManId int
as 
	begin tran
		declare @oldCount int 
		
		select @oldCount=productCount from tb_shelfProductCount where shelfCode=@shelfCode and productCode=@productCode
		
		if(@oldCount is null)
			set @oldCount=0
		
		if(@oldCount>0)
		begin
		update tb_shelfProductCount set productCount=productCount-@count where shelfCode=@shelfCode and productCode=@productCode
	
		if(@@error<>0)
			rollback tran 
		insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,productOldCount,dealManId,type) values(@shelfCode,@productCode,@count,@oldCount,@dealManId,-1)
		if(@@error<>0)
			rollback tran 

		end
	commit tran
