CREATE  procedure [dbo].[p_getBackProductStatus] 
as 

declare @dealingPrice int
declare @dealedPrice int
declare @inWyPrice int
declare @rejectPrice int
declare @backPrice int
declare @clzPrice int
SELECT  
@dealingPrice=sum(  instockCount*d.stockPriceReal) /100 

FROM tb_orderInstock a
inner join tb_orderInstockProduct b on b.instockId=a.id 
inner join tb_productStock c on c.productShelfCode=b.productCode
inner join tb_product d on d.id=c.productId
WHERE (status IN (1)) AND (deliverTime IS NOT NULL) AND (receviceTime IS NOT NULL)



SELECT  @dealedPrice=sum(  instockCount*d.stockPriceReal) /100 
FROM tb_orderInstock a
inner join tb_orderInstockProduct b on b.instockId=a.id 
inner join tb_productStock c on c.productShelfCode=b.productCode
inner join tb_product d on d.id=c.productId
WHERE (status IN ( 2))  and convert(varchar(10),oktime,120)=convert(varchar(10),getDate(),120)



SELECT  @inWyPrice=sum(  instockCount*d.stockPriceReal) /100 
FROM tb_orderInstock a
inner join tb_orderInstockProduct b on b.instockId=a.id 
inner join tb_productStock c on c.productShelfCode=b.productCode
inner join tb_product d on d.id=c.productId
WHERE (status IN (0,1)) AND (deliverTime IS NOT NULL) AND (receviceTime IS  NULL)


SELECT  @clzPrice=sum(  instockCount*d.stockPriceReal) /100 
FROM tb_orderInstock a
inner join tb_orderInstockProduct b on b.instockId=a.id 
inner join tb_productStock c on c.productShelfCode=b.productCode
inner join tb_product d on d.id=c.productId
WHERE (status IN (0,1)) AND (deliverTime IS  NULL) AND (receviceTime IS  NULL)


select @rejectPrice=sum(b.buyCount*c.stockPriceReal)/100 from supermarket..tb_rejectOrder a
inner join supermarket..tb_orderSaleProduct b on a.orderId=b.orderId and b.backCount>0 
inner join tb_product c on c.id=b.productId  



select @backPrice=sum(b.getCount*d.stockPriceReal)/100 from supermarket..tb_backOder a
inner join supermarket..tb_backProduct b on a.id=b.backId

inner join tb_productColorCode c on c.id=b.colorId
inner join tb_product d on d.id=c.productId
 where a.id not in(select orderId from erp..tb_orderInstockOrder where type=3) and  visaTime >='2010-09-01'

and a.isDeleted!=1 and backStatusId in(3,4) and getCount>0



select @dealingPrice as 处理中金额 ,@dealedPrice 今日处理,@inWyPrice 在途,@clzPrice 分点录入,@rejectPrice 未处理拒收,@backPrice 未处理退货
