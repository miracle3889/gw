/*------------------添加借出记录------------------------------*/
CREATE PROCEDURE [dbo].[P_addLend] @lendMan VARCHAR(50),@doManId INT,
			   @reMark VARCHAR(200)
AS 
	DECLARE @returnValue INT 
	SET @returnValue=0
	BEGIN TRAN 
		INSERT INTO dbo.tb_Lend(lendMan,doMan,reMark) VALUES(@lendMan,@doManId,@reMark)
		SET @returnValue=SCOPE_IDENTITY( )
	COMMIT TRAN
	SELECT @returnValue
