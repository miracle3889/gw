CREATE   procedure [dbo].[p_addInstockTransFer] @doManId int
as
	declare @insertId int
	declare @code varchar(50)
	set @insertId=0
	
	exec p_getinStockCode @code OUTPUT
	
	insert into tb_InstockTransFer(pCode,doMan) values(@code,@doManId)
	set @insertId=SCOPE_IDENTITY( ) --批号的id
	
	select @insertId
	
	exec p_addProductTostockAll44  @insertId

	 exec p_changerInstockTransferOk @insertId ,@doManId
