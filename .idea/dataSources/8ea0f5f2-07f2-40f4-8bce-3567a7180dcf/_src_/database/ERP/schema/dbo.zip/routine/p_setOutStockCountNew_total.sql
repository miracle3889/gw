/*******************************出货更新库存*************************************************************/
CREATE    PROCEDURE [dbo].[p_setOutStockCountNew_total] @orderId INT
AS
	BEGIN TRAN  
              
            			 INSERT INTO tb_updateOrderCountHis(orderId) VALUES(@orderId) --添加定单处理记录
	
			UPDATE Supermarket.dbo.tb_order  SET orderStatus=2,isUpdate=0,setTime=getDate() WHERE id=@orderId  --减库存失败则更新定单状态
	
			--减单件商品的库存
			/*UPDATE dbo.tb_productStock  
			SET productCount=productCount-a.buyCount  
			FROM	 SuperMarket.dbo.tb_orderSaleProduct a,SuperMarket.dbo.tb_saleProduct c,dbo.tb_product b 
			WHERE a.saleProductId=c.id  AND c.productId=b.id  AND a.orderId=@orderId AND dbo.tb_productStock.colorId=a.colorId 
			AND dbo.tb_productStock.metricsId=a.metricsId AND dbo.tb_productStock.productId=b.id
			*/
			UPDATE dbo.tb_productStock  
			SET productCount=productCount-t.total_buyCount
			from (
			select x.productId,a.colorId,a.metricsId,sum(a.buyCount) as total_buyCount
			FROM	dbo.tb_productStock x, SuperMarket.dbo.tb_orderSaleProduct a,SuperMarket.dbo.tb_saleProduct c,dbo.tb_product b 
			WHERE a.saleProductId=c.id  AND c.productId=b.id  AND a.orderId=@orderId AND x.colorId=a.colorId 
			AND x.metricsId=a.metricsId AND x.productId=b.id
			group by x.productId,a.colorId,a.metricsId) t
			where dbo.tb_productStock.colorId=t.colorId 
			AND dbo.tb_productStock.metricsId=t.metricsId 
			AND dbo.tb_productStock.productId=t.productId
			
			/*
			--减组合商品的库存
			UPDATE tb_productStock SET productCount=productCount-a.buyCount*b.buyCount
			FROM  SuperMarket.dbo.tb_orderSaleGroup a
			INNER join SuperMarket.dbo.tb_orderSaleGroupProduct b ON b.orderSaleGroupId=a.id
			INNER join SuperMarket.dbo.tb_saleProduct c ON c.id=b.saleProductId
			WHERE a.orderId=@orderId and b.colorId=dbo.tb_productStock.colorId and b.metricsId=dbo.tb_productStock.metricsId and c.productId=dbo.tb_productStock.productId
			*/
        			
			update tb_outProduct set outCount=0
			from tb_outStock a 
			inner join SuperMarket.dbo.tb_order b on a.adaptCode=b.orderCode
			where tb_outProduct.outId=a.id and b.id=@orderId
		
			update tb_outProduct set outCount=outCount+a.buyCount
			from SuperMarket.dbo.tb_orderSaleProduct a
			inner join SuperMarket.dbo.tb_saleProduct b on b.id=a.saleProductId
			inner join SuperMarket.dbo.tb_order c on c.id=a.orderId
			inner join tb_outStock d on d.adaptCode=c.orderCode
			where a.orderId=@orderId and tb_outProduct.colorId=a.colorId and tb_outProduct.metricsId=a.metricsId and tb_outProduct.productId=b.productId and tb_outProduct.outId=d.id
			
			update tb_outProduct set outCount=outCount+a.buyCount*b.buyCount
			from SuperMarket.dbo.tb_orderSaleGroup a
			inner join SuperMarket.dbo.tb_orderSaleGroupProduct b on a.id=b.orderSaleGroupId
			inner join SuperMarket.dbo.tb_saleProduct c on c.id=b.saleProductId
			inner join SuperMarket.dbo.tb_order d on d.id=a.orderId
			inner join tb_outStock e on e.adaptCode=d.orderCode
			where a.orderId=@orderId and tb_outProduct.colorId=b.colorId and tb_outProduct.metricsId=b.metricsId and tb_outProduct.productId=c.productId and tb_outProduct.outId=e.id
	
			IF(@@error<>0)
			BEGIN
                                                      PRINT '1111'
				ROLLBACK TRAN 
			END

	COMMIT TRAN
