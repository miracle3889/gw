/*  增加生产计划  */

CREATE PROCEDURE [dbo].[mf_addmfNewPlan] @planName varchar(32)
AS

	DECLARE @returnValue INT
	SET @returnValue=0

	BEGIN tran

	IF NOT EXISTS ( SELECT * FROM mf_newPlan WHERE planName=@planName)
	BEGIN
	
		insert into mf_newPlan (planName) values (@planName)
			SET @returnValue=SCOPE_IDENTITY()
			if (@@error<>0)
			begin
				set @returnValue=-1
				ROLLBACK tran
			end
			
	END
	ELSE
	BEGIN
		set @returnValue=-2
	END
	commit tran

	SELECT @returnValue
