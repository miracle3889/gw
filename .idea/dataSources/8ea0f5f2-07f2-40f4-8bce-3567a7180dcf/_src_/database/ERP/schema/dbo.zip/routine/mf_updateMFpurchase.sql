/*  修改采购单  */

CREATE PROCEDURE [dbo].[mf_updateMFpurchase] @saleCode varchar(32), @pCode varchar(32), @unitPrice int, @onSalePrice int, @price int, 
		@userId int, @mfSupplidersId int, @arrivalDate varchar(32), @isPayDate varchar(32), @productId int, @id int, 

		@fabricName varchar(64), @fabricTypeId int, @fabricColor varchar(64), @fabricUnitId int, @fabricOneCount int, @fabricRemark varchar(320)
AS

	DECLARE @returnValue INT
	SET @returnValue=0

	DECLARE @mfFabricPurchaseId INT
	SET @mfFabricPurchaseId=0
	
	UPDATE ERP..mf_purchase SET saleCode=@saleCode, pCode=@pCode, unitPrice=@unitPrice, onSalePrice=@onSalePrice,
				price=@price, userId=@userId, mfSupplidersId=@mfSupplidersId, arrivalDate=@arrivalDate, isPayDate=@isPayDate, productId=@productId 
		WHERE id=@id
	
	SELECT @mfFabricPurchaseId=mfFabricPurchaseId FROM erp..mf_purchase WHERE id=@id
	IF @mfFabricPurchaseId=0
	begin
		insert into ERP..mf_fabricPurchase (name, typeId, unitId, color, remark, oneCount) 
			VALUES (@fabricName, @fabricTypeId, @fabricUnitId, @fabricColor, @fabricRemark, @fabricOneCount)
		SET @returnValue=SCOPE_IDENTITY()
		IF (@returnValue!=0)
		BEGIN
			UPDATE ERP..mf_purchase SET mfFabricPurchaseId=@returnValue WHERE id=@id
		END
	END
	ELSE
	BEGIN
		UPDATE ERP..mf_fabricPurchase SET name=@fabricName, typeId=@fabricTypeId, unitId=@fabricUnitId, 
				color=@fabricColor, remark=@fabricRemark, oneCount=@fabricOneCount WHERE id=@mfFabricPurchaseId
	END
	

	SELECT @returnValue
