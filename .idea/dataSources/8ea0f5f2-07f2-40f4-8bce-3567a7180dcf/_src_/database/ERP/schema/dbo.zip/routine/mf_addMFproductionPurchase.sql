/*  增加面辅料  */

CREATE PROCEDURE [dbo].[mf_addMFproductionPurchase] @productionId INT, @purchaseId INT
AS

	DECLARE @returnValue INT
	SET @returnValue=0
	
	IF NOT EXISTS ( select * from erp..mf_productionPurchase where  productionId = @productionId and purchaseId=@purchaseId and isDelete=0)
	begin
		insert into ERP..mf_productionPurchase (productionId, purchaseId) VALUES (@productionId, @purchaseId)
		SET @returnValue=SCOPE_IDENTITY()
	END

	SELECT @returnValue
