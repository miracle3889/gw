CREATE procedure [dbo].[p_checkUser] @userName varchar(50),@psw varchar(50),@openId varchar(200)
as
if exists (select 1 from erp.dbo.tb_user where openId=@openId)
	return 0 
  else
  begin
	  declare @id int 
	  select  @id=id  from erp.dbo.tb_user  where userName=@userName  and psw=dbo.md5(@psw) 
	  and isCanLoginIn=1 and ISNULL(openId,'')=''
	  if(@id is not null and @id>0)
	  begin
		update   erp.dbo.tb_user  set openId=@openId where id=@id
		select 1
	  end
	  else
	  begin
		select 0
	  end
	end
