CREATE function [dbo].[f_parseProblemDesc]( @status int)
RETURNS VARCHAR(50)
as 
begin
	declare @problemDesc varchar(200)	
	if(@status=0)
		set @problemDesc=''
	if(@status=1)
		set @problemDesc='完全相符'
	if(@status=2)
		set @problemDesc='报损不能入库'
	if(@status=3)
		set @problemDesc='没有这件'
	if(@status=4)
		set @problemDesc='颜色尺码不符'
	return @problemDesc
end
