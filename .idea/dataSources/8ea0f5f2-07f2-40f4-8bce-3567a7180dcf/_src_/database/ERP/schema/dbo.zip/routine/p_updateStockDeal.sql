/*------------------处理仓库入库信息<仓库对到货商品的处理意见>-------------------*/
CREATE   PROCEDURE [dbo].[p_updateStockDeal] @buyProductId INT,@arrivedTime VARCHAR(50),
				   @transportPrice INT,@stockRemark VARCHAR(500),
				   @type INT,@userId INT
AS
  DECLARE @userName VARCHAR(50)
  DECLARE @remark VARCHAR(500)
  IF(@type=1) --提交不一致意见
  BEGIN
	SELECT @userName=name FROM tb_user WHERE id=@userId --得到用户姓名
	SET @remark=CONVERT(VARCHAR(20),getDate(),120)+'仓库'+@userName+':'+@stockRemark+'<br>'
	UPDATE dbo.tb_buyProductList SET arrivedTime=@arrivedTime,transportPriceStock=@transportPrice,stockRemark=stockRemark+@remark,buyStatus=3 WHERE id=@buyProductId--更新备注
  END 
  ELSE 
  BEGIN
	DECLARE @productId INT
	DECLARE @colorId INT
	DECLARE @metricsId INT
	DECLARE  @buyPrice INT
	DECLARE  @stockPrice INT
	DECLARE @buyCount INT
	DECLARE @buyId INT
	DECLARE @b_id INT
	DECLARE @mfAddrId INT
	DECLARE @buyCountT INT
	DECLARE @categoryOneId INT
	declare @shelfCodeMf varchar(10)
	set @buyCountT=0
	
	--begin tran
	SELECT @productId=productId,@buyPrice=buyPrice,@buyId=buyUserId,@mfAddrId=mfAddrId  FROM dbo.tb_buyProductList WHERE id=@buyProductId --得到商品id
	
	select @stockPrice=stockPriceReal,@categoryOneId=categoryOneId from tb_product where id=@productId

		if(@categoryOneId=51)
			begin
				
				select @shelfCodeMf=mfGoodShelf from mf_addrs where id=@mfAddrId
			end
		
		DECLARE  cs CURSOR FOR 
		SELECT  id,colorId,metricsId,buyCount
		FROM  dbo.tb_buyProductProtity WHERE buyProductId=@buyProductId   --AND isIn=0 --得到所有的规格信息
		OPEN cs
		FETCH NEXT FROM cs
		INTO @b_id,@colorId,@metricsId,@buyCount
		WHILE @@fetch_status =0
		BEGIN		
			set @buyCountT=@buyCountT+@buyCount

			exec p_addProductStockCount  @productId,@colorId,@metricsId,@buyCount,1,@userId,'采购入库'

			UPDATE dbo.tb_buyProductProtity SET isIn=1 WHERE id=@b_id --设置该记录已经入库
			
			--取SKU编号
			select @remark=productShelfCode from tb_productStock 
			WHERE productId=@productId AND colorId=@colorId AND metricsId=@metricsId

			--SKU编号不存在
			if(@remark is null  or @remark='') 
			begin
				declare @productCode varchar(50) 
				exec p_getShelfProductCode @productId,@colorId,@metricsId,@productCode output
				
				if(@productCode is null) 
				begin
					set @productCode=''
				end
				set @remark=@productCode 
				update tb_productStock set productShelfCode =@productCode where productId=@productId and colorId=@colorId and metricsId=@metricsId
				if not exists (select 1 from erp..tb_productSkuCode where productId=@productId and colorId=@colorId and metricsId=@metricsId )
				begin
					insert into tb_productSkuCode(productShelfCode,productId,colorId,metricsId) values(@productCode,@productId,@colorId,@metricsId)
				end
			end	
			
			
			if(@buyId=221)--为换货账户需要减掉X0000商品
				begin
					exec p_minusShelfStockWithNoCount  'X0000',@remark,@buyCount,@userId,0,'换货入库'
				end
			
			if(@categoryOneId<>51)
			begin
				exec p_addShelfStock 'A0000',@remark,@buyCount,@userId
			end
			else
			begin
				exec p_addShelfStock @shelfCodeMf,@remark,@buyCount,@userId
			end
			

			FETCH NEXT FROM cs
			INTO @b_id,@colorId,@metricsId,@buyCount
		END
		
		CLOSE cs
		DEALLOCATE cs		

	--IF(@@ERROR<>0) 
		--ROLLBACK TRAN 
	--COMMIT TRAN 

		update supermarket..tb_saleproduct set isdeleted=0 where isdeleted=1  and  isSystem=0 and productid=@productId --下架商品上架
	
		if not exists(select 1 from tb_productStock where productId=@productId)
		begin
			if(@buyId<>221)--为换货账户不算入采购成本
				begin
					--update tb_product set  stockPrice=@buyPrice,stockPriceReal=@buyPrice where id=@productId
					 print '11'
				end
		end
		else
		begin
			if(@buyId<>221)--为换货账户不算入采购成本
				begin
					declare @tempCount int
					declare @stockPriceReal int
					select @tempCount=sum(productCount) from tb_productStock where  productId=@productId
					
					if(@tempCount is null) set @tempCount=0	
				
					set @stockPriceReal=(@stockPrice*@tempCount+@buyPrice*@buyCountT)/(@tempCount+@buyCountT)
					
					--update tb_product set  stockPriceReal=@stockPriceReal where id=@productId
				end
		end

		
		UPDATE dbo.tb_buyProductList SET arrivedTime=@arrivedTime,inTime=getDate(),transportPriceStock=@transportPrice,buyStatus=4,inUserId=@userId WHERE id=@buyProductId --设置该采购单完成,transportPrice=@transportPrice
		declare @totalPrice int
		declare @oldPrice int 
		select @transportPrice=transportPrice  from  tb_buyProductList where id=@buyProductId
		set @totalPrice=@buyCountT*@buyPrice+@transportPrice
		select @oldPrice=account from tb_userAccount   where userId=@buyId
		if(@oldPrice is null) set @oldPrice=0
		insert into tb_userAccountMinus(inId,inPrice,oldPrice) values(@buyProductId,@totalPrice,@oldPrice)
		update tb_userAccount set account=account-@totalPrice  where userId=@buyId

		if not EXISTS( select 1 from dbo.tb_buyProductList where productId=@productId and buystatus in(1,2,3) and isdeleted<>1 )
		begin
			update tb_product set fillTimeRemark='' where id=@productId
		end

		
	
  END
