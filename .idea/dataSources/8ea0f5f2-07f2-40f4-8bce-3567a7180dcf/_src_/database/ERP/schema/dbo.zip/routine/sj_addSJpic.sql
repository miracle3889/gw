/*  增加设计师选款图片  */

CREATE PROCEDURE [dbo].[sj_addSJpic] @picUrl varchar(64), @productProtityId int, @gradeId int, @seasonId int, @status int, @pCode varchar(32)
						, @userId int, @remark varchar(128), @doManId int, @productProtityName varchar(32), @voteRemark varchar(128)  
AS

	DECLARE @picIdValue INT
	SET @picIdValue=0

	BEGIN tran	
	
	DECLARE @picCode VARCHAR(64)
	DECLARE @seasonName VARCHAR(16)
	DECLARE @protityName VARCHAR(32)
	DECLARE @picCount INT
	SET @picCount = 0
	
	IF (@productProtityName<>null and @productProtityName<>'' and len(@productProtityName)>0)
	BEGIN
		IF NOT EXISTS (SELECT * FROM sj_pic_productProtity WHERE protityName=@productProtityName)
		BEGIN
			INSERT INTO sj_pic_productProtity (protityName) VALUES (@productProtityName)
			SET @productProtityId=SCOPE_IDENTITY()
		END
		ELSE
		BEGIN
			SELECT @productProtityId=id FROM sj_pic_productProtity WHERE protityName=@productProtityName
		END
	END
	
	-- 设定图片编号
	SELECT @seasonName = seasonName FROM sj_pic_season WHERE id=@seasonId
	SELECT @protityName = protityName FROM sj_pic_productProtity WHERE id=@productProtityId
	SELECT @picCount = isnull(MAX(intV),0) FROM dbo.sj_pic_intV WHERE productProtityId=@productProtityId
	SET @picCount = @picCount + 1
	SET @picCode = @seasonName+'_' + @protityName+'_' + CONVERT(VARCHAR(8),@picCount)
	
	--  增加指定图片属性的最大编号
	INSERT INTO dbo.sj_pic_intV	(productProtityId, intV) VALUES (@productProtityId, @picCount)
	
		
	IF NOT EXISTS ( SELECT * FROM sj_pic WHERE picCode=@picCode)
	BEGIN		
			
		INSERT INTO sj_pic (picCode, codeInt, picUrl, productProtityId, gradeId, seasonId, status, pCode, userId, remark, doManId, voteRemark)
					VALUES (@picCode, @picCount, @picUrl, @productProtityId, @gradeId, @seasonId, @status, @pCode, @userId, @remark, @doManId, @voteRemark)
			SET @picIdValue=SCOPE_IDENTITY()  
			IF (@@error<>0)
			BEGIN
				SET @picIdValue=-1
			END

	END
	ELSE
	BEGIN
		SET @picIdValue=-2
	END
	commit tran

	SELECT @picIdValue 
	RETURN @picIdValue
