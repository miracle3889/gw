/*****--------------------------已不用-----得到采购定单的编号----------------------------------------*/
CREATE PROCEDURE [dbo].[p_getBuyBillCode] @code VARCHAR(20) OUTPUT
AS	
	DECLARE @maxInt INT
	SET @maxInt=0

	SELECT @maxInt=MAX(intcode) FROM tb_billCodeTemp WHERE CONVERT(VARCHAR(10),GETDATE(),120)=CONVERT(VARCHAR(10),addDate,120) AND type=1
	IF(@maxInt=0 OR @maxInt IS NULL)
	BEGIN
		INSERT INTO tb_billCodeTemp(intcode,addDate,type) VALUES (1,getDATE(),1)
		EXEC p_getNowDate @code OUTPUT
		SET @code='C'+@code+'001'
	END
	ELSE
	BEGIN
		DECLARE @codeTemp VARCHAR(10)
		SET @maxInt=@maxInt+1
		SET @codeTemp=CAST(@maxInt AS VARCHAR(10))
		WHILE(LEN(@codeTemp)<3)
		BEGIN
			SET @codeTemp='0'+@codeTemp
		END
		EXEC p_getNowDate @code OUTPUT
		SET @code='C'+@code+@codeTemp
		INSERT INTO tb_billCodeTemp(intcode,addDate,type) VALUES (@maxInt,getDATE(),1)
	END
