/*  增加物料分解的面辅料  */

CREATE PROCEDURE [dbo].[mf_updatemfpCodeFabricProtity] @fabricNewId int, @colorCard varchar(32), @fabricName varchar(32), @fabricColor varchar(32), 
				@supplidersId int 
AS

	DECLARE @returnValue INT
	SET @returnValue=0
	
	BEGIN tran
	
	IF( @fabricNewId<>0 and (@colorCard is not null and @colorCard<>'') 
		and (@fabricName is not null and @fabricName<>'') and (@fabricColor is not null and @fabricColor<>'') )
	BEGIN
		IF NOT EXISTS ( select * from erp..mf_fabricNew where  id<>@fabricNewId and colorCard=@colorCard and isDelete=0)
		BEGIN
			UPDATE mf_fabricNew SET colorCard=@colorCard , fabricName=@fabricName, fabricColor=@fabricColor, supplidersId=@supplidersId 
				WHERE id=@fabricNewId
			
			if (@@error<>0)
			begin
				set @returnValue=-1
			end
			else
			begin
				set @returnValue=1
			end
		END
		ELSE
		BEGIN
			set @returnValue=-2
		END
	END
	
	
	commit tran

	SELECT @returnValue
