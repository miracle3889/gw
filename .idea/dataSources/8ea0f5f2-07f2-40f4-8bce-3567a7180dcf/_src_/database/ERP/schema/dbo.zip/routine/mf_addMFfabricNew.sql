/*  增加 物料色卡  */

CREATE PROCEDURE [dbo].[mf_addMFfabricNew] @colorCard varchar(32), @fabricName varchar(32), @fabricColor varchar(32), 
				@supplidersId int, @doManId int, @colorShelf varchar(32), @picUrl varchar(32), @remark varchar(640),@type int, @searchTag varchar(64) 
AS

	DECLARE @mfFabricNewId INT
	SET @mfFabricNewId=0
	
	BEGIN tran
	
	IF( (@colorShelf is not null and @colorShelf<>'') and @supplidersId<>0 
		and (@fabricName is not null and @fabricName<>'') and (@fabricColor is not null and @fabricColor<>'') )
	BEGIN
		
		IF NOT EXISTS ( SELECT * FROM mf_fabricNew WHERE colorCard=@colorCard )
		BEGIN
						
			IF (@colorCard is null or @colorCard='' or @colorCard='null')
			BEGIN
				-- 取出供应商编码
				DECLARE @supplidersCode VARCHAR(8)
				SELECT @supplidersCode=supplidersCode FROM mf_suppliders WHERE id=@supplidersId 
				
				select * from mf_suppliders where name ='一万布业'
				--//
				-- 设定当前供应商包含的色卡数量
				DECLARE @supplidersCount int
				SET @supplidersCount=0				
				SELECT top 1 @supplidersCount=isnull(cast(SUBSTRING(colorCard,2, 4) as int),0) FROM mf_fabricNew 
					WHERE  SUBSTRING(colorCard,6,LEN(colorCard))=@supplidersCode --supplidersId=@supplidersId
					 order by SUBSTRING(colorCard,2, 4) desc
				
				
				IF (@type=0) -- 0面、里料  1辅料
				BEGIN
					SET @colorCard= 'B'+right(str(CONVERT(VARCHAR(8),@supplidersCount+1) + 100000 ),4)+@supplidersCode 
				END
				ELSE
				BEGIN
					SET @colorCard= 'F'+right(str(CONVERT(VARCHAR(8),@supplidersCount+1) + 100000 ),4)+@supplidersCode
				END
			END
		
			IF NOT EXISTS ( select * from erp..mf_fabricNew where  colorCard=@colorCard)
			BEGIN
				INSERT INTO mf_fabricNew (colorCard , fabricName, fabricColor, supplidersId, doManId, picUrl, remark, colorShelf, type, searchTag )
					VALUES (@colorCard , @fabricName, @fabricColor, @supplidersId, @doManId, @picUrl, @remark, @colorShelf, @type, @searchTag )
				SET @mfFabricNewId=SCOPE_IDENTITY()
				if (@@error<>0)
				begin
					set @mfFabricNewId=-1
				end
				else
				begin
					INSERT INTO mf_pCodeFabricProtity (pCodeFabricFormId, fabricNewId, doManId) 
						values (1094, @mfFabricNewId, 189)
				end
			END
			ELSE
			BEGIN
				SET @mfFabricNewId=-4
			END
		END
		ELSE
		BEGIN
			SET @mfFabricNewId=-3
		END
	END
	ELSE
	BEGIN
		SET @mfFabricNewId=-2
	END
	
	commit tran

	SELECT @mfFabricNewId
	RETURN @mfFabricNewId
