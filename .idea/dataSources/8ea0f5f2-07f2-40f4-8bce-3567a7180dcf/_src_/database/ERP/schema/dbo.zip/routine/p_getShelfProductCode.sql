CREATE procedure [dbo].[p_getShelfProductCode] @productId int,@colorId int,@metricsId int,@productCode varchar(50) output
as

select top 1 @productCode=isNULL(b.pre,'R') +a.saleCode+c.code+d.code from supermarket..tb_saleProduct a
left join supermarket.dbo.tb_webCategory b on a.webCategoryId=b.id and a.productId=@productId 
inner join  dbo.tb_productColorCode c on c.productId=a.productId and c.id=@colorId
inner join  dbo.tb_productMetricsCode d on d.productId=a.productId and d.id=@metricsId
order by a.id
