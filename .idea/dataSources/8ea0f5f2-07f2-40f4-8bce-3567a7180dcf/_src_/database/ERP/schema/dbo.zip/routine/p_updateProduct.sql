/*------------------------------------------------更新商品------------------------------------------------------------*/
CREATE      PROCEDURE [dbo].[p_updateProduct]  @name VARCHAR(150),@isOwn INT,
				          @categoryOneId INT,@categoryTwoId INT,
				          @remark VARCHAR(500),@price INT,
				          @priceScore INT,@priceRemark VARCHAR(200),
				          @gAmount INT,@gAmountScore INT,
				          @gAmountRemark VARCHAR(200),@fillTime INT,
				          @fillTimeScore INT,@fillTimeRemark VARCHAR(200),
				          @rejectTime INT,@rejectTimeScore INT,
				          @rejectTimeRemark VARCHAR(200),@deliverP INT,
				          @deliverPScore INT,@deliverPRemark VARCHAR(200),
				          @clearP INT,@clearPScore INT,
				          @clearPRemark VARCHAR(200),@server INT,
				          @serverScore INT,@serverRemark VARCHAR(200),
				          @beauty INT,@beautyScore INT,
				          @beautyRemark VARCHAR(200),@useful INT,
				          @usefulScore INT,@usefulRemark VARCHAR(200),
				          @newP INT,@newPScore INT,@newPRemark VARCHAR(200),@id INT,@stockPrice INT,@minStockCount INT,@uintId INT,@pCount INT,@pCode VARCHAR(50),@useRemark  VARCHAR(500),@quality VARCHAR(50),@inSize VARCHAR(200),@wbzsize VARCHAR(500)
AS
	DECLARE @count INT
	DECLARE @returnValue INT
	BEGIN TRAN 
		SELECT @count=COUNT(*) FROM dbo.tb_product WHERE  (name=@name and pCode=@pCode)  AND id!=@id
		IF(@count!=0)
		BEGIN
			SET @returnValue=-1
		END
		ELSE
		BEGIN
			UPDATE dbo.tb_product  SET  name=@name ,isOwn=@isOwn, 
				          categoryOneId=@categoryOneId,categoryTwoId=@categoryTwoId ,
				          remark=@remark,price=@price ,
				          priceScore=@priceScore ,priceRemark=@priceRemark ,
				          gAmount=@gAmount ,gAmountScore=@gAmountScore ,
				          gAmountRemark=@gAmountRemark ,fillTime=@fillTime ,
				          fillTimeScore=@fillTimeScore ,--fillTimeRemark=@fillTimeRemark ,
				          rejectTime=@rejectTime ,rejectTimeScore=@rejectTimeScore ,
				          rejectTimeRemark=@rejectTimeRemark ,deliverP=@deliverP ,
				          deliverPScore=@deliverPScore ,deliverPRemark=@deliverPRemark ,
				          clearP=@clearP ,clearPScore=@clearPScore ,inSize=@inSize,wbzsize=@wbzsize,
				          clearPRemark=@clearPRemark ,server=@server ,
				          serverScore=@serverScore ,serverRemark=@serverRemark ,
				          beauty=@beauty ,beautyScore=@beautyScore ,
				          beautyRemark=@beautyRemark ,useful=@useful ,
				          usefulScore=@usefulScore ,usefulRemark=@usefulRemark ,
				          newP=@newP ,newPScore=@newPScore ,newPRemark=@newPRemark,stockPrice=@stockPrice,minStockCount=@minStockCount,uintId=@uintId,pCount=@pCount,pCode=@pCode,useRemark=@useRemark ,quality=@quality
				WHERE id=@id
		SET @returnValue=1
		END
	COMMIT TRAN 
	SELECT @returnValue
