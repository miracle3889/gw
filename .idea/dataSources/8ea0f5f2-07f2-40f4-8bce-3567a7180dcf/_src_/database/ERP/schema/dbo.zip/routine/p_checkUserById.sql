CREATE procedure [dbo].[p_checkUserById] @userId int ,@openId varchar(200)
as
  if exists (select 1 from erp.dbo.tb_user where openId=@openId)
	return 0 
  else
  begin
	  declare @id int 
	  select  @id=id  from erp.dbo.tb_user  where id=@userId and ISNULL(openId,'')=''
	  and isCanLoginIn=1
	  if(@id is not null and @id>0)
	  begin
		update   erp.dbo.tb_user  set openId=@openId where id=@id
		select 1
	  end
	  else
	  begin
		select 0
	  end
  end
