--old add buybill not use now 
CREATE  PROCEDURE [dbo].[p_assBuyBillProduct] @billId INT,@productId INT,@buyCount INT,@buyPrice INT,@remark VARCHAR(200) 
AS 
	DECLARE @returnValue INT 
	SET @returnValue=0
	BEGIN TRAN 
		INSERT INTO dbo.tb_buyBillProduct(billId,productId,buyCount,buyPrice,remark) 
		VALUES(@billId,@productId,@buyCount,@buyPrice,@remark)
		SET @returnValue=SCOPE_IDENTITY()
	COMMIT TRAN
	SELECT @returnValue
