CREATE PROCEDURE [dbo].[p_addFormFL]
	@userId int,
	@codeFabriMsgId int,
	@fabricNewId int,--色卡id
	@cardCode varchar(50), --规格，色卡号
	@fabricolor varchar(20),--颜色
	@oneCountClippint varchar(20),--单位
	@oneCount int, --件耗
	@remark varchar(100),--备注
	@codeFormId int  --辅料记录id
AS
declare @formId int
declare @count int --数量
declare @mfUnitId int --单位对应的id
begin
	select @mfUnitId = id from ERP..mf_unit where unitName = @oneCountClippint	--查询单位对应的id
	
	if (@mfUnitId = null)	--若无此单位，则新增一条
		begin
			insert into ERP..mf_unit(unitName) values (@oneCountClippint)
			set @mfUnitId = SCOPE_IDENTITY()
		end
	if (@codeFormId=0)
		begin
			
				select @count= COUNT(*) from ERP..mf_pCodeFabricForm where mfTypeId=2 and pCodeFabricMsgId=@codeFabriMsgId

			--	insert into ERP..mf_pCodeFabricForm(pCodeFabricMsgId,formName,mfTypeId,oneCount,oneCountClipping,mfUnitId,remark,doManId,addDate)
				insert into ERP..mf_pCodeFabricForm(pCodeFabricMsgId,formName,mfTypeId,oneCount,mfUnitId,remark,doManId,addDate)
				values(@codeFabriMsgId,'辅料-'+cast((@count+1) as varchar(20)),2,@oneCount,@mfUnitId,@remark,@userId,GETDATE())
				set @formId=SCOPE_IDENTITY()
			
				insert into ERP..mf_pCodeFabricProtity(pCodeFabricFormId,fabricNewId,doManId,addDate)values(@formId,@fabricNewId,@userId,GETDATE())
			begin tran
				update ERP..mf_fabricNew set fabricName=@cardCode,fabricColor=@fabricolor where id=@fabricNewId
			commit tran		
		end		
	else
		begin
			begin tran			
				select  @formId =c.id from ERP..mf_pCodeFabricForm  a inner join ERP..mf_pCodeFabricProtity b on a.id = b.pCodeFabricFormId
				 inner join ERP..mf_fabricNew c on b.fabricNewId = c.id where a.id = @codeFormId
				
				update ERP..mf_fabricNew set fabricName=@cardCode,fabricColor=@fabricolor where id=@formId
				
				update ERP..mf_pCodeFabricForm set mfUnitId = @mfUnitId,oneCount=@oneCount,remark=@remark where id=@codeFormId
				set @formId = @codeFormId
			commit tran
		end
	
end
select @formId
