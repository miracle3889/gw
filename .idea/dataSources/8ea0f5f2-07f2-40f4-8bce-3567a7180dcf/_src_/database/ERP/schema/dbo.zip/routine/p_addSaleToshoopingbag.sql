/*------------------转换发货状态------------------------------------*/
Create  PROCEDURE [dbo].[p_addSaleToshoopingbag] @memberId INT
AS 
	DECLARE @saleProductId INT
	DECLARE @saleCode VARCHAR(50)
	DECLARE @colorId INT
	DECLARE @metricsId INT
	DECLARE @needCount INT

	BEGIN TRAN

		DECLARE authors_cursor CURSOR FOR
		SELECT b.saleCode,b.id,a.colorId,a.metricsId,a.needCount
		FROM Supermarket.dbo.tb_needProdcut a 
		inner join tb_saleProduct b on b.productId=a.productId
		where  a.saleTypeId=1 and a.isReturnCall!=3 and a.memberID=@memberId
		
		OPEN authors_cursor
		FETCH NEXT FROM authors_cursor 
		INTO @saleCode,@saleProductId,@colorId,@metricsId,@needCount
		WHILE @@FETCH_STATUS = 0
		BEGIN
				EXEC p_addShoppingBag @saleCode,@needCount,@saleProductId,@colorId,@metricsId,@memberId--定单发货减库存
				FETCH NEXT FROM authors_cursor 
				INTO @saleCode,@saleProductId,@colorId,@metricsId,@needCount
		END
	CLOSE authors_cursor
	DEALLOCATE authors_cursor

	COMMIT TRAN
