/*-------------------------------取得供应商的编号--------------------------------------------------*/
CREATE PROCEDURE [dbo].[p_getSupplyCode] @code VARCHAR(20) OUTPUT
AS
	DECLARE @maxID INT --最大编号
	DECLARE @CategoryOneCode VARCHAR(20) --编号
	SELECT @maxID=MAX(intCode) FROM tb_supplyCode  --得到当前最大编号
	IF( @maxID IS NULL)--不存在
	BEGIN
		INSERT INTO tb_supplyCode(intCode) VALUES(1)
		SET @code='S00001'
	END
	ELSE
	BEGIN--存在
		DECLARE @maxIdChar VARCHAR(10)
		SET @maxIdChar=CAST((@maxID+1) AS VARCHAR(10))
		INSERT INTO tb_supplyCode(intCode) VALUES(@maxID+1)
		WHILE LEN(@maxIdChar)<5
		BEGIN
			SET @maxIdChar='0'+@maxIdChar
		END
		SET @code='S'+@maxIdChar
	END
	SET @code=@code
