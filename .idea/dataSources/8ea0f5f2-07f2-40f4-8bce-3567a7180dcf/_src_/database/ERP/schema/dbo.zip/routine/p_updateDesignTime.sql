CREATE PROCEDURE [dbo].[p_updateDesignTime]
	 @userId int,
	 @codeFabriMsg int,
	 @time varchar(50)
   AS
   
  
		declare @patternId int --版式ID
		declare @designId int --样式ID
		
		select @patternId=a.mainPatternId,@designId=b.currentPattern from ERP..mf_pCodeFabricMsg a 
		inner join 
		ERP..tb_pattern_making b 
		on a.mainPatternId=b.id
		where a.id=@codeFabriMsg
		
		
		begin tran
		--更新款式状态
			update ERP..mf_pCodeFabricMsg set statusId=6 where id=@codeFabriMsg and statusId in (4,5)
			if(@@ROWCOUNT>0)
				begin
				  --更新二维码的试穿时间
					update ERP..tb_design_qrcode set wearDate=@time,userId=@userId where id=(select qrcode from ERP..tb_design where id=@designId)
					exec ERP..addCodeFabriMsgStatus_history @codeFabriMsg,6,@userId
				end
		commit tran
