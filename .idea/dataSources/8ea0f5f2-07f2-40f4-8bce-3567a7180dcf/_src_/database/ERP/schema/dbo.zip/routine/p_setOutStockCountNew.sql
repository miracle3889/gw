/*******************************出货更新库存*************************************************************/

CREATE    PROCEDURE [dbo].[p_setOutStockCountNew] @orderId INT
AS
	BEGIN TRAN 
	
	--减单件商品的库存
	UPDATE dbo.tb_productStock  
	SET productCount=productCount-a.buyCount  
	FROM	 SuperMarket.dbo.tb_orderSaleProduct a,SuperMarket.dbo.tb_saleProduct c,dbo.tb_product b 
	WHERE a.saleProductId=c.id  AND c.productId=b.id  AND a.orderId=@orderId AND dbo.tb_productStock.colorId=a.colorId 
	AND dbo.tb_productStock.metricsId=a.metricsId AND dbo.tb_productStock.productId=b.id


	
	update tb_outProduct set outCount=0
	from tb_outStock a 
	inner join SuperMarket.dbo.tb_order b on a.adaptCode=b.orderCode
	where tb_outProduct.outId=a.id and b.id=@orderId

	update tb_outProduct set outCount=outCount+a.buyCount
	from SuperMarket.dbo.tb_orderSaleProduct a
	inner join SuperMarket.dbo.tb_saleProduct b on b.id=a.saleProductId
	inner join SuperMarket.dbo.tb_order c on c.id=a.orderId
	inner join tb_outStock d on d.adaptCode=c.orderCode
	where a.orderId=@orderId and tb_outProduct.colorId=a.colorId and tb_outProduct.metricsId=a.metricsId and tb_outProduct.productId=b.productId and tb_outProduct.outId=d.id
	
	update tb_outProduct set outCount=outCount+a.buyCount*b.buyCount
	from SuperMarket.dbo.tb_orderSaleGroup a
	inner join SuperMarket.dbo.tb_orderSaleGroupProduct b on a.id=b.orderSaleGroupId
	inner join SuperMarket.dbo.tb_saleProduct c on c.id=b.saleProductId
	inner join SuperMarket.dbo.tb_order d on d.id=a.orderId
	inner join tb_outStock e on e.adaptCode=d.orderCode
	where a.orderId=@orderId and tb_outProduct.colorId=b.colorId and tb_outProduct.metricsId=b.metricsId and tb_outProduct.productId=c.productId and tb_outProduct.outId=e.id
	
	
	IF(@@error<>0)
	BEGIN
		ROLLBACK TRAN 
	END
	COMMIT TRAN
