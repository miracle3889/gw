-- 修改物料库存  
CREATE PROCEDURE [dbo].[mf_updateFabricNewStock] @pCodeFabricProtityId INT,@pCodeFabricFormId INT,@productionPlanId INT, @mfCount INT, @shelfCode varchar(32), @doManId int, @updateType int 
AS

	DECLARE @isUpdate INT
	SET @isUpdate = 1

	begin tran
				
		if ( @pCodeFabricProtityId<>0)	
		begin
		
			-- 设定 货架库存更改历史记录 初始值
			DECLARE @pCodeFabricShelfStockCount INT
			SET @pCodeFabricShelfStockCount=0
			DECLARE @pCodeFabricShelfId INT
			SET @pCodeFabricShelfId=0
			
			IF NOT EXISTS ( select * from erp..mf_pCodeFabricShelf where pCodeFabricProtityId=@pCodeFabricProtityId and shelfCode=@shelfCode )
			begin
				insert into mf_pCodeFabricShelf (pCodeFabricProtityId, shelfCode, stockCount) values (@pCodeFabricProtityId, @shelfCode, @mfCount)
				if (@@error<>0)
				begin
					SET @isUpdate = 0
					ROLLBACK tran
				end
				else
				begin
					set @pCodeFabricShelfId=SCOPE_IDENTITY()
				end
			end
			else
			begin
				update mf_pCodeFabricShelf set stockCount=stockCount+@mfCount where pCodeFabricProtityId=@pCodeFabricProtityId and shelfCode=@shelfCode
				if (@@error<>0)
				begin
					SET @isUpdate = 0
					ROLLBACK tran
				end
			end
			
			SELECT @pCodeFabricShelfId=id,@pCodeFabricShelfStockCount=stockCount FROM mf_pCodeFabricShelf where pCodeFabricProtityId=@pCodeFabricProtityId and shelfCode=@shelfCode
			
			update mf_pCodeFabricProtity set stockCount=stockCount+@mfCount where id=@pCodeFabricProtityId and isDelete=0
			if (@@error<>0)
			begin
				SET @isUpdate = 0
				ROLLBACK tran
			end
			
			IF (@updateType=1 or @updateType=2) --  =1 入库 2 出库 是生产出入库  减占用库存  其它 为 3报失 4报损  不用减占用库存
			BEGIN
				--如果出库数量大于生产计划占用库存 则设为0
				DECLARE @planTaskCount INT
				SELECT @planTaskCount = planTaskCount FROM mf_productionPlanTask WHERE mfProductionPlanId=@productionPlanId and mfpCodeFabricFormId=@pCodeFabricFormId
				IF (@planTaskCount+@mfCount<0)
				BEGIN
					SET @planTaskCount=0
				END
				ELSE
				BEGIN
					SET @planTaskCount=@planTaskCount+@mfCount
				END
				
				update mf_productionPlanTask set planTaskCount=@planTaskCount
					where mfProductionPlanId=@productionPlanId and mfpCodeFabricFormId=@pCodeFabricFormId
				if (@@error<>0)
				begin
					SET @isUpdate = 0
					ROLLBACK tran
				end
			END
			
			--增加 货架库存更改历史记录
			insert into mf_pCodeFabricShelfHistory (pCodeFabricShelfId, type, oldCount, newCount, doManId) 
				VALUES (@pCodeFabricShelfId, @updateType, @pCodeFabricShelfStockCount-@mfCount, @pCodeFabricShelfStockCount, @doManId)
		end
		else
		begin
			set @isUpdate = 0
		end
	
	commit tran

	SELECT @isUpdate
