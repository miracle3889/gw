CREATE function [dbo].[f_getImageIdStr](@pid int)
RETURNS VARCHAR(100)
as 
begin
declare @sql varchar(50)
SET @sql = ''
    SELECT @sql = @sql + ',' + cast(id AS varchar) FROM erp..tb_image
        WHERE pid = @pid RETURN stuff(@sql, 1, 1, '')
 END
