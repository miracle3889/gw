/*----------------------------------------修改二级类别信息---------------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[p_updateCategoryTwo] @name VARCHAR(50),@parentId INT,
					          @priceA INT,
					          @priceB INT,
 					          @priceC INT,
					          @gAmountA INT,
					          @gAmountB INT,
					          @gAmountC INT,					         
					          @fillTimeA INT,
					          @fillTimeB INT,
    					          @fillTimeC INT,
					          @clearPA INT,
					          @clearPB INT,
					          @clearPC INT,
				   	          @serverA INT,
				   	          @serverB INT,
				   	          @serverC INT,
					          @id INT,
						@remark VARCHAR(200)			
AS
	DECLARE @returnValue INT
	SET @returnValue=0
	BEGIN TRAN 
		UPDATE  tb_categoryTwo SET  name=@name,parentId=@parentId,remark=@remark WHERE id=@id
		UPDATE tb_categoryTwoP SET   priceA= @priceA,
					          priceB =@priceB,
 					          priceC =@priceC,
					          gAmountA =@gAmountA,
					          gAmountB  =@gAmountB ,
					          gAmountC =@gAmountC,					         
					          fillTimeA  =@fillTimeA,
					          fillTimeB  =@fillTimeB,
    					          fillTimeC  =@fillTimeC,
					          clearPA  =@clearPA,
					          clearPB  =@clearPB,
					          clearPC  =@clearPC,
				   	          serverA  =@serverA,
				   	          serverB  =@serverB,
				   	          serverC  =@serverC	

				WHERE categoryTwoId=@id
		SET @returnValue=1
	COMMIT TRAN
	SELECT @returnValue
