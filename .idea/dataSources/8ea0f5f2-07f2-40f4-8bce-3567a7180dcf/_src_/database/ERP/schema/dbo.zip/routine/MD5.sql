-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION dbo.MD5
(
	@src varchar(255)
)
RETURNS varchar(255)
AS
BEGIN
	DECLARE @md5 varchar(34)
    SET @md5 = sys.fn_VarBinToHexStr(hashbytes('MD5', @src));
    --RETURN SUBSTRING(@md5,11,16)   --16位
    RETURN SUBSTRING(@md5,3,32)    --32位

END
