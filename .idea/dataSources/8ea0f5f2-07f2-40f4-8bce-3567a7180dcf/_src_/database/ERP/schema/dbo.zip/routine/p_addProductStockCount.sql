--库存操作记录
CREATE procedure [dbo].[p_addProductStockCount]  @productId int,@colorId int,@metricsId int,@opCount int,@opType int,@opManId int,@remark  varchar(200)
AS 
	declare @oldCount int
	select @oldCount=productCount from erp.dbo.tb_productStock where productId=@productId and colorId=@colorId and metricsId=@metricsId
	if(@oldCount is null)
		set @oldCount=0
	--begin tran
		insert into  dbo.tb_productStockOpHis(productId,colorId,metricsId,oldCount,newCount,doMan,opType,remark)
		 values(@productId,@colorId,@metricsId,@oldCount,@oldCount+@opCount,@opManId,@opType,@remark)

		if EXISTS(select 1 from erp.dbo.tb_productStock where productId=@productId and colorId=@colorId and metricsId=@metricsId)
		begin
			update dbo.tb_productStock set productCount=productCount+@opCount  where productId=@productId and colorId=@colorId and metricsId=@metricsId
		end
		else
		begin
			INSERT INTO dbo.tb_productStock(productId,colorId,metricsId,productCount)
				VALUES(@productId,@colorId,@metricsId,@opCount)
		end
	--commit tran