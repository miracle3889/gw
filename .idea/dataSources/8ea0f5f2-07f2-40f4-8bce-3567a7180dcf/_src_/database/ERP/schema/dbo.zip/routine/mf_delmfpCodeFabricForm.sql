/*  删除物料分解的面辅料  */

CREATE PROCEDURE [dbo].[mf_delmfpCodeFabricForm] @id int, @delManId int
AS

	DECLARE @returnValue INT
	SET @returnValue=0

	BEGIN tran	
	
	IF NOT EXISTS (select * from dbo.mf_pCodeFabricProtity where pCodeFabricFormId=@id and isDelete=0)
	BEGIN
		UPDATE mf_pCodeFabricForm SET delManId=@delManId , isDelete=1 , delDate=getdate() WHERE id=@id
			SET @returnValue= 1
	END
	
	commit tran

	SELECT @returnValue
