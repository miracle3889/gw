/*------------修改采购单规格数量<采购更新采购单信息时>---------------------*/
CREATE PROCEDURE [dbo].[p_updateBuyProductProtity] @id INT,@buyCount INT,@userId INT
AS
	DECLARE @colorName VARCHAR(50)
	DECLARE @metricsName VARCHAR(50)
	DECLARE @oldCount VARCHAR(50)
	DECLARE @buyProductId INT
	DECLARE @userName VARCHAR(50)
	SELECT @userName=name FROM tb_user WHERE id=@userId
	SELECT @colorName=b.codeName,@metricsName=c.codeName,@oldCount=buyCount,
	@buyProductId=buyProductId 
	FROM tb_buyProductProtity a 
	INNER JOIN  dbo.tb_productColorCode b ON a.colorId=b.id
	INNER JOIN  dbo.tb_productMetricsCode c ON a.metricsId=c.id
	WHERE a.id=@id 
	DECLARE @updateRemark VARCHAR(500)
	IF(@buyCount>0)
	BEGIN
		UPDATE tb_buyProductProtity SET buyCount=@buyCount WHERE id=@id
		SET @updateRemark=CONVERT(VARCHAR(20),getDate(),120)+@userName+'：更改规格数量,'+@colorName+'|'+@metricsName+'从'+CAST(@oldCount AS VARCHAR(20))+'到'+CAST(@buyCount AS VARCHAR(20))
	END
	ELSE
	BEGIN
		DELETE FROM  tb_buyProductProtity WHERE  id=@id
		SET @updateRemark=CONVERT(VARCHAR(20),getDate(),120)+@userName+'：删除规格,'+@colorName+'|'+@metricsName
	END
	
	UPDATE tb_buyProductList SET updateRemark=updateRemark+@updateRemark+'<br>' WHERE id=@buyProductId
	
	
	UPDATE tb_buyProductList SET stockRemark='' WHERE id=2
