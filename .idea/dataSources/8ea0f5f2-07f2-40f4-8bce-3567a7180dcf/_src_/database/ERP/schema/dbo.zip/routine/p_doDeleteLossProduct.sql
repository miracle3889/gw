/************根据异常类型删除操作**************/
/*1为退货入库*/
/*2为退货报损*/
/*3为日常报损*/
CREATE PROCEDURE [dbo].[p_doDeleteLossProduct] 	@id int
AS
	declare @returnid int
	declare @type int
	DECLARE @productId INT
	DECLARE @coloId INT
	DECLARE @metricsId INT 
	DECLARE @myCount INT
	select @type=type,@productId=productId,@coloId=colorId,@metricsId=metricsId,@myCount=pCount from tb_exceptionInStock where id = @id
 	set xact_abort on 
	BEGIN TRAN 

	if (@type=1)
	begin	
			UPDATE tb_productStock SET productCount=productCount-@myCount WHERE productId=@productId AND colorId=@coloId AND metricsId=@metricsId
	end

	if (@type=2 OR @type=3)
	begin
			UPDATE tb_lossProduct SET lossCount=lossCount-@myCount WHERE productId=@productId AND colorId=@coloId AND metricsId=@metricsId
	end
	
	if(@type=3)	
	begin
			UPDATE tb_productStock SET productCount=productCount+@myCount WHERE productId=@productId AND colorId=@coloId AND metricsId=@metricsId
	end
			/**********************删除到异常入库表*********************/	
			delete from tb_exceptionInStock where id = @id
	COMMIT TRAN
