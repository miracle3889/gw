CREATE PROCEDURE [dbo].[p_addInStockShelf] @instockProductId INT ,@shelfCode VARCHAR(50),@dealManId INT 
AS
	DECLARE @inStockTransferId INT
	DECLARE @productCode  VARCHAR(50)
	DECLARE @productCount  INT
	DECLARE @count  INT
	begin tran 
	SELECT @inStockTransferId=inStockTransferId,@productCode=productCode,@productCount=productCount
	FROM  tb_inStockTransferProduct WITH(HOLDLOCK)    WHERE Id=@instockProductId AND isInstock=0  
	IF(@inStockTransferId IS NULL)
		SET @inStockTransferId=0
	IF(@inStockTransferId=0)
	BEGIN
		SELECT -1,'已经上过架了'
	END
	ELSE
	BEGIN
		select @count=count(*) from tb_goodsShelf  where code=@shelfCode
		IF @count>0
		BEGIN
			 EXEC p_addShelfStockBySystem @shelfCode,@productCode,@productCount,@dealManId,4,'采购交接上架'
			 UPDATE  tb_inStockTransferProduct SET isInstock=1,instockDate=getDate(),instockShelfCode=@shelfCode WHERE id=@instockProductId --已上架
				
			SELECT @count=COUNT(*) FROM tb_inStockTransferProduct WHERE isInstock=1 AND  inStockTransferId=@inStockTransferId
			
			UPDATE tb_InstockTransFer SET addShelfCount=@count WHERE id=@inStockTransferId --更新上架数量

			SELECT 1,'OK'
		END
		ELSE
		BEGIN
			SELECT -2,'货架号不存在'
		END
	END
	commit tran
