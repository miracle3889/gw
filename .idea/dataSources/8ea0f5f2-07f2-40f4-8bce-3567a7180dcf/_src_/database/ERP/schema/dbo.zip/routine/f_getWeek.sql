create function [dbo].[f_getWeek]( @date varchar(50))
RETURNS VARCHAR(10)
as 
begin
	declare @weekString varchar(10)
	declare @weekInt int 
	set @weekInt =datepart(W,@date)-1
	
	if(@weekInt=0)
		set @weekString='周日'
	
	if(@weekInt=1)
		set @weekString='周一'
	
	if(@weekInt=2)
		set @weekString='周二'
	
	if(@weekInt=3)
		set @weekString='周三'
	
	if(@weekInt=4)
		set @weekString='周四'
	if(@weekInt=5)
		set @weekString='周五'
	if(@weekInt=6)
		set @weekString='周六'
		
	return @weekString
end
