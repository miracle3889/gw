CREATE procedure [dbo].[p_changeToAddShelfNew] @instockId int,@doManId int 
as 
	delete from tb_orderInstockProduct where instockId=@instockId

	insert into tb_orderInstockProduct(instockId,productCode,productCount,inStockCount,loseCount,injureCount,shelfCode)
	
	select  @instockId,productShelfCode,sum(productCount),sum(inStockCount),sum(loseCount),sum(injureCount),'' from
	 (
		select e.productShelfCode,sum(c.buyCount) as productCount,sum(c.buyCount-0) as inStockCount,0 as loseCount,sum(0) as injureCount,'' as shelfCode
		 from  supermarket..tb_order a 
		inner join  erp..tb_orderSaleProductDistribute  c on a.id=c.orderId
		inner join supermarket..tb_saleProduct d on d.id=c.saleProductId 
		inner join tb_productSkuCode e on e.productId=d.productId and e.colorId=c.colorId and c.metricsId=e.metricsId
		where a.id in(select orderId from tb_orderInstockOrder where type=1 and instockId=@instockId)
		group by e.productShelfCode--删除订单
		
		union all 
		
		select e.productShelfCode,sum(c.backCount) as productCount,sum(c.backCount-c.loseCount) as inStockCount,0 as loseCount,sum(c.loseCount) as injureCount,'' as shelfCode
		 from  supermarket..tb_order a 
		inner join supermarket..tb_orderSaleProduct c on a.id=c.orderId
		inner join supermarket..tb_saleProduct d on d.id=c.saleProductId 
		inner join tb_productSkuCode e on e.productId=d.productId and e.colorId=c.colorId and c.metricsId=e.metricsId
		where a.id in(select orderId from tb_orderInstockOrder where type=2 and instockId=@instockId) and c.backCount>0
		group by e.productShelfCode--拒收订单
			
		union all 
		
	
		select e.productShelfCode,sum(y.backCount) as productCount,sum(y.backCount-y.loseCount) as inStockCount,0 as loseCount,sum(y.loseCount) as injureCount,'' as shelfCode
							 from  supermarket..tb_backOder a 
							inner join supermarket.dbo.tb_backProduct y on y.backId=a.id
							inner join tb_productSkuCode e on   e.colorId=y.colorId and y.metricsId=e.metricsId
							where a.id in(select orderId from tb_orderInstockOrder where type=3 and instockId=@instockId)
							group by e.productShelfCode --退单
	) as x 
	group by productShelfCode


	
	update tb_orderInstockProduct set shelfCode=b.shelfCode from tb_orderInstockProduct a ,(
	select a.* from tb_shelfProductCount a
	inner join (
	select productCode,max(productCount) as productCount from  tb_shelfProductCount  where   productCount>0  and shelfCode not in('A0000','X0000','Y0000') and shelfCode not like 'T____' and shelfCode not like 'X____'
	group by  productCode ) as  b on a.productCode=b.productCode and a.productCount=b.productCount) b 
	where a.productCode=b.productCode and a.instockId=@instockId   



	declare @count int 
	select @count=count(*) from tb_orderInstockProduct where instockId=@instockId
	
	update tb_orderInstock set okTime=getdate(), status=1,productCount=@count where id=@instockId


	update tb_dealUpdateOrder set isIn=1 where orderId in( select orderId from tb_orderInstockOrder  where instockId=@instockId and  type=1)

	delete from supermarket..tb_rejectOrder where orderId in(select orderId from tb_orderInstockOrder  where instockId=@instockId and  type=2)
