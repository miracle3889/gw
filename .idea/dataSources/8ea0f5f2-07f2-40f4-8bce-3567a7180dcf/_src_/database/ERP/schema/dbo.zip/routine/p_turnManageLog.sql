-- 转移业务日志
CREATE PROCEDURE [dbo].[p_turnManageLog]
AS

	DECLARE @hisCount int
	declare @tableName varchar(40)
	declare @sql nvarchar(500)
	begin tran

		--查找上一次his表名
		select top 1  @tableName=tableName from erp..tb_invokeLog_his_tableName order by id desc
		--不存在
		if(@tableName is null)
		begin 
			set @tableName='erp..tb_invokeLog_his'
		end 

		--判断his表数据是否大于500w
		set @sql = 'select @hisCount=count(1) from '+@tableName
		exec sp_executesql @sql,N'@hisCount int output',@hisCount output


		print 1
		if(@hisCount>5000000)
		begin
			--创建新表
			select @tableName='tb_invokeLog_his_'+convert( varchar(8), getdate(),112)
			
			set @sql = ' CREATE TABLE '+@tableName+'(
				[id] [bigint] IDENTITY(1,1) NOT NULL,
				[ip] [varchar](20) NOT NULL,
				[method] [varchar](200) NOT NULL,
				[description] [varchar](200) NULL,
				[userName] [varchar](200) NOT NULL,
				[parameters] [varchar](5000) NULL,
				[type] [int] NOT NULL,
				[addDate] [datetime] NOT NULL default getdate(),
				[takeTime] [varchar](2000) NULL,
				[userId] [int] NULL,
				[isResponse] [int] NOT NULL default 0
			) ON [PRIMARY]
			'
			exec sp_executesql @sql
			
			--记录表名
			insert into erp..tb_invokeLog_his_tableName(tableName)values(@tableName)
		end
	print @tableName
		--插入新表
		set @sql = 'insert into '+@tableName+'
			(
				[ip],
				[method] ,
				[description] ,
				[userName],
				[parameters] ,
				[type],
				[addDate] ,
				[takeTime] ,
				[userId],
				[isResponse]
				) 
			select 
				[ip],
				[method] ,
				[description] ,
				[userName],
				[parameters] ,
				[type] [int],
				[addDate] ,
				[takeTime] ,
				[userId] ,
				[isResponse]
			from 
			erp..tb_invokeLog where DateDiff(dd,addDate,getdate()) >=1'

			exec sp_executesql @sql
		
			delete erp..tb_invokeLog where DateDiff(dd,addDate,getdate()) >=1
			
			exec p_logByProducts @tableName,'supplyCenter'
			exec p_logByProducts @tableName,'designCenter'
			exec p_logByProducts @tableName,'erp'
			
		
	commit tran

	