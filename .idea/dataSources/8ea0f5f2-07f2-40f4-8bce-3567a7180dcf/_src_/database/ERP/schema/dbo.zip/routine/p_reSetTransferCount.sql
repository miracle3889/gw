CREATE procedure [dbo].[p_reSetTransferCount] @distributeId int
as 
declare @count int


select @count=count(*)  from tb_transferOrder where transferId=@distributeId

update tb_transFer set orderCount=@count where id=@distributeId
