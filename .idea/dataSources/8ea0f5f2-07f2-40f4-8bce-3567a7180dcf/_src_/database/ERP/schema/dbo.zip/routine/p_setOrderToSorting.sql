CREATE  procedure [dbo].[p_setOrderToSorting] @orderCode varchar(50),@userManId int,@transferId int 
as
	declare @orderId int
	declare @orderCodeNew varchar(50)
    declare @deliverName varchar(50)
    declare @deliverId int
    declare @receviceMobile varchar(50)
    declare @nickName varchar(50)
    declare @useAccount int
	select @orderId=a.id,@orderCodeNew=a.orderCode,@deliverName=b.name,@deliverId=b.id,@receviceMobile=
	a.receviceMobile,@useAccount=a.useAccount,
	@nickName=c.nickName 
	   from Supermarket..tb_order a
	   inner join erp..tb_user b on a.deliverManId=b.id
	   inner join supermarket..tb_orderNickName c on c.orderCode=a.orderCode
		where otherOrder=@orderCode and orderstatus in(13,20) and isdelete=0 
		
	--单号存在
	if(@orderId is not null and @orderId>0)
	begin
		if EXISTS (
		
		SELECT  d.id
		  FROM  [supermarket].[dbo].[tb_taobaoRefund]  a
		  inner join supermarket..tb_taobaoOId b on a.oid=b.taobaoOId
		  inner join supermarket..tb_orderSaleProduct c on c.id=b.orderSaleId
		  inner join supermarket..tb_order d on d.id=c.orderId 
		  inner join  reportruhnn.dbo.tb_orderNoDelivered x on x.orderSaleId=c.id and x.isHuanhuo=0 
		   where c.buyCount>0 and  a.status in('WAIT_SELLER_AGREE','WAIT_BUYER_RETURN_GOODS','WAIT_SELLER_CONFIRM_GOODS','SUCCESS') 
		   and d.orderStatus in(13,20) and isDelete<>1 and d.id=@orderId 
		   and (isnull(d.backCode,'')='' )
		) 
		begin
			--正在退款
		 	declare @code varchar(50)
		 	--begin tran 
			INSERT INTO supermarket.dbo.tb_order(orderCode,payType,deliverType,deliverPrice,memberId,orderStatus,
							doMan,reMark,magazineCode,magazineCodeS,magSourceRemark,receviceMan,post,receviceAddr1,
							receviceAddr2,receviceMobile,addrId,useAccount,getScore,regionalId1,regionalId2,useGift,
							orderSource,provinceId ,cityId ,createTime,paymentDate,deliverManId)
			
			select '',payType,deliverType,deliverPrice,memberId,1,
							doMan,reMark,magazineCode,magazineCodeS,magSourceRemark,receviceMan,post,receviceAddr1,
							receviceAddr2,receviceMobile,addrId,useAccount,getScore,regionalId1,regionalId2,useGift,
							orderSource,provinceId ,cityId ,createTime,paymentDate,deliverManId
			from supermarket.dbo.tb_order where  isdelete<>1 and id=@orderId
			declare @orderIdNew int
			set @orderIdNew= SCOPE_IDENTITY() --得到刚刚插入的定单id 
			
			set @code  =supermarket.[dbo].[f_getOrderCodePre](@orderIdNew,'00',@nickName,'r')
			--更新单号
			update supermarket.dbo.tb_order set orderCode =@code where ID =@orderIdNew
			--原订单删除
			update supermarket.dbo.tb_order  set isDelete=1 , visaRemark='退款拦截' where id=@orderId
			
			insert into supermarket..tb_orderNickName(orderCode,nickName) select @code,@nickName 
			
			update supermarket..tb_taobaoCode set orderCode=@code where orderCode=@orderCodeNew
		
			update supermarket..tb_orderSaleProduct set  orderId=@orderIdNew where orderId=@orderId 
			
			update    supermarket..tb_orderSaleOutOfStock set orderId=@orderIdNew where orderId=@orderId
			
			update reportruhnn.dbo.tb_orderNoDelivered set orderId=@orderIdNew where orderId=@orderId
			
			--commit tran 
			 select 0
		end
		else
		begin
			if not EXISTS(select 1 from tb_transferOrder where transferId=@transferId and orderCode=@orderCodeNew)
			begin
				insert into tb_transferOrder(transferId,orderCode,orderId,deliverManId,otherOrder) values(@transferId,@orderCodeNew,@orderId,@deliverId,@orderCode)
				update tb_transFer set orderCount=orderCount+1 where id=@transferId
				select @orderId
			end
			else
			begin
				select 0
			end
		end
	end
	else
	begin
		select 00
	end
