CREATE PROCEDURE [dbo].[p_addCallTaskRemark] @id int,@remark varchar(500),@userId int
as 
	update tb_callBackTaskOrder set callMan=@userId,callTime=getDate(),remark=@remark where id=@id
	
	declare @taskId int
	declare @count int
	SELECT @taskId=taskId FROM tb_callBackTaskOrder where id=@id
	select @count=count(*) from tb_callBackTaskOrder where callMan>0  and taskId=@taskId

	update tb_callBackTask set callBackCount =@count where id=@taskId
