create procedure [dbo].[p_getInProductHisEveryMonth]
as
select  convert(varchar(10), dealTime,120) as inDate,
y.name as brandName,x.saleCode,c.pCode ,f.addrName,c.name,d.codeName as colorName, 
sum(a.productCount) as productCount 
,sum(case when e.codeName='S'  then a.productCount else 0 end) as s,
sum(case when e.codeName='M'  then a.productCount else 0 end) as m,
sum(case when e.codeName='L'  then a.productCount else 0 end) as l,
sum(case when e.codeName='均码'  then a.productCount else 0 end) as jun

from  erp..tb_shelfProductOpHis a
inner join erp..tb_productStock b on a.productCode=b.productShelfCode 
inner join erp..tb_product c on c.id=b.productId
inner join erp.dbo.tb_productColorCode d on d.id=b.colorId
inner join  erp.dbo.tb_productMetricsCode e on e.id=b.metricsId  
inner join erp..mf_addrs f on f.id=c.mfAddrId
inner join supermarket..tb_saleProduct x on x.productId=c.id 
inner join supermarket..tb_brand y on y.id=x.brandId
where opType=4 and dealTime>CONVERT(varchar(7),dateadd(month,-1,GETDATE()),120)+'-01'
group by convert(varchar(10), dealTime,120),c.id,f.addrName,c.name,d.codeName ,x.saleCode,c.pCode,y.name
order by addrName,brandName,inDate
