/*----------------添加定单--------*/
CREATE    PROCEDURE [dbo].[p_addLendOrder]    
				     @doMan INT,
				     @lendMan VARCHAR(50),
				     @lendRemark VARCHAR(50),
				     @lendType INT
AS

	DECLARE @code VARCHAR(50)	
	BEGIN TRAN 
		EXEC p_getLendOrderCode 1,@code OUTPUT --得到订单号
		insert into tb_lendOrder(lendMan,lendRemark,doman,lendCode,lendType)
		values(@lendMan,@lendRemark,@doMan,@code,@lendType)
		select SCOPE_IDENTITY() 
	commit tran
