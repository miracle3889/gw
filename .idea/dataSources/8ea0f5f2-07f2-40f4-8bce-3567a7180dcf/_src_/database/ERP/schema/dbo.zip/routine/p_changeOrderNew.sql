CREATE procedure [dbo].[p_changeOrderNew] @distributeId int,@orderId int,@doMan int
as 
	begin
	
	declare @orderCode varchar(50)
	update erp..tb_Distribute set transferCount=transferCount+1 where id=@distributeId
		
	--订单交接完成
	update erp..tb_orderDistribute set isDistribute=1,distributeManId=@doMan,distributeDate=getDate() where orderId=@orderId 
	and distributeId=@distributeId and isDistribute=0
	
	--订单非删除状态 返回待配货状态
	if EXISTS (select 1 from supermarket..tb_order where isdelete<>1 and id=@orderId and orderstatus in(13,20))
	begin
		update supermarket..tb_order set orderstatus =1 where id=@orderId
		insert into  SuperMarket.dbo.tb_orderstatusHis(orderId,orderstatus,remark,doMan) values(@orderId,1,'缺货压单重配货',@doMan)
		
		delete from supermarket..tb_temp_waitPhProduct where orderId=@orderId
	
		insert into  supermarket..tb_temp_waitPhProduct(orderId,saleProductId,buyCount,colorId,metricsId)
		SELECT a.orderId,a.productId AS saleProductId, a.buyCount AS buyCount, a.colorId AS colorId, 
		      a.metricsId AS metricsId
	        FROM supermarket.dbo.tb_orderSaleProduct a 
		INNER JOIN    supermarket.dbo.tb_order b ON b.id = a.orderId
		WHERE b.orderStatus =1 AND b.isDelete != 1 and a.orderId=@orderId
		
	
	--
		select @orderCode=orderCode from supermarket..tb_order where id=@orderId
		

		update tb_shelfProductCount set productCount=a.productCount+b.backCount from tb_shelfProductCount a,
		(
			select b.productShelfCode,sum((buyCount-backCount)) as backCount  from tb_orderSaleProductDistribute a
			inner join tb_productStock b on a.colorId=b.colorId and a.metricsId =b.metricsId 
			 where  distributeId=@distributeId  and orderId=@orderId  and buyCount-backCount>0 group by productShelfCode
		) as  b  
		where a.productCode=b.productShelfCode  and a.shelfCode='Y0000' 
	
		
		insert into tb_shelfProductCount(shelfCode,productCode,productCount)  
		select 'Y0000',b.productShelfCode,sum(buyCount-backCount) as backCount  from tb_orderSaleProductDistribute a
			inner join tb_productStock b on a.colorId=b.colorId and a.metricsId =b.metricsId 
			 where  distributeId=@distributeId  and orderId=@orderId  and buyCount-backCount>0
		and  productShelfCode not in(select productCode from tb_shelfProductCount where shelfCode='Y0000') 
		group by productShelfCode
		
		
		
		insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,dealManId,type,optype,remark)
		select 'Y0000',b.productShelfCode,sum(buyCount-backCount) as backCount,@doMan,0,9,@orderCode from tb_orderSaleProductDistribute a
			inner join tb_productStock b on a.colorId=b.colorId and a.metricsId =b.metricsId 
			 where  distributeId=@distributeId  and orderId=@orderId  and buyCount-backCount>0 group by productShelfCode
	
	end
	
	end
