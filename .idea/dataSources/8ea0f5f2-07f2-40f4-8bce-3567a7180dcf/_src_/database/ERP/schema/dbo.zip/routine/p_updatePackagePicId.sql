-- =============================================
-- Author:		<runbin>
-- Create date: <2015-09-16>
-- Description:	<包裹拍照>
-- =============================================
CREATE PROCEDURE [dbo].[p_updatePackagePicId]
	@sid varchar(15),--快递单号
	@picId int,	--包裹图片pid
	@userId int--拆包人
	
AS
declare @packageId int	--拆包处理id
BEGIN
	begin tran
		select @packageId = id from SuperMarket..Tb_salePackageDeal where sid = @sid and userId = @userId
		if @packageId>0
			begin 
				update SuperMarket..Tb_salePackageDeal set picId = @picId,
					unPackTime = GETDATE() where sid = @sid and userId = @userId
			end
		else
			begin 
				insert into SuperMarket..Tb_salePackageDeal(sid,userId,unPackTime,status,problemDsc,picId)
					values (@sid,@userId,GETDATE(),0,'',@picId)
				set @packageId = SCOPE_IDENTITY()
			end
	commit tran	
END
select @packageId