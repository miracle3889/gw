CREATE PROCEDURE [dbo].[mf_updateMFsuppliders] @name varchar(64), @mobile varchar(32), @account varchar(128), 
			@addrs varchar(320), @remark varchar(320), @phone varchar(32), @fax varchar(32), @supplidersCode varchar(8), @mainType varchar(64), @id int   
AS

	DECLARE @returnValue INT
	SET @returnValue=0
	
	IF NOT EXISTS ( select * from erp..mf_suppliders where isDelete=0 and id<>@id and (supplidersCode=@supplidersCode or name = @name ) )
	begin
	
		update ERP..mf_suppliders set name=@name, mobile=@mobile, phone=@phone , fax=@fax, account=@account, addrs=@addrs, remark=@remark
				, mainType=@mainType, supplidersCode=@supplidersCode where id=@id
		SET @returnValue=1
		
	END
	SELECT @returnValue
