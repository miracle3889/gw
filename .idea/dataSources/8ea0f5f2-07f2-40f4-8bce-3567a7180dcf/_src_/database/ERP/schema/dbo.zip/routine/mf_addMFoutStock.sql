/*  面料出库  */

CREATE PROCEDURE [dbo].[mf_addMFoutStock] @fabricId INT, @addrsId INT, @outCount INT, @userId INT
AS

	DECLARE @returnValue INT
	SET @returnValue=0

	DECLARE @stockCount INT
	SET @stockCount=0
	DECLARE @outStockCount INT
	SET @outStockCount=0
	
	IF (@outCount > 0)
	BEGIN
		select @stockCount=isnull(sum(mfCount),0) from mf_fabricCount a, mf_purchase b where b.id=a.purchaseId and b.mfFabricId=@fabricId and mfAddrsId=@addrsId 
	
		select @outStockCount=isnull(sum(outCount),0) from mf_outStock WHERE addrsId=@addrsId and fabricId=@fabricId
		
		IF ( (@stockCount-@outStockCount-@outCount) >= 0)
		begin
			insert into ERP..mf_outStock (addrsId, fabricId, outCount, userId) VALUES (@addrsId, @fabricId, @outCount, @userId)
			SET @returnValue=SCOPE_IDENTITY()
		END
	END

	SELECT @returnValue
