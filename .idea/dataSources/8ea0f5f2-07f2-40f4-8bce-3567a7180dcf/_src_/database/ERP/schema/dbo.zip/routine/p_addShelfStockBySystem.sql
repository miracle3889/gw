CREATE procedure [dbo].[p_addShelfStockBySystem]  @shelfCode varchar(50),@productCode varchar(50),@count int,@dealManId int,@type INT,@remark VARCHAR(100)
AS 
	if EXISTS(select 1 from tb_goodsShelf  where code=@shelfCode )
		BEGIN
			if EXISTS(select 1 from tb_productStock  where productShelfCode=@productCode )
			BEGIN
				begin tran
					declare @oldCount int
					set @oldCount=0
					if EXISTS(select 1 from tb_shelfProductCount where shelfCode=@shelfCode and productCode=@productCode)
					begin
						select @oldCount=productCount from tb_shelfProductCount where shelfCode=@shelfCode and productCode=@productCode
						update tb_shelfProductCount set productCount=productCount+@count where shelfCode=@shelfCode and productCode=@productCode
					end
					else
					begin
						insert into tb_shelfProductCount(shelfCode,productCode,productCount) values(@shelfCode,@productCode,@count)
					end
					
					if(@@error<>0)
						begin
							select -1 as 'ret'
							rollback tran
							return
						end
					insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,productOldCount,dealManId,optype,remark) values(@shelfCode,@productCode,@count,@oldCount,@dealManId,@type,@remark)
					if(@@error<>0)
						begin
							select -1 as 'ret'
							rollback tran 
							return
						end
				commit tran
				select 1 as 'ret'
			END
		END
		