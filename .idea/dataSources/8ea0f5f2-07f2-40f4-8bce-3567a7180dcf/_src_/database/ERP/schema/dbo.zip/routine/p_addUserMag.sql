CREATE procedure [dbo].[p_addUserMag] @userId int,@magCode varchar(10),@magCount int,@sendman int
as 
    declare @magId int
     
    select @magId=id  from supermarket..tb_magSourceRemark where  subString(magSource,4,len(magSource))=@magCode

    if(isnull(@magId,0)>0)
	     begin
		insert into tb_userMag(magId,userId,magCount,sendman) values(@magId,@userId,@magCount,@sendman)
	     end
    if(@magId is null) set @magId=-1
    select @magId
