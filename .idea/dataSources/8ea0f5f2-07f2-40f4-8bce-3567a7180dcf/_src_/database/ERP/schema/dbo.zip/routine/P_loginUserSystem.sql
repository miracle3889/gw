CREATE    PROCEDURE [dbo].[P_loginUserSystem] @userName VARCHAR(50),@PSW VARCHAR(15)
AS 
	
	SELECT a.id AS id,a.name AS name,a.post AS post,b.name AS departname,
	b.id AS departId,a.pId,a.citys as usercitys,a.userCodes FROM tb_user a 
	INNER JOIN tb_depart b ON a.departId=b.id 
	WHERE a.userName=@userName AND psw=dbo.md5(@PSW) 
	and a.isCanLoginIn=1 and status in(1,2)  
	and a.id in(select userId from erp..tb_userRole where roleId=8)
