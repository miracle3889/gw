/*------------------转换发货状态------------------------------------*/
CREATE PROCEDURE [dbo].[p_changeDeliverOrder] @type INT
AS 
	DECLARE @orderId INT
	BEGIN TRAN

	DECLARE authors_cursor CURSOR FOR
	SELECT a.id
	FROM Supermarket.dbo.tb_order a 
	INNER JOIN Supermarket.dbo.tb_orderStatus b ON a.orderStatus=b.id
	INNER JOIN tb_outStock c ON c.adaptCode=a.orderCode	
	WHERE a.isUpdate=@type 
	OPEN authors_cursor
	FETCH NEXT FROM authors_cursor 
	INTO @orderId
	WHILE @@FETCH_STATUS = 0
	BEGIN
		DECLARE @orderStatus INT
		SELECT @orderStatus=orderStatus FROM Supermarket.dbo.tb_order WHERE id=@orderId
		IF(@orderStatus!=2)
		BEGIN
			EXEC p_setOutStockCountNew_total @orderId --定单发货减库存
		END
		FETCH NEXT FROM authors_cursor 
		INTO @orderId
	END
	CLOSE authors_cursor
	DEALLOCATE authors_cursor

	COMMIT TRAN
