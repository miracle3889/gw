-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE procedure [dbo].[p_changeUserRight]
	@roleIds varchar(500),--角色权限
	@addroles varchar(500),--额外添加权限
	@delroles varchar(500),--额外删除权限
	@userId int--用户ID
as
    declare @pointerRoleIds int--角色权限循环参数
    set @pointerRoleIds=1
    declare @PointerRoleIdsCurr int--角色权限截断位置
	declare @TRole int--角色权限号
	
	declare @pointerAddroles int--额外添加权限循环参数
	set @pointerAddroles=1
	declare @PointerAddrolesCurr int--角色权限截断位置
	declare @ARole int--角色权限号
	
	declare @pointerDelroles int--额外删除权限循环参数
	set @pointerDelroles=1
	declare @PointerDelrolesCurr int--角色权限截断位置
	declare @DRole int--角色权限号
	
	DECLARE @returnValue int
  	set @returnValue=0
Begin
set nocount on;

delete from ERP..tb_userrole where userid=@userId
delete from ERP..tb_userRight where userid=@userId
if(@roleIds<>'-1')--修改角色权限
	begin
	 while (@pointerRoleIds < LEN(@roleIds)) 
		Begin 
		print LEN(@roleIds)
			Set @PointerRoleIdsCurr=CharIndex(',',@roleIds,@pointerRoleIds) 
			print @PointerRoleIdsCurr
			if(@PointerRoleIdsCurr > 0) 
				Begin 
					set @TRole=cast(SUBSTRING(@roleIds,@pointerRoleIds,@PointerRoleIdsCurr-@pointerRoleIds) as int) 
					insert into tb_userrole(userId,roleId) values(@userId,@TRole)
					SET @pointerRoleIds = @PointerRoleIdsCurr+1 
				End
			else
				Break
		End
	end

if(@addroles<>'-1')--修改额外添加权限
	begin
	 while (@pointerAddroles < LEN(@addroles)) 
		Begin 
		 print LEN(@addroles)
			Set @PointerAddrolesCurr=CharIndex(',',@addroles,@pointerAddroles) 
			if(@PointerAddrolesCurr > 0) 
				Begin 
					set @ARole=cast(SUBSTRING(@addroles,@pointerAddroles,@PointerAddrolesCurr-@pointerAddroles) as int) 
					insert into ERP..tb_userRight(userId,rightId,type) values(@userId,@ARole,0)
					SET @pointerAddroles = @PointerAddrolesCurr+1 
				End
			else
				Break
		End
	end
	
if(@delroles<>'-1')--修改额外添加权限
	begin
	 while (@pointerDelroles < LEN(@delroles))
		Begin 
		print LEN(@delroles)
			Set @PointerDelrolesCurr=CharIndex(',',@delroles,@pointerDelroles) 
			if(@PointerDelrolesCurr > 0) 
				Begin 
					set @DRole=cast(SUBSTRING(@delroles,@pointerDelroles,@PointerDelrolesCurr-@pointerDelroles) as int) 
					insert into ERP..tb_userRight(userId,rightId,type) values(@userId,@DRole,1)
					SET @pointerDelroles = @PointerDelrolesCurr+1 
				End
			else
				Break
		End
	end	

end
select @returnvalue
