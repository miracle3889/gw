CREATE procedure [dbo].[p_checkUserSiwoo] @userName varchar(50),@psw varchar(50)
as

  begin
	  declare @id int 
	  select  @id=id  from erp.dbo.tb_user  where userName=@userName  and psw=SuperMarket.dbo.md5(@psw) 
	  and isCanLoginIn=1 
	  if(@id is not null and @id>0)
	  begin
		select * from erp.dbo.tb_user  where userName=@userName  and psw=SuperMarket.dbo.md5(@psw)
	  end
	  else
	  begin
		select 0 as id
	  end
	end
