/*********		添加文案		***********/
CREATE PROCEDURE [dbo].[p_insertCopywriter]
 @saleId	int,
 @userId	int,
 @content	varchar(2000)
AS

DECLARE @newId	INT  --返回文案id
set @newId=0
BEGIN
	 begin tran 
	 insert into ERP..tb_itemDocument (saleId,content,userId,isDel) values (@saleId,@content,@userId,0)
	 set @newId=SCOPE_IDENTITY()
	 
	 
	 if @@ERROR<>0
		begin
		set @newId=0
	    rollback tran
	    end
	 commit tran
END
select @newId
