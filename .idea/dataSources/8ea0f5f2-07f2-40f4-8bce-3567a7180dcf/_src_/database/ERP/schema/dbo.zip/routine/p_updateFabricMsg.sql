CREATE PROCEDURE [dbo].[p_updateFabricMsg]
	 @styleId int,
	 @userId int
	
   AS
   BEGIN
		begin tran 
		--更新款式表
			update ERP..mf_pCodeFabricMsg set statusId=8 where id = @styleId and statusId<8
			
			if(@@ROWCOUNT>0)
			begin 
				exec ERP..addCodeFabriMsgStatus_history @styleId,8,@userId
			end
		commit tran
		select 1 as 'ret' 
	END
