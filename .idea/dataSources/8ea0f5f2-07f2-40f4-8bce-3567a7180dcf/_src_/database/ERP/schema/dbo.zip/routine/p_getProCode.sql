-- =============================================
-- Author:		<runbin>
-- Create date: <2015-09-23>
-- Description:	<获取流水号>
-- =============================================
CREATE PROCEDURE [dbo].[p_getProCode]
	@status int	--类型
AS
BEGIN
	begin tran 
		declare @code varchar(15)	--流水
		declare @title varchar(10)	--流水号头
		DECLARE @temp INT
		set @code=CONVERT(VARCHAR(10),GETDATE(),12)
		if @status=1
			set @title = 'HT';
		if @status=2
			set @title = 'CP';
		if @status=3
			set @title = 'FK';
		if @status=4
			set @title = 'RKPC'
		if @status=5
			set @title = 'JG'
		if @status=6
			set @title = 'JGFK'
		if @status=7
			set @title = 'CCPC'
		if @status=8
			set @title = 'THPC'
		if @status=9
			set @title = 'GZ'
		if @status=10
			set @title = 'TK'
		if @status=14
			set @title = 'CTK'	
		if @status=11
			set @title = 'GFK'	
		SELECT  @temp=MAX(initCode) FROM supplycenter..pro_orderCode  WITH(HOLDLOCK) 
		  WHERE status=@status and CONVERT(varchar(20),addDate,111)=CONVERT(varchar(20),GETDATE(),111)
		IF( @temp=0 OR  @temp IS NULL)
			BEGIN
				SET @temp=1
			END
		ELSE
			BEGIN
				SET @temp=@temp+1
			END
		DECLARE @CharTemp VARCHAR(20)
		SET @CharTemp=CAST(@temp AS VARCHAR(20))

		declare @codeLength int 
		set @codeLength=4
		
		if(@temp<10000)
		begin
			WHILE(LEN(@CharTemp)<@codeLength)
			BEGIN
				SET @CharTemp='0'+@CharTemp
			END
		end
		
		SET @code=@title+@code+@CharTemp
		INSERT INTO supplycenter..pro_orderCode (initCode,status) VALUES(@temp,@status)
	commit tran
	select @code as 'proCode'
END
