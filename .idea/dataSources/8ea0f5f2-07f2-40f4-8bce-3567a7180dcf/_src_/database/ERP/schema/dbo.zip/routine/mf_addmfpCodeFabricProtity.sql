/*  增加物料分解的面辅料  */

CREATE PROCEDURE [dbo].[mf_addmfpCodeFabricProtity] @pCodeFabricFormId int, @fabricNewId int, @doManId int 
AS

	DECLARE @returnValue INT
	SET @returnValue=0
	
	BEGIN tran
	
	IF( @pCodeFabricFormId<>0 and @fabricNewId<>0 and @doManId <> 0 )
	BEGIN
		
			INSERT INTO mf_pCodeFabricProtity (pCodeFabricFormId , fabricNewId, doManId )
				VALUES (@pCodeFabricFormId , @fabricNewId, @doManId )
				SET @returnValue=SCOPE_IDENTITY()	
				if (@@error<>0)
				begin
					set @returnValue=-3
				end

	END
	
	
	commit tran

	SELECT @returnValue
