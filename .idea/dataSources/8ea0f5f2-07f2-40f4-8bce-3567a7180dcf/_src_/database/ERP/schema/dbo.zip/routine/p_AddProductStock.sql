/**-------------------------------------------------------------添加商品入库记录------------------------------------------------*/
CREATE PROCEDURE [dbo].[p_AddProductStock] @inId INT,@productId INT,
					     @inPrice INT,@inCount INT,@colorId INT,@metricsId INT,@billCode VARCHAR(50),@code INT,@packStyleId INT,@deliverCompanyId INT,@quality VARCHAR(50),@weight VARCHAR(50),@location VARCHAR(50),@metricsRemark VARCHAR(200),@wbzsize VARCHAR(50)
AS
	DECLARE @returnValue INT
	DECLARE @count INT
	SET @returnValue=0
	SELECT @count=COUNT(*) FROM tb_productStock WHERE colorId=@colorId AND metricsId=@metricsId
	AND productId=@productId
	BEGIN TRAN 
	UPDATE tb_product SET packStyleId=@packStyleId,deliverCompanyId=@deliverCompanyId,quality=@quality,weight=@weight,location=@location,inSize=@metricsRemark,wbzsize=@wbzsize WHERE id=@productId
	UPDATE tb_buyBill SET causeStatus=5 WHERE billCode=@billCode
	IF(@count=0)
	BEGIN
		INSERT INTO tb_productStock(productId,colorId,metricsId,productCount) VALUES(@productId,@colorId,@metricsId,@inCount)
		INSERT INTO tb_inStockList(inId,inPrice,inCount,colorId,metricsId,productId,adaptCode,code)
		VALUES(@inId,@inPrice,@inCount,@colorId,@metricsId,@productId,@billCode,@code)
	END
	ELSE
	BEGIN
		UPDATE tb_productStock SET productCount=productCount+@inCount WHERE  colorId=@colorId AND metricsId=@metricsId AND productId=@productId
		INSERT INTO tb_inStockList(inId,inPrice,inCount,colorId,metricsId,productId,adaptCode,code)
		VALUES(@inId,@inPrice,@inCount,@colorId,@metricsId,@productId,@billCode,@code)
	END
	SET @returnValue=1
	COMMIT TRAN 
	SELECT @returnValue
