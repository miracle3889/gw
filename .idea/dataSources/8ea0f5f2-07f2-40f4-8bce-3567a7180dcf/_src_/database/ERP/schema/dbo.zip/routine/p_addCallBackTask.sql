/********************************************
添加外呼任务
**********/
CREATE procedure [dbo].[p_addCallBackTask] @productId int,@addMan int,@callType int,@callRemark varchar(500)
as 
  -- if not exists(select 1 from tb_callBackTask where productId=@productId and callType=@callType)
 -- begin
   declare @insertId int
   declare @callCount int
   insert into tb_callBackTask(productId,calltype,callRemark,addMan) values(@productId,@callType,@callRemark,@addMan)
   set @insertId=SCOPE_IDENTITY( )

   if(@callType=1)
   begin 
	insert into tb_callBackTaskOrder(taskId,orderId)
	select top 30  @insertId,a.id from supermarket..tb_order a
	inner join  supermarket..tb_orderSaleproduct b on a.id=b.orderId and a.orderstatus in(11,17)  and backCount>0 and isdelete<>1 and b.productId = @productId order by orderstatus desc

	select @callCount=count(*) from tb_callBackTaskOrder where taskId=@insertId
	
	update tb_callBackTask set orderCount=@callCount where id=@insertId
   end
   else
   begin
	insert into tb_callBackTaskOrder(taskId,orderId)
	select   @insertId,a.id from  supermarket..tb_order a
	inner join  supermarket..tb_orderSaleproduct b on a.id=b.orderId and a.orderstatus in(1) and isdelete<>1 and b.productId = @productId order by orderstatus desc
	select @callCount=count(*) from tb_callBackTaskOrder where taskId=@insertId
	
	update tb_callBackTask set orderCount=@callCount where id=@insertId
   end
 -- end
