CREATE procedure [dbo].[p_setJstatusOk]
as
insert into tb_jstatusHis(pcode,jstatus)
select pcode,7 from  erp..mf_pCodeFabricMsg  
where pCode  in(
select Pcode from  erp..tb_clipping a
inner join erp..tb_product b on a.productId=b.id 
where outCount*100/clippingCount>=90
and clippingCount>0 and clippingCount>10)  and jstatus<7

update erp..mf_pCodeFabricMsg set jstatus=7 where pCode  in(
select Pcode from  erp..tb_clipping a
inner join erp..tb_product b on a.productId=b.id 
where outCount*100/clippingCount>=90
and clippingCount>0 and clippingCount>10)  and jstatus<7
