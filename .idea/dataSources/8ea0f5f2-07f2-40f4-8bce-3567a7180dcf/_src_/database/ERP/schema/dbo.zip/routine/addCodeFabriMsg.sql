/*********		初始化款式		***********/
CREATE PROCEDURE [dbo].[addCodeFabriMsg]
 @pCode	varchar(50),
 @addUserId	int,
 @addDate	varchar(50),
 @sheJiShiId	int,
 @banShiId	int,
 @yangyiId	int,
 @originalId	int,
 @seasonId	int,
 @mainPatternId	int,
 @designWrittenId	int,
 @originalTypeId	int
AS

DECLARE @gouxiangId	INT  --原样bzid
set @gouxiangId=0
DECLARE @type INT  --原样类别
set @type=0
DECLARE @ruhnnbrandId INT  --原样店铺ID
set @ruhnnbrandId=-1
DECLARE @styleId INT  --当前款式ID
set @styleId=0
DECLARE @picId INT  --当前款式picID
set @picId=0
DECLARE @noOriginalPicId INT  --当前款式picID
set @noOriginalPicId=0

BEGIN
    --新增构想多媒体
    
    --如果来源出自原样
    if(@originalId<>0)
		begin
			if
				(@originalTypeId=0) select @ruhnnbrandId=sourceId,@type=typeId from ERP..tb_original where id=@originalId
		
			else 
				select @ruhnnbrandId=ruhnnbrandId,@type=type from ERP..mf_pCodeFabricMsg where id=@originalId
		end
	else
		begin
			insert into ERP..tb_multimedia_pid (count,type) values (0,1)
			set @noOriginalPicId=SCOPE_IDENTITY()
		end
	begin tran 	
	insert into ERP..tb_multimedia_pid (count,type) values (0,3)
	set @gouxiangId=SCOPE_IDENTITY()
	
	--新增设计稿多媒体
	insert into ERP..tb_multimedia_pid (count,type) values (0,1)
	set @picId=SCOPE_IDENTITY()
	
	

    --新增款式
	insert into ERP..mf_pCodeFabricMsg
	(pCode,addUserId,addDate,sheJiShiId,banShiId,yangyiId,originalId,seasonId,mainPatternId,designWrittenId,originalTypeId,gouxiangId,type,ruhnnbrandId,statusId,status,jstatus,doManId,developMode,picId)
	 values 
	 (0,@addUserId,GETDATE(),@addUserId,@banShiId,@yangyiId,@originalId,@seasonId,@mainPatternId,@picId,@originalTypeId,@gouxiangId,@type,@ruhnnbrandId,1,0,0,0,0,@noOriginalPicId)
	 set @styleId=SCOPE_IDENTITY()
	 
	 --更新款式pcode=id
	 update ERP..mf_pCodeFabricMsg set pCode=@styleId where id=@styleId
	 
	 exec p_addProductPcodeNew '',@styleId -- 添加商品，为商品添加服装款号，让服装款号和商品关联起来
	 
	 --增加款式状态记录
	 exec ERP..addCodeFabriMsgStatus_history @styleId,1,@addUserId
	 if @@ERROR<>0
	    rollback tran
	 commit tran
END
select @styleId
