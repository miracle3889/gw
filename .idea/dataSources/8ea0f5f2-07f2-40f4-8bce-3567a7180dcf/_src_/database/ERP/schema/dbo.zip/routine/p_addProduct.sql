/*------------------------------------------------添加商品------------------------------------------------------------*/
CREATE   PROCEDURE [dbo].[p_addProduct]  @name VARCHAR(150),@isOwn INT,
				          @categoryOneId INT,@categoryTwoId INT,
				          @remark VARCHAR(500),@price INT,
				          @priceScore INT,@priceRemark VARCHAR(200),
				          @gAmount INT,@gAmountScore INT,
				          @gAmountRemark VARCHAR(200),@fillTime INT,
				          @fillTimeScore INT,@fillTimeRemark VARCHAR(200),
				          @rejectTime INT,@rejectTimeScore INT,
				          @rejectTimeRemark VARCHAR(200),@deliverP INT,
				          @deliverPScore INT,@deliverPRemark VARCHAR(200),
				          @clearP INT,@clearPScore INT,
				          @clearPRemark VARCHAR(200),@server INT,
				          @serverScore INT,@serverRemark VARCHAR(200),
				          @beauty INT,@beautyScore INT,
				          @beautyRemark VARCHAR(200),@useful INT,
				          @usefulScore INT,@usefulRemark VARCHAR(200),
				          @newP INT,@newPScore INT,@newPRemark VARCHAR(200),
					  @stockPrice INT,@minStockCount INT,@uintId INT,
					  @pCount INT,@pCode VARCHAR(50),@useRemark VARCHAR(500),@quality VARCHAR(50)
AS
	DECLARE @count INT
	DECLARE @returnValue INT
	DECLARE @code VARCHAR(20)
SET @returnValue=0
	BEGIN TRAN 
		SELECT @count=COUNT(*) FROM dbo.tb_product WHERE name=@name or (pCode=@pCode and pCode <>'')
		IF(@count!=0)
		BEGIN
			SET @returnValue=-1
		END
		ELSE
		BEGIN
			EXEC p_getProductCode  @categoryTwoId,@code OUTPUT
			INSERT INTO dbo.tb_product( name ,isOwn, 
				          categoryOneId,categoryTwoId ,
				          remark,price ,
				          priceScore ,priceRemark ,
				          gAmount ,gAmountScore ,
				          gAmountRemark ,fillTime ,
				          fillTimeScore ,fillTimeRemark ,
				          rejectTime ,rejectTimeScore ,
				          rejectTimeRemark ,deliverP ,
				          deliverPScore ,deliverPRemark ,
				          clearP ,clearPScore ,
				          clearPRemark ,server ,
				          serverScore ,serverRemark ,
				          beauty ,beautyScore ,
				          beautyRemark ,useful ,
				          usefulScore ,usefulRemark ,
				          newP ,newPScore ,newPRemark,code,stockPrice,minStockCount,uintId,pCount,pCode,useRemark,quality)
				VALUES( @name ,@isOwn,
				          @categoryOneId,@categoryTwoId ,
				          @remark,@price ,
				          @priceScore ,@priceRemark ,
				          @gAmount ,@gAmountScore ,
				          @gAmountRemark ,@fillTime ,
				          @fillTimeScore ,@fillTimeRemark ,
				          @rejectTime ,@rejectTimeScore ,
				          @rejectTimeRemark ,@deliverP ,
				          @deliverPScore ,@deliverPRemark ,
				          @clearP ,@clearPScore ,
				          @clearPRemark ,@server ,
				          @serverScore ,@serverRemark ,
				          @beauty ,@beautyScore ,
				          @beautyRemark ,@useful ,
				          @usefulScore ,@usefulRemark ,
				          @newP ,@newPScore ,@newPRemark,@code,@stockPrice,@minStockCount,@uintId,@pCount,@pCode,@useRemark,@quality)
		SET @returnValue=SCOPE_IDENTITY()
		END
	COMMIT TRAN 
	SELECT @returnValue
