create procedure [dbo].[p_addBlackMobileNum] @mobileNum varchar(11),@doManId int
as

	if not exists(select 1 from  c3..tb_blackMobile  where mobileNum=@mobileNum) 
	begin
		insert into  c3..tb_blackMobile(mobileNum,addManId) values(@mobileNum,@doManId)
	end
