/*-----------------------------------------添加二级类别---------------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[p_addCategoryTwo] @name VARCHAR(50),@parentId INT,
					          @priceA INT,
					          @priceB INT,
 					          @priceC INT,
					          @gAmountA INT,
					          @gAmountB INT,
					          @gAmountC INT,					         
					          @fillTimeA INT,
					          @fillTimeB INT,
    					          @fillTimeC INT,
					          @clearPA INT,
					          @clearPB INT,
					          @clearPC INT,
				   	          @serverA INT,
				   	          @serverB INT,
				   	          @serverC INT,
					          @remark VARCHAR(200)			
AS
	DECLARE @code VARCHAR(20)
	DECLARE @returnValue INT
	DECLARE @count INT
	SET @returnValue=0
	SELECT @count=COUNT(*) FROM tb_categoryTwo WHERE name=@name AND isdeleted=0
	IF(@count!=0) 
	BEGIN
		SET @returnValue=-1
	END
	ELSE
	BEGIN
	EXEC p_getCategoryTwoCode @parentId,@code OUTPUT
	IF(@code IS NOT NULL)
	BEGIN
		BEGIN TRAN 
		DECLARE @TMP INT
		INSERT INTO tb_categoryTwo(name,parentId,code,remark) VALUES(@name,@parentId,@code,@remark)
		SET  @TMP=SCOPE_IDENTITY( )
		INSERT INTO tb_categoryTwoP(categoryTwoId, 
					          priceA ,
					          priceB ,
 					          priceC ,
					          gAmountA ,
					          gAmountB ,
					          gAmountC ,					         
					          fillTimeA ,
					          fillTimeB ,
    					          fillTimeC ,
					          clearPA ,
					          clearPB ,
					          clearPC ,
				   	          serverA ,
				   	          serverB ,
				   	          serverC)
					VALUES
					(        @TMP,
					          @priceA ,
					          @priceB ,
 					          @priceC ,
					          @gAmountA ,
					          @gAmountB ,
					          @gAmountC ,					         
					          @fillTimeA ,
					          @fillTimeB ,
    					          @fillTimeC ,
					          @clearPA ,
					          @clearPB ,
					          @clearPC ,
				   	          @serverA ,
				   	          @serverB ,
				   	          @serverC 		
					)
		SET @returnValue=@TMP
		COMMIT TRAN
	END
	END
	SELECT @returnValue
