CREATE procedure [dbo].[p_changeToAddShelf] @instockId int,@doManId int 
as 
	/*
	insert into tb_orderInstockProduct(instockId,productCode,productCount,inStockCount,loseCount,injureCount,shelfCode)
	select @instockId,productShelfCode,productCount,inStockCount,loseCount,injureCount,'' from (
	--删除订单
	select e.productShelfCode,sum(c.buyCount) as productCount,sum(c.buyCount-c.loseCount) as inStockCount,0 as loseCount,sum(c.loseCount) as injureCount from supermarket..tb_order a 
	inner join tb_orderInstockOrder b on a.id=b.orderId and  b.instockId=@instockId and b.type=1
	inner join supermarket..tb_orderSaleProduct c on a.id=c.orderId
	inner join supermarket..tb_saleProduct d on d.id=c.saleProductId 
	inner join tb_productStock e on e.productId=d.productId and e.colorId=c.colorId and c.metricsId=e.metricsId
	group by e.productShelfCode
	
	union all 
	
	--拒收订单
	select e.productShelfCode,sum(c.backCount) as productCount,sum(c.backCount-c.loseCount) as inStockCount,0 as loseCount, sum(c.loseCount) as injureCount from supermarket..tb_order a 
	inner join tb_orderInstockOrder b on a.id=b.orderId and  b.instockId=@instockId and b.type=2
	inner join supermarket..tb_orderSaleProduct c on a.id=c.orderId and c.backCount>0
	inner join supermarket..tb_saleProduct d on d.id=c.saleProductId 
	inner join tb_productStock e on e.productId=d.productId and e.colorId=c.colorId and c.metricsId=e.metricsId
	group by e.productShelfCode

		
	union all 
	
	--退货单
	select e.productShelfCode,sum(y.getCount) as productCount,sum(y.getCount-y.loseCount) as inStockCount ,0 as loseCount,sum(y.loseCount) as injureCount from supermarket.dbo.tb_backOder a 
	inner join tb_orderInstockOrder b on a.id=b.orderId and  b.instockId=@instockId and b.type=3
	inner join supermarket.dbo.tb_backProduct y on y.backId=a.id
	inner join supermarket..tb_orderSaleProduct c on c.id=y.orderSaleId
	inner join supermarket..tb_saleProduct d on d.id=c.saleProductId 
	inner join tb_productStock e on e.productId=d.productId and e.colorId=c.colorId and c.metricsId=e.metricsId
	group by e.productShelfCode
	) as totalProduct
	*/
	--update tb_orderInstockProduct set shelfCode=b.shelfCode from tb_orderInstockProduct a ,tb_shelfProductCount b 
	--where a.productCode=b.productCode and a.instockId=@instockId and b.shelfCode not in('A0000','X0000','Y0000') and b.productCount>0
	
	update tb_orderInstockProduct set shelfCode=b.shelfCode from tb_orderInstockProduct a ,(
	select a.* from tb_shelfProductCount a
	inner join (
	select productCode,max(productCount) as productCount from  tb_shelfProductCount  where   productCount>0  and shelfCode not in('A0000','X0000','Y0000') and shelfCode not like 'T____'
	group by  productCode ) as  b on a.productCode=b.productCode and a.productCount=b.productCount) b 
	where a.productCode=b.productCode and a.instockId=@instockId   



	declare @count int 
	select @count=count(*) from tb_orderInstockProduct where instockId=@instockId
	
	update tb_orderInstock set okTime=getdate(), status=1,productCount=@count where id=@instockId


	update tb_dealUpdateOrder set isIn=1 where orderId in( select orderId from tb_orderInstockOrder  where instockId=@instockId and  type=1)

	delete from supermarket..tb_rejectOrder where orderId in(select orderId from tb_orderInstockOrder  where instockId=@instockId and  type=2)
