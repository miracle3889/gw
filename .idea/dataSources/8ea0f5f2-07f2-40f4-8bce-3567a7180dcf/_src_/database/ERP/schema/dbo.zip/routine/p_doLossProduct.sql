/************异常类型添加操作**************/
/*1为退货入库*/
/*2为退货报损*/
/*3为日常报损*/
CREATE PROCEDURE [dbo].[p_doLossProduct]  @id int, @color int,
					  @metrics int, @doMan int,
					  @lossCount int,
					  @type int, @orderCode varchar(50)
AS
	declare @returnid int
	declare @count int
 	set xact_abort on 
	BEGIN TRAN 
		/**********************添加到异常入库表*********************/
		insert into tb_exceptionInStock(productId,colorId,metricsId,doMan,pCount,type,orderCode)
		values(@id,@color,@metrics,@doMan,@lossCount,@type,@orderCode)
		set @returnid=SCOPE_IDENTITY()
		
		if (@type=1)
		begin	
				/***************************更新库存****************************/
				update tb_productStock set productCount=productCount+@lossCount WHERE productId=@id AND metricsId=@metrics AND colorId=@color
		end

		SELECT @count=COUNT(*) FROM tb_lossProduct  WHERE colorId=@color AND metricsId=@metrics AND productId=@id
		if (@type=2 OR @type=3)
		begin
			if (@count=0)
			begin
				/*********************添加到报损商品表**********************/
				insert into tb_lossProduct(productId,colorId,metricsId,lossCount)
				 values(@id,@color,@metrics,@lossCount)
			end
			else
			begin
				/*********************更新报损商品表***************************/
				update tb_lossProduct set lossCount=lossCount+@lossCount where colorId=@color and metricsId=@metrics
				and productId=@id
			end
		end
			

		if(@type=3)	
		begin
			update tb_productStock set productCount=productCount-@lossCount WHERE productId=@id AND metricsId=@metrics AND colorId=@color			
		end
	COMMIT TRAN
