CREATE procedure [dbo].[p_insertImageByQuery]
 @url varchar(200) ,
 @pid int ,
 @weixinId varchar(200) ,
 @mainPic varchar(5) ,
 @userId int 
as
DECLARE @returnValue INT --回滚事务
DECLARE @identity INT --最新ID
  begin
	  insert into erp..tb_image(url,pid,WeixinId,mainPic,userId,updateTime) values (@url,@pid,@weixinId,@mainPic,@userId,getDate())
	  set @identity=SCOPE_IDENTITY();
	  exec ERP..p_getCountByPid @pid,@returnValue output ;
  end
  begin
	if(@returnValue<>0)
		begin
			select @identity as 'ret';
		end
	else
		begin
			select @returnValue as 'ret';
		end
  end
