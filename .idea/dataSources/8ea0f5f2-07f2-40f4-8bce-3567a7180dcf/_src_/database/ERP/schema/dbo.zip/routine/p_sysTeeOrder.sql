-----同步t恤订单
CREATE  procedure [dbo].[p_sysTeeOrder] 
as
	declare @sellerNick varchar(10)
	
	set @sellerNick='teegether'
	
	
	
	-----更新标志位  将未读取订单更新为处理中
	update ERP..tb_TShirt_order set addStatus=2 where addStatus=0
	and orderId  in(
	select orderId from (
	
	select a.orderId,a.productCount,count(*) as skuCount from ERP..tb_TShirt_order a
	inner join tb_Tshirt_sku b on a.orderId=b.orderId 
	where addStatus=0 group by a.orderId,a.productCount
	
	) as x where x.productCount=skuCount)
	
	
	update ERP..tb_TShirt_order set address=province+'|'+city+'|'+district+'|'+street where addstatus=2
	
	
	-----如果存在需要处理的订单
	if exists(select 1 from  ERP..tb_TShirt_order where addStatus=2)
	begin
		--获取订单号
		update ERP..tb_TShirt_order set orderCode=
		 supermarket.[dbo].[f_getOrderCode](orderId,'02',@sellerNick) where addStatus=2 
		 
		--__________________________________________________________________________________________________________
		--添加不存在的会员信息
		insert into supermarket..tb_member(nickname,type,name,mobileNum,phoneNum,homeAddr,post,source,
		comeFrom,provinceId,cityId,homeAddrRegional)
		select a.phone,1, a.address,a.phone,a.phone,a.address,'00000',
		  'teegether','teegether',
		  a.provinceId,a.cityId,a.regionalId
		  from  ERP..tb_TShirt_order  a
		  left join supermarket..tb_taobaoMember b 
		  on a.phone=b.taobaoNickName 
		   where 	  addStatus=2
		  and   b.id is null group  by 	  a.phone,a.address,a.provinceId,a.cityId,a.regionalId
	  
	  
		--添加到会员表
		insert into  supermarket..tb_taobaoMember(memberId,taobaoNickname,source) 
		select a.ID,b.phone,@sellerNick from supermarket..tb_member a
		inner join  ERP..tb_TShirt_order b on a.nickname=b.phone and  b.addStatus=2
		left join supermarket..tb_taobaoMember c on c.taobaoNickName=b.phone
		where c.id is null group by a.id,b.phone 
			 
			--更新会员Id
		update  ERP..tb_TShirt_order  set memberId=b.memberId 
		from  ERP..tb_TShirt_order a, 
		supermarket..tb_taobaoMember b where  a.phone=b.taobaoNickname and a.addStatus=2
	--________________________________________________________________________________________________________________________	
		
		begin
			begin tran 
			
			--添加订单关联的店铺
			insert into  supermarket..tb_orderNickName(orderCode,nickName)
			select  orderCode,@sellerNick  from ERP..tb_TShirt_order
			 where addStatus=2   
			 
			--添加订单信息
			INSERT INTO SuperMarket.dbo.tb_order(orderCode,payType,deliverType,deliverPrice,memberId,orderStatus,
										   doMan,reMark,magazineCode,magazineCodeS,magSourceRemark,receviceMan,post,
										   receviceAddr1,receviceAddr2,receviceMobile,addrId,useAccount,getScore,
										   regionalId1,regionalId2,useGift,orderSource,provinceId ,cityId ,
										   createTime,paymentDate,buyCountOrder,outCode,productPrice)
									               
			select  orderCode,11,1,0,memberId,1,1,@sellerNick+'：'+cast(orderId  as varchar(20)),
			1,@sellerNick,@sellerNick,name,'000000',address,address,phone,1,0,0,regionalId,regionalId,
			0,3,provinceId,cityId,payTime,paytime,1,orderId,productPrice
			
			from ERP..tb_TShirt_order where addStatus=2  
			
			
			
			
			--添加商品信息
			INSERT INTO supermarket.dbo.tb_orderSaleProduct(orderId,colorId,metricsId,saleProductCode,
							saleProductId,buyCount,stockPrice,productId,giftPrice,outOCode)	 
						
			select a.id,c.colorId,c.metricsId,skuId,d.id,b.count,e.stockpriceReal,e.id,0,b.id 
			from 	 supermarket.dbo.tb_order  a 
			inner join erp..tb_Tshirt_sku b on a.outCode=b.orderId
				inner join erp..tb_productStock c on c.productShelfCode=b.skuId
				inner join supermarket..tb_saleProduct d on d.productId=c.productId and  c.productShelfCode like '%'+d.saleCode+'%'
				inner join erp..tb_product e on e.id=d.productId 
				inner join ERP..tb_TShirt_order x on x.orderCode=a.orderCode and x.addStatus=2 and a.isDelete=0


			--商品价格
			insert into supermarket.dbo.tb_orderSaleProductPay(orderSaleProductId,payType,payValue)  
			select c.id,1,b.amount/b.count from 	 supermarket.dbo.tb_order  a 
			inner join erp..tb_Tshirt_sku b on a.outCode=b.orderId  
			inner join supermarket..tb_orderSaleProduct c on c.outOCode=b.id and c.orderId=a.id 
			inner join ERP..tb_TShirt_order x on x.orderCode=a.orderCode and x.addStatus=2 and a.isDelete=0

			--标记为已经处理
			update ERP..tb_TShirt_order set addStatus=1 where addStatus=2 
			
			commit tran 
		end
		
	end
