-- =============================================
-- Author:		<runbin>
-- Create date: <2015-11-23>
-- Description:	<采购单完结审批>
-- =============================================
CREATE PROCEDURE [dbo].[sc_approvalFinishingPurchase]
	@purchaseCode varchar(20),	--票据单号
	@userId int,	--用户id
	@approvalResult int,	--审批结果
	@purchaseId int,	--采购单id
	@currentProcess int,	--当前审批进度
	@pid int	--备注pid
AS
BEGIN
	declare @approvalType int	--审批类型
	declare @payBatchId	varchar(20)	--批量付款单号
	begin tran
		declare @ret int	--返回值
		declare @amount int	--总流程数
		declare @approvalStatus int	--审批状态
		declare @groupId int	--审批级别
		declare @temp int
		
		
		declare @allturnMoney int --总转入合同金额
		declare @turnMoney	int --转入合同金额
		declare @oldPayBatchId varchar(50) --转入付款批次
		declare @oldPayAmount int --转入金额
		declare @finishId int --完结id
		
		set @ret=-1
		select @amount = amount from supplyCenter..pro_approval_type where typeId =
			(
				select approvalType from supplyCenter.materie.tb_finish_purchase where purchaseId=@purchaseId and approvalStatus<>2
			)	--查找总流程数
		select @groupId=groupId from ERP..tb_user where id = @userId	--查询审批人组别
		
		select @payBatchId=payBatchId,@approvalType=approvalType from 
					supplyCenter.materie.tb_finish_purchase where purchaseId = @purchaseId and approvalStatus<>2
		
		--if  not exists (select 1 from SuperMarket..pro_approval where documentId=@purchaseCode 
		--						and approvalUserId = @userId and documentType= @approvalType)
		begin
			--print @currentProcess
			--if @groupId!=@currentProcess
				
			if not exists (select 1 from supplyCenter..pro_approval_config a 
		inner join ERP..tb_user b on a.groupId = b.groupId and
		 a.typeId=@approvalType and a.grade = @currentProcess and b.id = @userId)
		
			set @ret=-1
		else
			begin
				
				if (@approvalResult = 1 )	--审批通过
					begin
						if @currentProcess< @amount	--不是最后一人审批进度加一
							begin
								set @currentProcess = @currentProcess+1
								set @approvalStatus = 1
							end
						else if @currentProcess=@amount	--最后一人审批且通过,流程结束
							set @approvalStatus = 3
					end
				else	--审批不通过
					begin
						set @approvalStatus = 2
					end
				
				
				insert into SuperMarket..pro_approval	--插入审批记录表
					(documentId,documentType,approvalUserId,approvalTime,approvalResult,mediaRemark,configId)
					values(@purchaseCode,@approvalType,@userId,GETDATE(),@approvalResult,@pid,
							(select id from supplyCenter..pro_approval_config where typeId = @approvalType
								and groupId = (select groupId from ERP..tb_user where id = @userId)) 
					)
				print '@approvalStatus1'+cast(@approvalStatus as varchar(10))	
				set @ret= SCOPE_IDENTITY()
				
	
				if @ret>0
				begin
				
				print '@approvalStatus3'+cast(@approvalStatus as varchar(10))
				
					update supplyCenter.materie.tb_finish_purchase	--更新采购单完结表
								set approvalStatus = @approvalStatus,currentProcess = @currentProcess
							where purchaseId = @purchaseId and approvalStatus <> 2
							
					if @payBatchId is not null --转入合同,同时审批批量付款
					begin 
						
						--转入合同的采购单批量付款审批
						update supplyCenter.materie.tb_payment
							set approvalStatus = @approvalStatus,currentProcess = @currentProcess
						where payBatchId = @payBatchId
					
						
						insert into SuperMarket..pro_approval	--插入批量付款审批记录表
							(documentId,documentType,approvalUserId,approvalTime,approvalResult,mediaRemark,configId)
							values(@payBatchId,3,@userId,GETDATE(),@approvalResult,0,
									(select id from SuperMarket..pro_approval_config where typeId = 3
										and groupId = (select groupId from ERP..tb_user where id = @userId)
										) 
							)
						
						if @approvalStatus=3	--财务总监审批通过
						begin
							--转入总金额
							select @allturnMoney=money,@finishId=id from supplyCenter.materie.tb_finish_purchase where purchaseId=@purchaseId
							
							--减少采购单已付金额
							update supplyCenter.materie.tb_materiePurchase set paidMoney = paidMoney-@allturnMoney where id = @purchaseId
						
							--查找采购单下所有已付的付款单,包含，按金额倒序
							begin
								declare pay_cursor CURSOR FOR	--采购单编号游标
									select a.payBatchId,payAmount from supplyCenter.materie.tb_payment a 
										inner join supplyCenter.materie.tb_payment_child b on a.payBatchId = b.payBatchId
										where a.approvalStatus=3  and b.purchaseId = @purchaseId order by b.payAmount desc
								
								open pay_cursor
									FETCH NEXT FROM pay_cursor INTO @oldPayBatchId,@oldPayAmount	--减少已付款金额
									WHILE @@FETCH_STATUS = 0
										begin
											
											if(@allturnMoney=0) break;
											
											if(@allturnMoney>@oldPayAmount) --转入金额大于老付款单的已付金额
											begin
												update supplyCenter.materie.tb_payment set totalAmount=totalAmount-@oldPayAmount where payBatchId=@oldPayBatchId
												update supplyCenter.materie.tb_payment_child set payAmount=payAmount-@oldPayAmount where payBatchId=@oldPayBatchId and purchaseId=@purchaseId
												set @turnMoney = @oldPayAmount
												set @allturnMoney=@allturnMoney-@oldPayAmount
											end
											
											if(@allturnMoney<=@oldPayAmount) --转入金额小于老付款单的已付金额
											begin
												update supplyCenter.materie.tb_payment set totalAmount=totalAmount-@allturnMoney where payBatchId=@oldPayBatchId
												update supplyCenter.materie.tb_payment_child set payAmount=payAmount-@allturnMoney where payBatchId=@oldPayBatchId and purchaseId=@purchaseId
												set @turnMoney = @allturnMoney
												set @allturnMoney=0
											end
											
											--插入完结采购单子表，记录转入批次号及金额
											insert into supplyCenter.materie.tb_finish_purchase_child (finishId,oldPayBatchId,money)
											values(@finishId,@oldPayBatchId,@turnMoney)
											
											
											FETCH NEXT FROM pay_cursor INTO @oldPayBatchId,@oldPayAmount	
										end
								CLOSE pay_cursor--关闭游标
								DEALLOCATE pay_cursor--释放游标
							end
							
							--更新被转入的采购单的已付金额
							begin
								declare purchaseId_cursor CURSOR FOR	--采购单编号游标
									select a.purchaseId from supplyCenter.materie.tb_payment_child a  join supplyCenter.materie.tb_payment b
										on a.payBatchId = b.payBatchId where b.payBatchId = @payBatchId and b.approvalStatus=3
								
								open purchaseId_cursor
									FETCH NEXT FROM purchaseId_cursor INTO @temp	--更新已付款金额
									WHILE @@FETCH_STATUS = 0
										begin
											 update supplyCenter.materie.tb_materiePurchase set paidMoney = 
												paidMoney+(select payAmount from supplyCenter.materie.tb_payment_child where purchaseId = @temp and payBatchId=@payBatchId )
											 where id = @temp
											FETCH NEXT FROM purchaseId_cursor INTO @temp
										end
								CLOSE purchaseId_cursor--关闭游标
								DEALLOCATE purchaseId_cursor--释放游标
							end
						end
					end
							
					if @approvalStatus=3	--审批通过
						begin
							declare @contract int	--合同id
							--更新采购单完结状态
							update supplyCenter.materie.tb_materiePurchase set finishStatus = 1,finishUserId=@userId,finishTime=GETDATE()
								where id = @purchaseId
								
							select @contract = contractId from supplyCenter.materie.tb_materiePurchase where id = @purchaseId
							--采购单完结,判断该采购单所属合同下的采购单是否都完结,是则完结合同
							if not exists (select 1 from supplyCenter.materie.tb_materiePurchase where finishStatus<>1 and contractId = @contract)
								begin
									update supplyCenter.materie.tb_contract  set finishStatus = 3 where id = @contract
								end 
							
						end
					else if @approvalStatus=2 --审批拒绝
						begin
							--更新采购单完结状态
							update supplyCenter.materie.tb_materiePurchase set finishStatus = 2,finishTime=GETDATE(),finishUserId=@userId where id = @purchaseId
							
							delete from SuperMarket..pro_approval_history	--删除审批历史记录
								where documentId = @purchaseCode and documentType=@approvalType
								
							insert into SuperMarket..pro_approval_history	--插入审批记录表
							(documentId,documentType,approvalUserId,approvalTime,approvalResult,mediaRemark,configId)
							values(@purchaseCode,@approvalType,@userId,GETDATE(),@approvalResult,@pid,
									(select id from SuperMarket..pro_approval_config where typeId = @approvalType
										and groupId = (select groupId from ERP..tb_user where id = @userId)) 
							)
							
							insert into SuperMarket..pro_approval_history	--插入审批记录历史表
							(documentId,documentType,approvalUserId,approvalTime,approvalResult,mediaRemark,configId)
							select documentId,documentType,approvalUserId,approvalTime,approvalResult,mediaRemark,configId
								from SuperMarket..pro_approval where documentId = @purchaseCode and documentType=@approvalType
								and approvalUserId<>@userId
							
						end
				end
			end	
		end
	if @@error <> 0  
    begin 
		set @ret=-1
		rollback tran 
	end
	commit tran
	select @ret as 'ret'
END
