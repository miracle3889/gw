CREATE PROCEDURE [dbo].[p_addMacIp] @macIp varchar(50),@macRemark varchar(50),@addManId int
as
   declare @returnValue int
	set @returnValue=0
   if EXISTS(select 1 from erp..tb_macIp where macIp=@macIp)
	set @returnValue=-1
   else
	begin
		insert into erp..tb_macIp(macIp,name,addManId) values(@macIp,@macRemark,@addManId)
		set @returnValue=SCOPE_IDENTITY( )
	end
   select @returnValue
