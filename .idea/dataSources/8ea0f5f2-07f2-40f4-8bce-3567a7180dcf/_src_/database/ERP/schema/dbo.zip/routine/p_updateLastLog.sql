create procedure [dbo].[p_updateLastLog] @user int
as 
update erp..tb_user set lastAccessTime=GETDATE() where id=@user
