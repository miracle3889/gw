CREATE PROCEDURE [dbo].[P_LoginNew] @userName VARCHAR(15),@PSW VARCHAR(15),@departId INT,@macIp VARCHAR(50) 
AS 
	SELECT a.id AS id,a.name AS name,a.post AS post,b.name AS departname,b.id AS departId FROM tb_user a 
	INNER JOIN tb_depart b ON a.departId=b.id 
	INNER JOIN tb_macIp c ON c.macIp=@macIp
	WHERE a.userName=@userName AND psw=dbo.md5(@PSW) AND (a.departId=@departId OR a.departId=1)
