/*******************************添加出库商品*************************************************************/

CREATE  PROCEDURE [dbo].[p_setOutProductNew] @orderId INT,@outId INT
AS
	declare @count int
	declare @colorId int 
	declare @metricsId int
	declare @productId int 
	declare @productCode varchar(50)
	declare @buyCount int
			
	BEGIN TRAN 
	/*****************根据该次出库号设置该次出库单件商品********************/
	declare cs CURSOR for
	SELECT a.colorId,a.metricsId,b.id,b.code,a.buyCount 
	FROM SuperMarket.dbo.tb_orderSaleProduct a
 	INNER JOIN SuperMarket.dbo.tb_saleProduct c ON a.saleProductId=c.id 
	INNER JOIN dbo.tb_product b ON c.productId=b.id 
	where a.orderId=@orderId
	open cs
	fetch next from cs
	into @colorId,@metricsId,@productId,@productCode,@buyCount
	while @@fetch_status =0
	begin
	select @count=count(*) from tb_outProduct
	where outId=@outId and colorId=@colorId and metricsId=@metricsId and productId=@productId
	if (@count=0)
		begin
		INSERT INTO dbo.tb_outProduct(outId,colorId,metricsId,productId,productCode,outCount) 
		values(@outId,@colorId,@metricsId,@productId,@productCode,@buyCount)
		end
	else
		begin
		update tb_outProduct set outCount=outCount+@buyCount	
		where outId=@outId and colorId=@colorId and metricsId=@metricsId and productId=@productId
		end
	fetch next from cs
	into @colorId,@metricsId,@productId,@productCode,@buyCount
	end
	close cs
	deallocate cs

	/*****************根据该次出库号设置该次出库组合中的商品********************/
	declare cs CURSOR for
	select b.colorId,b.metricsId,d.id,d.code,a.buyCount*b.buyCount
	from SuperMarket.dbo.tb_orderSaleGroup a 
	inner join SuperMarket.dbo.tb_orderSaleGroupProduct b on b.orderSaleGroupId=a.id
	inner join SuperMarket.dbo.tb_saleProduct c on c.id=b.saleProductId
	inner join tb_product d on d.id=c.productId
	where a.orderId=@orderId
	open cs
	fetch next from cs
	into @colorId,@metricsId,@productId,@productCode,@buyCount
	while @@fetch_status =0
	begin
	select @count=count(*) from tb_outProduct
	where outId=@outId and colorId=@colorId and metricsId=@metricsId and productId=@productId
	if (@count=0)
		begin
		INSERT INTO dbo.tb_outProduct(outId,colorId,metricsId,productId,productCode,outCount) 
		values(@outId,@colorId,@metricsId,@productId,@productCode,@buyCount)
		end
	else
		begin
		update tb_outProduct set outCount=outCount+@buyCount	
		where outId=@outId and colorId=@colorId and metricsId=@metricsId and productId=@productId
		end
	fetch next from cs
	into @colorId,@metricsId,@productId,@productCode,@buyCount
	end
	close cs
	deallocate cs
	
	UPDATE SuperMarket.dbo.tb_order SET orderStatus=13 WHERE id=@orderId
	IF(@@error<>0)
	BEGIN
		PRINT '111111111' 
	END
	COMMIT TRAN
