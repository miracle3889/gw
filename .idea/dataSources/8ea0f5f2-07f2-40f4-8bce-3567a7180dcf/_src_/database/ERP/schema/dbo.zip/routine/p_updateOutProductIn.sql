CREATE procedure [dbo].[p_updateOutProductIn] @outId int ,@doManId int
as 
	if exists(select 1 from tb_outFromFactory where id=@outId and status<>3)
	begin
	declare @okshelfCount int 
	declare @tShelfCount int
	
	select @okshelfCount=COUNT(*) from tb_outFromFactoryProduct a
	inner join erp..[tb_goodsShelf ] b on a.shelfCode=b.code and b.isStock=1 and factoryId=@outId
	
	if(@okshelfCount is null ) set @okshelfCount=0
	
	declare @inCount int
	--入库商品数量
	select @inCount=sum(inCount),@tShelfCount=COUNT(*) from tb_outFromFactoryProduct where factoryId=@outId
	
	if @inCount is null set @inCount=0
	--更新状态和入库数量
	if(@tShelfCount is null ) set @tShelfCount=0
	
	if(@tShelfCount=@okshelfCount)--货架号填写全部正确
	begin
		
		begin tran 
		update tb_outFromFactory set inTime=getDate(),inManId=@doManId,status=3,inCount=@inCount  where id=@outId
		--更新裁床单出货数量
		
		update  tb_clippingProtity set outCount=b.outCount+a.inCount from 
		(select clippingProtityId,sum(inCount) as inCount from   
		tb_outFromFactoryProduct where factoryId=@outId group by clippingProtityId)  a, 
		tb_clippingProtity b where  a.clippingProtityId=b.id   

		
		update tb_clipping set outCount=b.outCount from tb_clipping a,(
		
		select clippingId,sum(outCount) as outCount from tb_clippingProtity where clippingId in(
		select clippingId   from tb_clippingProtity  where id in(select clippingProtityId from tb_outFromFactoryProduct where factoryId=@outId))
		group by clippingId
		) b 

		where a.id=b.clippingId
		
		
		
		---商品入库到待入库区
		
		declare @id int,@colorId int ,@metricsId int ,@productId int ,@productCode varchar(50),@shelfCode varchar(50)
		
		DECLARE  cs CURSOR FOR 
			select c.productId,c.colorId,c.metricsId,a.inCount,c.productShelfCode,shelfCode from tb_outFromFactoryProduct a
			inner join tb_clippingProtity b on a.clippingProtityId=b.id 
			inner join tb_productStock c on c.colorId=b.colorId and c.metricsId=b.metricsId   where  factoryId=@outId
			OPEN cs
			FETCH NEXT FROM cs
			INTO @productId,@colorId,@metricsId,@inCount,@productCode,@shelfCode
			WHILE @@fetch_status =0
			BEGIN		

				exec p_addProductStockCount  @productId,@colorId,@metricsId,@inCount,1,@doManId,'采购入库'

				--SKU编号不存在
				if(@productCode is null  or @productCode='') 
				begin
					exec p_getShelfProductCode @productId,@colorId,@metricsId,@productCode output
					
					if(@productCode is null) 
					begin
						set @productCode=''
					end
					update tb_productStock set productShelfCode =@productCode
					 where productId=@productId and colorId=@colorId and metricsId=@metricsId
					
					if not exists (select 1 from erp..tb_productSkuCode 
					where productId=@productId and colorId=@colorId and metricsId=@metricsId )
					begin
						insert into tb_productSkuCode(productShelfCode,productId,colorId,metricsId)
						 values(@productCode,@productId,@colorId,@metricsId)
					end
				end	
				
				exec [dbo].[p_addShelfStockBySystem] @shelfCode,@productCode,@inCount,@doManId,4,''
				
				FETCH NEXT FROM cs
				INTO @productId,@colorId,@metricsId,@inCount,@productCode,@shelfCode
			END
			
			CLOSE cs
			DEALLOCATE cs	
			commit tran
		end
	end
