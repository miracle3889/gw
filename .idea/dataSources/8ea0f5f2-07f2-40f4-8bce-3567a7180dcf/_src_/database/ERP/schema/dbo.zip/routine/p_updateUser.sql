CREATE   procedure  [dbo].[p_updateUser] 
	@cardCode varchar(50),
	@name varchar(50),
	@sex int,
	@departId int,
	@post int,
	@status int,
	@pic varchar(50),
	@mobileNum varchar(50),
	@identityCard varchar(50),
	@MSN varchar(50),
	@QQ varchar(50),
	@educationId int,
	@addr varchar(200),
	@educationDesc varchar(500),
	@workexperience varchar(500),
	@isCanLoginIn int,
	@userName varchar(50),
	@psw varchar(50),
	@id int,
	@userCodes varchar(100)
as
	declare @returnValue int
	set  @returnValue=0
	declare @count int
	if(@userName='')
	begin
		select @count=count(*) from tb_user where id!=@id and (cardCode=@cardCode)
	end
	else
	begin
		select @count=count(*) from tb_user where id!=@id and (cardCode=@cardCode or userName=@userName)
	end
	if(@count>0)
		begin	
		set  @returnValue=-1
		end
	else
		begin 
			update dbo.tb_user set cardCode=@cardCode,name=@name
					,sex=@sex,departId=@departId,post=@post,status=@status,
					pic=@pic,
					mobileNum=@mobileNum,
					identityCard=@identityCard,
					MSN=@MSN,
					QQ=@QQ,
					educationId=@educationId,
					addr=@addr,
					educationDesc=@educationDesc,
					workexperience=@workexperience,
					isCanLoginIn=@isCanLoginIn,
					userName=@userName,userCodes=@userCodes where id=@id
			set  @returnValue=1
		end
	select @count=count(*) from tb_user where id=@id and psw=@psw
	if(@count=0)
	begin
		update tb_user set psw=dbo.md5(@psw) where id=@id
	end
	select @returnValue
