CREATE PROCEDURE [dbo].[p_updateDesign]
	 @patternId int,
	 @yangyiId int,
	 @userId int
   
   AS
   BEGIN
		declare @currentPatternId int--当前样衣
		declare @styleId int--款式Id
		--获取款式Id
		select @styleId = styleId from ERP..tb_pattern_making where id=@patternId 
			
		begin tran 
		--增加打样记录
			insert into ERP..tb_design(patternId,date,userId)values(@patternId,GETDATE(),@yangyiId)
				
			set @currentPatternId = SCOPE_IDENTITY()
		--更新样衣工到款式表
			update ERP..mf_pCodeFabricMsg set yangyiId = @yangyiId,statusId=3,jstatus=3 where id = @styleId and statusId=2
			
			if(@@ROWCOUNT>0)
			begin 
				update ERP..tb_pattern_making set currentPattern = @currentPatternId where id=@patternId
				exec ERP..addCodeFabriMsgStatus_history @styleId,3,@userId
				exec ERP..p_addDesignRecode @yangyiId,@styleId,0
			end
			else
			begin 
				delete from ERP..tb_design where id=@currentPatternId
			end  
		commit tran 
		
	END
