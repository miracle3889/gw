CREATE procedure [dbo].[p_getDistributOrder] @code varchar(20) OUTPUT
as
 begin tran
	declare @tempVarchar varchar(10) 
	declare @tempInt int
	EXEC p_getNowDate @code OUTPUT
	select  @tempInt=max(intId) from tb_DistributeCode where convert(varchar(10),adddate,120)=convert(varchar(10),getDate(),120)
	if(@tempInt is null)
	begin
		set @tempInt=0
	end
	set @tempInt=@tempInt+1
	set @tempVarchar=cast(@tempInt as varchar(10))

	while(len(@tempVarchar)<3)
	begin
		set @tempVarchar='0'+@tempVarchar
	end
	set @code='p'+@code+@tempVarchar
	
	insert into tb_DistributeCode(intId) values(@tempInt)

	insert into erp..tb_needCheckDistribute(needDistributeCode) values(@code)
 commit tran
