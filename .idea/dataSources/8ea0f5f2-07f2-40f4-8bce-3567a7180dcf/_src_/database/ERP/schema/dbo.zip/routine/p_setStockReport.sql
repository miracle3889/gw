CREATE procedure [dbo].[p_setStockReport]
as 
declare @mydate varchar(50)
declare @price  bigint

DECLARE authors_cursor0 CURSOR FOR
/*
select convert(varchar(10),b.inTime,120) as mydate,sum(a.buyCount*c.stockPriceReal)  as  inPrice
from erp..tb_buyProductProtity a 
inner join erp..tb_buyProductList b on a.buyProductId=b.id and a.isIn=1 
inner join erp..tb_product c on b.productId=c.id
where b.inTime >=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120)
group by convert(varchar(10),b.inTime,120)
*/
--采购入库
SELECT convert(varchar(10),opDate,120) ,sum((newCount-oldCount)*b.stockPriceReal)
FROM tb_productStockOpHis a
inner join tb_product b on a.productId=b.id
 where opDate >=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120) and opType in(1)  --and newCount>oldCount
group by convert(varchar(10),opDate,120)

OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_stockReport where addDate=@mydate)
		begin
			update tb_stockReport set inPrice=@price where addDate=@mydate
		end
	else
		begin
			insert into tb_stockReport(inPrice,addDate) values(@price,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0


--溢出
DECLARE authors_cursor0 CURSOR FOR

SELECT convert(varchar(10),opDate,120) ,sum((newCount-oldCount)*b.stockPriceReal)
FROM tb_productStockOpHis a
inner join tb_product b on a.productId=b.id
 where opDate >=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120) and opType in(7,9)  --and newCount>oldCount
group by convert(varchar(10),opDate,120)

OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_stockReport where addDate=@mydate)
		begin
			update tb_stockReport set overflowPrice=@price where addDate=@mydate
		end
	else
		begin
			insert into tb_stockReport(overflowPrice,addDate) values(@price,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0


DECLARE authors_cursor0 CURSOR FOR


SELECT convert(varchar(10),opDate,120),sum((newCount-oldCount)*cast(b.stockPriceReal as bigint))
FROM tb_productStockOpHis a
inner join tb_product b on a.productId=b.id
 where opDate >=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120) and opType in(4)  --and newCount>oldCount
group by convert(varchar(10),opDate,120)


OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_stockReport where addDate=@mydate)
		begin
			update tb_stockReport set backInPrice=@price where addDate=@mydate
		end
	else
		begin
			insert into tb_stockReport(backInPrice,addDate) values(@price,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0


DECLARE authors_cursor0 CURSOR FOR

SELECT convert(varchar(10),opDate,120),sum((newCount-oldCount)*b.stockPriceReal)
FROM tb_productStockOpHis a
inner join tb_product b on a.productId=b.id
 where opDate >=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120) and opType in(10)  --and newCount>oldCount
group by convert(varchar(10),opDate,120)


OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_stockReport where addDate=@mydate)
		begin
			update tb_stockReport set pressurePrice=@price where addDate=@mydate
		end
	else
		begin
			insert into tb_stockReport(pressurePrice,addDate) values(@price,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0


--借出
DECLARE authors_cursor0 CURSOR FOR
SELECT convert(varchar(10),opDate,120),sum((newCount-oldCount)*b.stockPriceReal)
FROM tb_productStockOpHis a
inner join tb_product b on a.productId=b.id
 where opDate >=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120) and opType in(11) and newCount>oldCount
group by convert(varchar(10),opDate,120)

OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_stockReport where addDate=@mydate)
		begin
			update tb_stockReport set borrowinPrice=@price where addDate=@mydate
		end
	else
		begin
			insert into tb_stockReport(borrowinPrice,addDate) values(@price,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0




--库存
DECLARE authors_cursor0 CURSOR FOR


select convert(varchar(10),dateAdd(day,1,a.addDate),120) as mydate,
sum(cast(productStock as bigint)*cast(b.stockPriceReal as bigint))  as stockPrice
from erp..tb_productStockPrice a
inner join erp..tb_product b on a.productid=b.id 

 where a.addDate>=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120) and productStock>0
group by  convert(varchar(10),dateAdd(day,1,a.addDate),120) order by  
convert(varchar(10),dateAdd(day,1,a.addDate),120)
OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_stockReport where addDate=@mydate)
		begin
			update tb_stockReport set stockPrice=@price where addDate=@mydate
		end
	else
		begin
			insert into tb_stockReport(stockPrice,addDate) values(@price,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0




DECLARE authors_cursor0 CURSOR FOR


SELECT convert(varchar(10),opDate,120),sum((oldCount-newCount)*b.stockPriceReal)
FROM tb_productStockOpHis a
inner join tb_product b on a.productId=b.id
 where opDate >=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120) and opType in(8) --and newCount<oldCount
group by convert(varchar(10),opDate,120) order by   convert(varchar(10),opDate,120)
OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_stockReport where addDate=@mydate)
		begin
			update tb_stockReport set outPrice=@price where addDate=@mydate
		end
	else
		begin
			insert into tb_stockReport(outPrice,addDate) values(@price,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0






DECLARE authors_cursor0 CURSOR FOR

SELECT convert(varchar(10),opDate,120),sum((oldCount-newCount)*b.stockPriceReal)
FROM tb_productStockOpHis a
inner join tb_product b on a.productId=b.id
 where opDate >=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120) and opType in(2,3) --and newCount<oldCount
group by convert(varchar(10),opDate,120) order by   convert(varchar(10),opDate,120)
OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_stockReport where addDate=@mydate)
		begin
			update tb_stockReport set losePrice=@price where addDate=@mydate
		end
	else
		begin
			insert into tb_stockReport(losePrice,addDate) values(@price,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0





DECLARE authors_cursor0 CURSOR FOR
SELECT convert(varchar(10),opDate,120),sum((oldCount-newCount)*b.stockPriceReal)
FROM tb_productStockOpHis a
inner join tb_product b on a.productId=b.id
 where opDate >=convert(varchar(10),DATEADD ( month , -1, getDate() ) ,120) and opType in(11) and newCount<oldCount
group by convert(varchar(10),opDate,120)
OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
WHILE @@FETCH_STATUS = 0
BEGIN
	if EXISTS(select 1 from tb_stockReport where addDate=@mydate)
		begin
			update tb_stockReport set borrowoutPrice=@price where addDate=@mydate
		end
	else
		begin
			insert into tb_stockReport(borrowoutPrice,addDate) values(@price,@mydate)
		end
	FETCH NEXT FROM authors_cursor0
	INTO @mydate,@price
END
CLOSE authors_cursor0
DEALLOCATE authors_cursor0
