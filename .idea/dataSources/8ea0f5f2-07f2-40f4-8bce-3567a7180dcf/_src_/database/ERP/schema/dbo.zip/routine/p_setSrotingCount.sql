CREATE procedure [dbo].[p_setSrotingCount] @distributeId int
as 
declare @count int

declare @countT int

insert into supermarket..tb_orderstatusHis(orderId,orderstatus,doMan,remark) 
		select orderId,13,1,'等待发货' from tb_orderDistribute a
		inner join supermarket..tb_order b on a.orderId=b.id and isDelete=0
		 where distributeId=@distributeId and  b.orderstatus=20 and deliverManId>0


update Supermarket.dbo.tb_order set orderstatus=13 where  orderstatus=20 and deliverManId>0 and   id in(
select orderId from tb_orderDistribute where distributeId=@distributeId)




/*select @count=count(*) from Supermarket.dbo.tb_order a
inner join tb_orderDistribute b on a.id=b.orderId and b.distributeId=@distributeId 
 where ( (deliverManId>0 and a.orderstatus=13)or ( deliverManId<=0 and   isdelete=1)) --and id in(
--select orderId from tb_orderDistribute where distributeId=@distributeId)*/

select @count=count(*) from Supermarket.dbo.tb_order a
inner join tb_orderDistribute b on a.id=b.orderId and b.distributeId=@distributeId 
 where deliverManId<=0  and   isdelete<>1 

select @countT=count(*)  from tb_orderDistribute where distributeId=@distributeId

set @count=@countT-@count
update tb_Distribute set sortingCount=@count where id=@distributeId
