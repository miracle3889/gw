CREATE  procedure [dbo].[p_dealUpdateorderByDealMan] @orderId int,@dealManId int
as
declare @isdelete int
declare @orderStatus int
/*
select @isdelete=isdelete,@orderStatus=orderStatus 
from Supermarket.dbo.tb_order where orderStatus in(13,20) and id=@orderid

if(@isdelete is null) set @isdelete=0
if(@isdelete=1)
begin
	
	
	
end
if(@isdelete=2)
begin
	update Supermarket.dbo.tb_order set orderStatus=1 , isdelete=0 ,deliverManId=-1 where id=@orderid
	insert into supermarket..tb_orderstatusHis(orderId,orderstatus,doMan,remark) values(@orderid,1,@dealManId,'修改后的订单重新配货')
end*/

delete from  [supermarket].[dbo].[tb_deleteOrderNeedCheck] where orderId=@orderId 

insert into tb_dealUpdateOrder(orderId,dealManId,orderStatus,dealType) values(@orderid,@dealManId,20,1)


update tb_orderDistribute set distributeManId=@dealManId,isDistribute=1,distributeDate=getDAte()  
 where orderId=@orderId
				
update tb_Distribute set transferCount=b.transferCount from tb_Distribute a,
(select distributeId,sum(isDistribute) as transferCount from   tb_orderDistribute 
	where distributeId in(select distributeId from tb_orderDistribute  where orderId=@orderId ) 
	group by distributeId ) as b where a.id=b.distributeId
