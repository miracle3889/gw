/*----------------新增退单快递单 单独宝贝--------------------------------*/
CREATE PROCEDURE [dbo].[updateTdConsignSaleCodeSend] @tdConsignSaleCodeId int, @tdConsignId int 
AS
	DECLARE @returnValue int
	set @returnValue=0
	
	UPDATE erp..tb_tdConsignSaleCode set isSend=1 where id=@tdConsignSaleCodeId
	
	DECLARE @isSendCount int
	set @isSendCount=0
	select @isSendCount=isnull(COUNT(*), 0) from erp..tb_tdConsignSaleCode where tdConsignId=@tdConsignId and isSend=1
	update erp..tb_tdConsign set sendCount=@isSendCount where id=@tdConsignId

	SELECT @returnValue
