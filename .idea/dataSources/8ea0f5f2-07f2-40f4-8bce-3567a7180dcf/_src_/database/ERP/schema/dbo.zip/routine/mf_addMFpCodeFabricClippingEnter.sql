-- 增加物料退货入库  
CREATE PROCEDURE [dbo].[mf_addMFpCodeFabricClippingEnter] @pCodeFabricProtityId INT, @clippingCode VARCHAR(32), @shelfCode VARCHAR(32), @stockCount INT, @remark VARCHAR(320), @doManId INT, @updateType INT
AS

	DECLARE @isUpdate INT
	SET @isUpdate = 1

	begin tran
		
		if ( @pCodeFabricProtityId<>0 and @shelfCode is not null and @stockCount > 0)	
		begin			
			exec mf_updateFabricNewStock @pCodeFabricProtityId, 0, 0, @stockCount, @shelfCode, @doManId, @updateType
			
			IF (@isUpdate <> 0)
			BEGIN
				INSERT INTO mf_pCodeFabric_clippingEnter (pCodeFabricProtityId, clippingCode, shelfCode, stockCount, remark, doManId, stockTypeId)
					VALUES (@pCodeFabricProtityId, @clippingCode, @shelfCode, @stockCount, @remark, @doManId,@updateType)
			END
		END
		else
		begin
			set @isUpdate = 0
		end
	
	commit tran

	SELECT @isUpdate
