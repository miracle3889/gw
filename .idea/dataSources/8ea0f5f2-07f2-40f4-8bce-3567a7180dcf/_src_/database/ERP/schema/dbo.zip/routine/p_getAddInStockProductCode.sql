CREATE PROCEDURE [dbo].[p_getAddInStockProductCode] 
AS
	DECLARE @code INT
	SET @code=0
	BEGIN TRAN 
	SELECT @code=MAX(code) FROM tb_addProductStockCode WHERE code is NOT NULL
	IF(@code IS NULL)
	BEGIN
		SET  @code=0
	END
	SET @code=@code+1
	INSERT INTO tb_addProductStockCode(code) VALUES(@code)
	COMMIT  TRAN
	SELECT @code
