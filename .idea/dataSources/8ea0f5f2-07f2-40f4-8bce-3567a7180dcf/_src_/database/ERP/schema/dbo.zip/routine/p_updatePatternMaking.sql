/******  新增版、改版重做、改版不重做 ******/
CREATE PROCEDURE [dbo].[p_updatePatternMaking]
	 @styleId int,
	 @userId int,
	 @needDesign int
   
   AS
   declare @prePatternId int--上一次版
   declare @patternId int --本次新增
   declare @number int --第几版 
   declare @yangyiId int --当前样衣
   declare @statusId int --当前样衣
   declare @banshiid int --上一版的版师
   BEGIN
		select @statusId=statusId,@number=number,@yangyiId=currentPattern,@prePatternId=mainPatternId,@banshiid=a.banShiId  from ERP..mf_pCodeFabricMsg a
		inner join ERP..tb_pattern_making b on a.mainPatternId=b.id where a.id =@styleId 
		
		if(@number is null) set @number=0
		if(@needDesign=0) set @yangyiId =0 --做样衣 打样记录为空，等待选择样衣工的时候更新回来，不做样衣
		begin tran 
			insert into ERP..tb_pattern_making (styleId,userId,date,needDesign,number,currentPattern)
			values(@styleId,@userId,GETDATE(),@needDesign,@number+1,isnull(@yangyiId,0))
			
			set @patternId = SCOPE_IDENTITY(
			)
			
			--如果是改版重做或者是改版不重做 需要把上一次的版师留痕
			if(@statusId=6) set @userId=@banshiid
			--更新当前版
			update ERP..mf_pCodeFabricMsg set mainPatternId = @patternId,banShiId=@userId,statusId=2,jstatus=2 where id=@styleId and statusid in(1,6,11)
			--添加历史记录
			if(@@ROWCOUNT>0)
				begin
					if(ISNULL(@statusId,0) in(0,1))
					exec ERP..addCodeFabriMsgStatus_history @styleId,2,@userId
				end
			else 
				delete from    ERP..tb_pattern_making where id=@patternId
		commit tran 
    END
    select @patternId
