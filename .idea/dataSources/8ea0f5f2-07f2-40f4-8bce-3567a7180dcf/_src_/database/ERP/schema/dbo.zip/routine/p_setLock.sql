create procedure [dbo].[p_setLock] @productCode varchar(50),@productCount int
as 
	declare @oldLock int
	
	 begin tran 
		if   exists (select 1 from erp..tb_lockStock where productCode =@productCode)
		begin
			select  @oldLock=productCount from erp..tb_lockStock  where productCode =@productCode
			
			if(@productCount>@oldLock)
				insert into supermarket..tb_updateTabaoProductCount(productCode,productCount,reMark) 
				values(@productCode,@productCount-@oldLock,'锁定库存')
			
			update  erp..tb_lockStock  set productCount=@productCount where   productCode =@productCode
		end
		else
		begin
			insert into supermarket..tb_updateTabaoProductCount(productCode,productCount,reMark) 
				values(@productCode,@productCount,'锁定库存')
				
			 insert into erp..tb_lockStock(productCode,productCount)  values(@productCode,@productCount)
		end
	 commit tran
