CREATE PROCEDURE [dbo].[addCodeFabriMsgFormFL]
	@userId int,
	@suppliyId int, ---供应商id
	@codeFormId int, --分解主表id
	@styleId int     ---款式id
AS



declare @fabricNewId int---色卡表id
declare @qCodeId int --二维码id
declare @count int
	BEGIN
		
		if(@codeFormId>0) --修改供应商
			begin
				begin tran
					select @fabricNewId = b.id from ERP..mf_pCodeFabricProtity a inner join ERP..mf_fabricNew b on a.fabricNewId=b.id where a.pCodeFabricFormId=@codeFormId
					update ERP..mf_fabricNew set supplidersId = @suppliyId,
					--有供应商色卡信息的则更新供应商色卡id
					suppliderCardCodeId = (select  b.qrCodeId from ERP..mf_suppliders a join ERP..mf_suppliderCardCode b on a.id = b.suppliderId where a.id=@suppliyId)
					where id=@fabricNewId
		
				commit tran
			end
		else
			begin
				select @qCodeId = qrCodeId from erp..mf_suppliders a join ERP..mf_suppliderCardCode b on a.id = b.suppliderId where a.id=@suppliyId
			
	
				insert into ERP..mf_fabricNew(colorCard, fabricName,fabricColor,supplidersId,type,isDelete,delManId,doManId,addDate,suppliderCardCodeId)
				values('','','',@suppliyId,0,0,0,@userId,GETDATE(),@qCodeId);
				SET @fabricNewId=SCOPE_IDENTITY();
				 
			end		
	END
select 	@fabricNewId
