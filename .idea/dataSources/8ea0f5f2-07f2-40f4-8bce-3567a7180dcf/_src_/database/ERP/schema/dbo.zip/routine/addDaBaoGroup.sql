/*----------------新增打包分组--------------------------------*/
CREATE PROCEDURE [dbo].[addDaBaoGroup] @groupCount int, @userId int, @groupName varchar(320) 
AS
	DECLARE @returnValue int
	set @returnValue=0
	
	INSERT INTO erp..tb_daBaoGroup (groupCount, userId ) 
		VALUES (@groupCount, @userId )
	set @returnValue=SCOPE_IDENTITY()
	
	IF @returnValue<>0 
	BEGIN
		DECLARE @i int
		SET @i=0		

		WHILE CHARINDEX(',',@groupName)<>0
		BEGIN
			INSERT INTO erp..tb_daBaoName (daBaoGroupId, name ) VALUES (@returnValue, SUBSTRING(@groupName, 0, CHARINDEX(',',@groupName))) 
			SET @groupName=SUBSTRING(@groupName, CHARINDEX(',',@groupName)+1,len(@groupName))
			SET @i=@i+1
		END

		-- 为打包名单分组
		DECLARE @typeInt int
		SET @typeInt=1
		IF @i<>0
		BEGIN
			WHILE EXISTS (select top 1 id from tb_daBaoName where daBaoGroupId = @returnValue and type=0)
			BEGIN
				UPDATE tb_daBaoName SET type=@typeInt WHERE id in (
					select top 1 id from tb_daBaoName where daBaoGroupId = @returnValue and type=0 order by newid()
				)
				IF (@typeInt=@groupCount)
				BEGIN
					SET @typeInt=1
				END
				ELSE
				BEGIN
					SET @typeInt=@typeInt+1
				END
			END	
		END
	END

	SELECT @returnValue
