/*-----------------------tiaozhenghuojia----------------------*/
CREATE  procedure [dbo].[p_changeShelfStock] @shelfCodeold varchar(50),@shelfCode varchar(50),@productCode varchar(50),@count int,@dealManId int
as 
	
		if EXISTS(select 1 from tb_productStock  where productShelfCode=@productCode )
		BEGIN			
			if EXISTS(select 1 from tb_goodsShelf  where code=@shelfCode  and code not in('X0000','Y0000','A0000'))
			BEGIN
				begin tran
					declare @oldCount int 
					
					select @oldCount=productCount from tb_shelfProductCount where shelfCode=@shelfCodeold and productCode=@productCode
					--原货架减少库存
					update tb_shelfProductCount set productCount=productCount-@count where shelfCode=@shelfCodeold and productCode=@productCode
					
					if(@@error<>0)
						rollback tran 
					insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,productOldCount,dealManId,type) values(@shelfCodeold,@productCode,@count,@oldCount,@dealManId,-1)
					if(@@error<>0)
						rollback tran 
					
					if EXISTS(select 1 from tb_shelfProductCount where shelfCode=@shelfCode and productCode=@productCode)
					begin
						select @oldCount=productCount from tb_shelfProductCount where shelfCode=@shelfCode and productCode=@productCode
						update tb_shelfProductCount set productCount=productCount+@count where shelfCode=@shelfCode and productCode=@productCode
					end
					else
					begin
						set @oldCount=0
						insert into tb_shelfProductCount(shelfCode,productCode,productCount) values(@shelfCode,@productCode,@count)
					end
					if(@@error<>0)
						rollback tran 
					insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,productOldCount,dealManId) values(@shelfCode,@productCode,@count,@oldCount,@dealManId)
					if(@@error<>0)
						rollback tran 

					SELECT 1,'操作成功'
				commit tran
			END
			ELSE
			BEGIN
				SELECT -1,'货架号不存在'
			END
		END
		ELSE
		BEGIN
			SELECT -2,'商品不存在'
		END
