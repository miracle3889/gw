CREATE PROCEDURE  [dbo].[p_AmendProduct]
AS
DECLARE @oneID INT
DECLARE @twoID INT
DECLARE authors_cursor CURSOR FOR
SELECT a.id,b.id  FROM dbo.tb_product a INNER JOIN dbo.tb_categoryTwo  b ON a.categoryTwoId=b.id 
WHERE SUBSTRING(a.code,1,4)!=b.code
OPEN authors_cursor
FETCH NEXT FROM authors_cursor 
INTO @oneID, @twoID
WHILE @@FETCH_STATUS = 0
BEGIN
	DECLARE @code VARCHAR(20)
	EXEC p_getProductCode @twoID,@code OUTPUT
	UPDATE tb_product SET code=@code WHERE id=@oneID
	FETCH NEXT FROM authors_cursor 
	INTO @oneID, @twoID
END
CLOSE authors_cursor
DEALLOCATE authors_cursor
