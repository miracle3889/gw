/*----------------------------------------------得到需要确认的采购单的数量-------------------------------------------------*/
CREATE PROCEDURE [dbo].[p_getNeedCheckCount]
AS
	SELECT COUNT(*) FROM dbo.tb_buyProductList WHERE buyStatus=3 AND isDeleted=0
