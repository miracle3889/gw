-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
create PROCEDURE [dbo].[lockMessage] 
	@top int 
AS
declare @sql varchar(200)
BEGIN
 
	if exists(select * from tempdb..sysobjects where id=object_id('tempdb..##lockMessage_temp'))
		 drop table ##lockMessage_temp
		 
	
	set @sql='select top '+ cast(@top as varchar(10))+' id,mobileNum,content,isSend into ##lockMessage_temp from c3.dbo.tb_smsMission where issend=0 '
	
	exec (@sql)
	
	declare @id int
	DECLARE MyCursor CURSOR		
	FOR SELECT  id FROM ##lockMessage_temp 
	open  MyCursor
	FETCH NEXT FROM  MyCursor INTO @id
	begin tran
	WHILE @@FETCH_STATUS =0
		BEGIN		
		update c3.dbo.tb_smsMission set isSend=2 where id=@id
		FETCH NEXT FROM  MyCursor INTO @id	
		END
			--关闭游标
		CLOSE MyCursor
			--释放资源
		DEALLOCATE MyCursor
	commit tran
	select * from ##lockMessage_temp
END
