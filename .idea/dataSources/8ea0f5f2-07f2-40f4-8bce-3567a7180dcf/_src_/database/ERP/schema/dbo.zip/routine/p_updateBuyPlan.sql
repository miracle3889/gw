/*-------------------------采购计划---------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[p_updateBuyPlan] @buyMan INT,
				          @causeId INT,
				          @remark VARCHAR(200),
					@id INT
AS
	DECLARE @returnValue INT
	SET @returnValue=0
	BEGIN TRAN 
		UPDATE dbo.tb_buyBill SET buyMan=@buyMan,causeId=@causeId,remark=@remark WHERE id=@id
		SET @returnValue=1
	COMMIT TRAN
	SELECT @returnValue
