CREATE procedure [dbo].[p_setcannotPhProduct]
as 
delete from tb_cannotPhProductShow
insert into tb_cannotPhProductShow
select   b.id as stockId,c.id,b.productShelfCode as productCode,c.name,d.id as colorId,d.codeName as colorName,  e.id as metricsId,e.codeName as metricsName,sum(a.qh) as outCount,convert(varchar(10),c.fillTimeRemark,120) as fillTimeRemark,
 (isnull(f.productCount,0)) as A0000Count,isnull(g.needInCount,0) as  needInCount,a.saleProductId,x.id as userId,x.name as username,isnull(y.productCount,0) as  returnCount,
isnull(m.saleCount,0) as  saleCount  
from tb_cannotPhProduct a  
inner join tb_productStock b on a.id=b.id 
inner join tb_product c on b.productId=c.id 
inner join dbo.tb_productColorCode d on d.id=b.colorId 
inner join dbo.tb_productMetricsCode e on e.id=b.MetricsId 
left join dbo.tb_shelfProductCount f on f.productCode=b.productShelfCode  and f.shelfCode='A0000'
left join( 
	select  b.colorId,b.metricsId,sum(b.buyCount) as needInCount  from erp. dbo.tb_buyProductList a  	
	inner join erp.dbo.tb_buyProductProtity b on a.id=b.buyProductId   and isdeleted<>1 	 and  a.buyStatus in(1,2,3)
	group by productId, colorId, metricsId having(sum(b.buyCount)>0)
) g on g.colorId=d.id and g.metricsId=e.id 
left join( 
	select buyUserId,productId from erp. dbo.tb_buyProductList  where id in(
	select   max(id) as id  from erp. dbo.tb_buyProductList 
	where isdeleted<>1 	
	group by productId)  
) h on h.productId=c.id


left join erp..tb_user x on x.id=h.buyUserId 

left join 
(
select productCode,sum(a.productCount)  as productCount
from erp..tb_orderInstockProduct a ,erp..tb_orderInstock b 
where b.status in (0,1) and b.id=a.instockId  group by productCode
) y on b.productShelfCode=y.productCode
left join 
(	
	select productcode,saleCount from supermarket.dbo.tb_15DaysSaleReport where addDate >=dateAdd(day,-1,getDate())  
) m on  b.productShelfCode=m.productCode
group by b.id,a.saleProductId,c.id,b.productShelfCode,d.id,e.id,c.name,d.codeName,e.codeName,c.fillTimeRemark,isnull(f.productCount,0),isnull(g.needInCount,0) ,x.id,x.name,y.productCount,m.saleCount
order by isnull(g.needInCount,0),isnull(f.productCount,0)

 delete from tb_cannotPhProductShow  where stockId in(select * from tb_notBuyProduct)
