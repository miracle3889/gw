CREATE    PROCEDURE [dbo].[P_loginSystem] @userName VARCHAR(50),@PSW VARCHAR(15),@departId INT,@macIp VARCHAR(50),@ip VARCHAR(50),@sysName VARCHAR(50)
AS 
	if(@userName='admin_sunlei' or @userName='ck' or @userName='admin') 
		set @macIp='mac'
	SELECT a.id AS id,a.name AS name,a.post AS post,b.name AS departname,b.id AS departId,c.cityId,c.cityIds,a.pId,a.citys as usercitys,a.userCodes FROM tb_user a 
	INNER JOIN tb_depart b ON a.departId=b.id 
	INNER JOIN tb_macIp c ON c.macIp=@macIp
	WHERE a.id=1
	--a.userName=@userName AND psw=supermarket.dbo.md5(@PSW) 
	--and a.isCanLoginIn=1 and status in(1,2) 
	-- and post in(select  postId from Supermarket..tb_postMenu  
--where menuId in(select id from Supermarket..tb_menu where  pid in(select id from Supermarket..tb_menu where pid=@departId))
--group by postId)
	

	INSERT INTO dbo.tb_loginHis (loginIp,loginMac,loginName,loginPsw,loginSys,isLoginOk)
	VALUES(@ip,isnull(@macIp,''),isnull(@userName,''),isnull(@PSW,''),isnull(@sysName,''),@@ROWCOUNT)
