-- =============================================
-- Author:		<runbin>
-- Create date: <2015-10-23>
-- Description:	<采购商品入库>
-- =============================================
CREATE PROCEDURE [dbo].[p_putPurchaseInStorage]
@factoryCode varchar(20),	--出厂单号
@userId int	--入库人
as
declare @id int,@colorId int ,@metricsId int ,@productId int ,@productCode varchar(50),@shelfCode varchar(50),@inCount int
declare @return int
set @return=0;
if exists (select 1 from supplycenter..pro_storage where factoryCode=@factoryCode and status=1)
begin
	declare @okshelfCount int 
	declare @tShelfCount int
	declare @saleCode int
	declare @taxPrice int 
	declare @unitPrice int
	
	select @okshelfCount=COUNT(1) from supplycenter..pro_storage_child a
	inner join erp..[tb_goodsShelf ] b on a.productShelf=b.code and b.isStock=1 and a.factoryCode=@factoryCode
	
	if(@okshelfCount is null ) set @okshelfCount=0
	
	--入库商品数量
	select @inCount=sum(storageAmount),@tShelfCount=COUNT(1) from supplycenter..pro_storage_child where factoryCode=@factoryCode
	
	if @inCount is null set @inCount=0
	--更新状态和入库数量
	if(@tShelfCount is null ) set @tShelfCount=0
	
	if(@tShelfCount=@okshelfCount)--货架号填写全部正确
	begin
		begin tran
		DECLARE  cs CURSOR FOR 
			select 
				productId,colorId,sizeId,a.storageAmount,skuCode,productShelf,b.saleCode,b.taxPrice,b.unitPrice
			from 
				supplycenter..pro_storage_child  a
				inner join supplycenter..pro_purchase b on a.purchaseId=b.id 
			where  factoryCode=@factoryCode
			
			OPEN cs
			FETCH NEXT FROM cs
			INTO @productId,@colorId,@metricsId,@inCount,@productCode,@shelfCode,@saleCode,@taxPrice,@unitPrice
			WHILE @@fetch_status =0
			BEGIN		
				exec p_addProductStockCount  @productId,@colorId,@metricsId,@inCount,1,@userId,'成品采购入库'
				--SKU编号不存在
				if(@productCode is null  or @productCode='') 
				begin
					exec p_getShelfProductCode @productId,@colorId,@metricsId,@productCode output
					
					if(@productCode is null) 
					begin
						set @productCode=''
					end
					update tb_productStock set productShelfCode =@productCode
					 where productId=@productId and colorId=@colorId and metricsId=@metricsId
					
					if not exists (select 1 from erp..tb_productSkuCode 
					where productId=@productId and colorId=@colorId and metricsId=@metricsId )
					begin
						insert into tb_productSkuCode(productShelfCode,productId,colorId,metricsId)
						 values(@productCode,@productId,@colorId,@metricsId)
					end
				end	
				
				exec [dbo].[p_addShelfStockBySystem] @shelfCode,@productCode,@inCount,@userId,4,''
				
				
				--加权平均
				
				exec  finance..p_finance_averagePrice   @productId,@saleCode,@taxPrice,@unitPrice,@inCount
	 
				FETCH NEXT FROM cs
				INTO @productId,@colorId,@metricsId,@inCount,@productCode,@shelfCode,@saleCode,@taxPrice,@unitPrice
			END
			
			CLOSE cs
		DEALLOCATE cs


		if @@ERROR<>0
			begin
				update supplycenter..pro_storage set status=1,storageAmount=0 where factoryCode=@factoryCode
				update supplycenter..pro_storage_child set productShelf='',storageAmount=0 where factoryCode=@factoryCode
				rollback tran
				RETURN;
			end
		else
			begin
				set @return=1;
				update supplycenter..pro_storage set status=2,storageAmount=
				(
					select SUM(storageAmount) from supplycenter..pro_storage_child where factoryCode=@factoryCode
				),inStorageTime=GETDATE(),inStorageUserId=@userId where factoryCode=@factoryCode
				
				--更新采购单入库数
				update  supplycenter..pro_purchase set storageAmount=a.storageAmount+b.storageAmount 
				from  supplycenter..pro_purchase  a,(
					select purchaseId,SUM(storageAmount) as storageAmount from  
					supplycenter..pro_storage_child
					where factoryCode=@factoryCode 
					group by purchaseId
				) b where a.id=b.purchaseId
				
				
				--更新采购单子表入库数
				declare @temp varchar(20)
				declare @temp2 varchar(20)
				declare p_cursor CURSOR FOR	--采购单编号游标
					select purchaseid,skucode from supplycenter..pro_storage_child where factoryCode=@factoryCode
				
				open p_cursor
					FETCH NEXT FROM p_cursor INTO @temp,@temp2	
					WHILE @@FETCH_STATUS = 0
						begin
						
							update erp..mf_pCodeFabricMsg  set jstatus=6 where jstatus<6 and pCode in(
							select a.pCode  from erp..tb_product a 
							inner join supermarket..tb_saleProduct b on b.productId=a.id 
							where b.id in(
								select saleCode from supplycenter..pro_purchase where id=@temp  )
							)
						
							 --更新采购单字表入库数
							update  supplycenter..pro_purchase_child set storagecount= b.storageAmount 
							from  supplycenter..pro_purchase_child  a,(
								select sum(c.storageAmount) as storageAmount,skuCode,d.purchaseCode from  
								supplycenter..pro_storage_child c
								join supplycenter..pro_purchase d on c.purchaseId=d.id
								where purchaseId=  @temp and skuCode=@temp2
								group by skuCode,purchaseCode
							) b where a.skucode=b.skuCode and a.purchaseCode=b.purchaseCode
							FETCH NEXT FROM p_cursor INTO @temp,@temp2
						end
				CLOSE p_cursor--关闭游标
				DEALLOCATE p_cursor--释放游标
				
				
				commit tran
			end
		end
end
select @return as ret;
