-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[p_updateStatusRe_in] 
	@codeFabriMsgId int,
	@userid int
AS
   declare @username varchar(200)
   declare @facturername varchar(200)
   declare @patternCount int
   declare @patternId int 
   declare @yangyiId int
   declare @bz varchar(200)
BEGIN
	begin tran
	  update mf_pCodeFabricMsg set status=3 where id=@codeFabriMsgId and statusId=6
	  if(@@ROWCOUNT>0)
	   begin
	   --取版数量
	   select @patternCount = COUNT(id) from tb_pattern_making where styleId = @codeFabriMsgId
	   if(@patternCount is null) set @patternCount=0
	   
	   --取用户名
	   select @username=name from tb_user where id=@userid
	   
	   --取厂商名字
	   select @facturername=name from tb_other_manufacturer a 
	   inner join ERP..mf_pCodeFabricMsg b on a.id = b.developMode
	   where b.id=@codeFabriMsgId
	   
	   --增加打版记录
		insert into tb_pattern_making (styleId,userId,date,needDesign,number)
			values(@codeFabriMsgId,@userId,GETDATE(),0,@patternCount+1)
		set @patternId = SCOPE_IDENTITY()
		 select @patternId
		--增加打样记录
		insert into ERP..tb_design(patternId,date)values(@patternId,GETDATE())
		set @yangyiId = SCOPE_IDENTITY()
		
		--更新打版中的当前样衣
		update tb_pattern_making set currentPattern=@yangyiId where id=@patternId
		
		--更新款中的当前版,更新当前版状态为3
		update ERP..mf_pCodeFabricMsg set mainPatternId=@patternId,statusId=3 where id=@codeFabriMsgId
		
		--更新样衣签收记录
		exec ERP..p_addDesignRecode @userid,@codeFabriMsgId,0
		
		--增加款式状态记录
		set @bz = @username+'组织试穿需改版重做'
		insert into tb_status_history (styleId,date,statusId,userId,bz)
		     values(@codeFabriMsgId,GETDATE(),3,@userid,@bz)
	   end
	commit tran
	print @patternId
	
	
	   
END
