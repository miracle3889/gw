CREATE PROCEDURE [dbo].[P_Login] @userName VARCHAR(15),@PSW VARCHAR(15),@departId INT 
AS 
	SELECT a.id AS id,a.name AS name,a.post AS post,b.name AS departname,b.id AS departId FROM tb_user a 
	INNER JOIN tb_depart b ON a.departId=b.id WHERE a.userName=@userName AND psw=dbo.md5(@PSW) AND (a.departId=@departId OR a.departId=1)
