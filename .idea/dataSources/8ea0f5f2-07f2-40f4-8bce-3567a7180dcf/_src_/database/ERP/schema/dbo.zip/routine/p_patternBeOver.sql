CREATE PROCEDURE [dbo].[p_patternBeOver]
	 @codeFabriMsg int,
	 @userId int
   AS
    begin tran
		update ERP..mf_pCodeFabricMsg set statusId=7 where id=@codeFabriMsg and statusId=2
		--if(@@ROWCOUNT>0)
		--	exec ERP..addCodeFabriMsgStatus_history @codeFabriMsg,7,@userId
	commit tran
