/*-----------------------------------修改供应商资料--------------------------------------------------------*/
CREATE  PROCEDURE [dbo].[p_updateSupply] @name VARCHAR(50),@contact VARCHAR(200)
				      ,@phone VARCHAR(50),@mobile VARCHAR(15)
				      ,@EMail VARCHAR(50),@webAddr VARCHAR(50)
				      ,@addr VARCHAR(500),@remark VARCHAR(500),@id INT ,@isWeb INT,@account VARCHAR(50)
AS
	DECLARE @code VARCHAR(20)
	DECLARE @count INT
	DECLARE @returnValue INT
	SET @returnValue=0
	SELECT @count=COUNT(*) FROM dbo.tb_supply WHERE name=@name AND id!=@id
	IF(@count!=0)
	BEGIN
		SET @returnValue=-1 --供应商已经
	END
	ELSE
	BEGIN
		BEGIN TRAN 
		UPDATE  dbo.tb_supply
	SET name=@name,contact=@contact,phone=@phone,mobile=@mobile,
	EMail=@EMail,webAddr=@webAddr,addr=@addr,remark=@remark,isWeb=@isWeb,account=@account WHERE id=@id
		
		SET @returnValue=1
		COMMIT TRAN
	END
	SELECT @returnValue
