/*------------------添加借出记录------------------------------*/
CREATE  PROCEDURE [dbo].[p_addInvoicePriceProduct] @productName VARCHAR(50),@productCount int,@productPrice int, @reMark VARCHAR(200),@doManId INT
			  
AS 
	DECLARE @returnValue INT 
	DECLARE @unitPrice INT 
	SET @unitPrice=@productPrice/@productCount
	
	SET @returnValue=0
	BEGIN TRAN 
		INSERT INTO dbo.tb_invoicePriceProduct(productName,invoicePrice,unitprice,productCount,addManId,remark,surplusCount) 
		VALUES(@productName,@productPrice,@unitPrice,@productCount,@doManId,@reMark,0)
		SET @returnValue=SCOPE_IDENTITY( )
	COMMIT TRAN
	SELECT @returnValue
