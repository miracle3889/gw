CREATE procedure [dbo].[p_setSrotingCountByUserTransfer] @distributeId int,@doMan int
as 
declare @count int

declare @countT int

declare @transferId int

if EXISTS( select 1 from tb_transferOrder a inner join supermarket..tb_order b on a.orderId=b.id and isDelete=0
		 where transferId=@distributeId and  b.orderstatus=20 and deliverManId>0 )
begin
	insert into supermarket..tb_orderstatusHis(orderId,orderstatus,doMan,remark) 
			select orderId,13,@doMan,'等待发货' from tb_transferOrder a
			inner join supermarket..tb_order b on a.orderId=b.id and isDelete=0
			 where transferId=@distributeId and  b.orderstatus=20 and deliverManId>0
	
	
	update Supermarket.dbo.tb_order set orderstatus=13 where  orderstatus=20 and deliverManId>0 and   id in(
	select orderId from tb_transferOrder where transferId=@distributeId)
	
	update tb_orderDistribute set distributeManId=@doman,isDistribute=1,distributeDate=getDAte()  
	where orderId in(select orderId from tb_transferOrder where transferId=@distributeId)
			
	update tb_Distribute set transferCount=b.transferCount from tb_Distribute a,
	(select distributeId,sum(isDistribute) as transferCount from   tb_orderDistribute 
	where distributeId in(select distributeId from tb_orderDistribute 
	where orderId in(select orderId from tb_transferOrder  where transferId=@distributeId))group by distributeId ) as b where a.id=b.distributeId
		
end


select @count=count(*) from Supermarket.dbo.tb_order a
inner join tb_transferOrder b on a.id=b.orderId and b.transferId=@distributeId 
 where deliverManId<=0  and   isdelete<>1 

select @countT=count(*)  from tb_transferOrder where transferId=@distributeId

set @count=@countT-@count
update tb_transFer set sortingCount=@count where id=@distributeId
