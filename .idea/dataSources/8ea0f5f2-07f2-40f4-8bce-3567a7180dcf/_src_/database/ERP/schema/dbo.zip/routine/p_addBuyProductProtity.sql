/*------------------添加采购规格-----------------------------*/
	CREATE PROCEDURE [dbo].[p_addBuyProductProtity] @colorId INT,--颜色
							@metricsId INT,--规格
							@buyCount INT,--采购数量
							@buyProductId INT,--采购商品id
							@userId INT--采购人
	AS
		DECLARE @colorName VARCHAR(50)
		DECLARE @metricsName VARCHAR(50)
		DECLARE @userName VARCHAR(50)
		SELECT @userName=name FROM tb_user WHERE id=@userId
		SELECT @colorName=codeName FROM dbo.tb_productColorCode WHERE id=@colorId
		SELECT @metricsName=codeName FROM dbo.tb_productMetricsCode WHERE id=@metricsId


		INSERT INTO tb_buyProductProtity(buyProductId,colorId,metricsId,buyCount,protityStockCount)
		select @buyProductId,@colorId,@metricsId,@buyCount,productCount from tb_productStock where colorId=@colorId and metricsId=@metricsId
		
		DECLARE @updateRemark VARCHAR(500)
		SET @updateRemark=CONVERT(VARCHAR(20),getDate(),120)+@userName+'：添加规格,'+@colorName+'|'+@metricsName+'  '+CAST(@buyCount AS VARCHAR(20))+'个'
		UPDATE tb_buyProductList SET updateRemark=updateRemark+@updateRemark+'<br>' WHERE id=@buyProductId
