---取货完成
CREATE  procedure [dbo].[p_setTransferDistribute] @distributeId int,@doman int
as
	--IF not  EXISTS (select 1 from (select shelfCode,productCode,sum(productCount) as productCount,distributeId from  tb_distributeProductShelf where distributeId=@distributeId  and  shelfCode <>'Q0101' group by shelfCode,productCode,distributeId) a
	--	inner join tb_shelfProductCount b on a.shelfCode=b.shelfCode and a.productCode=b.productCode and  b.productCount<a.productCount   )
	--begin
	if     EXISTS(select 1 from  erp..tb_Distribute where isTransfer=0 and  id=@distributeId )
	BEGIN
	begin tran 		
		
		update erp..tb_Distribute set isTransfer=1,transferMan=@doman,transferTime=getDate() where id=@distributeId				

		insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,productOldCount,dealManId,type,optype)
		select a.shelfCode,a.productCode,sum(a.productCount),b.productCount,@doman,-1,1 from tb_distributeProductShelf  a
		INNER JOIN tb_shelfProductCount b  on a.productCode=b.productCode and a.shelfCode=b.shelfCode  
		 where distributeId=@distributeId	and   a.shelfCode != 'Q0101'
		group by  a.shelfCode,a.productCode,b.productCount having b.productCount-sum(a.productCount)>=0
		
		
		update tb_shelfProductCount set productCount=a.productCount-b.productCount 
		from tb_shelfProductCount a,
		(
		select shelfCode,productCode,sum(productCount) as productCount,distributeId 
		from  tb_distributeProductShelf where distributeId=@distributeId and  shelfCode != 'Q0101' group by shelfCode,productCode,distributeId
		) as b
		 where a.productCode=b.productCode 
		and a.shelfCode=b.shelfCode and b.distributeId=@distributeId 	and a.productCount-b.productCount >=0
		

		
		declare @pCode varchar(50)
		select @pCode=pCode  from erp..tb_Distribute where id=@distributeId
		
		
		insert into  dbo.tb_productStockOpHis(productId,colorId,metricsId,oldCount,newCount,doMan,opType,remark)
		
		select a.productId,a.colorId,a.metricsId,a.productCount,a.productCount-b.productCount,@doman,8,@pCode from tb_productStock a
		inner join (
		select productCode,sum(productCount) as productCount 
		from tb_distributeProductShelf where distributeId=@distributeId  and  shelfCode != 'Q0101'
   		 group by productCode
		)  b on a.productShelfCode=b.productCode  where a.productCount-b.productCount>=0 

		
		update  dbo.tb_productStock  set productCount=a.productCount-b.productCount from dbo.tb_productStock a,
		(
			select productCode,sum(productCount) as productCount 
			from tb_distributeProductShelf where distributeId=@distributeId and len(shelfCode)>0
			and shelfCode != 'Q0101'
	   		 group by productCode
		)
		 b 
		where a.productShelfCode=b.productCode  and a.productCount-b.productCount>=0
		
	commit tran
	--END
	end
