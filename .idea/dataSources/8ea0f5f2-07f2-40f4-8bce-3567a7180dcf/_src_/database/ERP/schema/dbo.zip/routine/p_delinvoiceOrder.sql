create procedure [dbo].[p_delinvoiceOrder] @orderId int
AS 

update tb_invoicePriceProduct set surplusCount=surplusCount-b.productCount from tb_invoicePriceProduct a ,tb_voiceOrderProduct b where   b.invoiceProductId=a.id
and b.orderId=@orderId

delete from tb_voiceOrderProduct where orderId=@orderId

delete from tb_invoiceOrder where id=@orderid
