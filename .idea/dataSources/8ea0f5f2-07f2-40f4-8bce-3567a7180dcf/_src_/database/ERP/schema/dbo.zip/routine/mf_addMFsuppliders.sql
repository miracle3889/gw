CREATE PROCEDURE [dbo].[mf_addMFsuppliders] @name varchar(64), @mobile varchar(32), @account varchar(128), 
			@addrs varchar(320), @remark varchar(320), @phone varchar(32), @fax varchar(32), 
			@supplidersCode varchar(8), @mainType varchar(64), @type int,@pinyin varchar(50) 
AS

	DECLARE @returnValue INT
	SET @returnValue=0
	
	IF NOT EXISTS ( select * from erp..mf_suppliders where  name = @name and isDelete=0)
	begin
	
		DECLARE @supplidersCodeInt VARCHAR(8)
		SET @supplidersCodeInt='0'
		IF (@supplidersCode is null or @supplidersCode='')
		BEGIN
			SELECT TOP 1 @supplidersCodeInt=supplidersCode FROM ERP..mf_suppliders WHERE type=@type and supplidersCode is not null ORDER BY supplidersCode DESC
			IF(len(@supplidersCodeInt)=5)
			BEGIN
				SET @supplidersCodeInt=SUBSTRING(@supplidersCodeInt,2,4)
			END
			SET @supplidersCode=right(str( CONVERT(VARCHAR(8), cast(@supplidersCodeInt as int) + 1) + 1000000000 ),4)	-- 取4位
			IF (@type=1)
			BEGIN
				SET @supplidersCode='F'+@supplidersCode
			END
		END
		
			IF(len(@supplidersCode)=5)
			BEGIN
				SET @type=1
			END
			ELSE
			BEGIN
				SET @type=0
			END
			
		IF NOT EXISTS( SELECT * FROM ERP..mf_suppliders WHERE isDelete=0 and supplidersCode=@supplidersCode )
		BEGIN
			INSERT INTO ERP..mf_suppliders (name, mobile, account, addrs, remark, phone, fax, supplidersCode, mainType, type,pinyin) 
				VALUES (@name, @mobile, @account , @addrs, @remark , @phone , @fax, @supplidersCode, @mainType, @type,@pinyin)
			SET @returnValue=SCOPE_IDENTITY()
			
			update erp..mf_suppliders set name=erp.dbo.F_Ctofchar(name, 0), mobile=erp.dbo.F_Ctofchar(mobile, 0), phone=erp.dbo.F_Ctofchar(phone, 0), 
				fax=erp.dbo.F_Ctofchar(fax, 0), account=erp.dbo.F_Ctofchar(account, 0), mainType=erp.dbo.F_Ctofchar(mainType, 0), addrs=erp.dbo.F_Ctofchar(addrs, 0),
				remark=erp.dbo.F_Ctofchar(remark, 0),pinyin=@pinyin
			where id=@returnValue
		END
	END
	SELECT @returnValue
