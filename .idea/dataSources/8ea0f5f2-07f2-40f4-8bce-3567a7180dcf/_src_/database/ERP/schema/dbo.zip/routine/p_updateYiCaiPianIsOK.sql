/*------------------------- 修改裁片是否完成 ---------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[p_updateYiCaiPianIsOK] @yiCaiPianId INT
AS
	DECLARE @returnValue INT
	SET @returnValue=0
		
	update tb_yiCaiPianSize set daiChuCount=0 where yiCaiPianId=@yiCaiPianId

	update tb_yiCaiPian set isOK=1 where id=@yiCaiPianId

	SET @returnValue=1
	SELECT @returnValue
