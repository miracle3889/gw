CREATE procedure [dbo].[p_reSetInstockTransferCount] @distributeId int
as 
declare @count int


select @count=count(*)  from tb_inStockTransferProduct where inStockTransferId=@distributeId

update tb_InstockTransFer set productCount=@count where id=@distributeId
