-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE procedure [dbo].[ChangeUserBrands]
	@brands varchar(500),
	@userId int
as
    declare @pointerPrev int
	declare @pointerCurr int
	declare @TBrand int
	DECLARE @returnValue int
  	set @pointerPrev=1
  	set @returnValue=0
Begin
set nocount on;
begin try
 begin tran
delete from tb_userBrand where userid=@userId
if @brands <>'-1'
Begin
 while (@PointerPrev < LEN(@brands)) 
    Begin 
        Set @PointerCurr=CharIndex(',',@brands,@PointerPrev) 
        if(@PointerCurr>0) 
        Begin 
            set @TBrand=cast(SUBSTRING(@brands,@PointerPrev,@PointerCurr-@PointerPrev) as int) 
		
            insert into tb_userBrand(userId,brandId) values(@userId,@TBrand)
            SET @PointerPrev = @PointerCurr+1 
        End 
        else 
            Break 
    End
End 
commit tran
end try
BEGIN CATCH------------有异常被捕获
        IF @@TRANCOUNT > 0---------------判断有没有事务
        BEGIN
            ROLLBACK TRAN----------回滚事务
            set @returnValue=1
        END 
END CATCH

end
select @returnvalue
