/*-------------------------采购计划---------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[p_AddBuyPlan] @buyMan INT,
				          @makeBillMan INT,
				          @causeId INT,
				          @remark VARCHAR(200)
AS
	DECLARE @returnValue INT
	DECLARE @code VARCHAR(20)

	SET @returnValue=0
	EXEC p_getBuyBillCode @code OUTPUT
	BEGIN TRAN 
		INSERT INTO dbo.tb_buyBill(billCode,makeBillMan,buyMan,causeId,remark)
		VALUES(@code,@makeBillMan,@buyMan,@causeId,@remark)
		SET @returnValue=SCOPE_IDENTITY( )
	COMMIT TRAN
	SELECT @returnValue
