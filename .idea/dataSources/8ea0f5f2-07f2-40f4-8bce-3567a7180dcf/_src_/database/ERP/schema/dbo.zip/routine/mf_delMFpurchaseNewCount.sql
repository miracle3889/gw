-- 删除采购单物料
CREATE PROCEDURE [dbo].[mf_delMFpurchaseNewCount]  @id int, @userId int
AS

	DECLARE @returnValue INT	
	SET @returnValue=0
	
	begin tran

	IF (@id != 0 and @userId != 0)
	BEGIN

		update mf_purchaseNewCount set isDelete=1 , delManId=@userId , delManDate=getdate() where id=@id
		if (@@error<>0)
		begin
			ROLLBACK tran
		end
		SET @returnValue=1
				
		exec mf_updateMFpurchaseNewCountSystem @id, 0

	END
	commit tran

	SELECT @returnValue
