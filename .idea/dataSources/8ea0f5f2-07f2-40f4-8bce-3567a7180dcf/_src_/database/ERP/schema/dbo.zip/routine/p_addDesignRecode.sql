/******  增加样衣签收记录 ******/
CREATE PROCEDURE [dbo].[p_addDesignRecode]
	 @userId int,
	 @codeFabriMsg int,
	 @type int
   AS
   BEGIN
		declare @patternId int --版式ID
		declare @designId int --样式ID
		declare @designQRCode int --二维码ID
		declare @return int
			set @return=0;
		declare @oneUserId int --第一条记录的用户ID
			select @patternId=mainPatternId from ERP..mf_pCodeFabricMsg where id=@codeFabriMsg
			select @designId=currentPattern from ERP..tb_pattern_making where id=@patternId
			select @designQRCode=qrcode from ERP..tb_design where id=@designId
			if(@type=0 and @designQRCode<>0 and @designQRCode is not null)
				begin
					insert into ERP..tb_design_recode (designQRCode,date,userId,bz) values (@designQRCode,GETDATE(),@userId,'创建')
					set @return=1
				end
			else if(@type<>0 and @designQRCode<>0 and @designQRCode is not null)
				begin
					select top 1 @oneUserId=userId from ERP..tb_design_recode order by date desc
					if(@oneUserId!=@userId)
						begin
							insert into ERP..tb_design_recode (designQRCode,date,userId,bz) values (@designQRCode,GETDATE(),@userId,'签收')
							set @return=1
						end
					else if(@oneUserId=@userId)
						begin
							set @return=2
						end
				end
			select @return	
    END
