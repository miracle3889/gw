/*****************
	修改指定款号的 预警时间
*******/
CREATE PROCEDURE [dbo].[mf_updateMFpCodeSaleTime] @pCode varchar(32), @saleTime varchar(32)
AS

	DECLARE @returnValue INT
	SET @returnValue=0
	
	IF NOT EXISTS ( select * from erp..mf_pCodeInfo where pCode=@pCode )
	begin
		insert into ERP..mf_pCodeInfo (pCode, saleTime ) 
			VALUES (@pCode, @saleTime )
		SET @returnValue=1
	END
	ELSE
	BEGIN
		update erp..mf_pCodeInfo set saleTime=@saleTime where  pCode=@pCode
		SET @returnValue=2
	END

	SELECT @returnValue
