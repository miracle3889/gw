/*********		初始化款式（新）		***********/
CREATE PROCEDURE [dbo].[addCodeFabriMsgNew]
 @pCode	varchar(50),
 @addUserId	int,
 @addDate	varchar(50),
 @developMode	int,--开发方式
 @gouxiangId	int,--构想ID
 @type	int,--类别ID
 @originalId	int,
 @seasonId	int,--季节ID
 @ruhnnbrandId	int,--品牌ID
 @originalTypeId	int,
 @noOriginalPicId   int,
 @supplierId	int--供应商id
AS

DECLARE @styleId INT  --当前款式ID
set @styleId=0
DECLARE @designWrittenId INT  --当前款式设计稿
set @designWrittenId=0

BEGIN
	--新增设计稿多媒体
	insert into ERP..tb_multimedia_pid (count,type) values (0,1)
	set @designWrittenId=SCOPE_IDENTITY()
	
	
	
	if(@originalId=0)
		begin
			insert into ERP..tb_multimedia_pid (count,type) values (0,3)
			set @gouxiangId=SCOPE_IDENTITY()
		end

    --新增款式
    begin tran 
		if(@developMode=9)	--外开内采
			begin 
				insert into ERP..mf_pCodeFabricMsg
				(pCode,addUserId,addDate,sheJiShiId,banShiId,yangyiId,supliderId,originalId,seasonId,mainPatternId,designWrittenId,originalTypeId,gouxiangId,type,ruhnnbrandId,statusId,status,jstatus,doManId,developMode,picId)
				 values 
				 (0,@addUserId,GETDATE(),@addUserId,0,0,@supplierId,@originalId,@seasonId,0,@designWrittenId,@originalTypeId,@gouxiangId,@type,@ruhnnbrandId,9,0,0,0,@developMode,@noOriginalPicId)
				 set @styleId=SCOPE_IDENTITY()
			end
		else
			begin
				insert into ERP..mf_pCodeFabricMsg
				(pCode,addUserId,addDate,sheJiShiId,banShiId,yangyiId,originalId,seasonId,mainPatternId,designWrittenId,originalTypeId,gouxiangId,type,ruhnnbrandId,statusId,status,jstatus,doManId,developMode,picId)
				 values 
				 (0,@addUserId,GETDATE(),@addUserId,0,0,@originalId,@seasonId,0,@designWrittenId,@originalTypeId,@gouxiangId,@type,@ruhnnbrandId,1,0,0,0,@developMode,@noOriginalPicId)
				 set @styleId=SCOPE_IDENTITY()
			end
	 
	 --更新款式pcode=id
	 update ERP..mf_pCodeFabricMsg set pCode=@styleId where id=@styleId
	 
	 exec p_addProductPcodeNew '',@styleId -- 添加商品，为商品添加服装款号，让服装款号和商品关联起来
	 
	 --增加款式状态记录
	 exec ERP..addCodeFabriMsgStatus_history @styleId,1,@addUserId
	 if @@ERROR<>0
	    rollback tran
	 commit tran
END
select @styleId

