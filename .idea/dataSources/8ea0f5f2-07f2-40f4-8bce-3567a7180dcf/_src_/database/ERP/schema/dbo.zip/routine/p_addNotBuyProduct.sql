create procedure [dbo].[p_addNotBuyProduct] @stockId int
as 
insert into tb_notBuyProduct(stockId) values(@stockId)
delete from tb_cannotPhProductShow where stockId=@stockId
