-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[P_updateBrandNick] 
	@id int,
	@brandName varchar(100),
	@brandId int,
	@nickName varchar(100),
	@chName varchar(100),
	@msgImg varchar(100),
	@firChar varchar(100),
	@sessionKey varchar(100),
	@imgUrl varchar(100),
	@isOn int
AS
	DECLARE @returnValue int
	DECLARE @tempBrandId int
	declare @userId int
	declare @roles varchar(100)
	set @returnValue=0
BEGIN
  SET NOCOUNT ON;
   begin tran
    if @id<>-1
		begin
		  update SuperMarket..tb_Brand set name=@brandName,chName=@chName,firCha=@firChar where id=@brandId
		  update SuperMarket..tb_brandNick set nickName=@nickName,imgUrl=@imgUrl,chName=@chName,msgImg=@msgImg,sessionKey=@sessionKey,isOn=@isOn where id=@id
		end  
    else
		begin
		insert into SuperMarket..tb_Brand (name,chName,firCha) values(@brandName,@chName,@firChar)
		insert into SuperMarket..tb_brandNick (nickName,imgUrl,chName,msgImg,sessionKey,brandId,isOn) values(@nickName,@imgUrl,@chName,@msgImg,@sessionKey,@@IDENTITY,@isOn)
		end
commit tran 

end
 select @returnValue
