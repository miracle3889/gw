CREATE PROCEDURE [dbo].[p_addBackQualityLoss] @backProductId int, @id int, @colorId int, @metricsId int, @lossCount int, @type int 

 AS
	declare @count int
	begin tran
	
	select @count=count(*) from tb_lossProduct where productId=@id and colorId=@colorId and metricsId=@metricsId
	if (@count>0)
	begin
	update tb_lossProduct set lossCount=lossCount+@lossCount where productId=@id and colorId=@colorId and metricsId=@metricsId
	end
	else
	begin
	insert into tb_lossProduct(productId,colorId,metricsId,lossCount) values(@id,@colorId,@metricsId,@lossCount)
	end
	
	if (@type=0)
	begin 
	update SuperMarket.dbo.tb_backProduct set lossCount=lossCount+@lossCount where id=@backProductId
	end
	else
	begin
	update SuperMarket.dbo.tb_backGroupProduct set lossCount=lossCount+@lossCount where id=@backProductId
	end	

	commit tran
