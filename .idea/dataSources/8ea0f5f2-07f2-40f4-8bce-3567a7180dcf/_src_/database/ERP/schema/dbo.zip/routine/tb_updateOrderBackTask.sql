/*  修改返单任务  */

CREATE PROCEDURE [dbo].[tb_updateOrderBackTask] @id int,@pCode varchar(32), @productId int, @saleCode varchar(6), 
				@pCount int, @reduce varchar(32), @allCount int, @saleTime varchar(32), @userId int
AS

	DECLARE @returnValue INT
	SET @returnValue=0
	
	
		insert into ERP..tb_orderBackTaskInfo (orderBackTaskId, pCode, productId, saleCode, pCount, reduce, allCount, saleTime, userId,updateTime) 
		SELECT id, pCode, productId, saleCode, pCount, reduce, allCount, saleTime, userId, updateTime FROM ERP..tb_orderBackTask
		WHERE id=@id

		UPDATE ERP..tb_orderBackTask SET pCode=@pCode, productId=@productId, saleCode=@saleCode, 
				pCount=@pCount, reduce=@reduce, allCount=@allCount, saleTime=@saleTime, userId=@userId, updateTime=getdate() WHERE id=@id
		SET @returnValue=SCOPE_IDENTITY()
	

	SELECT @returnValue
