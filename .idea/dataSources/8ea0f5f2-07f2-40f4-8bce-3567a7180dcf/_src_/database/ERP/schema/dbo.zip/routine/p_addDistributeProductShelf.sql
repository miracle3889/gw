---货架位计算
CREATE procedure [dbo].[p_addDistributeProductShelf] @distributeId int
as
		--假设库存都是够的
		
		DECLARE @tb_shelfProductCountOnly Table--定义表变量记录当前状态下商品货架信息
		(
         productCode varchar(50),
         shelfCode varchar(50),
		 productCount int
		)
		
		DECLARE @tb_shelfProductCountOther Table--定义表变量记录当前状态下商品货架信息
		(
         productCode varchar(50),
         shelfCode varchar(50),
		 productCount int
		)
		
		insert into @tb_shelfProductCountOnly(productCode,shelfCode,productCount)
		select productCode,MIN(shelfCode) as shelfCode,SUM(productCount) as productCount
		from tb_shelfProductCount where shelfCode  
		in(select code from erp..[tb_goodsShelf ] where isLock=0 and isStock=1) and  productCount >0
		group by productCode  having COUNT(*)=1
		
		insert into @tb_shelfProductCountOther(productCode,shelfCode,productCount)
		select productCode,MIN(shelfCode) as shelfCode ,SUM(productCount) as productCount  
		from tb_shelfProductCount where shelfCode  
		in(select code from erp..[tb_goodsShelf ] where isLock=0 and isStock=1) and  productCount >0
		group by productCode  having COUNT(*)>1
		

		--添加一一对应的商品所需货架数量
	    insert into tb_distributeProductShelf(distributeId,productCode,shelfCode,productCount) 
        select @distributeId,productShelfCode,shelfCode,buycount from (
		select c.productShelfCode,sum(a.buyCount) as buycount 
		from  tb_orderSaleProductDistribute a
		inner join dbo.tb_productStock c on  a.colorid=c.colorid  and c.metricsId=a.metricsId 
		where a.distributeId=@distributeId
		group by c.productShelfCode  
		) as x
		 inner join 
		 @tb_shelfProductCountOnly   d on d.productCode=x.productShelfCode   and productCount>=buycount
		
		
		
	

	declare @productCode varchar(50)--商品编号	
	declare @shelfCode varchar(50)--货架编号	
	declare @productCount int--商品数量
	declare @hasCount int
	declare @shelCount int
	
	DECLARE authors_cursor0 CURSOR FOR
		--取得所有的待取的商品列表
		select productShelfCode,buyCount-ISNULL(productCount,0) from (
		select c.productShelfCode,sum(a.buyCount) as buyCount from tb_orderSaleProductDistribute a
		inner join dbo.tb_productStock c on  a.colorid=c.colorid 
		and c.metricsId=a.metricsId 
		where a.distributeId=@distributeId
		group by  c.productShelfCode )
		as x 
		left  join 
		(
		  select productCode,sum(productCount) as productCount 
		  from  tb_distributeProductShelf where distributeId=@distributeId  group by productCode
		) as y  on   y.productCode=x.productShelfCode  where buyCount-ISNULL(productCount,0)>0
		 
	OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0
	INTO @productCode,@productCount
	WHILE @@FETCH_STATUS = 0
	BEGIN
		set @hasCount=@productCount --初始化剩余没有生成的货架商品数
		
		DECLARE authors_cursor1 CURSOR FOR
			--取该编号商品所在货架数量
			select a.shelfCode,a.productCount from tb_shelfProductCount  a
			 where  a.productCode=@productCode and a.shelfCode in(select code from tb_GoodsShelf where isLock=0 and isStock=1) and  a.productCount >0
			 and productCode in(select productCode from @tb_shelfProductCountOther)
			order by  case  when a.shelfCode like 'E%' then 0 else 1 end  ,
			 a.productCount
		
		
		OPEN authors_cursor1
			FETCH NEXT FROM authors_cursor1
			INTO @shelfCode,@shelCount
		WHILE @@FETCH_STATUS = 0
		BEGIN
			if(@hasCount<=@shelCount)--如果待取数量小于等于货架上的商品 则退出
			begin
				insert into tb_distributeProductShelf(distributeId,productCode,shelfCode,productCount) 
				values(@distributeId,@productCode,@shelfCode,@hasCount)
				set @hasCount=0
				break
			end
			else
			begin
				if(@shelCount>0)
				begin
					insert into tb_distributeProductShelf(distributeId,productCode,shelfCode,productCount) 
					values(@distributeId,@productCode,@shelfCode,@shelCount)
					set @hasCount=@hasCount-@shelCount--更新剩余没有生成货架数量
				end
			end
			FETCH NEXT FROM authors_cursor1 
			INTO @shelfCode,@shelCount
		END
		CLOSE authors_cursor1
		DEALLOCATE authors_cursor1
		
		if(@hasCount>0)
		begin
			insert into tb_distributeProductShelf(distributeId,productCode,shelfCode,productCount) 
				values(@distributeId,@productCode,'Q0101',@hasCount)
			if not exists(select 1 from  tb_shelfProductCount where shelfCode='Q0101' and   productCode=@productCode)
			begin
				insert into tb_shelfProductCount(shelfCode,productCode,productCount) values('Q0101',@productCode,0)
			end
		end		
		
		FETCH NEXT FROM authors_cursor0 
		INTO @productCode,@productCount
	END
	CLOSE authors_cursor0
	DEALLOCATE authors_cursor0


	exec p_setTransferDistribute  @distributeId,-100
