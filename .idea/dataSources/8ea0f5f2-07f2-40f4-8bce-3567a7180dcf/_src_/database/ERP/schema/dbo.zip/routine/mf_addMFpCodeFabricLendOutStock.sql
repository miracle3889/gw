-- 增加 物料报失、报损
CREATE PROCEDURE [dbo].[mf_addMFpCodeFabricLendOutStock] @pCodeFabricLendId int, @pCodeFabricShelfId int, @outCount int, @doManId INT, @type INT 
AS

	DECLARE @returnValue INT	
	SET @returnValue=0
	
	begin tran

	
	IF (@pCodeFabricLendId <> 0 and @pCodeFabricShelfId <> 0)
	BEGIN

		DECLARE @stockCount INT
		SET @stockCount=0
		SELECT @stockCount=stockCount FROM mf_pCodeFabricShelf WHERE id=@pCodeFabricShelfId
		IF (@stockCount >= @outCount)
		BEGIN
			
			DECLARE @outRemark varchar(128)
			set @outRemark=''
			select @outRemark=remark from mf_pCodeFabricLend where id=@pCodeFabricLendId 
			
			
			--增加出库记录
			exec @returnValue = mf_addFabricNewOutStock 0,@pCodeFabricShelfId , @outCount, @doManId, @type,@outRemark 
			
			--如果 增加出库记录 返回的 @returnValue <> 0 
			IF (@returnValue<>0)
			BEGIN
				--增加报失 报损 记录
				INSERT INTO ERP..mf_pCodeFabricLendOutStock ( pCodeFabricLendId, productionPlanOutStockId ) 
				VALUES (@pCodeFabricLendId, @returnValue )
				SET @returnValue=SCOPE_IDENTITY()
				if (@@error<>0)
				begin
					SET @returnValue = -2
					ROLLBACK tran
				end
			END
			
		END
	
	END
	commit tran

	SELECT @returnValue
