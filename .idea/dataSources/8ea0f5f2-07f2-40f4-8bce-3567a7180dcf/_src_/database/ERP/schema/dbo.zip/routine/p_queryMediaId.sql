-- =============================================
-- Author:		<runbin>
-- Create date: <2015-09-26>
-- Description:	<获得多媒体父表id>
-- =============================================
-----------------------------得到图片父表id--------------------------------
CREATE PROCEDURE [dbo].[p_queryMediaId]
@type int-- 1：图片 2：语音 3：图片语音文字
AS
BEGIN
	insert into ERP..tb_multimedia_pid (type,count) values (@type,0);
	select SCOPE_IDENTITY() as 'ret'; 
END
