CREATE procedure [dbo].[p_setPhMan] @distributeId int,@userList varchar(50)
as 
 	declare @sql varchar(500)
	declare @userListTemp varchar(50)
	declare @phMancount int --配货人总数
	declare @buyCountt int --商品总数
	declare @buyCountV int --商品平均数
	
	declare @phManId int 
	set @userListTemp=@userList
	set @phMancount=0
	while(charindex(',',@userListTemp)<>0)   
	begin
		print substring(@userListTemp,1,charindex(',',@userListTemp)-1)
		set @userListTemp=substring(@userListTemp,charindex(',',@userListTemp)+1,len(@userListTemp))
		set @phMancount=@phMancount+1
	end
	
	
	select  @buyCountt=count(*) from tb_orderDistribute a
	inner join supermarket..tb_ordersaleProduct b on a.orderId=b.orderId
	 where distributeId=@distributeId
	
	set @buyCountV=@buyCountt/@phMancount+@buyCountt%@phMancount

	if(@buyCountV=0)
		set @buyCountV=@phMancount

	while(charindex(',',@userList)<>0)   
	begin
		set @phManId= cast(substring(@userList,1,charindex(',',@userList)-1) as int)
		set @userList=substring(@userList,charindex(',',@userList)+1,len(@userList))
		
		
		set @sql='update tb_orderDistribute set phManId ='+cast(@phManId as varchar(10))++' where orderId in(
		select top '+ cast(@buyCountV as varchar(10))+' a.orderId  from tb_orderDistribute a
		inner join supermarket..tb_ordersaleProduct b on a.orderId=b.orderId
		 where distributeId='+cast(@distributeId as varchar(10))+' and phManId=0) and distributeId='+cast(@distributeId as varchar(10))
		
		exec(@sql)
	end
