/*********		拒绝核销发票		***********/
CREATE PROCEDURE [dbo].[sc_delOffInvoice]
 @invoiceId	int,
 @userId int,
 @pid int,
 @remark int
AS

DECLARE @approvalType	INT  --审批类型
DECLARE @updaterst	INT  --是否成功核销
set @updaterst=0;
DECLARE @ret	INT  --返回值
set @ret=0
if exists (select 1 from supplyCenter.materie.tb_invoice_main where id=@invoiceId)
BEGIN
select @approvalType=approvalType from supplyCenter.materie.tb_invoice_main where id=@invoiceId
	begin tran
		update supplyCenter.materie.tb_invoice_main 
		set approvalStatus=2,
			approvalDoneTime=GETDATE(),
			remark=@remark
		where id=@invoiceId
		if exists (select 1 from supplyCenter.materie.tb_invoice_main where id=@invoiceId and approvalStatus=2)
			set @updaterst=1;
		if(@updaterst=1)
			begin
				insert into SuperMarket..pro_approval (documentId,documentType,approvalUserId,approvalTime,approvalResult,mediaRemark,configId)
				values 
				(
					(select invoiceCode from supplyCenter.materie.tb_invoice_main where id=@invoiceId),
					@approvalType,
					@userId,
					GETDATE(),
					2,
					@pid,
					(select id from SuperMarket..pro_approval_config where typeId = @approvalType and groupId = (select groupId from ERP..tb_user where id = @userId))
				)
				set @ret=1;
			end
		
		
    if @@ERROR<>0
		begin
			set @ret=0;
			rollback tran
		end
	commit tran
END
select @ret as ret;

