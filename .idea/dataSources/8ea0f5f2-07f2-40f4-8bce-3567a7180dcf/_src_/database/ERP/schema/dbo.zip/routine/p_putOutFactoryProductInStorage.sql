-- =============================================
-- Author:		<runbin>
-- Create date: <2016-5-11>
-- Description:	<出厂商品入库>
-- =============================================
CREATE PROCEDURE [dbo].[p_putOutFactoryProductInStorage]
@factoryCode varchar(20),	--出厂单号
@userId int	--入库人
as
declare 
@id int,
@colorId int ,
@metricsId int ,
@productId int ,
@productCode varchar(50),
@shelfCode varchar(50),
@inCount int,
@taskId int,
@return int
set @return=0;
if exists (select 1 from supplyCenter.production.tb_outfactory_batch where factoryCode=@factoryCode and status=2)
begin
	declare 
	@okshelfCount int, 
	@tShelfCount int,
	@saleCode int,
	@productAmount int, 
	@storageAmount int
	
	--货架号
	select 
		@okshelfCount=COUNT(1) 
	from  
		supplyCenter.production.tb_outfactory_batch_child a
	inner join  
		storagecenter.od.tb_goodShelf  b on a.productShelf=b.code and b.isStock=1 and a.factoryCode=@factoryCode
	
	if(@okshelfCount is null ) set @okshelfCount=0
	
	--入库商品数量
	select 
		@inCount=sum(storageAmount),
		@tShelfCount=COUNT(1) 
	from
		supplyCenter.production.tb_outfactory_batch_child 
	where factoryCode=@factoryCode
	
	if @inCount is null set @inCount=0
	--更新状态和入库数量
	if(@tShelfCount is null ) set @tShelfCount=0
	
	if(@tShelfCount=@okshelfCount)--货架号填写全部正确

	begin
		begin tran
		begin try
			DECLARE  cs CURSOR FOR 
			
				select 
					productId,colorId,sizeId,storageAmount,skuCode,productShelf,taskId
				from 
					supplyCenter.production.tb_outfactory_batch_child 
				where  factoryCode=@factoryCode
				
				OPEN cs
				FETCH NEXT FROM cs
					INTO @productId,@colorId,@metricsId,@inCount,@productCode,@shelfCode,@taskId
				WHILE @@fetch_status =0
				BEGIN		
					exec p_addProductStockCount @productId,@colorId,@metricsId,@inCount,1,@userId,@factoryCode
			
					exec [dbo].[p_addShelfStockBySystem] @shelfCode,@productCode,@inCount,@userId,4,@factoryCode
					
					--更新生产任务最终成品数
					update supplycenter.production.tb_production_task set endCount = endCount+@inCount
					where id = @taskId
					
					FETCH NEXT FROM cs
					INTO @productId,@colorId,@metricsId,@inCount,@productCode,@shelfCode,@taskId
				END
				
				CLOSE cs
			DEALLOCATE cs
		
			set @return=1;
			update erp..mf_pCodeFabricMsg  set jstatus=6 where jstatus<6 
			and pCode in(
					select a.pCode from erp..tb_product a inner join supermarket..tb_saleProduct b on b.productId=a.id 
					where b.productId in(
						select  productId from supplyCenter.production.tb_outfactory_batch_child   where factoryCode=@factoryCode )
					)
					
			--更新出厂主表入库数量 入库时间和状态  status=3 代表入库中
			UPDATE supplyCenter.production.tb_outfactory_batch
					SET status=4, storageAmount = 
						(
							select isnull(sum(storageAmount),0) from 
							supplyCenter.production.tb_outfactory_batch_child where factoryCode=@factoryCode
						),
						inStorageUserId=@userId,
						inStorageTime=GETDATE()
					WHERE factoryCode=@factoryCode
						
			--出厂数量是否等于已入库数量,相等则状态为4,入库完成
			SELECT	@productAmount = isnull(productAmount,0),
				@storageAmount = isnull(storageAmount,0)
			FROM supplyCenter.production.tb_outfactory_batch
			WHERE factoryCode=@factoryCode	
			
			if(@productAmount=@storageAmount and @storageAmount!=0)
				UPDATE supplyCenter.production.tb_outfactory_batch
 					SET status=4
 				WHERE factoryCode=@factoryCode
		end try
		begin catch
			update supplyCenter.production.tb_outfactory_batch set status=2,storageAmount=0 where factoryCode=@factoryCode
			update supplyCenter.production.tb_outfactory_batch_child set productShelf='',storageAmount=0 where factoryCode=@factoryCode
			rollback tran
			declare @msg varchar(2000)
			set @msg=error_message()
--			exec  ruhnnsystem.[dbo].[p_sendWeiXinMsg_title] '执行出错，回滚',@msg,1
			RETURN;
		end catch
				
		commit tran
		
		declare @sendUserId int 
		select @sendUserId =applyUserId  from  supplyCenter.production.tb_outfactory_batch where factoryCode=@factoryCode
		declare @title varchar(200)
		set @title ='你的工厂出厂单：'+@factoryCode+'已经于'+convert(varchar(30),GETDATE(),120)+'入库，总数:'+CAST(@inCount as varchar(10))
	--			exec  ruhnnsystem.[dbo].[p_sendWeiXinMsg_title] @title,@title,@sendUserId
	end
end
select @return as ret;
