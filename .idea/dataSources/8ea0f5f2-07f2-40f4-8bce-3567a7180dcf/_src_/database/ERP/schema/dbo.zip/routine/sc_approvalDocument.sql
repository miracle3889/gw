-- =============================================
-- Author:		<runbin>
-- Create date: <2015-09-24>
-- Description:	<各种票据审批>
-- =============================================
CREATE PROCEDURE [dbo].[sc_approvalDocument]
	@documentId varchar(20),	--票据单号
	@documentType int,	--票据类型
	@userId int,	--用户id
	@currentProcess int,	--当前审批流程
	@approvalResult int,	--审批结果
	@mediaId int,	--多媒体id
	@exceptTime varchar(15)	--需求付款时间(付款审批时可以修改)
AS
BEGIN
		declare @ret int	--返回值
		declare @amount int	--总流程数
		declare @approvalStatus int	--审批状态
		declare @groupId int	--审批级别
		declare @configId int 
		select @amount = amount from supermarket..pro_approval_type where typeId = @documentType	--查找总流程数
		select @groupId=groupId from ERP..tb_user where id = @userId	--查询审批人组别
		
		select @configId=a.id 
		from SuperMarket..pro_approval_config a 
			 join ERP..tb_user b on a.groupId = b.groupId and b.id = @userId
		where typeId = @documentType
		
		if exists (select 1 from SuperMarket..pro_approval where documentId=@documentId and approvalUserId = @userId ) 
			begin
				set @ret=-1
				select @ret as 'ret'
				return 
			end
		
		if @groupId!=@currentProcess
			begin
				set @ret=-1
				select @ret as 'ret'
				return 
			end
	set xact_abort on  
	begin tran
		if (@approvalResult = 1 )	--审批通过
			begin
				if @currentProcess< @amount	--不是最后一人审批进度加一
					begin
						set @currentProcess = @currentProcess+1
						set @approvalStatus = 1
					end
				else if @currentProcess=@amount	--最后一人审批且通过,流程结束
					set @approvalStatus = 3
			end
		else	--审批不通过
			begin
				set @approvalStatus = 2
			end
				
		insert into SuperMarket..pro_approval	--插入审批记录表
			(
				documentId,documentType,approvalUserId,approvalTime,approvalResult,mediaRemark,configId)
				values(@documentId,@documentType,@userId,GETDATE(),@approvalResult,@mediaId,@configId
			)
		set @ret= SCOPE_IDENTITY()
				
		if @ret>0
			begin
				if @documentType = 7	--物料采购
					begin
						update supplyCenter.materie.tb_materiePurchase 
							set approvalStatus = @approvalStatus,currentProcess = @currentProcess
						where purchaseCode = @documentId
					end
			end
	if @@error<>0
		begin
			set @ret=-1
            rollback tran
        end
	commit tran
	select @ret as 'ret'
END
