-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--插入色卡表，获取色卡id
CREATE PROCEDURE [dbo].[p_insertFabricNew]
@suppliersCodeId int,	--供应商色卡id
@color varchar(20),		--颜色
@colorCode	varchar(20),	--色卡号
@userId	int,	--添加人
@returnValue int OUTPUT
AS
BEGIN
	set @returnValue=0;
	--查询是否有重复
	select @returnValue=id from ERP..mf_fabricNew where fabricColor = @color and suppliderCardCodeId = @suppliersCodeId
	if(@returnValue=0)
	begin
		--插入色卡表
		insert into ERP..mf_fabricNew(colorCard, fabricName,fabricColor,supplidersId,type,isDelete,delManId,doManId,addDate,suppliderCardCodeId)
			values(@colorCode,(select cardCode from ERP..mf_suppliderCardCode where (qrCodeId = @suppliersCodeId) ),@color,(select suppliderId from ERP..mf_suppliderCardCode where (qrCodeId = @suppliersCodeId)),0,0,0,@userId,GETDATE(),@suppliersCodeId);
		SET @returnValue=SCOPE_IDENTITY();
	end
	IF(@@ERROR<>0)
		SET @returnValue = 0
END
