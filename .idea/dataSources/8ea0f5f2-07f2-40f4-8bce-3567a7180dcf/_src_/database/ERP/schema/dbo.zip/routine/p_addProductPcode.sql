/*------------------------------------------------添加商品------------------------------------------------------------*/
CREATE   PROCEDURE [dbo].[p_addProductPcode]   @remark VARCHAR(500),@pCode VARCHAR(50)
AS
	DECLARE @count INT
	DECLARE @returnValue INT
	DECLARE @code VARCHAR(20)
	SET @returnValue=0
	BEGIN TRAN 

		set @pCode= dbo.F_Ctofchar(@pCode,0)
		set @pCode=ltrim(rtrim(@pCode))
		SELECT @count=COUNT(*) FROM dbo.tb_product WHERE pCode=@pCode
		IF(@count!=0)
		BEGIN
			SET @returnValue=-1
		END
		ELSE
		BEGIN
			EXEC p_getProductCode  208,@code OUTPUT
			INSERT INTO dbo.tb_product( pCode,reMark,categoryOneId,categoryTwoId,name,code)
				VALUES( UPPER(@pCode) ,@remark,43,208,UPPER(@pCode),@code)
		SET @returnValue=SCOPE_IDENTITY()
		insert into  erp..tb_supplyProduct(pruductId,supplyId) values(@returnValue,0)
		END
	COMMIT TRAN 
	SELECT @returnValue
