/*------------------录入退回商品结果----------------------------*/
CREATE PROCEDURE [dbo].[p_addReturnReslut] @productId INT,@colorId INT,
				   @metricsId INT,@inCount INT,
				   @lostCount INT,@tableId INT,
				   @type INT,@doManId INT
AS
	BEGIN TRAN 
		/*---------更新库存---------------------*/
		UPDATE tb_productStock SET productCount=productCount+@inCount WHERE 
		productId=@productId AND colorId=@colorId AND  metricsId=@metricsId
		/*---------插入报失记录-----------------*/
		IF(@lostCount>0)
		BEGIN
		INSERT INTO  dbo.tb_loseProduct(productId,colorId,metricsId,loseCount,type,doManId)
		VALUES (@productId,@colorId,@metricsId,@lostCount,1,@doManId)
		END
		IF(@type=0)
		BEGIN
			UPDATE Supermarket.dbo.tb_orderSaleProduct SET inCount=@inCount,
			loseCount=@lostCount WHERE id=@tableId
		END
		ELSE
		BEGIN
			UPDATE Supermarket.dbo.tb_orderSaleGroupProduct SET inCount=@inCount,
			loseCount=@lostCount WHERE id=@tableId
		END
		
	COMMIT TRAN
