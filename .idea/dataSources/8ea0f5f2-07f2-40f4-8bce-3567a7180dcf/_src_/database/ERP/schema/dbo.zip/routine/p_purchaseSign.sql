-- =============================================
-- Author:		sjw
-- Create date: 2016-04-19
-- Description:	采购签收
-- =============================================
CREATE PROCEDURE  [dbo].[p_purchaseSign]
	@codeFabriMsgId int,
	@userId int,
	@userName varchar(100),
	@type int
AS
   declare @productId int
   declare @brandId int 
   declare @brandId_saleProduct int
   declare @planCount int
   declare @saleCode varchar(100)
   declare @color_count int 
   declare @planCompleteTime varchar(100)
   declare @purchaseUserId int 
   declare @taskId int
   declare @multiId int 
   declare @multiId_Comfirm int 
   declare @multiId_wear int 
   declare @bConfirmId int
   declare @roleId int 
   declare @exceptTime varchar(100)
   declare @saleProductId int
begin tran
begin try
	--获取操作人姓名和角色
	select @userName = a.name,@roleId=MAX(roleId) from ERP..tb_user a
	inner join ERP..tb_userRole b on a.id=b.userId 
	where a.id = @userId
	group by a.name
	
	select @productId = b.id,@brandId = c.id,@brandId_saleProduct = c.brandId,@purchaseUserId = a.purchaseUserId ,@exceptTime=substring(isnull(CONVERT(varchar(100), a.exceptArriveTime, 23),''),3,9)  from mf_pCodeFabricMsg a 
	inner join tb_product b on b.Pcode = a.pCode 
	inner join SuperMarket..tb_brandNick c on c.id = a.ruhnnbrandId 
	where a.id = @codeFabriMsgId
	
	--更新款状态
	update mf_pCodeFabricMsg set statusid=12 , purchaseUserId=@userId where id=@codeFabriMsgId and statusId=10
	if(@@ROWCOUNT>0)
	begin
		select @saleCode=cast(id as varchar(50)) from SuperMarket.dbo.tb_saleProduct where productId = @productId
		--销售编号不存在创建销售编号
		if(@saleCode is null or @saleCode ='')
		begin
			--生成销售编号
			INSERT INTO ERP..tb_multimedia_pid(type,count)VALUES (1,0) 
			set @multiId_Comfirm=SCOPE_IDENTITY();
			print '@productId'+cast(@productId as varchar)
			print '@brandId_saleProduct'+cast(@brandId_saleProduct as varchar)
			print '@@multiId_Comfirm'+cast(@multiId_Comfirm as varchar)
			INSERT INTO SuperMarket.dbo.tb_saleProduct(saleCode,productId,oldPrice,remark,saleCount,salePlanId,saleTypeId,brandId,remarkId)
			VALUES('',@productId,0,'',0,316,11,@brandId_saleProduct,@multiId_Comfirm)
			set @saleCode = SCOPE_IDENTITY()
			-- 更新saleCode
			print 3
			update SuperMarket.dbo.tb_saleProduct set saleCode = @saleCode where id=@saleCode
			--插入售价
			insert into SuperMarket..tb_saleProductPay(payStyleId,saleProductId,payValue) values(1,@saleCode,0)
		end
		else
			update SuperMarket.dbo.tb_saleProduct set brandId = @brandId_saleProduct where id = @saleCode
		
		declare @productTagCount int
		select @productTagCount = COUNT(1) from erp..tb_productTag where productId = @productId
		if(@productTagCount=0) insert into erp..tb_productTag(productId,pinming,leibei,biaozhun)values(@productId,'','','')
		
		
		--更新sku是空的记录
		update ERP..tb_productStock set productShelfCode=b.sku from ERP..tb_productStock a,
		(
			select a.productId,b.id colorId,a.id metricsId,@saleCode+a.code+b.code sku 
			from ERP..tb_productMetricsCode a 
			inner join ERP..tb_productColorCode b on a.productId = b.productId and b.isdeleted=0 and a.isdeleted=0
			where a.productId = @productId 
		) b where a.colorId=b.colorId and a.metricsId=b.metricsId and isnull(a.productShelfCode,'')=''
		
		
		--插入不存在的尺码颜色sku
		insert into ERP..tb_productStock(productId,colorId,metricsId,productShelfCode)
		select a.productId,b.id colorId,a.id metricsId,@saleCode+b.code+a.code sku 
		from ERP..tb_productMetricsCode a 
		inner join ERP..tb_productColorCode b on a.productId = b.productId and b.isdeleted=0 and a.isdeleted=0
		left join erp..tb_productStock c on c.colorId=b.id and c.metricsId=a.id 
		where a.productId = @productId  and c.id is null
		
		--如果没有规格 就抛出异常
		if not exists (select 1 from ERP..tb_productStock where productId=@productId )
		begin
			RAISERROR ('Error raised in TRY block.', -- Message text.
			16, -- Severity.
			1 -- State.
			)
		end
print 2
		--更新老系统状态
		insert into erp..tb_jstatusHis(pcode,jstatus)
		select pcode,4 from  erp..mf_pCodeFabricMsg  
		where pCode  in(
		select pCode from erp..tb_product where id=@productId
		) and jstatus <4
		--更新款式状态（老系统）
		UPDATE erp..mf_pCodeFabricMsg set jstatus=4 where pCode in(
		select pCode from erp..tb_product where id=@productId
		) and jstatus <4
		--插入款式历史表
		insert into erp..tb_status_history(styleid,statusId,userid,date,bz) values(@codeFabriMsgId,12,@userId,getDate(),'采购'+@userName+'已签收')

		--原料采购
		if(@type=2 and not exists (select 1 from supplyCenter.materie.tb_materiePurchase_task where saleCode=@saleCode) )
		begin
			--原料采购只能有一种颜色
			select @color_count = COUNT(id) from designCenter.fabric.tb_colorPlanAmountRecord where fabricId = @codeFabriMsgId
			if(@color_count<>1)
			begin
				RAISERROR ('Error raised in tow kind of color.', -- Message text.
				16, -- Severity.
				1 -- State.
				)
			end

			---------------------采购开始---------------------------
			insert into ERP..tb_multimedia_pid values(1,0)
			set @multiId = SCOPE_IDENTITY()
			
		    --计划数
			select @planCount = amount from designCenter.fabric.tb_colorPlanAmountRecord where fabricId = @codeFabriMsgId
			--原材料采购任务主表信息
			insert into supplyCenter.materie.tb_materiePurchase_task(batchId,saleCode,planCount,fabriMsgId,productId,type,planCompleteTime,remarkId,status,applyUser,purchaseUserId,brandId)
			values(0,@saleCode,@planCount,@codeFabriMsgId,@productId,0,@exceptTime,@multiId,1,@userId,@userId,@brandId)

			set @taskId = SCOPE_IDENTITY()

			--采购任务 记录
			insert into supplyCenter.materie.tb_materiepurchasetask_recode
			(
				taskId,status,addUser
			)
			values
			(
				@taskId,1,@userId
			)

			--采购比例信息
			insert into supplyCenter.materie.tb_materiePurchaseTask_sizeratio select @taskId,colorId,metricsId,amount,'首单' from designCenter.fabric.tb_fabricAmountRecord where fabricId = @codeFabriMsgId
			---------------------采购结束---------------------------

			---------------------封样开始---------------------------

			INSERT INTO ERP..tb_multimedia_pid
			(type,count) 
			VALUES 
			(1,0) 
			set @multiId_Comfirm=SCOPE_IDENTITY();


			INSERT INTO ERP..tb_multimedia_pid
			(type,count) 
			VALUES 
			(3,0) 
			set @multiId_wear=SCOPE_IDENTITY();

			INSERT INTO supplyCenter.bConfirm.tb_pCodeFabricBConfirm
			(fabricId,specificationMediaId,yangyiId,mediaId,status,date,typeNumb) 
			VALUES 
			(@codeFabriMsgId,@multiId_wear,0,@multiId_Comfirm,0,GETDATE(),(select isnull(MAX(typeNumb),0)+1 typeNumb from supplyCenter.bConfirm.tb_pCodeFabricBConfirm where fabricId=@codeFabriMsgId)) 

			set @bConfirmId = SCOPE_IDENTITY();

			INSERT INTO supplyCenter.bConfirm.tb_pCodeFabricSpecification
			(bConfirmId,date,status) 
			VALUES 
			(@bConfirmId,getdate(),0) 

			INSERT INTO supplyCenter.bConfirm.tb_pCodeFabricBConfirmHistory
			(userId,date,remark,userRoleId,bConfirmId,status) 
			VALUES 
			(@userId,GETDATE(),@userName+'采购签收',3,@bConfirmId,0) 
			---------------------封样结束---------------------------
		end

	end  
	else 
		select 0 as ret
end try
begin catch  
	if @@trancount > 0  
	begin 
	rollback tran   
	select 0 as ret
	end
end catch  

if @@trancount > 0   
begin
	commit tran  
	select @saleCode as ret
end











