CREATE   procedure [dbo].[p_addProductTostock] @productCode varchar(50),@productCount int ,@transferId int
as
  declare @returnValue int
  set @returnValue=0
 if   EXISTS(select 1 from tb_InstockTransFer where  id=@transferId and status=0 )
 begin
	  if   EXISTS(select 1 from tb_productStock where productShelfCode=@productCode)
		begin
			insert into tb_inStockTransferProduct(inStockTransferId,productCode,productCount)
			values(@transferId,@productCode,@productCount)
			declare @count int
			select @count=count(*) from tb_inStockTransferProduct where inStockTransferId=@transferId
			update tb_InstockTransFer set productCount=@count where id=@transferId
			set @returnValue=1
		end
   end
  select @returnValue
