CREATE procedure [dbo].[p_insertMultimediaByQuery]
 @mediaTypeId varchar(200) ,
 @text varchar(200) ,
 @url varchar(200) ,
 @pid int ,
 @weixinId varchar(200) ,
 @userId int 
as
DECLARE @returnValue INT --回滚事务
DECLARE @identity INT --最新ID
  begin
	  insert into erp..tb_multimedia(mediaTypeId,text,url,pid,weixinId,userId,updateTime) values (@mediaTypeId,@text,@url,@pid,@weixinId,@userId,getDate())
	   set @identity=SCOPE_IDENTITY();
	  exec ERP..p_getCountByPid @pid,@returnValue output ;
  end
  begin
	if(@returnValue<>0)
		begin
			select @identity as 'ret';
		end
	else
		begin
			select @returnValue as 'ret';
		end
  end
