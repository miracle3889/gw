-- 增加生产任务
CREATE PROCEDURE [dbo].[mf_addProduction] @saleCode varchar(6), @productionCount int, @addManId int, @remark varchar(320)
				, @productionStatusList varchar(128),@productId int
AS

	DECLARE @returnValue INT	
	begin tran

	INSERT INTO ERP..mf_production (saleCode, productionCount, addManId, remark, productId) 
	VALUES (@saleCode, @productionCount, @addManId, @remark, @productId)
	SET @returnValue=SCOPE_IDENTITY()
	if (@@error<>0)
	begin
		ROLLBACK tran
	end
	


	DECLARE @i INT
	SET @i=1
	DECLARE @j INT
	
	DECLARE @T INT
	DECLARE @TT INT	

	DECLARE @productionStatus VARCHAR(20)

	while @i<=5
	begin
		SET @productionStatus = SUBSTRING(@productionStatusList, 0,CHARINDEX('|',@productionStatusList))
		SET @j=1
		
		WHILE @j<=2
		BEGIN
			IF (@j=1)
			BEGIN
				SET @T=SUBSTRING(@productionStatus, 0,CHARINDEX(',',@productionStatus))
			END
			IF (@j=2)
			BEGIN
				SET @TT=SUBSTRING(@productionStatus, 0,CHARINDEX(',',@productionStatus))
			END
			SET @productionStatus = SUBSTRING(@productionStatus, CHARINDEX(',',@productionStatus)+1,len(@productionStatus)) 
			SET @j=@j+1
		END

		INSERT INTO ERP..mf_productionStatus (userId, productionId, typeId)
		VALUES (@T, @returnValue, @TT)
		if (@@error<>0)
		begin
			ROLLBACK tran
		end

		SET @productionStatusList= SUBSTRING(@productionStatusList, CHARINDEX('|',@productionStatusList)+1,len(@productionStatusList))
		SET @i=@i+1

	end

	commit tran

	SELECT @returnValue
