/*-----------------------得到一级类别的编号-------------------*/
CREATE PROCEDURE [dbo].[p_getBM]  @bm VARCHAR(20) OUTPUT
AS
	SET @bm='0'
	SELECT top 1 @bm=BM FROM dbo.tb_BM WHERE BM NOT IN(SELECT BM FROM dbo.tb_test) ORDER BY ID 
	IF(@bm='0')
	BEGIN
		INSERT INTO dbo.tb_BM(BM) VALUES('')
		DECLARE @tmp INT
		SET @tmp=SCOPE_IDENTITY( )
		UPDATE dbo.tb_BM SET BM=CAST(@tmp AS VARCHAR(10))+'N' WHERE id=@tmp
		SET @bm=CAST(@tmp AS VARCHAR(10))+'N'
	END
	INSERT dbo.tb_test (BM) VALUES(@bm)
