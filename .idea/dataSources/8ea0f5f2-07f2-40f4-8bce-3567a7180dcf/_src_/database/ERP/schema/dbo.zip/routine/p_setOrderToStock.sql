--添加订单入库
CREATE  procedure [dbo].[p_setOrderToStock] @orderCode varchar(50),@instockId int 
as
	declare @orderId int
	declare @type int
	set @orderId=0
	if not EXISTS(select 1 from tb_orderInstockOrder WITH(HOLDLOCK) where  orderCode=@orderCode  ) --是否已经处理过  and instockId=@instockId
	begin 
		select @orderId=id from Supermarket..tb_order where orderCode=@orderCode
		if(@orderId is not null and @orderId>0) --订单存在
		begin
			if  EXISTS(select 1 from tb_dealUpdateOrder where  orderId=@orderId ) --删除修改订单 --  and isIn=0
				set @type=1
			if  EXISTS(select 1 from supermarket.dbo.tb_order where  id=@orderId  and orderstatus in(11,17,18))--拒收订单
				set @type=2
			
			if(@type>0)
			begin
				insert into tb_orderInstockOrder(instockId,orderCode,orderId,type) values(@instockId,@orderCode,@orderId,@type)
				update tb_orderInstock set orderCount=orderCount+1 where id=@instockId
				
				if(@type=1)
					BEGIN
						update  tb_orderInstockProduct set productCount=a.productCount+b.productCount,inStockCount=a.inStockCount+b.inStockCount,injureCount=a.injureCount+b. injureCount 
						from tb_orderInstockProduct a,(
						select e.productShelfCode,sum(c.buyCount) as productCount,sum(c.buyCount-0) as inStockCount,
						sum(0) as injureCount
						 from  supermarket..tb_order a 
						inner join erp..tb_orderSaleProductDistribute c on a.id=c.orderId
						inner join supermarket..tb_saleProduct d on d.id=c.saleProductId 
						inner join tb_productSkuCode e on e.productId=d.productId and e.colorId=c.colorId and c.metricsId=e.metricsId
						where a.id=@orderId  and e.productShelfCode in(select productCode from tb_orderInstockProduct where instockId=@instockId )
						group by e.productShelfCode) as b where a.productCode=b.productShelfCode and a.instockId=@instockId
						
						
						insert into tb_orderInstockProduct(instockId,productCode,productCount,inStockCount,loseCount,injureCount,shelfCode)
						
						select @instockId,e.productShelfCode,sum(c.buyCount) as productCount,sum(c.buyCount-c.loseCount) as inStockCount,0,sum(c.loseCount) as injureCount,''
						 from  supermarket..tb_order a 
						inner join supermarket..tb_orderSaleProduct c on a.id=c.orderId
						inner join supermarket..tb_saleProduct d on d.id=c.saleProductId 
						inner join tb_productSkuCode e on e.productId=d.productId and e.colorId=c.colorId and c.metricsId=e.metricsId
						where a.id=@orderId  and e.productShelfCode not  in(select productCode from tb_orderInstockProduct where instockId=@instockId )
						group by e.productShelfCode
						
						
						update tb_dealUpdateOrder set isIn=1 where orderId =@orderId
					END
				if(@type=2)
					BEGIN

						update  tb_orderInstockProduct set productCount=a.productCount+b.productCount,inStockCount=a.inStockCount+b.inStockCount,injureCount=a.injureCount+b. injureCount 
						from tb_orderInstockProduct a,(
						select e.productShelfCode,sum(c.backCount) as productCount,sum(c.backCount-c.loseCount) as inStockCount,sum(c.loseCount) as injureCount
						 from  supermarket..tb_order a 
						inner join supermarket..tb_orderSaleProduct c on a.id=c.orderId and c.backCount>0
						inner join supermarket..tb_saleProduct d on d.id=c.saleProductId 
						inner join tb_productSkuCode e on e.productId=d.productId and e.colorId=c.colorId and c.metricsId=e.metricsId
						where a.id=@orderId  and e.productShelfCode in(select productCode from tb_orderInstockProduct where instockId=@instockId )
						group by e.productShelfCode) as b where a.productCode=b.productShelfCode and a.instockId=@instockId
						
						insert into tb_orderInstockProduct(instockId,productCode,productCount,inStockCount,loseCount,injureCount,shelfCode)
						
						select @instockId,e.productShelfCode,sum(c.backCount) as productCount,sum(c.backCount-c.loseCount) as inStockCount,0,sum(c.loseCount) as injureCount,''
						 from  supermarket..tb_order a 
						inner join supermarket..tb_orderSaleProduct c on a.id=c.orderId and c.backCount>0
						inner join supermarket..tb_saleProduct d on d.id=c.saleProductId 
						inner join tb_productSkuCode e on e.productId=d.productId and e.colorId=c.colorId and c.metricsId=e.metricsId
						where a.id=@orderId  and e.productShelfCode not  in(select productCode from tb_orderInstockProduct where instockId=@instockId )
						group by e.productShelfCode
						
						delete from supermarket..tb_rejectOrder where orderId=@orderId
					END
				select @orderId,@type,'添加成功'
			end
			else
			begin
				select 0,0,'无效订单'
			end
			
		end
		else --检查是否是退货单
		begin
			set @orderId=0
			select @orderId=id from Supermarket.dbo.tb_backOder where code=@orderCode   
			if(@orderId is not null and @orderId>0) --订单存在
				begin
					set @type=3
					insert into tb_orderInstockOrder(instockId,orderCode,orderId,type) values(@instockId,@orderCode,@orderId,@type)
					update tb_orderInstock set orderCount=orderCount+1 where id=@instockId




					update  tb_orderInstockProduct set productCount=a.productCount+b.productCount,inStockCount=a.inStockCount+b.inStockCount,injureCount=a.injureCount+b. injureCount 
					from tb_orderInstockProduct a,(
						select e.productShelfCode,sum(y.getCount) as productCount,sum(y.getCount-y.loseCount) as inStockCount,sum(y.loseCount) as injureCount
						 from  supermarket..tb_backOder a 
						inner join supermarket.dbo.tb_backProduct y on y.backId=a.id
						inner join tb_productSkuCode e on  e.colorId=y.colorId and e.metricsId=y.metricsId
						where a.id=@orderId  and e.productShelfCode in(select productCode from tb_orderInstockProduct where instockId=@instockId )
						group by e.productShelfCode) as b where a.productCode=b.productShelfCode and a.instockId=@instockId
						
						insert into tb_orderInstockProduct(instockId,productCode,productCount,inStockCount,loseCount,injureCount,shelfCode)
						
						select @instockId,e.productShelfCode,sum(y.getCount) as productCount,sum(y.getCount-y.loseCount) as inStockCount,0,sum(y.loseCount) as injureCount,''
						 from  supermarket..tb_backOder a 
						inner join supermarket.dbo.tb_backProduct y on y.backId=a.id
						inner join tb_productSkuCode e on   e.colorId=y.colorId and y.metricsId=e.metricsId
						where a.id=@orderId  and e.productShelfCode not  in(select productCode from tb_orderInstockProduct where instockId=@instockId )
						group by e.productShelfCode

					select @orderId,@type,'添加成功'
				end
			else --退单不存在
				begin
					select 0,0,'订单不存在'
				end
		end
	end
	else
	begin
		select 0,0,'订单已处理过'
	end
