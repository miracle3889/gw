create procedure [dbo].[p_addProductEvery]
 as 
 delete from  erp..tb_productStockPrice where addDate>=CONVERT(varchar(10),GETDATE(),120)

insert into erp..tb_productStockPrice
select  b.productId,a.name as productname,SUM(b.productCount) as productCount,
a.stockPriceReal as productPrice,GETDATE() as addDate from tb_product a
inner join tb_productStock b on a.id=b.productId
group by b.productId,a.name,a.stockPriceReal
