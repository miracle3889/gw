CREATE PROCEDURE [dbo].[p_addBatchOutBatchId]
 @userId int
AS

DECLARE @batchId	INT  --批次ID
set @batchId=0
DECLARE @nowDate	datetime  --当前日期（日）
set @nowDate=GETDATE()
DECLARE @batchCount	INT  --批次数
set @batchCount=0
BEGIN
	--查询当日批次数
	select @batchCount=COUNT(*) from ERP..tb_batch where date>=Convert(varchar(10),getdate(),112) and date<Convert(varchar(10),getdate()+1,112)
    --新增批次
    insert into ERP..tb_batch (nextstr,date,userId,type) values (Convert(varchar(10),@nowDate,112)+'-'+cast((@batchCount+1) as varchar(10)),replace(Convert(varchar(10),@nowDate,111),'/','-'),@userId,0)
    set @batchId=SCOPE_IDENTITY()
END
select @batchId as ret
