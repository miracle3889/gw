CREATE procedure [dbo].[p_addorderOutOfstock] 
as 
	insert into tb_orderOutOfstock(id,orderCode,memberId,outCount,expectedInTime,mobileNum)
	select b.id,orderCode,memberId,sum(outCount) as outCount ,max(expectedInTime) as expectedInTime ,   
	(case  when subString(mobileNum,1,1)='0' then  subString(mobileNum,2,len(mobileNum)) else mobileNum end ) as mobileNum
		
	 from erp..tb_notCanDistributeProduct  a
	inner join supermarket..tb_order b on a.orderId=b.id and DATEDIFF ( hour , b.createTime , getDate() ) >24
	inner join erp..tb_productStock c on a.productId=c.id
	inner join 
	(
		select productId,colorId,metricsId,max(expectedInTime) as expectedInTime  from erp.dbo.tb_buyProductList a
		inner join dbo.tb_buyProductProtity b on a.id=b.buyProductId
		 where isDeleted=0 and buyStatus in(1,2,3)  and  DATEDIFF(Day,getDate(),expectedInTime )>=1
		group by productId,colorId,metricsId 
	) d on d.colorId=c.colorId and c.metricsId=d.metricsId
	inner join supermarket..tb_member  e on e.id=memberId
	where case  when subString(mobileNum,1,1)='0' then  subString(mobileNum,2,len(mobileNum)) else mobileNum end  like '1__________' 
		
	and b.id not in(select id from tb_orderOutOfstock )
	group by b.id,orderCode,memberId,e.mobileNum

	/*INSERT INTO c3.dbo.tb_smsMission(sourceType,mobileNum,content,sendTime)  
	select 0,mobileNum,'您在优邮的订单'+orderCode+'有'+cast(outCount as varchar(10))+'件商品缺货，预计'+convert(varchar(10),expectedInTime,120)+'到货,现赠送您10元礼金券以表歉意,下次订购可用',getDate() from  erp..tb_orderOutOfstock where issend=0
		
		declare @memberId int

		DECLARE authors_cursor2 CURSOR FOR
			select memberId from erp..tb_orderOutOfstock where issend=0
		OPEN authors_cursor2
		FETCH NEXT FROM authors_cursor2  INTO @memberId
		WHILE @@FETCH_STATUS = 0
		BEGIN			
			
			
			exec supermarket..p_sendGiftCard @memberId,98
			FETCH NEXT FROM authors_cursor2  
			INTO @memberId
		END
		CLOSE authors_cursor2
		DEALLOCATE authors_cursor2
	*/
	update    erp..tb_orderOutOfstock set issend=1 where issend=0
