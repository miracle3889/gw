-- =============================================
-- Author:		<runbin>
-- Create date: <2015-08-05>
-- Description:	<关联设计师>
-- =============================================
CREATE PROCEDURE [dbo].[p_connectShejishi]
	@shejishiId int,	--设计师id
	@zhuliId int	--设计助理id
AS
declare @existedNum int	--判断设计师是否已 被关联
BEGIN
	begin tran
		if exists(select 1 from ERP..tb_userRole where userId=@zhuliId and roleId=13 )
		and not exists(select 1 from  ERP..tb_userRole where userId=@zhuliId and roleId=11)
		and not exists (select 1 from ERP..tb_designer_assistant where userPid = @shejishiId )
			begin
				insert into ERP..tb_designer_assistant(userId,userPid) values(@zhuliId,@shejishiId)
				set @existedNum = SCOPE_IDENTITY()
			end
		else
			set @existedNum = 0
	commit tran
	select @existedNum as ret
END
