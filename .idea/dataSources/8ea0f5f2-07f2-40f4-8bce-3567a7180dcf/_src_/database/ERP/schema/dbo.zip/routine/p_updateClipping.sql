-- 修改裁剪单
CREATE PROCEDURE [dbo].[p_updateClipping] @productId int, @clippingTime varchar(32), @outTime varchar(32), @mfAddrId int, @status int, @doManId int,
				@reMark varchar(320), @batchNumber int, @protity varchar(320), @productTime varchar(32), @id int 

AS

	DECLARE @returnValue INT	
	SET @returnValue=0
	
	DECLARE @allClippingCount INT
	SET @allClippingCount=0
	
	begin tran

	IF (@id!=0)
	BEGIN
		
		UPDATE ERP..tb_clipping SET  clippingTime=@clippingTime, outTime=@outTime, mfAddrId=@mfAddrId, 
		 reMark=@reMark, batchNumber=@batchNumber,productTime=@productTime WHERE id=@id --status=1,
		SET @returnValue=1
		/*****增加裁剪单的裁剪数****/
	
		DECLARE @colorString VARCHAR(300)
		DECLARE @protityId int
		DECLARE @clippingCount int
		
		DECLARE @i INT
		while len(@protity)>0
		begin
	
			SET @colorString= SUBSTRING(@protity, 0,CHARINDEX(',',@protity))
			
			SET @i=1
			while @i<=2
			BEGIN
				IF @i=1
				SET @protityId= SUBSTRING(@colorString, 0,CHARINDEX('&',@colorString))
				IF @i=2
				SET @clippingCount= SUBSTRING(@colorString, 0,CHARINDEX('&',@colorString))
	
				set @colorString=SUBSTRING(@colorString, CHARINDEX('&',@colorString)+1,len(@colorString))
				
				SET @i=@i+1
				
			END
			/** 是否修改了值 **/
			if NOT EXISTS (select * from ERP..tb_clippingProtity where id=@protityId and clippingCount=@clippingCount)
			begin
				DECLARE @oldClippingCount int
				select @oldClippingCount=clippingCount from ERP..tb_clippingProtity where id=@protityId
				/*修改了*/
				INSERT INTO ERP..tb_clippingProtityInfo (clippingProtityId, clippingCount, oldClippingCount, doManId) 
						values (@protityId, @clippingCount, @oldClippingCount, @doManId)
			end
			
			
			
			UPDATE ERP..tb_clippingProtity SET clippingCount=@clippingCount WHERE id=@protityId
			if (@@error<>0)
			begin
				ROLLBACK tran
			end

			SET @allClippingCount=@allClippingCount+@clippingCount

			SET @protity= SUBSTRING(@protity, CHARINDEX(',',@protity)+1,len(@protity))
			
		end

	END
	commit tran
	select @allClippingCount=sum(clippingCount) from  tb_clippingProtity where clippingId=@id
	UPDATE ERP..tb_clipping set clippingCount=@allClippingCount where id=@id

	SELECT @returnValue
