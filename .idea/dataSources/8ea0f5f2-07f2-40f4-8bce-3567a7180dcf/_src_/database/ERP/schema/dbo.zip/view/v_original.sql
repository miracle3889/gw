
/*and h.mainPic=0
where a.id=1*/
CREATE VIEW [dbo].[v_original]
AS
SELECT     a.id, a.price, ISNULL(a.sourceId, 0) AS sourceId, CASE a.sourceId WHEN 0 THEN '平台款' ELSE f.chName END AS chName, g.name + ' ' + CONVERT(varchar(11), 
                      e.date, 20) + CASE a.status WHEN 0 THEN '签收' WHEN 1 THEN '签出' WHEN - 1 THEN '创建' END AS historyStr, a.status, a.typeId, b.name, ISNULL(h.count, 0) 
                      AS countPic, a.bzId, a.picId, ISNULL(z.count, 0) AS countMedia, ISNULL(y.name, '') AS fisionerName, a.fisionerId
FROM         dbo.tb_original AS a LEFT OUTER JOIN
                      dbo.tb_code_base AS b ON b.id = a.typeId AND b.pid = 12 LEFT OUTER JOIN
                      dbo.tb_operateHistory AS e ON e.id = a.historyId LEFT OUTER JOIN
                      dbo.tb_user AS g ON e.userId = g.id LEFT OUTER JOIN
                      supermarket.dbo.tb_brandNick AS f ON f.id = a.sourceId LEFT OUTER JOIN
                      dbo.tb_multimedia_pid AS h ON h.id = a.picId LEFT OUTER JOIN
                      dbo.tb_multimedia_pid AS z ON z.id = a.bzId LEFT OUTER JOIN
                      dbo.tb_original_fisioner AS y ON y.id = a.fisionerId

