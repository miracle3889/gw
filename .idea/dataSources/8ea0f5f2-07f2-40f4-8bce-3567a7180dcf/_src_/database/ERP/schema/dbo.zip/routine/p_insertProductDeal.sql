-- =============================================
-- Author:		<runbin>
-- Create date: <2015-08-24>
-- Description:	<处理单件商品>
-- =============================================
CREATE PROCEDURE [dbo].[p_insertProductDeal]
	@sid varchar(20),--快递单号
	@userId int,--拆包人
	@status int,--问题状态
	@colorId int, --颜色id
	@sizeId int, --尺码id
	@productId	int, --商品id
	@picId int,	--破损衣服图片pid
	@memberId int, --会员id
	@taobaoRefundId int, --淘宝退款单号
	@sellerNick	varchar(30), --卖家
	@tid varchar(30),	--淘宝单号
	@oColorId int, --原始颜色id
	@oSizeId int, --原始颜色id
	@flag varchar(30) --标记
AS
declare @packageId int	--拆包处理id
declare @problemDesc varchar(200) --问题描述
declare @ret int
declare @productDealId int	--商品处理表id
declare @type int	--类型 0-普通退单 1-拒收单 2-无商品信息单
BEGIN
	begin tran
		select @packageId = id,@problemDesc = problemDsc from SuperMarket..Tb_salePackageDeal where sid = @sid and userId = @userId
		if PATINDEX ('%'+dbo.f_parseProblemDesc(@status)+'%',@problemDesc) =0	--处理结果不同
				set @problemDesc = @problemDesc+','+dbo.f_parseProblemDesc(@status)
		--同一人处理同一个快递
		if @packageId>0
			begin 
				update SuperMarket..Tb_salePackageDeal set problemDsc = @problemDesc,
					unPackTime = GETDATE() where sid = @sid and userId = @userId and status<3
			end
		--不同人处理快递或者第一次处理
		else
			begin 
				--拒收单
				if exists (select 1 from SuperMarket..tb_order where otherOrder = @sid)
					begin
						set @type = 1
					end
				----无商品信息单
				if not exists (select 1 from SuperMarket..tb_order where otherOrder = @sid) 
				and 
				not exists (select 1 from supermarket..tb_taobaorefund where sid = @sid)
				begin
					set @type = 2
				end
				
			
				insert into SuperMarket..Tb_salePackageDeal(sid,userId,unPackTime,status,problemDsc,type)
					values (@sid,@userId,GETDATE(),0,dbo.f_parseProblemDesc(@status),@type)
				set @packageId = SCOPE_IDENTITY()
			end
			
		--存在则更新(商品编号不是唯一的)	
		if exists (select 1 from SuperMarket..Tb_saleProductDeal where productId = @productId and storageStatus = 0 and flag=@flag and packageId = @packageId)
			begin
				select @picId = picId from SuperMarket..Tb_saleProductDeal where productId = @productId and storageStatus = 0 and flag*1= @flag*1 and packageId = @packageId
				update SuperMarket..Tb_saleProductDeal set 
				skuCode = (select a.productShelfCode skuCode from erp..tb_productStock a 
										inner join erp..tb_product b on a.productId=b.id
										inner join erp..tb_productColorCode c on c.id=a.colorId
										inner join erp..tb_productMetricsCode d on d.id=a.metricsId 
									where c.id = @colorId and d.id = @sizeId and a.productId = @productId ),
									picId = @picId,status = @status where productId = @productId and flag = @flag and refundTime is null					
			end
		else
			begin
				if not exists (select 1 from supermarket..Tb_saleProductDeal where flag=@flag and packageId=@packageId)
			--插入商品处理表
				insert into SuperMarket..Tb_saleProductDeal(packageId,skuCode,status,storageStatus,memberId,picId,taobaoRefundId,sellerNick,productId,tid,oColorId,oSizeId,flag)
					values (@packageId,(select a.productShelfCode skuCode from erp..tb_productStock a 
										inner join erp..tb_product b on a.productId=b.id
										inner join erp..tb_productColorCode c on c.id=a.colorId
										inner join erp..tb_productMetricsCode d on d.id=a.metricsId 
									where c.id = @colorId and d.id = @sizeId and a.productId = @productId ),@status,0,
									@memberId,@picId,@taobaoRefundId,@sellerNick,@productId,@tid,@oColorId,@oSizeId,@flag)
						
			end
		
	commit tran
	set @ret = 1
END
select @ret