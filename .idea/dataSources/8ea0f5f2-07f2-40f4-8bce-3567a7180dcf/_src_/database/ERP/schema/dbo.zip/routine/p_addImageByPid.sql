/*********		新增img		***********/
CREATE PROCEDURE [dbo].[p_addImageByPid]
 @pid	int,
 @userId int
AS

DECLARE @id	INT  --返回的图片id
DECLARE @count	INT  --返回的图片数量
set @count=0

BEGIN
	select @count=count from erp..tb_multimedia_pid where id=@pid
    insert into ERP..tb_image (pid,userId,mainPic,updateTime) values (@pid,@userId,'0',GETDATE())
    set @id=SCOPE_IDENTITY()
    set @count=@count+1
    print @count
    update erp..tb_multimedia_pid set count=@count where id=@pid
END
select @id as id

