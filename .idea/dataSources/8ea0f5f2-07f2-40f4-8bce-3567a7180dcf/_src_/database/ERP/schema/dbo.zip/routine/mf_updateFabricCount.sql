-- 物料入库
CREATE PROCEDURE [dbo].[mf_updateFabricCount] @mfCount INT, @mfDate VARCHAR(10), @mfAddrsId INT, @userId INT, @id INT
AS

	DECLARE @returnValue INT
	SET @returnValue = 1

	DECLARE @purchaseId INT
	DECLARE @i INT
	SET @i=0
	DECLARE @j INT
	SET @j=0

	begin tran

		update ERP..mf_fabricCount set mfCount=@mfCount, mfDate=@mfDate, mfAddrsId=@mfAddrsId, userId=@userId where id=@id
		if (@@error<>0)
		begin
			SET @returnValue = 0
			ROLLBACK tran
		end
		ELSE
		BEGIN
			SELECT @purchaseId=purchaseId FROM ERP..mf_fabricCount WHERE id=@id
			
			SELECT @i=count(*) FROM ERP..mf_fabricCount WHERE purchaseId=@purchaseId and mfCount=0

			SELECT @j=count(*) FROM ERP..mf_fabricCount WHERE purchaseId=@purchaseId and mfCount!=0

			IF(@i=0) -- 全部到货
			BEGIN
				UPDATE ERP..mf_purchase SET isDaoHuo=2 WHERE id=@purchaseId
			END
			IF (@i!=0 and @j!=0) -- 部分到货
			BEGIN
				UPDATE ERP..mf_purchase SET isDaoHuo=1 WHERE id=@purchaseId
			END
		END
	
	commit tran

	SELECT @returnValue
