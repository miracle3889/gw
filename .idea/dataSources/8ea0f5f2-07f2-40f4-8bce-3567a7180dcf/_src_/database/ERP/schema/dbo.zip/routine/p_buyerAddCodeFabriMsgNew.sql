-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>  买手开款
-- Description:	<Description,,>
-- =============================================
create PROCEDURE [dbo].[p_buyerAddCodeFabriMsgNew] 
	@userid int,
	@type int,
	@picId int
AS
	declare @styleId int
	declare @gouxiangId int
		set @gouxiangId=0
	declare @userName varchar(200)
BEGIN

	insert into ERP..tb_multimedia_pid (count,type) values (0,3)
	set @gouxiangId=SCOPE_IDENTITY()
	 --新增款式
	insert into ERP..mf_pCodeFabricMsg
	(pCode,addUserId,addDate,sheJiShiId,banShiId,yangyiId,originalId,seasonId,mainPatternId,designWrittenId,originalTypeId,gouxiangId,type,ruhnnbrandId,statusId,status,jstatus,doManId,developMode,picId)
	 values 
	 (0,@userid,GETDATE(),@userid,0,0,0,0,0,0,0,@gouxiangId,0,0,9,0,0,0,5,@picId)
	 
	 
	 
	 set @styleId=SCOPE_IDENTITY()
	 update ERP..mf_pCodeFabricMsg set pCode=@styleId where id=@styleId
	 
	 select @userName=name from ERP..tb_user where id=@userId
	 --增加款式状态记录
	 insert into ERP..tb_status_history (styleId,statusId,userId,date,bz) values (@styleId,9,@userId,getDate(),@userName+'完成买手开款录入')
	
END
 select @styleId
