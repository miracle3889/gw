CREATE procedure [dbo].[p_delImageByQuery]
 @id int ,
 @userId int 
as
DECLARE @returnValue INT --回滚事务
DECLARE @nowPid INT --查询当前PID
DECLARE @isDel INT --删除是否成功
DECLARE @pid INT --删除信息的PID
DECLARE @groupId int --职能
  begin try
	  select @pid=pid from erp..tb_image where id=@id
	  select @groupId=groupId from ERP..tb_user where id=@userId;
	  if(@groupId = 1)
	  begin
		 delete from erp..tb_image where id=@id
	  end
	  if(@groupId <> 1)
	  begin
		 delete from erp..tb_image where id=@id and userId=@userId
	  end
	  exec ERP..p_getCountByPid @pid,@returnValue output ;
  end try
  BEGIN CATCH------------有异常被捕获
        IF @@TRANCOUNT > 0---------------判断有没有事务
        BEGIN
            ROLLBACK TRAN----------回滚事务
           set @returnValue=0
        END 
  END CATCH
select @returnValue as 'ret';
