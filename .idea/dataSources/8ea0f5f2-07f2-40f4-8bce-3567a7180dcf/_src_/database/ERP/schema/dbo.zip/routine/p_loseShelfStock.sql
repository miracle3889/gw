/*-----------------------tiaozhenghuojia----------------------*/
CREATE  procedure [dbo].[p_loseShelfStock] @shelfCodeold varchar(50),@productCode varchar(50),@count int,@remark VARCHAR(200),@dealManId int,@type int
as 
		DECLARE @shelfCode  varchar(50)
		if(@type=1)
		BEGIN
			SET @shelfCode='X0000'
		END
		ELSE
		BEGIN
			SET @shelfCode='Y0000'
		END
		if EXISTS(select 1 from tb_productStock  where productShelfCode=@productCode )
		BEGIN			
			if EXISTS(select 1 from tb_goodsShelf  where code=@shelfCodeold )
			BEGIN
				begin tran
					declare @oldCount int 
					select @oldCount=productCount from tb_shelfProductCount where shelfCode=@shelfCodeold and productCode=@productCode
					--原货架减少库存
					update tb_shelfProductCount set productCount=productCount-@count where shelfCode=@shelfCodeold and productCode=@productCode
					
					--update tb_productStock set productCount=productCount-@count where productShelfCode=@productCode
					
					DECLARE @productId int
					DECLARE @colorId int
					DECLARE @count2 int
					DECLARE @metricsId int
					
					select @productId=productId,@colorId=colorId,@metricsId=metricsId from tb_productStock where  productShelfCode=@productCode
					set @count2=@count*-1
					if(@type=1)
					BEGIN
						exec p_addProductStockCount  @productId,@colorId,@metricsId,@count2,2,@dealManId,@remark
					END
					ELSE
					BEGIN
						exec p_addProductStockCount  @productId,@colorId,@metricsId,@count2,3,@dealManId,@remark
					END
					
				
					if(@@error<>0)
						rollback tran 
					insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,productOldCount,dealManId,type) values(@shelfCodeold,@productCode,@count,@oldCount,@dealManId,-1)
					if(@@error<>0)
						rollback tran 
					
					if EXISTS(select 1 from tb_shelfProductCount where shelfCode=@shelfCode and productCode=@productCode)
					begin
						select @oldCount=productCount from tb_shelfProductCount where shelfCode=@shelfCode and productCode=@productCode
						update tb_shelfProductCount set productCount=productCount+@count where shelfCode=@shelfCode and productCode=@productCode
					end
					else
					begin
						set @oldCount=0
						insert into tb_shelfProductCount(shelfCode,productCode,productCount) values(@shelfCode,@productCode,@count)
					end

					insert into supermarket..tb_updateTabaoProductCount(productCode,productCount,reMark)  values(@productCode,@count,'报损报失')
					if(@@error<>0)
						rollback tran 
					insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,productoldCount,dealManId,remark) values(@shelfCode,@productCode,@count,@oldCount,@dealManId,@remark)
					if(@@error<>0)
						rollback tran 
					
					if(@count>=5)
					begin
						INSERT INTO c3.dbo.tb_smsMission(sourceType,mobileNum,content,sendTime,orderByClass,sendManId)
						select 1,'18668122055','【如涵】信息中心提醒您，编号'+@productCode+'发生报损报失操作，数量为'+CAST(@count as varchar(10))+',请确认操作行为是否正确。',
						GETDATE(),9999,1
						INSERT INTO c3.dbo.tb_smsMission(sourceType,mobileNum,content,sendTime,orderByClass,sendManId)
						select 1,'13606818964','【如涵】信息中心提醒您，编号'+@productCode+'发生报损报失操作，数量为'+CAST(@count as varchar(10))+',请确认操作行为是否正确。',
						GETDATE(),9999,1
					end
					SELECT 1,'操作成功'
				commit tran
			END
			ELSE
			BEGIN
				SELECT -1,'货架号不存在'
			END
		END
		ELSE
		BEGIN
			SELECT -2,'商品不存在'
		END
