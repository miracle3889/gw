/*********		生成款式多媒体ID		***********/
CREATE PROCEDURE [dbo].[addFCMMeidaPid]
AS

DECLARE @picId INT  --款式picID
set @picId=0

BEGIN
    --新增构想多媒体
    
	insert into ERP..tb_multimedia_pid (count,type) values (0,3)
	set @picId=SCOPE_IDENTITY()
	
END
select @picId as ret
