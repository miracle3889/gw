CREATE PROCEDURE [dbo].[p_updateCodeTpyeIsDelete]
		@id int
    AS
    BEGIN
		declare @isDelete int 
		select  @isDelete=isdelete from  ERP..tb_code_type  where  id=@id
		DECLARE @returnValue int
		if(@isDelete=0)
		begin
			update ERP..tb_code_type set isdelete=1 where id=@id
			set @returnValue=1		       
        end
        ELSE
        begin
			update ERP..tb_code_type set isdelete=0 where id=@id
			set @returnValue=0		       
        end
    END
select @returnvalue
