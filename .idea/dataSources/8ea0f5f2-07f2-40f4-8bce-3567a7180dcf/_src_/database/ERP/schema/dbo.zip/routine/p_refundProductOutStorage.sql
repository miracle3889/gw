-- =============================================
-- Author:		<runbin>
-- Create date: <2016-07-07>
-- Description:	<退货商品出库>
-- =============================================
CREATE PROCEDURE [dbo].[p_refundProductOutStorage]
@outCode varchar(20),	--出库单号
@userId int	--出库人
as
declare @id int,
@colorId int ,
@metricsId int ,
@productId int ,
@productCode varchar(50),
@shelfCode varchar(50),
@outCount int,
@outCountComp int,--比较库存
@return int
set @return=0;
if exists (select 1 from supplyCenter.product_refund.tb_outStorage where outCode=@outCode and status=1)
begin
	declare @okshelfCount int 
	declare @tShelfCount int
	declare @saleCode int
	declare @taxPrice int 
	declare @unitPrice int
	
	select @okshelfCount=COUNT(1) from supplyCenter.product_refund.tb_outStorage_child a
	inner join erp..[tb_goodsShelf ] b on a.productShelf=b.code and b.isStock=1 and a.outCode=@outCode
	
	if(@okshelfCount is null ) set @okshelfCount=0
	
	--出库商品数量
	select @outCount=sum(outAmount),@tShelfCount=COUNT(1) from supplyCenter.product_refund.tb_outStorage_child where outCode=@outCode
	
	if @outCount is null set @outCount=0
	--更新状态和入库数量
	if(@tShelfCount is null ) set @tShelfCount=0
	
	if(@tShelfCount=@okshelfCount)--货架号填写全部正确
	begin
		begin tran
		DECLARE  cs CURSOR FOR 
			select 
				productId,colorId,sizeId,a.outAmount*-1,skuCode,productShelf,b.saleCode,b.taxPrice,b.unitPrice
			from 
				supplyCenter.product_refund.tb_outStorage_child  a
			inner join
				supplyCenter.product_refund.tb_product_refund c on a.refundId = c.id
			inner join 
				supplycenter..pro_purchase b on c.purchaseId=b.id 
			where  
				outCode=@outCode
			
			OPEN cs
			FETCH NEXT FROM cs
			INTO @productId,@colorId,@metricsId,@outCount,@productCode,@shelfCode,@saleCode,@taxPrice,@unitPrice
			WHILE @@fetch_status =0
			
			BEGIN		
				
				select @outCountComp=productCount from ERP..tb_productStock where productShelfCode=@productCode
				
				if(@outCountComp<@outCount) set @outCount=@outCountComp*-1;
				
			
				exec p_addProductStockCount  @productId,@colorId,@metricsId,@outCount,1,@userId,'退货商品出库'
				--SKU编号不存在
				if(@productCode is null  or @productCode='') 
				begin
					exec p_getShelfProductCode @productId,@colorId,@metricsId,@productCode output
					
					if(@productCode is null) 
					begin
						set @productCode=''
					end
					update tb_productStock set productShelfCode =@productCode
					 where productId=@productId and colorId=@colorId and metricsId=@metricsId
					
					if not exists (select 1 from erp..tb_productSkuCode 
					where productId=@productId and colorId=@colorId and metricsId=@metricsId )
					begin
						insert into tb_productSkuCode(productShelfCode,productId,colorId,metricsId)
						 values(@productCode,@productId,@colorId,@metricsId)
					end
				end	
				
				exec [dbo].[p_addShelfStockBySystem] @shelfCode,@productCode,@outCount,@userId,4,''
				
				
				--加权平均
				
				exec  finance..p_finance_averagePrice   @productId,@saleCode,@taxPrice,@unitPrice,@outCount
	 
				FETCH NEXT FROM cs
				INTO @productId,@colorId,@metricsId,@outCount,@productCode,@shelfCode,@saleCode,@taxPrice,@unitPrice
			END
			
			CLOSE cs
		DEALLOCATE cs


		if @@ERROR<>0
			begin
				update supplyCenter.product_refund.tb_outStorage set status=1,outAmount=0 where outCode=@outCode
				update supplyCenter.product_refund.tb_outStorage_child set productShelf='',outAmount=0 where outCode=@outCode
				rollback tran
				RETURN;
			end
		else
			begin
				set @return=1;
				--更新出库单
				update supplyCenter.product_refund.tb_outStorage set status=2,outAmount=
				(
					select SUM(outAmount) from supplyCenter.product_refund.tb_outStorage_child where outCode=@outCode
				),outStorageTime=GETDATE(),outStorageUserId=@userId where outCode=@outCode
				
				--更新退货单出库数
				update supplyCenter.product_refund.tb_product_refund set outStorageAmount =outStorageAmount+ outAmount
				from supplyCenter.product_refund.tb_product_refund a,(
					select 
						SUM(outAmount) outAmount,refundId 
					from 
						supplyCenter.product_refund.tb_outStorage_child where outCode=@outCode
					group by refundId
				) b where a.id = b.refundId
				
				
				--更新采购单出库数和入库数
				update  supplycenter..pro_purchase set refundAmount=a.refundAmount+b.outAmount ,storageAmount=storageAmount-b.outAmount
				from  supplycenter..pro_purchase  a,(
					select 
						purchaseId,
						SUM(outAmount) as outAmount 
					from  
						supplyCenter.product_refund.tb_outStorage_child  b
					inner join
						supplyCenter.product_refund.tb_product_refund c on b.refundId = c.id
					where 
						outCode=@outCode 
					group by purchaseId
				) b 
				where 
					a.id=b.purchaseId
				
				
				--更新采购单子表出库数
				declare @temp varchar(20)
				declare @temp2 varchar(20)
				declare @refundId int
				declare p_cursor CURSOR FOR	--采购单编号游标
					select 
						c.purchaseid,b.skucode,c.id
					from 
						supplyCenter.product_refund.tb_outStorage_child  b
					inner join
						supplyCenter.product_refund.tb_product_refund c on b.refundId = c.id
					where
						outCode=@outCode 
				
				open p_cursor
					FETCH NEXT FROM p_cursor INTO @temp,@temp2,@refundId
					WHILE @@FETCH_STATUS = 0
						begin
							 --更新采购单子表出库数
							update  supplycenter..pro_purchase_child set refundAmount= b.outAmount ,storageCount=storageCount-b.outAmount
							from  supplycenter..pro_purchase_child  a,(
								select 
									sum(b.outAmount) as outAmount,
									skuCode,
									d.purchaseCode 
								from  
									supplyCenter.product_refund.tb_outStorage_child  b
								inner join
									supplyCenter.product_refund.tb_product_refund c on b.refundId = c.id
								inner join
									supplyCenter..pro_purchase d on c.purchaseId = d.id
								where 
									purchaseId=  @temp and skuCode=@temp2
								group by skuCode,purchaseCode
							) b where a.skucode=b.skuCode and a.purchaseCode=b.purchaseCode
							
								--更新退货单子表出库数
							update supplyCenter.product_refund.tb_product_refund_child set outStorageAmount = outAmount
							from supplyCenter.product_refund.tb_product_refund_child a ,(
								select 
									SUM(outAmount) outAmount,refundId,skuCode 
								from supplyCenter.product_refund.tb_outStorage_child 
								where 
									refundId = @refundId and skuCode = @temp2
								group by refundId,skuCode
							) b where a.skuCode = b.skuCode and a.refundId = b.refundId
							
							FETCH NEXT FROM p_cursor INTO @temp,@temp2,@refundId
						end
						
						
				CLOSE p_cursor--关闭游标
				DEALLOCATE p_cursor--释放游标
				
				
				commit tran
			end
		end
end
select @return as ret;
