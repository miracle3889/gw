-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>  买手开款
-- Description:	<Description,,>
-- =============================================
create PROCEDURE [dbo].[p_buyerAddCodeFabriMsg] 
	@userid int
AS
	declare @picId int
	declare @styleId int
BEGIN
	insert into ERP..tb_multimedia_pid (count,type) values (0,1)
	set @picId=SCOPE_IDENTITY()
	
	 --新增款式
	insert into ERP..mf_pCodeFabricMsg
	(pCode,addUserId,addDate,sheJiShiId,banShiId,yangyiId,originalId,seasonId,mainPatternId,designWrittenId,originalTypeId,gouxiangId,type,ruhnnbrandId,statusId,status,jstatus,doManId,developMode,picId)
	 values 
	 (0,@userid,GETDATE(),@userid,0,0,0,0,0,0,0,0,0,0,9,0,0,0,5,@picId)
	 
	 
	 
	 set @styleId=SCOPE_IDENTITY()
	 update ERP..mf_pCodeFabricMsg set pCode=@styleId where id=@styleId
	
END
 select @styleId
