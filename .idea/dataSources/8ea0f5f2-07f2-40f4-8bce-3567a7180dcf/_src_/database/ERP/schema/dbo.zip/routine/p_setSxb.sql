create  procedure  [dbo].[p_setSxb] @imgPath varchar(50),@remark varchar(50),@orderByClass int,@productId int
as 
	begin tran 
	delete from [tb_sxb] where productId=@productId and orderByClass=@orderByClass
	insert into [tb_sxb]([imgPath],[remark],[orderByClass],productId) values(@imgPath,@remark,@orderByClass,@productId)
 
	commit tran
