-- 将剩余库存加入本计划
CREATE PROCEDURE [dbo].[mf_updateProductionPlanTaskCount] @id INT, @planTaskCount INT, @userId int, @endTime varchar(32), @status int
AS

	DECLARE @returnValue INT
	SET @returnValue = 0

	begin tran
		if (len(@endTime) >= 10)
		BEGIN
			--, status=@status
			update ERP..mf_productionPlanTask set planTaskCount=planTaskCount+@planTaskCount, userId=@userId, endTime=@endTime where id=@id
			if (@@error<>0)
			begin
				SET @returnValue = 0
				ROLLBACK tran
			end
		END
		ELSE
		BEGIN
			--, status=@status
			update ERP..mf_productionPlanTask set planTaskCount=planTaskCount+@planTaskCount, userId=@userId where id=@id
			if (@@error<>0)
			begin
				SET @returnValue = 0
				ROLLBACK tran
			end
		END
	
	commit tran

	SELECT @returnValue
