CREATE procedure [dbo].[addEveryMonthReport] @date dateTime
as 
--declare @date datetime  --初始时间 月份
declare @startdate dateTime  --月初时间
declare @enddate dateTime  --月末时间
--set @date='2015-01-05'
set @startdate= dateadd(day,-1,DATEADD(MONTH,DATEDIFF(month,0,@date),0)) --月初
set @enddate= dateadd(day,-1,DATEADD(MONTH,1+DATEDIFF(month,0,@date),0)) --月末

--月末销量
insert into  reportruhnn..tb_everyMonthStockReport 
select  endMonth.productId,endMonth.productName,  CONVERT(varchar(7),@date,120) as nmonth
,ISNULL(startMonth.productStock,0) as scount,ISNULL(endMonth.productStock,0) as eCount,'000000' as saleCode
--into reportruhnn..tb_everyMonthStockReport
 from (
select * from erp..tb_productStockPrice where CONVERT(varchar(10),addDate,120)= CONVERT(varchar(10),@enddate,120)
) 
as endMonth 
left join 
(
	--月初销量
	select * from erp..tb_productStockPrice where CONVERT(varchar(10),addDate,120)= CONVERT(varchar(10),@startdate,120)
) as startMonth on endMonth.productId=startMonth.productId
