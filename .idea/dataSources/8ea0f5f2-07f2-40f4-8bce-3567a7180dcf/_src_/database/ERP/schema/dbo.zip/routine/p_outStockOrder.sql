/******************配货数和订单数对比***********************/
CREATE PROCEDURE [dbo].[p_outStockOrder] 	@orderId int
						
AS
	begin tran
		 IF EXISTS (SELECT *
	             FROM dbo.sysobjects
	            WHERE id = object_id(N'.[dbo].[tb_tempStockOrder]') AND 
	                  OBJECTPROPERTY(id, N'IsUserTable') = 1) 
		DROP TABLE dbo.tb_tempStockOrder

		select a.saleProductCode as saleCode,a.colorId as colorId,a.metricsId as metricsId,b.productId as productId,sum(a.buyCount) as buyCount,a.saleProductId as saleProductId 
		into tb_tempStockOrder
		from SuperMarket.dbo.tb_orderSaleProduct a
		inner join SuperMarket.dbo.tb_saleProduct b on b.id=a.saleProductId
		where a.orderId=@orderId
		group by a.saleProductCode,colorId,metricsId,productId,saleProductId	
		union select a.saleGroupCode as saleCode,b.colorId,b.metricsId,c.productId,sum(a.buyCount*b.buyCount),b.saleProductId as saleProductId
		from SuperMarket.dbo.tb_orderSaleGroup a
		inner join SuperMarket.dbo.tb_orderSaleGroupProduct b on b.orderSaleGroupId=a.id
		inner join SuperMarket.dbo.tb_saleProduct c on c.id=b.saleProductId
		where a.orderId=@orderId
		group by a.saleGroupCode,colorId,metricsId,productId,saleProductId

		SELECT c.code AS productCode,d.codeName AS color,e.codeName AS metrics,c.location AS location,
		sum(a.buyCount) AS buyCount,f.id AS packStyleId,f.packStyleName AS packStyleName,
		g.id AS deliverCompanyId,a.colorId as colorId,a.metricsId as metricsId,a.productId as productId,
		g.deliverCompanyName AS deliverCompanyName,
		b.id as saleProductId,c.name AS name,i.outCount as outCount 
		FROM  tb_tempStockOrder a
		INNER JOIN  Supermarket.dbo.tb_saleProduct b ON a.saleProductId=b.id 
		INNER JOIN ERP.dbo.tb_product c ON b.productId=c.id 
		INNER JOIN ERP.dbo.tb_productColorCode d ON a.colorId=d.id 
		INNER JOIN ERP.dbo.tb_packStyle f ON c.packStyleId=f.id
		INNER JOIN ERP.dbo.tb_deliverCompany g ON c.deliverCompanyId=g.id
		INNER JOIN ERP.dbo.tb_productMetricsCode e ON a.metricsId=e.id
		inner join SuperMarket.dbo.tb_order j on j.id=@orderId
		inner join ERP.dbo.tb_outStock h on h.adaptCode=j.orderCode
		inner join ERP.dbo.tb_outProduct i on i.outId=h.id
		WHERE c.id=i.productId and i.colorId=a.colorId and i.metricsId=a.metricsId
		group by c.code,d.codeName,e.codeName,c.location,f.id,f.packStyleName,g.id,g.deliverCompanyName,b.id,c.name,i.outCount,a.colorId,a.metricsId,a.productId

	commit tran
