-- =============================================
-- 原样新增
-- =============================================
CREATE PROCEDURE [dbo].[p_addOriginal] 
	-- Add the parameters for the stored procedure here
	@id int,
	@sourceId int,
	@typeId int,
	@picId int,
	@bzId int,
	@fisionerId int,
	@price varchar(200)
AS
declare @id_media int
BEGIN

	SET IDENTITY_INSERT ERP..tb_original ON 
	insert into ERP..tb_original (id,price,sourceId,status,typeId,picId,bzId,fisionerId)
	  values(@id,@price,@sourceId,'-1',@typeId,@picId,@bzId,@fisionerId)
	SET IDENTITY_INSERT ERP..tb_original OFF
END
