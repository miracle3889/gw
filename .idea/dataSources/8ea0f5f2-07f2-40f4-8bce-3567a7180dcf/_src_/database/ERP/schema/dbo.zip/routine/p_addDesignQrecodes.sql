CREATE PROCEDURE [dbo].[p_addDesignQrecodes]
	 @count int --条数
   AS
   BEGIN
		declare @basecount int --初始条数
			set @basecount=0;
		declare @i int 
			set @i=0
		declare @id int --二维码ID
		declare @wearMediaId int --试穿多媒体id
		declare @checkMediaId int --检验单id
		declare @designMediaId int --设计稿id
		declare @designQrecodes varchar(500) --二维码ID集合
			set @designQrecodes=''
		if(@count>0)
			begin
				set @basecount=@count
				while @i<@basecount
					begin
						insert into ERP..tb_multimedia_pid(type,count)values(3,0)
						set @wearMediaId=SCOPE_IDENTITY()
						print @wearMediaId
						insert into ERP..tb_multimedia_pid(type,count)values(1,0)
						set @checkMediaId=SCOPE_IDENTITY()
						print @checkMediaId
						insert into ERP..tb_multimedia_pid(type,count)values(1,0)
						set @designMediaId=SCOPE_IDENTITY()
						print @designMediaId
						insert into ERP..tb_design_qrcode (wearMediaId,checkMediaId,designMediaId,url) values (@wearMediaId,@checkMediaId,@designMediaId,'http://www.liblin.com.cn/layercake/fabriMsg/yangyiQrcodeToCodeFabric')
						set @id=SCOPE_IDENTITY()
						print @id
						if(@designQrecodes='')
							begin
								set @designQrecodes=cast(@id as varchar(20))
							end
						else
							begin
								set @designQrecodes=@designQrecodes+','+cast(@id as varchar(20))
							end
						set @i+=1
					end
			end
		select @designQrecodes
    END
