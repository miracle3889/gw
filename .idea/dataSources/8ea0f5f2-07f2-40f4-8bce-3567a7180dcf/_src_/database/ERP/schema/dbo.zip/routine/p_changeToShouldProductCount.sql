/*------------------修正商品------------------------------------*/
CREATE  PROCEDURE [dbo].[p_changeToShouldProductCount]
AS 
	DECLARE @productId INT --数量
	DECLARE @colorId INT --颜色
	DECLARE @metricsId INT --规格
	DECLARE @inCount INT --进货数量
	DECLARE @outCount INT --发货数量
	DECLARE @lendCount INT --借出数量
	DECLARE @lossCount INT --报失数量
	BEGIN TRAN

	DECLARE authors_cursor CURSOR FOR
	SELECT productId,colorId,metricsId
	FROM dbo.tb_productStock
	
	OPEN authors_cursor

	FETCH NEXT FROM authors_cursor 
	INTO @productId,@colorId,@metricsId
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SELECT @inCount=SUM(inCount) FROM dbo.tb_inStockList
		WHERE productId=@productId AND colorId=@colorId 
		AND metricsId=@metricsId
		
		SELECT @outCount=SUM(buyCount) FROM SuperMarket.dbo.tb_orderSaleProduct a
		INNER JOIN SuperMarket.dbo.tb_saleProduct b
		ON a.saleProductId=b.id
		WHERE a.colorId=@colorId AND a.metricsId=@metricsId AND b.productId=@productId
		
		SELECT @lendCount=SUM(lendCount-backCount-breakCount) FROM dbo.tb_lendProduct
		WHERE productId=@productId AND colorId=@colorId AND metricsId=@metricsId
			
		SELECT @lossCount=SUM(lossCount) FROM  dbo.tb_lossProduct
		WHERE productId=@productId AND colorId=@colorId AND metricsId=@metricsId
		
		IF(@lossCount IS NULL)BEGIN SET @lossCount=0 END	
		IF(@lendCount IS NULL)BEGIN SET @lendCount=0 END	
		IF(@outCount IS NULL)BEGIN SET @outCount=0 END		

		UPDATE dbo.tb_productStock SET productCount=@inCount-@outCount-@lossCount-@lendCount

		WHERE productId=@productId AND colorId=@colorId AND metricsId=@metricsId
		FETCH NEXT FROM authors_cursor 
		INTO @productId,@colorId,@metricsId
	END
	CLOSE authors_cursor
	DEALLOCATE authors_cursor

	COMMIT TRAN
