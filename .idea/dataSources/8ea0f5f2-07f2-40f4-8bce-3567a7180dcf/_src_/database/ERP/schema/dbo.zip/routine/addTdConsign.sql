/*----------------新增退单快递单--------------------------------*/
CREATE PROCEDURE [dbo].[addTdConsign] @consignCode int, @userId int 
AS
	DECLARE @returnValue int
	set @returnValue=0
	select @returnValue=id from erp..tb_tdConsign where consignCode=@consignCode
	if(@returnValue=0)
	begin
		INSERT INTO erp..tb_tdConsign (consignCode, userId)
			VALUES (@consignCode, @userId )
		set @returnValue=SCOPE_IDENTITY()
	end

	SELECT @returnValue
