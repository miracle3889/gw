/*------------------------- 增加服装裁片 ---------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[p_addYiCaiPian] @yiFactoryId INT, @caiPianDate varchar(32), @caiPianCount INT, @remark varchar(500)
AS
	DECLARE @returnValue INT

	SET @returnValue=0
	
	DECLARE @caiPianSize INT
	select @caiPianSize=count(id) from tb_yiCaiPian where caiPianCode like CONVERT(varchar( 12) ,getdate(),12)+'%'	
	
	SET @caiPianSize=@caiPianSize+1	

	INSERT INTO tb_yiCaiPian (yiFactoryId, caiPianDate, caiPianCount, caiPianCode, remark) 
		VALUES (@yiFactoryId, @caiPianDate, @caiPianCount, CONVERT(varchar(12),getdate(),12)+convert(varchar(10),@caiPianSize), @remark)
	SET @returnValue=SCOPE_IDENTITY()


	SELECT @returnValue
