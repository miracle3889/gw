--库存操作记录
CREATE procedure [dbo].[p_addProductStockCountWithProductCode]  @productCode varchar(50),@opCount int,@opType int,@opManId int,@remark  varchar(200)
AS 
	declare  @productId int
	declare  @colorId int
	declare  @metricsId int
	select @productId=productId,@colorId=colorId,@metricsId=metricsId from erp..tb_productStock where productShelfCode=@productCode
	EXEC p_addProductStockCount  @productId ,@colorId ,@metricsId ,@opCount ,@opType ,@opManId ,@remark  
	--declare  @tCount int
	--select @tCount=sum(productCount) from erp..tb_shelfProductCount where productCode=@productCode

	--update erp..tb_productStock set productCount=@tCount where productShelfCode=@productCode
