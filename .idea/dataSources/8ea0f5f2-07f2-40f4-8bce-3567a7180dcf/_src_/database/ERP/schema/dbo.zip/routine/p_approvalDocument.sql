-- =============================================
-- Author:		<runbin>
-- Create date: <2015-09-24>
-- Description:	<各种票据审批>
-- =============================================
CREATE PROCEDURE [dbo].[p_approvalDocument]
	@documentId varchar(20),	--票据单号
	@documentType int,	--票据类型
	@userId int,	--用户id
	@currentProcess int,	--当前审批流程
	@approvalResult int,	--审批结果
	@mediaId int,	--多媒体id
	@exceptTime varchar(15),	--需求付款时间(付款审批时可以修改)
	@remark varchar(2000)	--审批拒绝备注
AS
BEGIN
	declare @temp int--临时变量，用来保存游标值
	begin tran
		declare @ret int	--返回值
		declare @amount int	--总流程数
		declare @approvalStatus int	--审批状态
		declare @groupId int	--审批级别
		declare @nror int
		set @nror =0
		set @ret=-1
		select @amount = amount from supplycenter..pro_approval_type where typeId = @documentType	--查找总流程数
		select @groupId=groupId from ERP..tb_user where id = @userId	--查询审批人组别
		if (@userId = 770) set @userId = 21		--审批人是洪达 换成冯敏
		print '1'
		if  not exists (select 1 from supplycenter..pro_approval where documentId=@documentId and approvalUserId = @userId )
		print '2'
		begin
			if @groupId!=@currentProcess
			set @ret=-1
		else
			begin
				if (@approvalResult = 1 )	--审批通过
					begin
						if @currentProcess< @amount	--不是最后一人审批进度加一
							begin
								set @currentProcess = @currentProcess+1
								set @approvalStatus = 1
							end
						else if @currentProcess=@amount	--最后一人审批且通过,流程结束
							set @approvalStatus = 3
					end
				else	--审批不通过
					begin
						set @approvalStatus = 2
					end
				insert into supplycenter..pro_approval	--插入审批记录表
					(documentId,documentType,approvalUserId,approvalTime,approvalResult,mediaRemark,configId)
					values(@documentId,@documentType,@userId,GETDATE(),@approvalResult,@mediaId,
							(select id from supplycenter..pro_approval_config where typeId = @documentType
								and groupId = (select groupId from ERP..tb_user where id = @userId)) 
					)
				set @ret= SCOPE_IDENTITY()
				set @nror=@nror+@@error
				if @ret>0
					begin
						if @documentType=1 --供应商
							begin
								update SuperMarket..pro_supliders 
									set approvalStatus = @approvalStatus,currentProcess = @currentProcess
								where id = @documentId
								set @nror=@nror+@@error
							end
						else if @documentType = 2	--采购
							begin
								update supplycenter..pro_purchase 
									set approvalStatus = @approvalStatus,currentProcess = @currentProcess
								where purchaseCode = @documentId
								
								update ERP..tb_product set lastprice = b.taxPrice ,lastPurchaseSupliderId = b.suppliderId
								from ERP..tb_product a,
										(select y.productId,x.taxPrice,case when x.type=2 then -1 else x.suppliderId end suppliderId
										 from supplyCenter..pro_purchase x 
										inner join SuperMarket..tb_saleProduct y on x.saleCode=y.id 
										where x.purchaseCode=@documentId ) b 
								where a.id= b.productId
								
								set @nror=@nror+@@error
							end
						else	--付款
							begin 
								if @exceptTime is not null
									begin
										update supplycenter..pro_payment 
											set approvalStatus = @approvalStatus,currentProcess = @currentProcess,
											exceptTime = cast(@exceptTime as datetime),approvalDoneTime = GETDATE(),
											remark=@remark
										where payBatchId = @documentId
										set @nror=@nror+@@error
										print 2
									end
								else
									begin
										update supplycenter..pro_payment 
											set approvalStatus = @approvalStatus,currentProcess = @currentProcess,approvalDoneTime = GETDATE(),
											remark=@remark
										where payBatchId = @documentId
										set @nror=@nror+@@error
										print 4
									end
									
								if @approvalStatus=3	--出纳审批通过
									begin 
										declare purchaseId_cursor CURSOR FOR	--采购单编号游标
											select a.purchaseId from supplycenter..pro_payment_child a  join supplycenter..pro_payment b
												on a.payBatchId = b.payBatchId where b.payBatchId = @documentId and b.approvalStatus=3
										
										open purchaseId_cursor
											FETCH NEXT FROM purchaseId_cursor INTO @temp	--更新已付款金额
											WHILE @@FETCH_STATUS = 0
												begin
													 update supplycenter..pro_purchase set paidMoney = 
														paidMoney+(select payAmount from supplycenter..pro_payment_child where purchaseId = @temp and payBatchId=@documentId )
													 where id = @temp
													FETCH NEXT FROM purchaseId_cursor INTO @temp
													set @nror=@nror+@@error	
												end
											
										CLOSE purchaseId_cursor--关闭游标
										DEALLOCATE purchaseId_cursor--释放游标
									end 
								
							end
					end
			end	
		end
		
	if @nror<>0
		begin
			set @ret=-1
            rollback tran
        end
    else
		commit tran
	select @ret as 'ret'
END
