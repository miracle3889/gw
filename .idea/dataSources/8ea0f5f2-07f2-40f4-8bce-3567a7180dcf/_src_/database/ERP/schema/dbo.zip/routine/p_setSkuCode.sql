/*------------------处理仓库入库信息<仓库对到货商品的处理意见>-------------------*/
CREATE   PROCEDURE [dbo].[p_setSkuCode] @productId int,@colorId int,@metricsId int 
AS	
	declare @productCode  varchar(50)
	
	--取SKU编号
	select @productCode=productShelfCode  from tb_productStock  
	 where productId=@productId and colorId=@colorId and metricsId=@metricsId

	--SKU编号不存在
	if(@productCode is null  or @productCode='') 
	begin
		exec p_getShelfProductCode @productId,@colorId,@metricsId,@productCode output
		update tb_productStock set productShelfCode =@productCode   where productId=@productId and colorId=@colorId and metricsId=@metricsId  and  (productShelfCode is null or productShelfCode='')
		if not exists (select 1 from erp..tb_productSkuCode where productId=@productId and colorId=@colorId and metricsId=@metricsId )
		begin
			insert into tb_productSkuCode(productShelfCode,productId,colorId,metricsId) values(@productCode,@productId,@colorId,@metricsId)
		end
	end
