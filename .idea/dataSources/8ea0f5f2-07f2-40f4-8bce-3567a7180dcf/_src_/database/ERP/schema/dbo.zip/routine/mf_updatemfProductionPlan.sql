/*  修改生产计划  */

CREATE PROCEDURE [dbo].[mf_updatemfProductionPlan] @id int, @productionCount int, @productionPurchaseDate varchar(32),@productionOverDate varchar(32), 
			@mfAddrId int, @remark varchar(320), @status int, @userId int, @purchaseStatus int, @newPlanId int, @newPlanNameAdd varchar(32), @newTypeId int, @newYear int, @newMonth int, @newBatch int,@cLevel int
AS

	DECLARE @returnValue INT
	SET @returnValue=0

	BEGIN tran
		--IF (@newPlanId=0)
		--BEGIN
		--	IF NOT EXISTS ( SELECT * FROM mf_newPlan WHERE planName=@newPlanNameAdd)
		--	BEGIN		
		--		insert into mf_newPlan (planName) values (@newPlanNameAdd)
		--			SET @newPlanId=SCOPE_IDENTITY()	
		--	END
		--	ELSE
		--	BEGIN
		--		SELECT @newPlanId=id FROM mf_newPlan WHERE planName=@newPlanNameAdd
		--	END
		--END

		IF (@newTypeId <> 0 and @newYear <> 0 and @newBatch <> 0)
		BEGIN
			UPDATE erp..mf_productionPlan SET productionCount = @productionCount , productionPurchaseDate=@productionPurchaseDate, 
			productionOverDate=@productionOverDate, remark=@remark, mfAddrId=@mfAddrId, status=@status, userId=@userId, purchaseStatus=@purchaseStatus, 
			newPlanId=@newPlanId, newTypeId=@newTypeId, newYear=@newYear, newMonth=@newMonth, newBatch=@newBatch, cLevel=@cLevel  
			WHERE id=@id
		END
		
		set @returnValue=1
	
	commit tran

	SELECT @returnValue
