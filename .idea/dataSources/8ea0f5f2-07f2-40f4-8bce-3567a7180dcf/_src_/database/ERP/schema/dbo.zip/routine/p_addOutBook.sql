CREATE PROCEDURE [dbo].[p_addOutBook] @outAmount int, @outDate varchar(32), @outName varchar(32), @outVersion int, 
	@bookNumber varchar(32), @bookPrice int, @outRemark varchar(512), @outType int
AS
	declare @returnValue int
	set @returnValue = 0

	declare @bAmount int
	set @bAmount = 0 
	declare @oAmount int
	set @oAmount = 0 

	select @bAmount=bookAmount from tb_books where id=@outVersion
	select @oAmount=sum(outAmount) from tb_outBook where outVersion=@outVersion
	if (@oAmount is null)
	begin
		set @oAmount=0
	end
	
	if ((@bAmount-cast(@oAmount as int))>=@outAmount)
	begin
		INSERT INTO tb_outBook (outAmount, outDate, outName, outVersion, bookNumber, bookPrice, outRemark, outType) values (@outAmount, @outDate, @outName, @outVersion, @bookNumber, @bookPrice, @outRemark, @outType)
		set @returnValue=scope_identity()
	end
	
	select @returnValue
