-- 修改采购单
CREATE PROCEDURE [dbo].[mf_updateMFpurchaseNew] @id int, @mfpCodeFabricProtityId INT, 
				@purchaseUnit int, @unitPrice int, @onSalePrice int, @price int, @arrivalDate varchar(32),
				@doManId int, @fabricCount int, @fabricCountList varchar(320), @fabricCountListId varchar(320), @userId int, @remark varchar(320)
AS

	DECLARE @returnValue INT	
	SET @returnValue=0
	
	begin tran

	IF (@id != 0)
	BEGIN

		UPDATE ERP..mf_purchaseNew SET mfpCodeFabricProtityId=@mfpCodeFabricProtityId, purchaseUnit=@purchaseUnit, 
				unitPrice=@unitPrice, onSalePrice=@onSalePrice, price=@price, arrivalDate=@arrivalDate, userId=@userId, remark=@remark
			WHERE id=@id

		if (@@error<>0)
		begin
			ROLLBACK tran
		end

		/*****如果增加采购单的面料采购匹数****/
		DECLARE @i INT
		SET @i=1
		while @i<=@fabricCount
		begin
			IF (SUBSTRING(@fabricCountListId, 0,CHARINDEX(',',@fabricCountListId))='0')
			BEGIN
				INSERT INTO ERP..mf_purchaseNewCount (doManId, purchaseNewId, purchaseCount)
				VALUES (@doManId, @id, SUBSTRING(@fabricCountList, 0,CHARINDEX(',',@fabricCountList)))
				if (@@error<>0)
				begin
					ROLLBACK tran
				end
			END
			ELSE
			BEGIN
				UPDATE ERP..mf_purchaseNewCount SET doManId=@doManId, purchaseNewId=@id, purchaseCount=SUBSTRING(@fabricCountList, 0,CHARINDEX(',',@fabricCountList))
					WHERE id=SUBSTRING(@fabricCountListId, 0,CHARINDEX(',',@fabricCountListId))
				if (@@error<>0)
				begin
					ROLLBACK tran
				end
			END
			SET @fabricCountListId= SUBSTRING(@fabricCountListId, CHARINDEX(',',@fabricCountListId)+1,len(@fabricCountListId))
			SET @fabricCountList= SUBSTRING(@fabricCountList, CHARINDEX(',',@fabricCountList)+1,len(@fabricCountList))
			SET @i=@i+1
		end
		
		exec mf_updateMFpurchaseNewCountSystem 0, @id
		SET @returnValue=1
	END


	commit tran

	SELECT @returnValue
