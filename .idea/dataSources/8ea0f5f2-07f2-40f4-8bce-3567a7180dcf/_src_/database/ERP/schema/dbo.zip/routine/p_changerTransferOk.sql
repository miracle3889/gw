CREATE    procedure [dbo].[p_changerTransferOk] @transferId int ,@domanId int
as
		declare @setTime dateTime
		set @setTime=GETDATE()
		if EXISTS (select 1 from tb_transFer where status=0 and  id=@transferId)
		begin
			---更新状态为已交接
			BEGIN TRAN 
				update tb_transFer set okTime=getdate(), status=1 where id=@transferId
				
				update tb_transFer set orderCount=b.orderCount from tb_transFer a
				,(select COUNT(*) as orderCount,@transferId  as transferId from tb_transferOrder where transferId=@transferId ) b 
				where a.id=b.transferId and a.id=@transferId
			commit tran
			--修改订单状态 	
			begin tran
				insert into  SuperMarket.dbo.tb_orderstatusHis(orderId,orderstatus,remark,doMan) 
				select orderId,2,'交接到物流',@domanId from tb_transferOrder where transferId=@transferId
			
				--设定状态
				update 	SuperMarket.dbo.tb_order set orderstatus=2,setTime=@setTime
				where id in(select orderId from tb_transferOrder where transferId=@transferId) 
				and orderstatus in(13,20)
			commit tran 
			if(@@ERROR<>0)
				update tb_transFer set okTime=getdate(), status=0 where id=@transferId  
			else
				begin 
					begin tran 
						update tb_orderDistribute set distributeManId=@domanId,isDistribute=1,distributeDate=@setTime 
						 where orderId in(select orderId from tb_transferOrder where transferId=@transferId)
						
						update tb_Distribute set transferCount=b.transferCount from tb_Distribute a,
						(
						select distributeId,sum(isDistribute) as transferCount 
						from   tb_orderDistribute 
						where distributeId in(
							select distributeId from tb_orderDistribute 
							where orderId in
								(
								select orderId from tb_transferOrder  where transferId=@transferId
								)
								)
							group by distributeId 
						) as b where a.id=b.distributeId
					commit tran 
					
					insert into tb_needSendTaobaoWl(tid,oid,orderId,otherOrder,userName)

					select taobaoTid,taobaoOId,a.orderId,otherOrder,userName  from tb_transferOrder  a
					inner join reportruhnn.dbo.tb_orderNoDelivered  b on a.orderId=b.orderId
					inner join supermarket..tb_taobaoOId  c on c.orderSaleId=b.orderSaleId 
					inner join erp..tb_user d on d.id=a.deliverManId
					 where transferId=@transferId
					 group by taobaoTid,taobaoOId,a.orderId,otherOrder,userName
					
					--缓存已发货订单商品信息
					insert into reportruhnn.dbo.tb_orderDelivered
					select b.orderId,b.orderSaleId,b.orderCode,b.saleProductId,b.productId,b.colorId,b.metricsId,b.buyCount
					,b.createTime,@setTime,b.isHuanhuo
					 from tb_transferOrder a
					inner join reportruhnn.dbo.tb_orderNoDelivered b on a.orderId=b.orderId and a.transferId=@transferId
					
					
					
					delete from reportruhnn.dbo.tb_orderNoDelivered 
					where orderId  in(select orderId  from tb_transferOrder where transferId=@transferId)
					
					--更新T
					update  ERP..tb_TShirt_order  set updateStatus=4 ,isChanged=0 ,expressNum= c.otherOrder
					,expressName=d.userName,shipTime=c.setTime 
					from ERP..tb_TShirt_order a,erp..tb_transferOrder b ,supermarket..tb_order c,erp..tb_user d 
					where a.orderCode=b.orderCode and b.orderCode=c.orderCode and transferId=@transferId and d.id=c.deliverManId
					and ISNULL(updateStatus,0)=0
					
				end
		end
