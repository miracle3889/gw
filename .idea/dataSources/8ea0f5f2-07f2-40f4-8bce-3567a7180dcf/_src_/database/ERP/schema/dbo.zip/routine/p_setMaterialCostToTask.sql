/*-----------------------------------将原料总成本(含税)塞入生产任务表totalMaterialCost--------------------------------------------------------*/
CREATE PROCEDURE [dbo].[p_setMaterialCostToTask]
AS
	
	BEGIN

		delete from supplyCenter..tb_taskTotalMaterialCost

		insert into  supplyCenter..tb_taskTotalMaterialCost (taskId,totalMaterialCost)
			select
				a.id taskId,
				isnull(sum(d.cost/100000000.0*(isnull(b.hasPicAmount,0)-isnull(e.commitAmount,0)))*1.17,0) totalMaterialCost 
			from 
				supplyCenter.production.tb_production_task a
			inner join 
				(
					select 
						x.id,x.produceTaskId,x.materialSkuId , y.amount hasPicAmount
					from 
						supplyCenter.materie.tb_material_pickupRecord x 
					LEFT JOIN
						(
							SELECT 
								pickupRecordId, 
								sum(amount)/100.0 amount 
							FROM 
								supplyCenter.materie.tb_material_exportRecord
							WHERE
								signUserId is not null
							GROUP BY pickupRecordId
						) y on x.id = y.pickupRecordId 
				)  b on a.id = b.produceTaskId
			inner join 
				designCenter.materials.tb_materials_sku c on b.materialSkuId=c.id
			left join 
				supplyCenter.materie.tb_material_remainingBack e on a.id = e.produceTaskId and b.materialSkuId = e.materialSkuId
			inner  join 
				finance.store.tb_materialsMonthCost d on c.materialsId = d.materials
			where 
				d.month = convert(varchar(7),dateadd(mm,+1,a.invoiceTime),120)+'-01' and a.status = 4 and  a.processContractInvoice=1 
				GROUP BY a.id
			union all 
			select
				a.id taskId,
				isnull(sum(d.cost/100000000.0*(isnull(b.hasPicAmount,0)-isnull(e.commitAmount,0)))*1.17,0) totalMaterialCost 
			from 
				supplyCenter.production.tb_production_task a
			inner join 
				(
					select 
						x.id,x.produceTaskId,x.materialSkuId , y.amount hasPicAmount
					from 
						supplyCenter.materie.tb_material_pickupRecord x 
					LEFT JOIN
						(
							SELECT 
								pickupRecordId, 
								sum(amount)/100.0 amount 
							FROM 
								supplyCenter.materie.tb_material_exportRecord
							WHERE
								signUserId is not null
							GROUP BY pickupRecordId
						) y on x.id = y.pickupRecordId 
				)  b on a.id = b.produceTaskId
			inner join 
				designCenter.materials.tb_materials_sku c on b.materialSkuId=c.id
			left join 
				supplyCenter.materie.tb_material_remainingBack e on a.id = e.produceTaskId and b.materialSkuId = e.materialSkuId
			inner  join 
				finance.store.tb_materialsMonthCost d on c.materialsId = d.materials
			where 
				d.month = convert(varchar(7),dateadd(mm,+1,a.completeTime),120)+'-01' and a.status = 4 and  a.processContractInvoice=0
				GROUP BY a.id
		
		update supplyCenter.production.tb_production_task 
		set totalMaterialCost=b.totalMaterialCost
		from supplyCenter.production.tb_production_task a 
		inner join supplyCenter..tb_taskTotalMaterialCost b on a.id = b.taskId
	END
