-- =============================================
-- 新增原样二维码
-- =============================================
create PROCEDURE [dbo].[p_initOriginalNew] 
	-- Add the parameters for the stored procedure here
	@initCount int
AS
declare @index int
declare @id_image int
declare @id_media int
declare @id_qrcode int
declare @id_original int
declare @designQrecodes varchar(500) --二维码ID集合
 set @designQrecodes=''
 set @index = 0;
 while @index<@initCount
BEGIN
	
	select @id_original=MAX(a.id) from ERP..tb_original a
	set @id_original=@id_original+@index+1
	
	insert into ERP..mf_suppliderCardCodeQrcode (type,url) 
	  values (1,'http://www.liblin.com.cn/layercake/original/originalNew/'+cast(@id_original as varchar(20))); 
	set @id_qrcode=SCOPE_IDENTITY()
	
	if(@designQrecodes='')
		begin
			set @designQrecodes=cast(@id_original as varchar(20))
		end
	else
		begin
			set @designQrecodes=@designQrecodes+','+cast(@id_original as varchar(20))
		end
	 set @index = @index+1
END
select @designQrecodes
