/*  增加生产导出  */

CREATE PROCEDURE [dbo].[mf_addMFproductionPlanDown] @remark varchar(320), @doManId int
AS

	DECLARE @returnValue INT
	SET @returnValue=0

	BEGIN tran
	
	IF(@doManId<>0)
	BEGIN
		INSERT INTO mf_productionPlanDown (remark, doManId) 
			values (@remark, @doManId)
			SET @returnValue=SCOPE_IDENTITY()		
	END
	
	commit tran

	SELECT @returnValue
