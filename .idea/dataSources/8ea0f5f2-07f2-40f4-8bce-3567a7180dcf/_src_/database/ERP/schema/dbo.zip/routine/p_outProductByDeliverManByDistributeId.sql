/****发货***/
CREATE procedure [dbo].[p_outProductByDeliverManByDistributeId] @deliverManId int,@doManId int, @distributeId int
as
	declare @code varchar(20)
	declare @insertId int
	set @insertId=0
	if EXISTS  (select 1  from Supermarket.dbo.tb_order 
		where orderStatus=20 and isDelete=0 and isUpdate=0 and deliverManId=@deliverManId)
	begin
	begin tran 
		
		exec  p_getOutStockCode @code output
		/*---出库记录----*/
		insert into tb_orderOut(outCode,doManId,deliverManId) values(@code,@doManId,@deliverManId)
		set @insertId=SCOPE_IDENTITY( )
		
		/*---出库订单-------*/
		insert into tb_orderOutOrder(outId,orderCode,orderId) 
		
		select @insertId,orderCode,id  from Supermarket.dbo.tb_order 
		where orderStatus=20 and isDelete=0 and isUpdate=0 and deliverManId=@deliverManId 
		and id in(select orderId from erp..tb_orderDistribute where distributeId=@distributeId )
		
		
		-----------------换货单
		update   Supermarket.dbo.tb_backOder set backStatusId=2 ,   deliverManId=@deliverManId  where code in(
		select backCode from Supermarket.dbo.tb_order 
		where orderStatus=20 and isDelete=0 and 
		isUpdate=0 and deliverManId=@deliverManId and isnull(backCode,'') <>'') and backStatusId=1
		and id in(select orderId from erp..tb_orderDistribute where distributeId=@distributeId )

		
		--update tb_orderDistribute set distributeManId=@doManId,isDistribute=1,distributeDate=getDAte()  
			--	 where orderId in(select orderId from tb_orderOutOrder  where outId=@insertId) 
			--	 and distributeId=@distributeId
		
		

		declare @transferCount int 
		
		--select  @transferCount=count(*) from tb_orderDistribute where distributeId=@distributeId and isDistribute=1
		
		--update tb_Distribute set transferCount=@transferCount where id=@distributeId 
	
		update tb_Distribute  set isPirnt=1,printTime=getDate(),printManId=doManId where id=@distributeId 
		
	
		declare @count int
		select @count=count(*) from tb_orderOutOrder where  outId=@insertId
		
		update 	tb_orderOut set orderCount=@count where id=@insertId

		UPDATE Supermarket.dbo.tb_order  SET orderStatus=13--,setTime=getDate() 
		WHERE id in(select orderId from tb_orderOutOrder  where outId=@insertId )

		insert into supermarket..tb_orderstatusHis(orderId,orderstatus,doMan,remark) 
		select id,13,@doManId,'快递面单打印完毕' from  Supermarket.dbo.tb_order  where id  in(select orderId from tb_orderOutOrder  where outId=@insertId ) 
		commit tran 
	
	end 
	select @insertId
