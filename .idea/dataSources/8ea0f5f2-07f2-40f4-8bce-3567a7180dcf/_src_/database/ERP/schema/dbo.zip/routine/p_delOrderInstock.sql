CREATE procedure [dbo].[p_delOrderInstock] @orderId int ,@instockId int
as 
declare @type int
SELECT @type=type from tb_orderInstockOrder where orderId=@orderId and instockId=@instockId
if(@type=1)
	BEGIN
		update tb_dealUpdateOrder set isIn=0 where orderId =@orderId
		update  tb_orderInstockProduct set productCount=a.productCount-b.productCount,inStockCount=a.inStockCount-b.inStockCount,injureCount=a.injureCount-b. injureCount 
		from tb_orderInstockProduct a,
		(
			select e.productShelfCode,sum(c.buyCount) as productCount,sum(c.buyCount-c.loseCount) as inStockCount,sum(c.loseCount) as injureCount
						 from  supermarket..tb_order a 
						inner join supermarket..tb_orderSaleProduct c on a.id=c.orderId
						inner join supermarket..tb_saleProduct d on d.id=c.saleProductId 
						inner join tb_productSkuCode e on e.productId=d.productId and e.colorId=c.colorId and c.metricsId=e.metricsId
						where a.id=@orderId  --and e.productShelfCode in(select productCode from tb_orderInstockProduct where instockId=@instockId )
						group by e.productShelfCode
		) as b where a.productCode=b.productShelfCode and a.instockId=@instockId
	END
if(@type=2)
	BEGIN
		insert into supermarket..tb_rejectOrder values(@orderId)
		update  tb_orderInstockProduct set productCount=a.productCount-b.productCount,inStockCount=a.inStockCount-b.inStockCount,injureCount=a.injureCount-b. injureCount 
						from tb_orderInstockProduct a,(
						select e.productShelfCode,sum(c.backCount) as productCount,sum(c.backCount-c.loseCount) as inStockCount,sum(c.loseCount) as injureCount
						 from  supermarket..tb_order a 
						inner join supermarket..tb_orderSaleProduct c on a.id=c.orderId
						inner join supermarket..tb_saleProduct d on d.id=c.saleProductId 
						inner join tb_productSkuCode e on e.productId=d.productId and e.colorId=c.colorId and c.metricsId=e.metricsId
						where a.id=@orderId -- and e.productShelfCode in(select productCode from tb_orderInstockProduct where instockId=@instockId )
						group by e.productShelfCode) as b where a.productCode=b.productShelfCode and a.instockId=@instockId
	END
if(@type=3)
	BEGIN
		update  tb_orderInstockProduct set productCount=a.productCount-b.productCount,inStockCount=a.inStockCount-b.inStockCount,injureCount=a.injureCount-b. injureCount 
					from tb_orderInstockProduct a,(
						select e.productShelfCode,sum(y.getCount) as productCount,sum(y.getCount-y.loseCount) as inStockCount,sum(y.loseCount) as injureCount
						 from  supermarket..tb_backOder a 
						inner join supermarket.dbo.tb_backProduct y on y.backId=a.id
						inner join tb_productSkuCode e on  e.colorId=y.colorId and e.metricsId=y.metricsId
						where a.id=@orderId  --and e.productShelfCode in(select productCode from tb_orderInstockProduct where instockId=@instockId )
						group by e.productShelfCode) as b where a.productCode=b.productShelfCode and a.instockId=@instockId
	END


delete from tb_orderInstockOrder where orderId=@orderId and instockId=@instockId
declare @count int
select @count=count(*)  from tb_orderInstockOrder where instockId=@instockId

update tb_orderInstock set orderCount=@count where id=@instockId
