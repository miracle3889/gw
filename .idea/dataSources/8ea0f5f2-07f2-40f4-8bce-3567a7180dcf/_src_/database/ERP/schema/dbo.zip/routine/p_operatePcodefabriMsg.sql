-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[p_operatePcodefabriMsg] 
	@id int,
	@type int,
	@userid int,
	@msg varchar(500)
AS
 declare @retu int
 set @retu = 0
BEGIN
	declare @username varchar(200)
	begin tran
		 if(@type=1) --删除
		   begin
			 update ERP..mf_pCodeFabricMsg set delman = @userid,delReason = @msg,delDate = GETDATE() where id=@id 
			 insert into erp..mf_pCodeFabricMsg_his 
					(id,pCode,doManId,addDate,sheJiShiId,banShiId,urlPath,picPath,
					remark,status,ruhnnbrandId,yangyiId,jstatus,addUserId,originalId,
					picId,gouxiangId,type,seasonId,originalTypeId,mainPatternId,designWrittenId,
					statusId,developMode,returnDate,takeTime,delreason,delman,deldate,purchaseUserId,
					gongyishiId,caigouId,exceptArriveTime,unFinishIsNeedAssist,finishIsNeedAssist,
					supliderId,canRedo,materialCost,settlementRatio,maquillageType) 
			 select id,pCode,doManId,addDate,sheJiShiId,banShiId,
				 urlPath,picPath,remark,status,ruhnnbrandId,yangyiId,
				 jstatus,addUserId,originalId,picId,gouxiangId,type,
				 seasonId,originalTypeId,mainPatternId,designWrittenId,
				 statusId,developMode,returnDate,takeTime,delreason,delman,
				 deldate,purchaseUserId,gongyishiId,caigouId,exceptArriveTime,
				 unFinishIsNeedAssist,finishIsNeedAssist,supliderId,canRedo,
				 materialCost,settlementRatio,maquillageType 
			 from ERP..mf_pCodeFabricMsg where id = @id
			 set @retu = @@ROWCOUNT
			 if(@retu=1)
			 begin
				select @username = name from ERP..tb_user where id=@userid
				delete from ERP..mf_pCodeFabricMsg where id=@id
				insert into ERP..tb_status_history(userId,date,bz,statusId,styleId) values(@userid,GETDATE(),@username+'中止此款,原因:'+@msg,-1,@id)
			 end
		   end
		else if @type=2 --取回
			begin
				SET IDENTITY_INSERT erp..mf_pCodeFabricMsg ON
				insert into erp..mf_pCodeFabricMsg(id,pCode,doManId,addDate,sheJiShiId,banShiId,urlPath,picPath,remark,status,ruhnnbrandId,yangyiId,jstatus,addUserId,originalId,picId,gouxiangId,type,seasonId,originalTypeId,mainPatternId,designWrittenId,statusId,developMode,returnDate,takeTime,delreason,delman,deldate,purchaseUserId,gongyishiId,caigouId,exceptArriveTime,unFinishIsNeedAssist,finishIsNeedAssist,supliderId,canRedo,materialCost,settlementRatio,maquillageType)
				 select id,pCode,doManId,addDate,sheJiShiId,banShiId,urlPath,picPath,remark,status,ruhnnbrandId,yangyiId,jstatus,addUserId,originalId,picId,gouxiangId,type,seasonId,originalTypeId,mainPatternId,designWrittenId,statusId,developMode,returnDate,takeTime,delreason,delman,deldate,purchaseUserId,gongyishiId,caigouId,exceptArriveTime,unFinishIsNeedAssist,finishIsNeedAssist,supliderId,canRedo,materialCost,settlementRatio,maquillageType from ERP..mf_pCodeFabricMsg_his where id = @id
				set @retu = @@ROWCOUNT
				SET IDENTITY_INSERT erp..mf_pCodeFabricMsg OFF
				 if(@retu=1)
				 begin
					select @username = name from ERP..tb_user where id=@userid
					delete from ERP..mf_pCodeFabricMsg_his where id=@id
					insert into ERP..tb_status_history(userId,date,bz,statusId,styleId) values(@userid,GETDATE(),@username+'激活此款',-2,@id)
				 end
			end
	commit tran
END
select @retu

