-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[p_changeOldFlData]
	
AS
BEGIN
	
	declare @maxMaterialsId int
	declare @materialsId int
	declare @newMaterialsId int
	declare @codingId int
	declare @sort_num int
	declare @oldCodingName varchar(20) --老辅料编号
	declare @newCodingName varchar(20)	--新辅料编号
	declare @newCodingId int
	declare @skuId int
	declare @groupId int
	
	
	set @maxMaterialsId = 100323
	
begin tran
	
	declare p_cursor CURSOR FOR	
		
		select id,materialsId,codingId,sort_num,groupId from (
			
			
			select 
				a.id, 
				materialsId,
				b.codingId,
				a.groupId,
				ROW_NUMBER() over(PARTITION by materialsId order by b.codingId asc) sort_num
			from designCenter.materials.tb_materials_sku a
			inner join designCenter.materials.tb_materials b on a.materialsId = b.id
			where groupId >0 and b.codingId is not null 

		) v where sort_num >1 
	
	open p_cursor
		FETCH NEXT FROM p_cursor INTO @skuId,@materialsId,@codingId,@sort_num,@groupId	
		WHILE @@FETCH_STATUS = 0
			begin
				set @maxMaterialsId = @maxMaterialsId+1
				--获取原来的编号
				select @oldCodingName = name from designCenter.auxiliary.tb_coding where id = @codingId
				if @sort_num<9
					set @newCodingName = @oldCodingName+'00'+cast(@sort_num as varchar)
				if @sort_num>9 and @sort_num<99
					set @newCodingName = @oldCodingName+'0'+cast(@sort_num as varchar)
				if @sort_num>99
					set @newCodingName = @oldCodingName+cast(@sort_num as varchar)
				print 'codingname:' +@newCodingName
				
				--按照序号补位编号成8位，并获取新增编号id，
				insert into designCenter.auxiliary.tb_coding(name, nameId,picId,typeId,desId,textureId,standardId,unitId,remark,isNew)
				select @newCodingName,nameId,picId,typeId,desId,textureId,standardId,unitId,remark,isNew 
				from designCenter.auxiliary.tb_coding where id = @codingId
				set @newCodingId = @@IDENTITY
				print 'newcodingid:'+ cast(@newCodingId as varchar)
				
				--新增编号供应商价格记录
				insert into designCenter.auxiliary.tb_coding_supplier(codingId,supplierId,price,isDefault,orderById)
				select @newCodingId,supplierId,price,isDefault,orderById from designCenter.auxiliary.tb_coding_supplier where codingId=@codingId
				
				insert into designCenter.materials.tb_materials(id,suppliderId,suppliderCode,suppliderType,materialsType,status,userId,addTime,codingId,codingName)
				select @maxMaterialsId,suppliderId,suppliderCode,suppliderType,materialsType,status,891,GETDATE(),@newCodingId,@newCodingName from designCenter.materials.tb_materials where id = @materialsId
			
				
				--更新sku色卡字段
				update designCenter.materials.tb_materials_sku set materialsId=@maxMaterialsId where id = @skuId
				
				update designCenter.auxiliary.tb_combination set codingId=@newCodingId where id = @groupId
				
				FETCH NEXT FROM p_cursor INTO @skuId,@materialsId,@codingId,@sort_num,@groupId
			end
	CLOSE p_cursor--关闭游标
	DEALLOCATE p_cursor--释放游标
commit tran
END
