-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[p_updateFawangInWareHouse]
@batchId varchar(50),
@userId int
as
declare 
	@id int,
	@childCOUNT int,
	@purchaseStorageId int ,
	@purchaseStorageChildId int ,
	@productCode varchar(50),
	@ruhnnChildId int,
	@inCount int
declare 
	@return int
	
set @return=1;
if exists (select	1  from SuperMarket..Tb_saleStorageBatch where batchId=@batchId and status=1)
begin
update SuperMarket..Tb_saleStorageBatch set status=2,userId=@userId where batchId=@batchId and status=1

--查询商品信息条数
select @childCOUNT=COUNT(a.id) from SuperMarket..Tb_saleStorageBatchChild a
	inner join SuperMarket..Tb_saleStorageBatch c on c.id=a.batchId
	where  c.batchId=@batchId

--添加主表,状态为1
insert into [tradecenter].[fw].[fw_purchaseStorage] (wareHouseCode,billId,actionType,billType,remark,pushFWStatus)
values ('22659',@batchId,'IN','th',@batchId,-1);

set @purchaseStorageId = @@IDENTITY;

declare @childSUM int
set @childSUM=0;
DECLARE  cs CURSOR FOR 
	
	--查询商品信息
	select a.amount,a.skuCode,a.id
	from SuperMarket..Tb_saleStorageBatchChild a  
	inner join SuperMarket..Tb_saleStorageBatch c on c.id=a.batchId
	where  c.batchId=@batchId

	--循环
	OPEN cs
	FETCH NEXT FROM cs
	INTO @inCount,@productCode,@ruhnnChildId
	WHILE @@fetch_status =0
	BEGIN		
		
		--插入子表信息
		insert into tradecenter.fw.fw_purchaseStorage_b (fwPurchaseId,barCode,quantity,ruhnnChildId)
		values (@purchaseStorageId,@productCode,@inCount,@ruhnnChildId);
		
		set @purchaseStorageChildId = @@IDENTITY;
		
		--判断是否插入成功
		if(@purchaseStorageChildId>0)
			begin
				--子表总数+1
				set @childSUM = @childSUM+1;
			end
			
		
		FETCH NEXT FROM cs
		INTO @inCount,@productCode,@ruhnnChildId 
	END
	
	CLOSE cs
DEALLOCATE cs

--子表总数=商品条数 则 插入完毕,主表状态变0
if(@childCOUNT=@childSUM)
	begin
		update [tradecenter].[fw].[fw_purchaseStorage] set pushFWStatus=0 where id=@purchaseStorageId
	end

end
select @return;
