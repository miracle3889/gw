CREATE procedure [dbo].[p_unLock]
as 
	declare @count int
	update tb_goodsShelf  set isLock=0 where isLock=1 and lockTime<=dateAdd(hour,-6,getDate())
	set @count=@@rowCount
	if(@count>0)
		exec supermarket..p_sendMsgByClass '13606818964' ,'由于部分货架锁定时间超过六小时已经被系统自动解锁',999,1
