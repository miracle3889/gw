create procedure [dbo].[p_addPlate] @domanId int
as
  declare @insertId int
  insert into tb_Plate(doManId) values(@domanId)
  set @insertId=scope_identity()
  select @insertId
