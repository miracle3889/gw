/*****************
	修改指定款号的 设计师和版师
*******/
CREATE PROCEDURE [dbo].[mf_updateMFpCodeShejiShi] @pCode varchar(32), @shejiShi varchar(32), @banShi varchar(32)
AS

	DECLARE @returnValue INT
	SET @returnValue=0
	
	IF NOT EXISTS ( select * from erp..mf_pCodeInfo where pCode=@pCode )
	begin
		insert into ERP..mf_pCodeInfo (pCode, shejiShi, banShi ) 
			VALUES (@pCode, @shejiShi, @banShi)
		SET @returnValue=1
	END
	ELSE
	BEGIN
		update erp..mf_pCodeInfo set shejiShi=@shejiShi, banShi=@banShi where  pCode=@pCode
		SET @returnValue=2
	END

	SELECT @returnValue
