/*----------------------修改采购单信息----------------------------*/
CREATE PROCEDURE [dbo].[p_updateBuyProductBatchNumber] @billType INT,@productId INT,@supplyId INT,
				 @buyPrice INT,@buyCount INT,@transportTypeId INT,
				 @remittancesPice INT,@invoicesType INT,
				 @invoicesPrice INT,@buyRemark VARCHAR(500),
				 @remittancesTime VARCHAR(50),@buyUserId INT,@id INT,
				@stockRemark VARCHAR(50),
				 @transportPrice INT,@expectedInTime VARCHAR(50),--预计到货时间
				@isBuyStock  INT, --运费
				@mfAddrsId INT,@batchNumber int
	AS
	
	if(@expectedInTime is null or @expectedInTime='') set @expectedInTime=dateAdd(day,3,getDate())
	UPDATE dbo.tb_buyProductList SET billType=@billType,productId=@productId,supplyId=@supplyId,
					buyPrice=@buyPrice,buyCount=@buyCount,transportTypeId=@transportTypeId,
					remittancesPice=@remittancesPice,
				     invoicesType=@invoicesType,invoicesPrice=@invoicesPrice,
					buyRemark=@buyRemark,remittancesTime=@remittancesTime,
					buyStatus=1,transportPrice=@transportPrice,expectedInTime=@expectedInTime,isBuyStock=@isBuyStock,mfAddrId=@mfAddrsId,batchNumber=@batchNumber
					 WHERE id=@id--buyUserId=@buyUserId,
	
	UPDATE erp..tb_product set fillTimeRemark=@expectedInTime,mfAddrId=@mfAddrsId where id=@productId
	
	IF(@stockRemark!='')
	BEGIN
		DECLARE @myReMark VARCHAR(500)
		DECLARE @UserName VARCHAR(50)
		SELECT @UserName=name FROM tb_user WHERE id=@buyUserId
		SET @myReMark=CONVERT(VARCHAR(20),getDate(),120)+'采购'+@UserName+':'+@stockRemark+'<br>'
		UPDATE tb_buyProductList SET stockRemark=stockRemark+@myReMark WHERE id=@id
	END
