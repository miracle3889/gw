CREATE procedure [dbo].[p_insertCardCodeImage]
 @mediaId varchar(200) ,
 @userId int ,
 @suppliderCardCodeId int
 
as
DECLARE @identity INT --最新ID
  begin
	
		insert into ERP..mf_suppliderCardCodeMedia(mediaId,suppliderCardCodeId,mediaUrl,type,qrCodeId,userId,addDate)
		values(@mediaId,@suppliderCardCodeId,'',0,0,@userId,GETDATE())
		set @identity=SCOPE_IDENTITY();
  end
select @identity;
