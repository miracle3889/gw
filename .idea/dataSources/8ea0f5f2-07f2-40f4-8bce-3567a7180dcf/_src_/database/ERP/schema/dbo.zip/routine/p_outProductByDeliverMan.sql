/****发货***/
CREATE procedure [dbo].[p_outProductByDeliverMan] @deliverManId int,@doManId int
as
	declare @code varchar(20)
	declare @insertId int
	set @insertId=0
	if EXISTS  (select 1  from Supermarket.dbo.tb_order 
		where orderStatus=13 and isDelete=0 and isUpdate=0 and deliverManId=@deliverManId)
	begin
	begin tran 
		
		exec  p_getOutStockCode @code output
		/*---出库记录----*/
		insert into tb_orderOut(outCode,doManId,deliverManId) values(@code,@doManId,@deliverManId)
		set @insertId=SCOPE_IDENTITY( )
		
		/*---出库订单-------*/
		insert into tb_orderOutOrder(outId,orderCode,orderId) 
		select @insertId,orderCode,id  from Supermarket.dbo.tb_order 
		where orderStatus=13 and isDelete=0 and isUpdate=0 and deliverManId=@deliverManId
		
		-----------------换货单
		update   Supermarket.dbo.tb_backOder set backStatusId=2 ,   deliverManId=@deliverManId  where code in(
		select backCode from Supermarket.dbo.tb_order 
		where orderStatus=13 and isDelete=0 and 
		isUpdate=0 and deliverManId=@deliverManId and isnull(backCode,'') <>'') and backStatusId=1
		

		
		/*----出库商品------*/
		--insert into tb_orderOutProduct(productId,colorId,metricsId,buyCount,outId)
		--select c.productId,b.colorId,b.metricsId,sum(b.buyCount),@insertId from Supermarket.dbo.tb_order a
		--inner join Supermarket.dbo.tb_orderSaleProduct b on a.id=b.orderId
		--inner join Supermarket.dbo.tb_saleProduct c on b.saleProductId=c.id
		--where a.id in(select orderId from tb_orderOutOrder  where outId=@insertId)
		--group by c.productId,b.colorId,b.metricsId
		
		/*----减库存------*/
		--update  dbo.tb_productStock  set productCount=productCount-b.buyCount from dbo.tb_productStock a,tb_orderOutProduct b 
		--where a.productId=b.productId and a.colorId=b.colorId and a.metricsId=b.metricsId and b.outId=@insertId
		
		declare @count int
		select @count=count(*) from tb_orderOutOrder where  outId=@insertId
		
		update 	tb_orderOut set orderCount=@count where id=@insertId

		UPDATE Supermarket.dbo.tb_order  SET orderStatus=2,setTime=getDate() 
		WHERE id in(select orderId from tb_orderOutOrder  where outId=@insertId )

		insert into supermarket..tb_orderstatusHis(orderId,orderstatus,doMan,remark) 
		select id,2,@doManId,'订单发货' from  Supermarket.dbo.tb_order  where id  in(select orderId from tb_orderOutOrder  where outId=@insertId ) 
		commit tran 
		---圣诞颂礼券
		/*insert into supermarket..tb_preMemberGift(memberId,orderCode,orderId,giftCount,giftPrice)
		select  memberId,orderCode,a.id,(productPrice-useGift)/30000,2000 from supermarket..tb_order a 
		inner join supermarket..tb_member b on a.memberId=b.id 
		inner join erp..tb_user c on a.deliverManId=c.id  where a.id in( 
		select orderId from tb_orderOutOrder  where outId=@insertId)  and (productPrice-useGift)>=30000  and  a.createTime>='2010-12-20'
		
		INSERT INTO c3.dbo.tb_smsMission(sourceType,mobileNum,content,sendTime)
		select  1,b.mobileNum,'感谢参加优邮圣诞新年庆活动，您所获赠的'+cast(((productPrice-useGift)/30000)*20 as varchar(10))+'元礼金券已充入您的账户中，在您签收确认无误后将自动激活！再此感谢您的支持！',getDate()  
		from supermarket..tb_order a 
		inner join supermarket..tb_member b on a.memberId=b.id 
		inner join erp..tb_user c on a.deliverManId=c.id  where a.id in(
		select orderId from tb_orderOutOrder  where outId=@insertId)  and (productPrice-useGift)>=30000 and  a.createTime>='2010-12-20' and  a.createTime<='2011-01-10'
		and  b.mobileNum like '1__________'*/


		
		
		
		--INSERT INTO c3.dbo.tb_smsMission(sourceType,mobileNum,content,sendTime)
		--select 0,b.mobileNum,'您的订单'+a.orderCode+'已于'+ convert(varchar(19) ,getDate(),120)+'发货,送货员:'+c.name+',电话'+c.mobileNum+',优邮网感谢您的惠顾,如有问题请致电400-6721-555,www.yoyo18.com',getdate() from supermarket..tb_order a 
		--inner join supermarket..tb_member b on a.memberId=b.id 
		--inner join erp..tb_user c on a.deliverManId=c.id
		--where b.mobileNum like '1__________' 
		--and c.id not in(select transportId from dbo.tb_transport)
		--and a.id in(
		--select orderId from tb_orderOutOrder  where outId=@insertId) and (c.name='沈辉' or c.name='郭红超' )

		/*



		INSERT INTO c3.dbo.tb_smsMission(sourceType,mobileNum,content,sendTime)
		select 0,b.mobileNum,'您的订单'+a.orderCode+'已于'+ convert(varchar(19) ,getDate(),120)+'使用'+c.name+'发货,电话'+c.mobileNum+',快递单号:'+a.otherOrder+',优邮网感谢您的惠顾,如有问题请致电400-6721-555,www.yoyo18.com' ,getdate() from supermarket..tb_order a 
		inner join supermarket..tb_member b on a.memberId=b.id 
		inner join erp..tb_user c on a.deliverManId=c.id
		where b.mobileNum like '1__________'  and otherOrder is not null 
		and c.id  in(select transportId from dbo.tb_transport)
		and a.id in(
		select orderId from tb_orderOutOrder  where outId=@insertId)


		
		INSERT INTO c3.dbo.tb_smsMission(sourceType,mobileNum,content,sendTime)
		select 0,b.mobileNum,'您的订单'+a.orderCode+'已于'+ convert(varchar(19) ,getDate(),120)+'使用'+c.name+'发货,电话'+c.mobileNum+',优邮网感谢您的惠顾,如有问题请致电400-6721-555,www.yoyo18.com' ,getdate()  from supermarket..tb_order a 
		inner join supermarket..tb_member b on a.memberId=b.id 
		inner join erp..tb_user c on a.deliverManId=c.id
		where b.mobileNum like '1__________'  and otherOrder is  null 
		and c.id  in(select transportId from dbo.tb_transport)
		and a.id in(
		select orderId from tb_orderOutOrder  where outId=@insertId)
	*/

		--delete from tb_tempOrderMember 
		--insert into tb_tempOrderMember( memberId,productPrice,mobileNum,receviceMan)
		---select memberId,productPrice,b.mobileNum,a.receviceMan  from  Supermarket.dbo.tb_order   a
		--inner join Supermarket..tb_member  b on a.memberId=b.id
		--where a.id  in(select orderId from tb_orderOutOrder  where outId=@insertId) and productPrice>=30000 and a.createTime<='2010-01-06'


		/*
		declare @content nvarchar(500)
		declare @memberId int
		declare @mobileNum varchar(50)
		declare @receviceMan varchar(50)
		declare @productPrice int
		declare @inCount int
		DECLARE authors_cursor CURSOR FOR
		select memberId,productPrice,mobileNum,receviceMan from  tb_tempOrderMember
		OPEN authors_cursor
		FETCH NEXT FROM authors_cursor 
		INTO @memberId,@productPrice,@mobileNum,@receviceMan
		WHILE @@FETCH_STATUS = 0
		BEGIN
		
			set @inCount=@productPrice/30000
			if(@inCount is null) set @inCount=0
			set @content='亲爱的'+@receviceMan+'，圣诞快乐！'+cast((@inCount*50) as varchar(10))+'元礼券已返入您账户中，请查收！'+convert(varchar(10),dateAdd(month,2,getDate()),120)+'号前使用有效！感谢您对优邮的支持!' 
			if(len(@mobileNum)=11 )
			begin
				exec Supermarket..p_sendMsg @mobileNum,@content
			end
			while(@inCount>=1)
			begin
				exec Supermarket..p_sendGiftCard20TwoMonth @memberId,78
				exec Supermarket..p_sendGiftCard20TwoMonth @memberId,78
				exec Supermarket..p_sendGiftCardTwoMonth @memberId,79
				set @inCount=@inCount-1
			end
			FETCH NEXT FROM authors_cursor 
			INTO @memberId,@productPrice,@mobileNum,@receviceMan
		END
			
		CLOSE authors_cursor
		DEALLOCATE authors_cursor
	
*/
	
	end 
	select @insertId
