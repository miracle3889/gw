--查询多张发票编号,以','分隔
CREATE function [dbo].[f_getInvoiceCodeOfPurchase](@purchaseId int)
RETURNS VARCHAR(500)
as 
begin
declare @invoiceCode varchar(500)
SET @invoiceCode = ''
    SELECT @invoiceCode = @invoiceCode+invoiceCode+' ' FROM
      SuperMarket..pro_invoice_next a where purchaseId = @purchaseId 
      and exists (select 1 from SuperMarket..pro_invoice_main where invoiceCode = a.invoiceCode and approvalStatus=1 )
	set @invoiceCode = stuff(@invoiceCode, 1, 0, '')
	
	RETURN @invoiceCode
 END
