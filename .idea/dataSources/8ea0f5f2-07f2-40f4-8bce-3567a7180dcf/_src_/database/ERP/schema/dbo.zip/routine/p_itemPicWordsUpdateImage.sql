/*********		替换图文编辑的图片		***********/
CREATE PROCEDURE [dbo].[p_itemPicWordsUpdateImage]
 @id	int,
 @userId	int,
 @weixinId	varchar(500)
AS

DECLARE @newId	INT  --返回图片id
set @newId=0
if exists (select	1  from ERP..tb_itemPicWords where id=@id)
BEGIN
	 begin tran 
	 insert into ERP..tb_image (mainPic,pid,updateTime,userId,weixinId) values (0,-1,GETDATE(),@userId,@weixinId)
	 set @newId=SCOPE_IDENTITY()
	 update ERP..tb_itemPicWords set imageId=@newId where id=@id
	 
	 
	 if @@ERROR<>0
		begin
		set @newId=0
	    rollback tran
	    end
	 commit tran
END
select @newId
