CREATE procedure [dbo].[p_getERP_StockCount] 
as 
	declare @kphCount int
	declare @phwwcCount int 
	declare @wjxCount int 
	declare @wsjCount int 
	declare @dclthCount int 
	declare @cghjCount int 

	
	select @kphCount=count(*) from supermarket..tb_order a
	inner join  erp..tb_canDistributeOrder b 
	on a.id=b.orderId and a.isdelete<>1 and a.orderstatus=1 
	and  isUpdate=0
	
	select @phwwcCount=count(*) from erp..tb_Distribute  where isTransfer=0
	
	select @wjxCount=count(*) from erp..tb_Distribute  where orderCount!=transferCount
	
	
	select @wsjCount=count(*) from erp..tb_InstockTransFer where productCount<> addShelfCount  and status=1
	
	select @dclthCount=count(*) from tb_orderInstock where status=1 and  deliverManId>0
	
	select @cghjCount=count(*) from tb_shelfProductCOunt where shelfCode='A0000' and productCount>0
	
	
	select @kphCount as 可配货,@phwwcCount 取货未完成,@wjxCount as 未交接,@wsjCount as 未上架,@dclthCount as 待处理退货
	,@cghjCount as 采购货架
