/*----------------添加定单--------*/
CREATE    PROCEDURE [dbo].[p_addGetClothSupplies]  
				     @doMan INT,
				     @getMan VARCHAR(50),
				     @getRemark VARCHAR(50),
				     @mfAddrId int,
				     @createTime varchar(50)
AS

	DECLARE @code VARCHAR(50)	
	BEGIN TRAN 
		EXEC p_getGetOrderCode 1,@code OUTPUT --得到订单号
		insert into tb_getClothSupplies(getMan,getRemark,doman,getCode,mfAddrId,createTime)
		values(@getMan,@getRemark,@doMan,@code,@mfAddrId,@createTime)
		select SCOPE_IDENTITY() 
	commit tran
