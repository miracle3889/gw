/************************交接完成**********/
CREATE     procedure [dbo].[p_changerInstockTransferOk] @transferId int ,@domanId int
as
	if exists(select 1 from tb_InstockTransFer(TABLOCKX)  where id=@transferId and status=0)
	BEGIN

		update tb_InstockTransFer set okTime=getdate(), status=1 where id=@transferId
		
		insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,productOldCount,dealManId,type)
		select 'A0000',a.productCode,sum(a.productCount),b.productCount,@domanId,-1 from tb_inStockTransferProduct a
		inner join  tb_shelfProductCount b on a.productCode=b.productCode and b.shelfCode='A0000'  where inStockTransferId=@transferId
		group by a.productCode,b.productCount
		
		update tb_shelfProductCount set productCount=a.productCount-b.productCount
		 from tb_shelfProductCount a,(select productCode,sum(productCount)  as productCount from tb_inStockTransferProduct 
		where inStockTransferId=@transferId group by productCode) b 
		where a.productCode=b.productCode and a.shelfCode='A0000'  --and b.inStockTransferId=@transferId

	END
