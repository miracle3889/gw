/*------------------------- 增加出货 ---------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[p_addYiFactoryProduct] @yiCaiPianId INT,@userId INT,@createTime VARCHAR(26),@sampling INT,@unqualified INT,@remark VARCHAR(500),@fCount INT
AS
	DECLARE @returnValue INT

	DECLARE @id INT
	DECLARE @yiFactoryId INT
	SET @id=0
	SET @yiFactoryId=0
	SELECT @id=id,@yiFactoryId=yiFactoryId FROM tb_yiCaiPian WHERE id=@yiCaiPianId

	SET @returnValue=0

		INSERT INTO tb_yiFactoryProduct (caiPianId, yiFactoryId, userId, fCount,createTime,sampling,unqualified,remark) 
		VALUES (@id,@yiFactoryId,@userId,@fCount,@createTime,@sampling,@unqualified,@remark)
		SET @returnValue=SCOPE_IDENTITY()
	
	IF (@returnValue<>0)
	BEGIN
		INSERT INTO tb_yiFactoryProductSize (yiFactoryProductId, colorId, metricsId)
		SELECT @returnValue,colorId, metricsId FROM tb_yiCaiPianSize WHERE yiCaiPianId=@yiCaiPianId
	END

	SELECT @returnValue
