CREATE procedure [dbo].[p_setTaobaoAndUs]
as 
/*delete from tb_needUpdateTaobao  
where numId not in(
 select num_iid from sys_info.dbo.items where approve_status='onsale')*/

insert into erp..tb_needUpdateTaobao(saleCode,numId,status,isOld)
 
select outer_id,num_iid,1,case when nick='爱runa' then 1 else 0 end from sys_info.dbo.items  where approve_status='onsale' and num_iid not in(
select numId from tb_needUpdateTaobao
)


update erp..tb_needUpdateTaobao set salePrice=cast(b.price as varchar(10)),title=b.title,mainPic=b.pic_url,
list_time=b.list_time,delist_time=b.list_time,num=b.num,price=cast(b.price as varchar(10)),lastTimeDis=getDate()
from erp..tb_needUpdateTaobao a,sys_info.dbo.items b where a.numId=b.num_iid
