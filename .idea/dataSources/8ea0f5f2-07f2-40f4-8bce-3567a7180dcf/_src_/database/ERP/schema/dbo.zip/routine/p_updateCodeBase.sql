create PROCEDURE [dbo].[p_updateCodeBase]
		@id int,
		@pid int,
        @name varchar(200),
        @bz varchar(200)
    AS
    BEGIN
       if @id <> 0
		begin
			update ERP..tb_code_base set name=@name,bz=@bz where id=@id		       
        end 
        ELSE 
            BEGIN
                insert into ERP..tb_code_base(name,pid,bz,isdelete)values(@name,@pid,@bz,0)
             END

    END
