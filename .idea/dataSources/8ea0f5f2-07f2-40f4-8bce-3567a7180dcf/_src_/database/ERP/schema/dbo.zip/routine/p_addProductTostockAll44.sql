CREATE   procedure [dbo].[p_addProductTostockAll44]  @transferId int
as
  declare @returnValue int
  set @returnValue=0
 if   EXISTS(select 1 from tb_InstockTransFer where  id=@transferId and status=0 )
 begin
			delete from tb_inStockTransferProduct where inStockTransferId=@transferId
			
			insert into tb_inStockTransferProduct(inStockTransferId,productCode,productCount)
			
			select @transferId,productCode,a.productCount from tb_shelfProductCount a
			inner join tb_productStock b on a.productCode=b.productShelfCode 
			left join supermarket..tb_saleProduct c on c.productId=b.productId  and c.saleTypeId=1
			  where  shelfCode='A0000' and a.productCount>0 -- c.saleTypeId=1 and c.capabilityId=44 and
				
			declare @count int
			select @count=count(*) from tb_inStockTransferProduct where inStockTransferId=@transferId
			update tb_InstockTransFer set productCount=@count where id=@transferId
			set @returnValue=1
		
   end
  select @returnValue
