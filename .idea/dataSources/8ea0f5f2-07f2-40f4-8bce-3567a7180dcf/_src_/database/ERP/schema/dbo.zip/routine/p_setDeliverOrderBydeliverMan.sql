/*-----------物流取货--------------------------------*/
CREATE  PROCEDURE [dbo].[p_setDeliverOrderBydeliverMan] @deliverManId INT,@startTime VARCHAR(50),
						@endTime VARCHAR(50)
AS
   declare @updateType INT
   if(@deliverManId=1)
   begin
	update SuperMarket.dbo.tb_order set isUpdate=-1 
	where  (isUpdate <> 1) AND (isDelete<> 1) AND orderStatus = 13 
	AND orderType = 1  AND deliverManId not  in( select transportId from tb_transport)
	AND  createTime>=@startTime AND createTime<=@endTime
	set @updateType=-1 --自己配送
   end 
  else
 begin
	select top 1 @updateType=type from   tb_transport where groupId=@deliverManId --宅急送配送
	update SuperMarket.dbo.tb_order set isUpdate=@updateType
	where  (isUpdate <>1) AND (isDelete <> 1) AND orderStatus = 13 
	AND orderType = 1 AND deliverManId in(select transportId from tb_transport where groupId=@deliverManId)
	AND  createTime>=@startTime AND createTime<=@endTime
	
 end
    select @updateType
