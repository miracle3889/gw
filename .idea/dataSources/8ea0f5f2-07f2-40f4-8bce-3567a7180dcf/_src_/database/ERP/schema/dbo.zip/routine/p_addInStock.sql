/*-------------------------------添加入库单---------------------------------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[p_addInStock] @inType INT,@inUserId INT,@doUserId INT,
					@remark VARCHAR(200)
AS
	DECLARE @returnValue INT
	DECLARE @code VARCHAR(50)
	EXEC dbo.p_getinStockCode @code OUTPUT
	SET @returnValue=0
	BEGIN TRAN
		INSERT INTO  dbo.tb_inStock(inCode,inType,inUserId,doUserId,remark) 
		VALUES(@code,@inType,@inUserId,@doUserId,@remark)
		SET @returnValue=SCOPE_IDENTITY( )
	COMMIT TRAN  
	SELECT @returnValue
