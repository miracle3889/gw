/****************************
归还商品
*****************/
CREATE procedure [dbo].[p_backLendProduct] @lendProductId int,@doManId int,@backCount int,@loseCount int,@lostCount int,@shelfCode varchar(50),@remark varchar(200)
as 
 begin tran 
  if exists( select 1 from  tb_goodsShelf where code=@shelfCode and code not in('X0000','Y0000'))
	begin
		---添加还回商品历史记录
		insert into tb_lendOrderProductBackHis(lendProductId,shelfCode,backCount,loseCount,lostCount,doManid,remark)
		values(@lendProductId,@shelfCode,@backCount,@loseCount,@lostCount,@doManId,@remark) 
		
		--更新单件商品还回总数
		update tb_lendOrderProduct set backCount=backCount+@backCount,loseCount=loseCount+@loseCount,lostCount=lostCount+@lostCount where id=@lendProductId 

		declare @lendId int
		declare @totalBackCount int 
		declare @totalCount int 

		select @lendId=lendId from tb_lendOrderProduct where id=@lendProductId  --借出单ID

		select @totalBackCount=sum(backCount+loseCount+lostCount) ,@totalCount=sum(productCount) from tb_lendOrderProduct where lendId=@lendId--总还回数
		
		
		if(@totalCount<=@totalBackCount)
			update tb_lendOrder set lendStatus=3,backCount=@totalBackCount where id=@lendId
		else
			update tb_lendOrder set lendStatus=2,backCount=@totalBackCount  where id=@lendId
		
		if(@backCount>0)
		begin
		
			if exists(select 1 from tb_shelfProductCount a inner join tb_lendOrderProduct b on a.productCode=b.productCode and  a.shelfCode=@shelfCode and b.id=@lendProductId  )
			begin
				insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,productOldCount,dealManId,type,opType,remark)		
				select @shelfCode,a.productCode,@backCount,b.productCount,@doManId,0,10,'借出还回' from tb_lendOrderProduct a
				inner join tb_shelfProductCount  b on  a.productCode=b.productCode  and b.shelfCode=@shelfCode
				where a.id=@lendProductId
				
				update tb_shelfProductCount set productCount=a.productCount+@backCount
				from tb_shelfProductCount a,tb_lendOrderProduct b 
				where a.productCode=b.productCode and a.shelfCode=@shelfCode  and   b.id=@lendProductId   
			end
			else
			begin
				insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,productOldCount,dealManId,type,opType,remark)		
				select @shelfCode,a.productCode,@backCount,0,@doManId,0,10,'借出还回' from tb_lendOrderProduct a
				inner join tb_productStock  b on  a.productCode=b.productShelfCode  
				where a.id=@lendProductId

				insert into tb_shelfProductCount(shelfCode,productCode,productCount) 
					select @shelfCode,b.productCode,@backCount from  tb_productStock a 
					inner join tb_lendOrderProduct b on a.productShelfCode=b.productCode and     b.id=@lendProductId 
			end
			
	
			
			
			insert into  dbo.tb_productStockOpHis(productId,colorId,metricsId,oldCount,newCount,doMan,opType,remark)			
			select a.productId,a.colorId,a.metricsId,a.productCount,a.productCount+@backCount,@doManId,11,'商品借出还回' from tb_productStock a
			inner join tb_lendOrderProduct b on a.productShelfCode=b.productCode  where  b.id=@lendProductId
	
			
			update  dbo.tb_productStock  set productCount=a.productCount+@backCount from dbo.tb_productStock a,
			tb_lendOrderProduct b 
			where a.productShelfCode=b.productCode    and  b.id=@lendProductId
		
		end
		if(@loseCount>0)
		begin
			--报损
			insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,productOldCount,dealManId,type,opType,remark)		
			select  'X0000',a.productCode,@loseCount,b.productCount,@doManId,0,10,'借出还回报损' from tb_lendOrderProduct a
			inner join tb_productStock b on  a.productCode=b.productShelfCode  
			where a.id=@lendProductId
			
			if exists(select 1 from tb_shelfProductCount a inner join tb_lendOrderProduct b on a.productCode=b.productCode and  a.shelfCode='X0000' and b.id=@lendProductId  )
			begin
				update tb_shelfProductCount set productCount=a.productCount+@loseCount
				from tb_shelfProductCount a,tb_lendOrderProduct b 
				where a.productCode=b.productCode and     b.id=@lendProductId   and  a.shelfCode='X0000'
			end
			else
			begin
				insert into tb_shelfProductCount(shelfCode,productCode,productCount) 
				select 'X0000',b.productCode,@loseCount from  tb_productStock a 
				inner join tb_lendOrderProduct b on a.productShelfCode=b.productCode and     b.id=@lendProductId 
			end
		
		end
		--报失
		if(@lostCount>0)
		begin
			insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,productOldCount,dealManId,type,opType,remark)		
			select  'Y0000',a.productCode,@lostCount,b.productCount,@doManId,0,10,'借出还回报失' from tb_lendOrderProduct a
			inner join tb_productStock b on  a.productCode=b.productShelfCode  
			where a.id=@lendProductId
			
			if exists(select 1 from tb_shelfProductCount a inner join tb_lendOrderProduct b on a.productCode=b.productCode and  a.shelfCode='Y0000'  and b.id=@lendProductId )
			begin
				update tb_shelfProductCount set productCount=a.productCount+@lostCount
				from tb_shelfProductCount a,tb_lendOrderProduct b 
				where a.productCode=b.productCode and     b.id=@lendProductId   and  a.shelfCode='Y0000'
			end
			else
			begin
				insert into tb_shelfProductCount(shelfCode,productCode,productCount) 
				select 'Y0000',a.productShelfCode,@lostCount from  tb_productStock a 
				inner join tb_lendOrderProduct b on a.productShelfCode=b.productCode and  
				b.id=@lendProductId 
			end

		end
	end
	commit tran 



sp_who2
