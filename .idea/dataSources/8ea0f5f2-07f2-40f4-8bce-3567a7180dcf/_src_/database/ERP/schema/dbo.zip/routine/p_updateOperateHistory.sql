CREATE PROCEDURE [dbo].[p_updateOperateHistory]
		@userId int,
		@originalId int,
		@status int
    AS
    BEGIN
		declare @lastUserId int
		declare @primaryId int
		declare @retStatus int
		select top 1 @lastUserId = userId  from  ERP..tb_operateHistory where originalId=@originalId order by date desc
		select @retStatus = status from ERP..tb_original where id = @originalId
		if NOT EXISTS(select userId from ERP..tb_operateHistory where originalId=@originalId )
			BEGIN
				insert into ERP..tb_operateHistory (date,userId,originalId,status)values(GETDATE(),@userId,@originalId,@status)
				begin tran 
					select top 1 @primaryId = id  from  ERP..tb_operateHistory order by date desc
					update  ERP..tb_original set historyId = @primaryId,status=@status where id=@originalId
				commit tran
			END
		if (@lastUserId <> @userId )
			BEGIN
				insert into ERP..tb_operateHistory (date,userId,originalId,status)values(GETDATE(),@userId,@originalId,@status)
				begin tran 
					select top 1 @primaryId = id  from  ERP..tb_operateHistory order by date desc
					update  ERP..tb_original set historyId = @primaryId,status=@status where id=@originalId
				commit tran
			END
		 if(@lastUserId = @userId and @status <> @retStatus)
			BEGIN
				insert into ERP..tb_operateHistory (date,userId,originalId,status)values(GETDATE(),@userId,@originalId,@status)
				begin tran 
					select top 1 @primaryId = id  from  ERP..tb_operateHistory order by date desc
                    update  ERP..tb_original set historyId = @primaryId,status=@status where id=@originalId

				commit tran
			END			
    END
