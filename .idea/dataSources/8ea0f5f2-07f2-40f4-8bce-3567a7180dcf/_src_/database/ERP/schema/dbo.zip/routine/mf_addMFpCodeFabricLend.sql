-- 增加 物料报失、报损
CREATE PROCEDURE [dbo].[mf_addMFpCodeFabricLend] @lendUserName varchar(32), @doManId int, @type int, @remark varchar(320) 
AS

	DECLARE @returnValue INT	
	SET @returnValue=0
	
	begin tran
	
	DECLARE @lendCount INT
	SET @lendCount = 0
	SELECT @lendCount=COUNT(*) FROM ERP..mf_pCodeFabricLend 
	DECLARE @lendCode VARCHAR(32)
	SET @lendCode='MFS'+right(str(CONVERT(VARCHAR(8),@lendCount+1) + 10000000 ),5)
		
	INSERT INTO ERP..mf_pCodeFabricLend (lendCode, lendUserName, doManId, type, remark ) 
	VALUES (@lendCode, @lendUserName, @doManId, @type, @remark )
	SET @returnValue=SCOPE_IDENTITY()
	

	commit tran

	SELECT @returnValue
