create   procedure  [dbo].[p_addUser] 
	@cardCode varchar(50),
	@name varchar(50),
	@sex int,
	@departId int,
	@post int,
	@status int,
	@pic varchar(50),
	@mobileNum varchar(50),
	@identityCard varchar(50),
	@MSN varchar(50),
	@QQ varchar(50),
	@educationId int,
	@addr varchar(200),
	@educationDesc varchar(500),
	@workexperience varchar(500),
	@isCanLoginIn int,
	@userName varchar(50),
	@psw varchar(50)
as
	declare @insertId int
	declare @count int
	if(@userName='')
	begin
		select @count=count(*) from tb_user where (cardCode=@cardCode)
	end
	else
	begin
		select @count=count(*) from tb_user where  (cardCode=@cardCode or userName=@userName)
	end
	if(@count>0)
		begin	
		set  @insertId=-1
		end
	else
		begin 
			insert into dbo.tb_user(cardCode,name,sex,departId,post,status,
					pic,
					mobileNum,
					identityCard,
					MSN,
					QQ,
					educationId,
					addr,
					educationDesc,
					workexperience,
					isCanLoginIn,
					userName,
					psw)
			values(@cardCode,@name,@sex,@departId,@post,@status,
					@pic,
					@mobileNum,
					@identityCard,
					@MSN,
					@QQ,
					@educationId,
					@addr,
					@educationDesc,
					@workexperience,
					@isCanLoginIn,
					@userName,
					dbo.md5(@psw))
			set  @insertId=SCOPE_IDENTITY( )
		end
	select @insertId
