/*  修改物料构成  */

CREATE PROCEDURE [dbo].[mf_updatemfpCodeFabricForm] @id int, @oneCount int, @mfUnitId int, @remark varchar(320)
AS

	DECLARE @returnValue INT
	SET @returnValue=0

	BEGIN tran
	
	IF(@id <>0)
	BEGIN
		UPDATE mf_pCodeFabricForm SET oneCount=@oneCount, mfUnitId=@mfUnitId, remark=@remark
			WHERE id=@id
			SET @returnValue=1
		
	END
	
	
	commit tran

	SELECT @returnValue
