/****************  制作样衣转试穿排期     ***************/
CREATE PROCEDURE [dbo].[p_updateDesignToOver]
	 @userId int,
	 @codeFabriMsg int
   AS
   BEGIN tran
		declare @patternId int --版式ID
		declare @designId int --样式ID
		declare @useryangyi int --样衣工
		declare @useryangyiname varchar(10) --样衣工名字
		declare @username varchar(10) --样衣工名字
		declare @number int    --版号
		declare @bz varchar(400) 
			--select @patternId=mainPatternId from ERP..mf_pCodeFabricMsg where id=@codeFabriMsg
			--select @designId=currentPattern from ERP..tb_pattern_making where id=@patternId
			--查找样衣工名字
			select @patternId=mainPatternId,@designId=currentPattern,@useryangyi=a.yangyiId,@number=b.number,@useryangyiname=c.name from ERP..mf_pCodeFabricMsg a 
			inner join ERP..tb_pattern_making b on a.mainPatternId=b.id 
			inner join erp..tb_user c on c.id= a.yangyiId
			where a.id=@codeFabriMsg
			
			select @username=name from ERP..tb_user where id=@userId
			
			--把款式状态从3变成4
			update ERP..mf_pCodeFabricMsg set statusId=4 where id=@codeFabriMsg and statusId=3
			if(@@ROWCOUNT>0)
			  begin
			   --变更样衣签收人
				update ERP..tb_design set userId=@userId where id = @designId
				--exec ERP..addCodeFabriMsgStatus_history @codeFabriMsg,4,@userId
				
				--更新样衣签收记录
				exec ERP..p_addDesignRecode @userId,@codeFabriMsg,1
				
				--新增款式状态记录
				--insert into ERP..tb_status_history(statusId,userId,styleId,bz) 
			    --values(3,@userId,@codeFabriMsg,'第'+CAST(@number as varchar(2))+'版样衣'+@useryangyiname+'完成')
			    set @bz = @useryangyiname+'交付样衣给'+@username
			    if(@number<>1)
			        set @bz = @bz+' /第'+CAST(@number as varchar(2))+'版'
			    --新增款式状态记录
				insert into ERP..tb_status_history(statusId,userId,styleId,bz) 
			    values(3,@userId,@codeFabriMsg,@bz)
			  end
	if @@ERROR<>0 
		 rollback tran 
   commit tran
