CREATE procedure [dbo].[p_UpdateOrderInstockProductCount] @id int,@inStockCount int,@loseCount int,@injureCount int,@shelfCode varchar(50)
	as 
		if EXISTS(select 1 from tb_goodsShelf  where code=@shelfCode )
		begin
			declare @productCount int
			select @productCount=productCount from tb_orderInstockProduct where id=@id
			if(@productCount=(@inStockCount+@loseCount+@injureCount))
			begin
				update tb_orderInstockProduct set inStockCount=@inStockCount,loseCount=@loseCount,injureCount=@injureCount,shelfCode=@shelfCode where id=@id
				select 1,'ok'
			end
			else
			begin
				select 0,'数量不一致'
			end
		end
		else
		begin
			select 0,'货架号不存在'
		end
