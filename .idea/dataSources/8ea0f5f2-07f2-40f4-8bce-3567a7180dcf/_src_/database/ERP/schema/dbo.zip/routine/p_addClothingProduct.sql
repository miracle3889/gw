--添加服装

CREATE PROCEDURE [dbo].[p_addClothingProduct] @name VARCHAR(50),@supplyName VARCHAR(200),
					        @code VARCHAR(50),@area VARCHAR(200),
					        @material VARCHAR(200),@measure VARCHAR(200),
					        @stockPrice INT,@yoyoPrice INT,
					        @marketPrice INT,@pic VARCHAR(50)
AS

	IF NOT  EXISTS(SELECT 1 FROM dbo.tb_clothingProduct WHERE [name]=@name)
	BEGIN
		INSERT INTO tb_clothingProduct (name,supplyName,code,area,material,measure,stockPrice,yoyoPrice,marketPrice,pic)
		VALUES(@name,@supplyName,@code,@area,@material,@measure,@stockPrice,@yoyoPrice,@marketPrice,@pic)
		DECLARE @addId INT
		SET @addId=SCOPE_IDENTITY( ) 
		--IF   EXISTS(SELECT 1 FROM dbo.tb_clothingProduct WHERE id=@addId AND LEN(ISNULL(supplyName,''))>0  				
		--			AND LEN(ISNULL(material,''))>0  AND LEN(ISNULL(measure,''))>0 
		--			AND LEN(ISNULL(pic,''))>0
		--		    )
		--BEGIN
		--	UPDATE tb_clothingProduct SET isComplete=1 ,completeTime=getDate() WHERE id=@addId
		--END
		INSERT INTO tb_productFiledDeal(productId,fieldId) select @addId,id from tb_productField
		SELECT  @addId AS returnId,'添加成功' as returnMsg
	END
	ELSE
	BEGIN
		SELECT 0 as returnId,'商品已存在'  as returnMsg
	END
