/*------------------------------------------------------------添加退货单------------------------------------------------------------------------------------*/
CREATE  PROCEDURE [dbo].[p_backOrderTotal]   @orderId int, @backTypeId int, @backPriceTypeId int,
					@backCauseTypeId int, @backCauseRemark varchar(200), @addr varchar(200), @deliverPrice int, @doman int
AS
	declare @returnId int
	declare @code varchar(50)
	/*----------------------------插入一条新的订单----------初始退货状态和支付状态设1--------退货价设0---------*/
	EXEC p_geBackOrderCode @code OUTPUT
	insert into tb_backOder(ordeId, code, backTypeId, BackPrice, backPriceTypeId, backCauseTypeId, backCauseRemak, backStatusId, payStatusId,addr,deliverPrice,doman)
	values(@orderId,@code,@backTypeId,0,@backPriceTypeId,@backCauseTypeId,@backCauseRemark,3,1,@addr,@deliverPrice,@doman)
	set @returnId=@@identity
	select @returnId
