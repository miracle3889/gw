--将多列查询结果合并成一列，','分割
CREATE function [dbo].[f_mergeColumn](@sid varchar(15))
RETURNS VARCHAR(500)
as 
begin
--declare @buyerNick varchar(500)
declare @sellerNick varchar(500)
--SET @buyerNick = ''
SET @sellerNick = ''
--    SELECT @buyerNick = @buyerNick + ',' + buyernick,
    SELECT @sellerNick = @sellerNick+sellerNick+':'+buyerNick+' ' FROM (
			select distinct c.sellerNick,c.buyerNick from supermarket..tb_taobaorefund a
					inner join supermarket..tb_taobaoPayOrderProduct b on a.oid=b.oId 
					inner join supermarket..tb_taobaoPayOrder c on c.tid=b.tId where a.sid = @sid) v
	set @sellerNick = stuff(@sellerNick, 1, 0, '')
	if(@sellerNick is null)
		begin
			 SELECT @sellerNick = taobaoNickName  FROM  SuperMarket..Tb_taobaoMember where memberId = 
			 (select top 1 memberId from SuperMarket..Tb_saleProductDeal where packageId = 
				(select id from SuperMarket..Tb_salePackageDeal where sid = @sid)
			 )
		end
--       RETURN stuff(@buyerNick, 1, 1, '')+'@'+stuff(@sellerNick, 1, 1, '')
	 RETURN @sellerNick
 END