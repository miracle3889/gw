CREATE  procedure [dbo].[p_mf_updateSupplierCardCode] 
@suppliderId int ,
@cardCodeClassOneId int,
@cardCodeClassTwoId int,
@cardCode varchar(50),
@name varchar(50),
@price varchar(50),
@componets varchar(50),
@width varchar(50),
@remark varchar(200),
@qrCodeId int,
@mainMedia varchar(200),
@id int 
as
     begin tran 
     update erp.dbo.mf_suppliderCardCode 
     set suppliderId=@suppliderId,cardCodeClassOneId=@cardCodeClassOneId,
     cardCodeClassTwoId=@cardCodeClassTwoId,cardCode=@cardCode,name=@name,
     price=@price,componets=@componets,width=@width,remark=@remark,mainMedia=@mainMedia
     where id=@id
    
	  
	  select 1
     commit tran
