CREATE PROCEDURE [dbo].[p_delayDesign]
	 @userId int,
	 @codeFabriMsg int
   AS
  
		declare @patternId int --版式ID
		declare @designId int --样式ID
			select @patternId=mainPatternId from ERP..mf_pCodeFabricMsg where id=@codeFabriMsg
			select @designId=currentPattern from ERP..tb_pattern_making where id=@patternId
		  begin tran
			update ERP..mf_pCodeFabricMsg set statusId=5 where id=@codeFabriMsg and statusid=4
			if(@@ROWCOUNT>0)
			begin
				update ERP..tb_design_qrcode set userId=@userId where id=(select qrcode from ERP..tb_design where id=@designId)
				exec ERP..addCodeFabriMsgStatus_history @codeFabriMsg,5,@userId
			end
          commit tran
