CREATE PROCEDURE [dbo].[p_returnBackA0000] @dealManId INT ,@productCode VARCHAR(50),@returnCount INT
AS
	return 
	/*
	DECLARE @productId INT
	DECLARE @colorId INT
	DECLARE @metricsId INT
	DECLARE @userId INT
	DECLARE @buyPrice INT
	DECLARE @buyCount INT
	
	
	
	SELECT @productId=productId,@colorId=colorId,@metricsId=metricsId FROM dbo.tb_productStock WHERE productShelfCode=@productCode


	
	SELECT @buyCount=productCount FROM dbo.tb_shelfProductCount WHERE shelfCode='A0000' AND productCode=@productCode
	
	SELECT top 1 @userId=buyUserId,@buyPrice=buyPrice  FROM dbo.tb_buyProductList a
	INNER JOIN dbo.tb_buyProductProtity b on a.id=b.buyProductId
	 where buystatus=4 and isdeleted<>1 and b.colorId=@colorId and b.metricsId=@metricsId order by a.inTime desc
	

	IF(@returnCount<=@buyCount)
	BEGIN	

		SET @returnCount=@returnCount*-1	
		exec p_addShelfStockBySystem 'A0000',@productCode,@returnCount,@dealManId,7,'采购从A0000退出商品'
		exec p_addProductStockCount  @productId,@colorId,@metricsId,@returnCount,1,@dealManId,'采购从A0000退出商品'
		SET @returnCount=@returnCount*-1
		SET @buyPrice=@buyPrice*@returnCount
		update tb_userAccount set account=account+@buyPrice  where userId=@userId
	END
*/
