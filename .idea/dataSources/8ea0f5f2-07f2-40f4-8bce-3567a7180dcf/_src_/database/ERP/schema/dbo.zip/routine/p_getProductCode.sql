/*-------------------------------取得商品的编号--------------------------------------------------*/
CREATE PROCEDURE [dbo].[p_getProductCode] @type INT,@code VARCHAR(20) OUTPUT
AS
	DECLARE @maxID INT --最大编号
	DECLARE @CategoryTwoCode VARCHAR(20) --编号
	SELECT @CategoryTwoCode=code FROM dbo.tb_categoryTwo WHERE id=@type
	SELECT @maxID=MAX(intCode) FROM tb_productCode WHERE type=@type --得到当前最大编号
	IF( @maxID IS NULL)--不存在
	BEGIN
		INSERT INTO tb_productCode(intCode,type) VALUES(1,@type)
		SET @code=@CategoryTwoCode+'000001'
	END
	ELSE
	BEGIN--存在
		DECLARE @maxIdChar VARCHAR(10)
		SET @maxIdChar=CAST((@maxID+1) AS VARCHAR(10))
		INSERT INTO tb_productCode(intCode,type) VALUES(@maxID+1,@type)
		WHILE LEN(@maxIdChar)<6
		BEGIN
			SET @maxIdChar='0'+@maxIdChar
		END
		SET @code=@CategoryTwoCode+@maxIdChar
	END
	SET @code=@code
