CREATE procedure [dbo].[p_delOrderInstockNew] @orderId int ,@instockId int
as 

declare @type int
SELECT @type=type from tb_orderInstockOrder where orderId=@orderId and instockId=@instockId
if(@type=1)
	BEGIN
		update tb_dealUpdateOrder set isIn=0 where orderId =@orderId
	END
if(@type=2)
	BEGIN
		insert into supermarket..tb_rejectOrder values(@orderId)
	END

delete from tb_orderInstockOrder where orderId=@orderId and instockId=@instockId
declare @count int
select @count=count(*)  from tb_orderInstockOrder where instockId=@instockId

update tb_orderInstock set orderCount=@count where id=@instockId
