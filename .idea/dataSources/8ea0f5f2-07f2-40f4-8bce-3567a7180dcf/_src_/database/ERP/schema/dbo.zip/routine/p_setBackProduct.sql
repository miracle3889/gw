/********************外借商品归还操作**********************/
CREATE PROCEDURE [dbo].[p_setBackProduct]  	@id int, @backCount int, @breakCount int

 AS
	declare @count int
	declare @productId int
	declare @colorId int
	declare @metricsId int
	select @productId=productId, @colorId=colorId, @metricsId=metricsId from tb_lendProduct where id=@id
	set xact_abort on 
	begin tran
		/****************更新外借商品表，添加归还记录***************************/
		update tb_lendProduct set backCount=backCount+@backCount,breakCount=breakCount+@breakCount
		where id = @id
	
		insert into tb_backProductHis(lendProductId, backCount, breakCount) values(@id, @backCount, @breakCount)

		/*****************更新对应库存**********************/
	if (@backCount!=0)
	begin
		update tb_productStock set productCount=productCount+@backCount
		where @productId=tb_productStock.productId and @colorId=tb_productStock.colorId 
			and @metricsId=tb_productStock.metricsId
	end

		/*****************更新（插入）报损**********************/
	if (@breakCount!=0)
	begin
		select @count=count(*) from tb_lossProduct where tb_lossProduct.ProductId=@productId 
			and tb_lossProduct.colorId=@colorId and tb_lossProduct.metricsId=@metricsId
		if (@count=0)
			begin
			insert into tb_lossProduct(productId, colorId, metricsId, lossCount)
			values (@productId, @colorId, @metricsId, @breakCount)
			end
		else
			begin
			update tb_lossProduct set lossCount=lossCount+@breakCount
			where tb_lossProduct.productId=@productId and tb_lossProduct.colorId=@colorId
				 and tb_lossProduct.metricsId=@metricsId
			end
	end
	commit tran
