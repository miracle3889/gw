/*----------------增加设计部需要的各店铺商品图片--------------------------------*/
CREATE PROCEDURE [dbo].[addShejibuPic] @eName varchar(64), @picPath varchar(320), @productName varchar(120), @price int, @saleCount int , @liulanCount int
				,@urlPath varchar(128)
AS
	DECLARE @returnValue int
	set @returnValue=0
	
	IF NOT EXISTS ( select * from erp..shejibuPic where  productName = @productName and eName=@eName)
	begin
		INSERT INTO shejibuPic (picPath, productName, price, eName, saleCount, liulanCount, urlPath) 
				VALUES (@picPath, @productName, @price, @eName , @saleCount, @liulanCount, @urlPath)
		set @returnValue=SCOPE_IDENTITY()
	end
	else
	begin
		set @returnValue=-1
	end
	SELECT @returnValue
