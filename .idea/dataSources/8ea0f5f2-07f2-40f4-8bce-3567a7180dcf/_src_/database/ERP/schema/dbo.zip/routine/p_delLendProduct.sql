/*---------------------删除借出商品---------------------------*/
CREATE PROCEDURE [dbo].[p_delLendProduct] @id INT
AS 
	DECLARE @returnValue INT
	DECLARE @productId INT
	DECLARE @colorId INT
	DECLARE @metricsId INT
	DECLARE @lendCount INT

	SET @returnValue=0
	SELECT @productId=productId,@colorId=colorId,@metricsId=metricsId,@lendCount=lendCount
	 FROM dbo.tb_lendProduct WHERE id=@id
	BEGIN TRAN
		UPDATE dbo.tb_productStock SET productCount=productCount+@lendCount WHERE productId=@productId
			AND colorId=@colorId AND  metricsId=@metricsId
		DELETE FROM dbo.tb_lendProduct WHERE id=@id
		SET @returnValue=1
	COMMIT TRAN
	SELECT @returnValue
