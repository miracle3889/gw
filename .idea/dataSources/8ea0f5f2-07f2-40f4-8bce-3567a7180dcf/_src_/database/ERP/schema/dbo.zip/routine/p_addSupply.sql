/*-----------------------------------添加供应商--------------------------------------------------------*/
CREATE PROCEDURE [dbo].[p_addSupply] @name VARCHAR(50),@contact VARCHAR(200)
				      ,@phone VARCHAR(50),@mobile VARCHAR(15)
				      ,@EMail VARCHAR(50),@webAddr VARCHAR(50)
				      ,@addr VARCHAR(500),@remark VARCHAR(500)
				      ,@isWeb INT,@account VARCHAR(50)
AS
	DECLARE @code VARCHAR(20)
	DECLARE @count INT
	DECLARE @returnValue INT
	SET @returnValue=0
	SELECT @count=COUNT(*) FROM dbo.tb_supply WHERE name=@name
	IF(@count!=0)
	BEGIN
		SET @returnValue=-1 --供应商已经
	END
	ELSE
	BEGIN
		BEGIN TRAN 
		EXEC p_getSupplyCode @code OUTPUT
		INSERT INTO  dbo.tb_supply(name,contact,phone,mobile,EMail,webAddr,addr,remark,code,isWeb,account)
		VALUES(@name,@contact,@phone,@mobile,@EMail,@webAddr,@addr,@remark,@code,@isWeb,@account)
		SET @returnValue=SCOPE_IDENTITY()
		COMMIT TRAN
	END
	SELECT @returnValue
