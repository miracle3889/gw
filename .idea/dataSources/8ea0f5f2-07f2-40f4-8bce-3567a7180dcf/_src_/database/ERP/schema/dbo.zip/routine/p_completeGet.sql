CREATE procedure [dbo].[p_completeGet] @getId int,@domanId int
as 
	begin tran 
	declare @count int
	
	select @count =sum(productCount) from tb_getClothSuppliesProduct where getId=@getId

	
	update tb_getClothSupplies set productCount=@count,isOk=1 where id=@getId




	insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,productOldCount,dealManId,type,opType)
	
	select a.shelfCode,a.productCode,sum(a.productCount)  ,b.productCount,@domanId,-1,11 from tb_getClothSuppliesProduct a
	inner join tb_shelfProductCount b on  a.productCode=b.productCode and a.shelfCode=b.shelfCode  
	 where getId=@getId group by a.shelfCode,a.productCode ,b.productCount
	
		
	update tb_shelfProductCount set productCount=a.productCount-b.productCount
	 from tb_shelfProductCount a,(select productCode,shelfCode,sum(productCount) as productCount from   tb_getClothSuppliesProduct 
			 where   getId=@getId group by  productCode,shelfCode) b 
		where a.productCode=b.productCode and a.shelfCode=b.shelfCode     --and b.inStockTransferId=@transferId


	insert into  dbo.tb_productStockOpHis(productId,colorId,metricsId,oldCount,newCount,doMan,opType,remark)
		
	select a.productId,a.colorId,a.metricsId,a.productCount,a.productCount-b.productCount,@domanId,12,'领取耗材' from tb_productStock a
	inner join (
select getId,productCode,sum(productCount) as productCount
 from erp..tb_getClothSuppliesProduct group by getId,productCode ) as  b on a.productShelfCode=b.productCode  where a.productCount-b.productCount>=0   and getId=@getId

		
	update  dbo.tb_productStock  set productCount=a.productCount-b.productCount from dbo.tb_productStock a,
	(select getId,productCode,sum(productCount) as productCount
 from erp..tb_getClothSuppliesProduct group by getId,productCode) as  b 
	where a.productShelfCode=b.productCode  and a.productCount-b.productCount>=0  and  getId=@getId


	
	commit tran
