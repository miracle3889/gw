-- 增加出库记录
CREATE PROCEDURE [dbo].[mf_addFabricNewOutStock] @productionPlanTaskId INT, @pCodeFabricShelfId INT, 
		@outCount INT, @doManId INT, @type INT, @remark varchar(640)  
AS

	DECLARE @isUpdate INT
	DECLARE @returnValue INT
	SET @returnValue=0

	begin tran
				
		if ( @pCodeFabricShelfId<>0 and @doManId<>0 and @outCount<>0)	
		begin
			INSERT INTO mf_productionPlanOutStock (productionPlanTaskId, pCodeFabricShelfId, outCount, doManId, type, remark)
				VALUES (@productionPlanTaskId, @pCodeFabricShelfId, @outCount, @doManId, @type, @remark)
			SET @returnValue=SCOPE_IDENTITY()
			if (@@error<>0)
			begin
				SET @returnValue = -1
				ROLLBACK tran
			end
		end
		else
		begin
			set @returnValue = -2
		end
		
		IF(@returnValue > 0)
		BEGIN
			DECLARE @pCodeFabricProtityId INT
			SET @pCodeFabricProtityId=0
			DECLARE @pCodeFabricFormId INT
			SET @pCodeFabricFormId=0
			DECLARE @productionPlanId INT
			SET @productionPlanId=0
			DECLARE @shelfCode varchar(32)
			
			SELECT @productionPlanId=mfProductionPlanId, @pCodeFabricFormId=mfpCodeFabricFormId FROM mf_productionPlanTask WHERE id=@productionPlanTaskId
			SELECT @pCodeFabricProtityId=pCodeFabricProtityId, @shelfCode=shelfCode FROM mf_pCodeFabricShelf WHERE id=@pCodeFabricShelfId
			
			-- 修改物料库存  
			SET @outCount= @outCount*-1
			exec mf_updateFabricNewStock @pCodeFabricProtityId ,@pCodeFabricFormId ,@productionPlanId , @outCount , @shelfCode , @doManId , @type 
			if (@isUpdate=0)
			begin
				SET @returnValue = -3
				ROLLBACK tran
			end
		END
	commit tran

	
	SELECT @returnValue
	return @returnValue
