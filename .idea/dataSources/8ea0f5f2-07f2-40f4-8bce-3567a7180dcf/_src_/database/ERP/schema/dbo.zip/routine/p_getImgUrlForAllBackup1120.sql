-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[p_getImgUrlForAll]
	@id int,
	@type int
AS
   declare @imgurl varchar(500)
   declare @originalId int
   declare @count_img int
BEGIN
	if @type=1  --原样
	 begin
		select top 1 * from ERP..tb_image where pid = (select picid from ERP..tb_original where id=@id) order by mainPic,id desc
	 end
	else if @type=2 --款式
	 begin
		select @originalId =originalId  from ERP..mf_pCodeFabricMsg where id=@id
		if @originalId=0 --无原样开款
		 begin
		   select @count_img = COUNT(1) from ERP..tb_image where pid=(select picid from ERP..mf_pCodeFabricMsg where id=@id)
		   if @count_img<>0 --无原样开款 有参考图
		    begin
				select top 1 * from ERP..tb_image where pid=(select picid from ERP..mf_pCodeFabricMsg where id=@id) order by mainPic,id desc
		    end
		   else  --无原样开款  无参考图
		    begin
				select top 1 * from ERP..tb_image d 
					inner join (
						select wearMediaId from ERP..tb_pattern_making a 
							inner join ERP..tb_design b on a.id = b.patternId 
							inner join ERP..tb_design_qrcode c on c.id = b.qrcode
						where styleId = @id
					) e on d.pid in (e.wearMediaId) order by  mainPic,id desc	
		    end
		 end
		else --有原样开款
		 begin
			select @count_img = COUNT(1) from ERP..tb_image d 
					inner join (
						select wearMediaId from ERP..tb_pattern_making a 
							inner join ERP..tb_design b on a.id = b.patternId 
							inner join ERP..tb_design_qrcode c on c.id = b.qrcode
						where styleId = @id
					) e on d.pid in (e.wearMediaId) 
			if @count_img <>0   --有原样开款  试穿最近的有图
			 begin
				select top 1 * from ERP..tb_image d 
					inner join (
						select wearMediaId from ERP..tb_pattern_making a 
							inner join ERP..tb_design b on a.id = b.patternId 
							inner join ERP..tb_design_qrcode c on c.id = b.qrcode
						where styleId = @id
					) e on d.pid in (e.wearMediaId) order by  mainPic,id desc	
			 end
			else   --有原样开款  试穿最近的没图  取原样图
			 begin
				select top 1 * from ERP..tb_image 
				    where pid = (select a.picId from ERP..tb_original a inner join ERP..mf_pCodeFabricMsg b on a.id = b.originalId and b.id=@id) 
				    order by mainPic,id desc
			 end
		 end
	 end
	 else if @type=3	--取tb_img 表一条记录
		begin
			select * from ERP..tb_image where id = @id
		end
	else if @type=5	--取tb_img 表第一条记录
		begin
			select top 1 * from ERP..tb_image where pid = @id
		end
	else if @type=4 --款式
	 begin
		select @originalId =originalId  from ERP..mf_pCodeFabricMsg_his where id=@id
		if @originalId=0 --无原样开款
		 begin
		   select @count_img = COUNT(1) from ERP..tb_image where pid=(select picid from ERP..mf_pCodeFabricMsg_his where id=@id)
		   if @count_img<>0 --无原样开款 有参考图
		    begin
				select top 1 * from ERP..tb_image where pid=(select picid from ERP..mf_pCodeFabricMsg_his where id=@id) order by mainPic,id desc
		    end
		   else  --无原样开款  无参考图
		    begin
				select top 1 * from ERP..tb_image d 
					inner join (
						select wearMediaId from ERP..tb_pattern_making a 
							inner join ERP..tb_design b on a.id = b.patternId 
							inner join ERP..tb_design_qrcode c on c.id = b.qrcode
						where styleId = @id
					) e on d.pid in (e.wearMediaId) order by  mainPic,id desc	
		    end
		 end
		else --有原样开款
		 begin
			select @count_img = COUNT(1) from ERP..tb_image d 
					inner join (
						select wearMediaId from ERP..tb_pattern_making a 
							inner join ERP..tb_design b on a.id = b.patternId 
							inner join ERP..tb_design_qrcode c on c.id = b.qrcode
						where styleId = @id
					) e on d.pid in (e.wearMediaId) 
			if @count_img <>0   --有原样开款  试穿最近的有图
			 begin
				select top 1 * from ERP..tb_image d 
					inner join (
						select wearMediaId from ERP..tb_pattern_making a 
							inner join ERP..tb_design b on a.id = b.patternId 
							inner join ERP..tb_design_qrcode c on c.id = b.qrcode
						where styleId = @id
					) e on d.pid in (e.wearMediaId) order by  mainPic,id desc	
			 end
			else   --有原样开款  试穿最近的没图  取原样图
			 begin
				select top 1 * from ERP..tb_image 
				    where pid = (select a.picId from ERP..tb_original a inner join ERP..mf_pCodeFabricMsg_his b on a.id = b.originalId and b.id=@id) 
				    order by mainPic,id desc
			 end
		 end
	 end
END
