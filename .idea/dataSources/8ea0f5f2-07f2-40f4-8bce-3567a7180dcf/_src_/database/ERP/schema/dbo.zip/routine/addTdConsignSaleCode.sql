/*----------------新增退单快递单 单独宝贝--------------------------------*/
CREATE PROCEDURE [dbo].[addTdConsignSaleCode] @tdConsignId int, @saleCode varchar(32) 
AS
	DECLARE @returnValue int
	set @returnValue=0
	
	INSERT INTO erp..tb_tdConsignSaleCode (tdConsignId, saleCode)
		VALUES (@tdConsignId, @saleCode)
	set @returnValue=SCOPE_IDENTITY()
	
	if(@returnValue>0)
	begin
		DECLARE @saleCount int
		set @saleCount=0
		select @saleCount=isnull(COUNT(*), 0) from erp..tb_tdConsignSaleCode where tdConsignId=@tdConsignId
		update erp..tb_tdConsign set saleCount=@saleCount where id=@tdConsignId
	end

	SELECT @returnValue
