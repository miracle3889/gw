CREATE procedure [dbo].[p_setPlateOk] @platId int,@doman int
as 

   if exists(select 1 from erp..tb_Plate where id=@platId and status=0)
	begin
		insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,productOldCount,dealManId,type,optype,remark)
		 select a.shelfCode,a.productCode,oldCount-newCount,b.productCount,@doman,-1,6,remark  from erp..tb_plateShelfProduct a
            	 INNER JOIN tb_shelfProductCount b  on a.productCode=b.productCode and a.shelfCode=b.shelfCode  
		 where platId=@platId  and oldCount>newCount

		
		 insert into tb_shelfProductOpHis(shelfCode,productCode,productCount,productOldCount,dealManId,type,optype,remark)		
         	 select a.shelfCode,a.productCode,oldCount-newCount,b.productCount,@doman,0,6,remark  from erp..tb_plateShelfProduct a
            	 INNER JOIN tb_shelfProductCount b  on a.productCode=b.productCode and a.shelfCode=b.shelfCode  
		 where platId=@platId and newCount>oldCount
		
		 update tb_shelfProductCount  set productCount=a.productCount-(b.oldCount-b.newCount)  from tb_shelfProductCount  a,erp..tb_plateShelfProduct b  
		 where a.shelfCode=b.shelfCode and a.productCode=b.productCode and b.platId=@platId  and oldCount<>newCount


		 
		insert into  dbo.tb_productStockOpHis(productId,colorId,metricsId,oldCount,newCount,doMan,opType)
		
		select a.productId,a.colorId,a.metricsId,a.productCount,a.productCount-b.productCount,@doman,9 from tb_productStock a
		inner join (
			select productCode,sum(oldCount-newCount) as productCount  from tb_plateShelfProduct where  platId=@platId  and oldCount<>newCount
			group  by productCode
		) b on a.productShelfCode=b.productCode  
		


		update  dbo.tb_productStock  set productCount=a.productCount-b.productCount from dbo.tb_productStock a, 
		(
			select productCode,sum(oldCount-newCount) as productCount from tb_plateShelfProduct where  platId=@platId  and oldCount<>newCount
			group  by productCode
		)
		 b 
		where a.productShelfCode=b.productCode and a.productCount-b.productCount>=0
		
		
		insert into supermarket..tb_updateTabaoProductCount(productCode,productCount,reMark) 
		select productCode,sum(oldCount-newCount) as productCount,'盘库' from tb_plateShelfProduct where  platId=@platId  and oldCount>newCount
			group  by productCode



		
		
		update erp..tb_Plate  set status=1 where id=@platId 
	end
