-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
create PROCEDURE [dbo].[updateShejishiBanshi]
	@shejishiId int,
	@banshiId int,
	@id int,
	@userid int
AS
   DECLARE @oldShejishiName varchar(200)
   DECLARE @oldBanshiName varchar(200)
   DECLARE @newShejishiName varchar(200)
   DECLARE @newBanshiName varchar(200)
   DECLARE @username varchar(200)
BEGIN
	select @oldBanShiName = c.name,@oldShejishiName = b.name from ERP..mf_pCodeFabricMsg a 
	   left join ERP..tb_user b on a.sheJiShiId = b.id 
	   left join ERP..tb_user c on a.banShiId = c.id
	   where a.id = @id
	   
	select @newBanShiName  = name from ERP..tb_user where id = @banshiId
	select @newShejishiName = name from ERP..tb_user where id = @shejishiId 
	select @username = name from ERP..tb_user where id = @userid 
	if(@shejishiId<>0) 
	   begin
		update ERP..mf_pCodeFabricMsg set sheJiShiId=@shejishiId where id=@id
		insert into ERP..tb_status_history(styleId,statusId,userId,date,bz) values(@id,0,@userid,GETDATE(),@username+'更改设计师'+@oldShejishiName+'为'+@newShejishiName)
	   end 
	else if @banshiId<>0
	   begin
	    update ERP..mf_pCodeFabricMsg set banshiId=@banshiId where id=@id
	    insert into ERP..tb_status_history(styleId,statusId,userId,date,bz) values(@id,0,@userid,GETDATE(),@username+'更改版师'+@oldBanshiName+'为'+@newBanshiName)
	   end
	select 1
END
