/*------------------------------修改入库单---------------------------------------------------------------------------------------*/
CREATE   PROCEDURE [dbo].[p_updateInStock] @inUserId INT,
					@remark VARCHAR(200),@id INT 
AS
	DECLARE @returnValue INT
	SET @returnValue=0
	BEGIN TRAN
		UPDATE   dbo.tb_inStock SET inUserId=@inUserId,remark=@remark,OkTime=getDate() WHERE id=@id
		SET @returnValue=1
	COMMIT TRAN  
	SELECT @returnValue
