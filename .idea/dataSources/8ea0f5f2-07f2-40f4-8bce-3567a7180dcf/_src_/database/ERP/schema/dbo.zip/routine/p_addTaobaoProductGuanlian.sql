--淘宝关联
CREATE procedure [dbo].[p_addTaobaoProductGuanlian] @saleCode varchar(50),@numId varchar(50),@status int
as 
  -- if not  exists(select 1 from erp..tb_needUpdateTaobao  where numId=@numId)
 --  begin
	 if   exists(select 1 from supermarket..tb_saleProduct   where saleCode=@saleCode)
	   begin
		 if  not  exists(select 1 from   erp..tb_needUpdateTaobao  where saleCode=@saleCode and numId=@numId)
		   begin
			 insert into erp..tb_needUpdateTaobao(saleCode,numId,status ) values(@saleCode,@numId,@status)
			 select 1
		  end
		else
		begin
			 select 1
		end
	   end 
	 else
	   begin
		 select -2
	   end
  -- end
  -- else
 --  begin
	-- select -1
 --  end
