--修改服装

CREATE  PROCEDURE [dbo].[p_updateClothingProduct]   @name VARCHAR(50),@supplyName VARCHAR(200),
					        @code VARCHAR(50),@area VARCHAR(200),
					        @material VARCHAR(200),@measure VARCHAR(200),
					        @stockPrice INT,@yoyoPrice INT,
					        @marketPrice INT,@pic VARCHAR(50),@isComplete INT,@id INT
AS

	IF NOT  EXISTS(SELECT 1 FROM dbo.tb_clothingProduct WHERE [name]=@name AND id<>@id)
	BEGIN
		IF(len(@pic)>0)
		BEGIN
			UPDATE  tb_clothingProduct SET  name=@name,supplyName=@supplyName,code=@code,area=@area,
		           material=@material,measure=@measure,stockPrice=@stockPrice,yoyoPrice=@yoyoPrice,marketPrice=@marketPrice,pic=@pic
			WHERE ID=@id
		END
		ELSE
		BEGIN
			UPDATE  tb_clothingProduct SET  name=@name,supplyName=@supplyName,code=@code,area=@area,
		           material=@material,measure=@measure,stockPrice=@stockPrice,yoyoPrice=@yoyoPrice,marketPrice=@marketPrice
			WHERE ID=@id
		END
		IF  @isComplete=1
		BEGIN
			UPDATE tb_clothingProduct SET isComplete=1 ,completeTime=getDate() WHERE id=@id
		END
		SELECT  1 AS returnId,'修改成功' as returnMsg
	END
	ELSE
	BEGIN
		SELECT 0 as returnId,'商品已存在'  as returnMsg
	END
