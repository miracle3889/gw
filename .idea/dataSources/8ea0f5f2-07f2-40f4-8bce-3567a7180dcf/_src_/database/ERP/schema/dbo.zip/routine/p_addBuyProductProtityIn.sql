/*------------------添加采购规格-----------------------------*/
	CREATE PROCEDURE [dbo].[p_addBuyProductProtityIn] @buyProductId INT,--采购商品id
						  @colorId INT,--颜色
							@metricsId INT,--规格
							@buyCount INT
	AS
		
		INSERT INTO tb_buyProductProtity(buyProductId,colorId,metricsId,buyCount,protityStockCount)
		select @buyProductId,@colorId,@metricsId,@buyCount,productCount from tb_productStock where colorId=@colorId and metricsId=@metricsId
