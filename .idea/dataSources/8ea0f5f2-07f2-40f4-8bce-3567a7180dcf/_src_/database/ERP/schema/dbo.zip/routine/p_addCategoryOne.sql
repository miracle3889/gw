/*------------------------添加一级类别------------------------------*/
CREATE PROCEDURE [dbo].[p_addCategoryOne] @name VARCHAR(50),@remark VARCHAR(200)
AS 
	DECLARE @returnValue INT
	SET @returnValue=0
	BEGIN TRAN 
		INSERT INTO dbo.tb_categoryOne(name,remark) VALUES(@name,@remark)
		SET @returnValue=SCOPE_IDENTITY( )
	COMMIT TRAN
	SELECT @returnValue
