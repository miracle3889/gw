--淘宝关联
CREATE procedure [dbo].[p_addTaobaoProductGuanlianNew] @saleCode varchar(50),@numId varchar(50),@status int,@isOld int
as 
  -- if not  exists(select 1 from erp..tb_needUpdateTaobao  where numId=@numId)
 --  begin
	 if   exists(select 1 from supermarket..tb_saleProduct   where saleCode=@saleCode)
	   begin
		 if  not  exists(select 1 from   erp..tb_needUpdateTaobao  where saleCode=@saleCode and numId=@numId)
		   begin
			 insert into erp..tb_needUpdateTaobao(saleCode,numId,status,isOld) values(@saleCode,@numId,@status,@isOld)
			 --新店沿用老店更新信息
			 if(@isOld=0)
			 begin
			    if exists(select 1 from erp..tb_needUpdateTaobao where saleCode=@saleCode  and isOld=1 )
			    begin
					declare @statusold int
					set @statusold=-1
					--提取老店信息
					select @statusold=[status] from erp..tb_needUpdateTaobao where saleCode=@saleCode  and isOld=1
					if(@statusold!=null and @statusold>=0)
					begin
					update erp..tb_needUpdateTaobao set [status]=@statusold where numId=@numId and saleCode=@saleCode  and isOld=0
					
					update  erp..tb_needUpdateTaobao set [status]=0 where saleCode=@saleCode    and isOld=1
					end
				end
			 end
			 select 1
		  end
		else
		begin
			 select 1
		end
	   end 
	 else
	   begin
		 select -2
	   end
  -- end
  -- else
 --  begin
	-- select -1
 --  end
