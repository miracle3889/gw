
  create   procedure p_generateTrade @luckyBagTradeId int
  as 
	select 1 from dbo.tb_luckyBagTrade
	