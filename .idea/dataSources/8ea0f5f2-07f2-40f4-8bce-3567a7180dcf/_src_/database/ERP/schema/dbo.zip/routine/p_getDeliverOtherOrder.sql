/*----------------------------已不用-----------------------------原为得到第三方物流发货定单-------------------------------*/
CREATE PROCEDURE [dbo].[p_getDeliverOtherOrder] @startTime VARCHAR(20),@endTime VARCHAR(20)
AS
	BEGIN TRAN 

	UPDATE Supermarket.dbo.tb_order SET isUpdate=0 WHERE  isUpdate=-2   --将原来计算的带发送定单置回

	UPDATE Supermarket.dbo.tb_order SET isUpdate=-2 
	WHERE id IN 
	(
		SELECT id 
		FROM Supermarket.dbo.v_deliverOtherOrder
		WHERE createTime>=@startTime AND createTime<=@endTime
	)
	
	SELECT a.id AS id,a.orderCode AS orderCode,a.receviceMan AS receviceMan,a.regionalId1 AS regionalId1,a.regionalId2 AS regionalId2,
	c.id AS outId,a.createTime AS createTime,(case a.payType WHEN 1 then 
(a.deliverPrice+a.productPrice-a.useAccount-a.useGift) else 0 END) AS totalPrice,
	a.receviceAddr1 AS receviceAddr1,a.receviceAddr2 AS receviceAddr2,
	a.receviceMan AS receviceMan,a.addrId AS addrId,b.orderStatus AS orderStatusName,
	a.isUpdate as isUpdate,a.isDelete as isDelete,a.reMark AS reMark
	FROM Supermarket.dbo.tb_order a 
	INNER JOIN Supermarket.dbo.tb_orderStatus b ON a.orderStatus=b.id
	INNER JOIN tb_outStock c ON c.adaptCode=a.orderCode	
	WHERE a.isUpdate=-2 
	ORDER BY regionalId2,regionalId1
	COMMIT TRAN
