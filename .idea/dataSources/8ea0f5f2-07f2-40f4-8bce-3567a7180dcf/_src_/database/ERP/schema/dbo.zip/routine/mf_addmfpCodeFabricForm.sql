/*  增加物料构成  */

CREATE PROCEDURE [dbo].[mf_addmfpCodeFabricForm] @pCodeFabricMsgId int, @formName varchar(32), @mfTypeId int, @oneCount int, @mfUnitId int, @remark varchar(320), @doManId int
AS

	DECLARE @returnValue INT
	SET @returnValue=0

	BEGIN tran
	
	IF(@pCodeFabricMsgId<>0 and (@formName is not null and @formName<>'') and @mfTypeId <>0)
	BEGIN
		INSERT INTO mf_pCodeFabricForm (pCodeFabricMsgId, formName, mfTypeId, oneCount, mfUnitId, remark, doManId) 
			values (@pCodeFabricMsgId, @formName, @mfTypeId, @oneCount, @mfUnitId, @remark, @doManId)
			SET @returnValue=SCOPE_IDENTITY()
					if (@@error<>0)
					begin
						set @returnValue=-1
					end
					else
					begin
						exec mf_setMFpCodeFabricFormCode @pCodeFabricMsgId
					end
		
	END
	
	
	commit tran

	SELECT @returnValue
