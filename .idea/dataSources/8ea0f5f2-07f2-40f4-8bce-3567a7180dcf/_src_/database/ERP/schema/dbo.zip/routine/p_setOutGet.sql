create procedure [dbo].[p_setOutGet] @outId int,@getManId int
as 
	update tb_outFromFactory set getManId=@getManId,getTime=getDate() where id=@outId
