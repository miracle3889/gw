CREATE    procedure [dbo].[p_DistributOrderUsePayTypeNew] @doManId int,@distributeCount int,@payType int,@userId int
as
	--exec supermarket..p_setCanOrdernew 0
	declare @insertId int
	declare @code varchar(50)
	declare @sql varchar(2000)
	declare @count int
	set @insertId=0
	if EXISTS  (select * from Supermarket.dbo.tb_order where orderstatus=1 and isDelete<>1 and 
	id in(select orderId from   tb_canDistributeOrder ))
	begin
	update tb_canDistributeOrder set type=1 where type=0
	exec p_getDistributOrder @code OUTPUT
	
	insert into tb_Distribute(pCode,doManId,brandId,userId) values(@code,@doManId,@payType,@userId)
	set @insertId=SCOPE_IDENTITY( ) --批号的id
	
	
	
	
	--获取信息并且设置标志利用update排他锁防止并发问题
	set @sql='update erp..tb_canDistributeOrder set distributeId='+CAST(@insertId as varchar(10))+' where  distributeId=0
	    and orderId in
	    (
			select top '+CAST(@distributeCount as varchar(10))+' orderId 
			from erp..tb_canDistributeOrder a inner join supermarket..tb_brandNick b on a.nickName=b.nickName
			  where b.brandId='+CAST(@payType as varchar(10))+' and expressId='+CAST(@userId as varchar(10))+' 
			order by colorMetrics  ,orderByClass  , orderId
		)'
		
		exec(@sql)
		if(@@ROWCOUNT>0) ---更新数量存在
		begin
			set @sql=''
			begin tran 		
		
			---缓存订单信息
			insert into tb_orderDistribute(distributeId,orderId,orderCode,payType,deliverType,
			deliverPrice,memberId,orderStatus,doMan,reMark,receviceMan,post,receviceAddr1,regionalId1,
			receviceAddr2,regionalId2,receviceMobile,addrId,useGift,useAccount,getScore,proCode,oldOrderCode,
			backCode,otherOrder,provinceId,cityId,productPrice,needGetPrice,transport,proxy)
						
			select  @insertId,a.id,a.orderCode,payType,deliverType,
			deliverPrice,memberId,orderStatus,doMan,reMark,receviceMan,post,receviceAddr1,regionalId1,
			receviceAddr2,regionalId2,receviceMobile,addrId,useGift,useAccount,getScore,proCode,oldOrderCode,
			backCode,otherOrder,provinceId,cityId,productPrice,needGetPrice,transport,proxy from  Supermarket.dbo.tb_order a  
			inner join tb_canDistributeOrder b on a.id=b.orderId  and distributeId=@insertId
			where orderstatus=1 and isDelete=0 and a.createTime>=dateadd(month,-3,getDate())  and isUpdate=0 and a.deliverManId=@userId
			order by b.colorMetrics  ,b.orderByClass  , a.id
			
			
			set @count=@@ROWCOUNT --记录成功条数
			
			/*---快照所有待配货订单商品信息*/
			insert into dbo.tb_orderSaleProductDistribute(distributeId,orderProductId,orderId,colorId,
			metricsId,saleProductCode,saleProductId,buyCount,groupPh)

			select @insertId,id,orderId,colorId,
			metricsId,saleProductCode,saleProductId,buyCount,groupPh from Supermarket.dbo.tb_orderSaleProduct where orderId in
		    (select orderId from tb_orderDistribute where distributeId=@insertId)
			
			--删除待配货
			delete from  erp..tb_canDistributeOrder where orderId  in(select orderId from tb_orderDistribute where distributeId=@insertId)
			
			delete from supermarket..tb_ordersaleOutOfStock where orderId in(select orderId from tb_orderDistribute where distributeId=@insertId)
			--更新订单状态
			update Supermarket.dbo.tb_order set orderstatus=20,isDelete=0 where id 
			in(select orderId from tb_orderDistribute where distributeId=@insertId)
			
			insert into supermarket..tb_orderstatusHis(orderId,orderstatus,doMan,remark) 
			select orderId,20,@doManId,'配货' from tb_orderDistribute 
			 where distributeId=@insertId
			
			update tb_Distribute set orderCount=@count where id=@insertId
			
			--设置未发货已经配货状态
			update reportruhnn.dbo.tb_orderNoDelivered  set status=1 where orderId in(
				select orderId from tb_orderDistribute where distributeId=@insertId
			)
			select orderId from tb_orderDistribute where distributeId=@insertId
			if(@@ERROR<>0)
			begin
				--如果发生错误 则回滚 并且将待配货记录返回
				rollback tran 
				update erp..tb_canDistributeOrder set distributeId=0 where distributeId=@insertId
				select @insertId
				return 
			end
			commit tran 
			exec p_addDistributeProductShelf  @insertId
		end
		select @insertId
	end
