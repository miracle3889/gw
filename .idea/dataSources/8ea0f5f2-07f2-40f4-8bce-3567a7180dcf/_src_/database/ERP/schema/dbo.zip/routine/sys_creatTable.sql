/*********	创建表	***********/
CREATE PROCEDURE [dbo].[sys_creatTable] @tableName varchar(4000),@count int
AS
	DECLARE @StrSql VARCHAR(4000) 
	DECLARE @number INT
	SET @number=0
	DECLARE @returnValue INT 
BEGIN TRAN 
    SET @StrSql = 'USE supplyCenter CREATE TABLE  '+@tableName+'('
    while @number<@count
	begin
	 set @StrSql = @StrSql + 'co' + cast(@number as varchar) + ' varchar(100),'
	 set @number = @number+1
	end
	SET @StrSql = substring(@StrSql,1,len(@StrSql)-1) + ')'
    exec(@StrSql) 
    set @returnValue=1
COMMIT TRAN 




