CREATE procedure [dbo].[p_addHuanhuoOrderTaobao] @backId int
as 
	declare @orderId int
	declare @orderIdNew int
	declare @backCode varchar(20)
	declare @orderCodeNew varchar(20)

	select @backCode=code,@orderId=ordeId from dbo.tb_backOder where id=@backId 
	begin tran 
		EXEC p_geOrderCodeNew 1,@orderCodeNew OUTPUT --得到订单号
		INSERT INTO dbo.tb_order(orderCode,payType,deliverType,deliverPrice,memberId,orderStatus,
								   doMan,reMark,orderSource,magazineCodeS,receviceMan,post,
								receviceAddr1,receviceAddr2,receviceMobile,addrId,useAccount,
							getScore,regionalId1,regionalId2,provinceId ,cityId,useGift,magSource,magSourceRemark,buyCountOrder,freeType,backCode)

		select @orderCodeNew,payType,deliverType,deliverPrice,memberId,1,
								   doMan,reMark+'换货单：'+@backCode,orderSource,magazineCodeS,receviceMan,post,
								receviceAddr1,receviceAddr2,receviceMobile,addrId,useAccount,
							getScore,regionalId1,regionalId2,provinceId ,cityId,0,magSource,magSourceRemark,buyCountOrder,freeType,@backCode
		from tb_order where id=@orderId
				
					
		SET @orderIdNew=SCOPE_IDENTITY() --得到刚刚插入的定单id 
		
		insert into tb_huanhuoOrder(orderId) values(@orderIdNew)
		
		select @orderIdNew
		
		
	commit tran
