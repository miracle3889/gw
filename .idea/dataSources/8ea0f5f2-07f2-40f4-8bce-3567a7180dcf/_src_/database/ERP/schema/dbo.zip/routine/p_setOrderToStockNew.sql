--添加订单入库
CREATE  procedure [dbo].[p_setOrderToStockNew] @orderCode varchar(50),@instockId int 
as
	declare @orderId int
	declare @type int
	set @orderId=0
	if not EXISTS(select 1 from tb_orderInstockOrder WITH(HOLDLOCK) where  orderCode=@orderCode  ) --是否已经处理过  and instockId=@instockId
	begin 
		select @orderId=id from Supermarket..tb_order where orderCode=@orderCode or otherOrder=@orderCode
		if(@orderId is not null and @orderId>0) --订单存在
		begin
			 if  EXISTS(select 1 from supermarket..tb_order where  id=@orderId and isDelete=1  and createTime>=DATEADD(MONTH,-2,GETDATE()) ) --删除修改订单 --  and isIn=0
				set @type=1
			--if  EXISTS(select 1 from supermarket.dbo.tb_order where  id=@orderId  and orderstatus in(11,17,18))--拒收订单
			--	set @type=2
			
			if(@type>0)
			begin
				insert into tb_orderInstockOrder(instockId,orderCode,orderId,type) values(@instockId,@orderCode,@orderId,@type)
				update tb_orderInstock set orderCount=orderCount+1 where id=@instockId
				
				--if(@type=1)
				--	BEGIN						
				--		update tb_dealUpdateOrder set isIn=1 where orderId =@orderId
				--	END
				--if(@type=2)
				--	BEGIN
							
					--	delete from supermarket..tb_rejectOrder where orderId=@orderId
				--	END
				select @orderId,@type,'添加成功'
			end
			else
			begin
				select 0,0,'无效订单'
			end
			
		end
		else --检查是否是退货单
		begin
			set @orderId=0
			select @orderId=id from Supermarket.dbo.tb_backOder where code=@orderCode   
			if(@orderId is not null and @orderId>0) --订单存在
				begin
					set @type=3
					insert into tb_orderInstockOrder(instockId,orderCode,orderId,type) values(@instockId,@orderCode,@orderId,@type)
					update tb_orderInstock set orderCount=orderCount+1 where id=@instockId
					select @orderId,@type,'添加成功'
				end
			else --退单不存在
				begin
					select 0,0,'订单不存在'
				end
		end
	end
	else
	begin
		select 0,0,'订单已处理过'
	end
