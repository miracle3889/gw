/*-------------------------------取得二级类别的编号--------------------------------------------------*/
CREATE  PROCEDURE [dbo].[p_getCategoryTwoCode] @type INT,@code VARCHAR(20) OUTPUT
AS
	BEGIN TRAN 
	DECLARE @maxID INT --对应一级类别的最大编号
	DECLARE @CategoryOneCode VARCHAR(20) --一级类别编号
	SELECT @CategoryOneCode=code FROM tb_categoryOne WHERE id=@type --得到一级类别编号
	SELECT @maxID=MAX(code) FROM tb_codeTwoTmp WHERE type=@type --得到当前类别最大编号
	IF( @maxID IS NULL)--不存在
	BEGIN
		INSERT INTO tb_codeTwoTmp(code,type) VALUES(1,@type)
		SET @code=@CategoryOneCode+'001'
	END
	ELSE
	BEGIN--存在
		DECLARE @maxIdChar VARCHAR(10)
		SET @maxIdChar=CAST((@maxID+1) AS VARCHAR(10))
		INSERT INTO tb_codeTwoTmp(code,type) VALUES(@maxID+1,@type)
		WHILE LEN(@maxIdChar)<3
		BEGIN
			SET @maxIdChar='0'+@maxIdChar
		END
		SET @code=@CategoryOneCode+@maxIdChar
	END
	SET @code=@code
	COMMIT TRAN
