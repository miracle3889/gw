CREATE PROCEDURE [dbo].[tb_addTaobaoNickVisit] @nickName varchar(64), @userName varchar(64)
AS

	DECLARE @returnValue INT
	SET @returnValue=0
	set @userName=replace(@userName,'--客服工作台','') 

	IF NOT EXISTS ( select 1 from erp..tb_nickVisit where  nickName = @nickName)
	begin
		insert into ERP..tb_nickVisit (nickName, userName) VALUES (@nickName, @userName)
		SET @returnValue=SCOPE_IDENTITY()
	END

	--SELECT @returnValue
