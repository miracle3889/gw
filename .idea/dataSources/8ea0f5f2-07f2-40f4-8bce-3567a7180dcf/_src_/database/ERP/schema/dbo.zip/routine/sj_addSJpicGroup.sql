/*  增加组合搭配  */

CREATE PROCEDURE [dbo].[sj_addSJpicGroup] @picId INT, @groupPicId Int, @doManId INT  
AS

	DECLARE @addOk INT
	SET @addOk=0

	BEGIN tran	
		
	IF (@picId <> 0 and @groupPicId <> 0 and @doManId <> 0)
	BEGIN
		-- 正反双加 
		IF NOT EXISTS (select * from dbo.sj_pic_group WHERE picId=@picId and groupPicId=@groupPicId and isDelete=0)
		BEGIN
			INSERT INTO dbo.sj_pic_group (picId, groupPicId, doManId) VALUES (@picId, @groupPicId, @doManId)
			SET @addOk = SCOPE_IDENTITY()  
				IF (@@error <> 0)
				BEGIN
					SET @addOk = -1
				END
		END	
		
		IF NOT EXISTS (select * from dbo.sj_pic_group WHERE picId=@groupPicId and groupPicId=@picId and isDelete=0)
		BEGIN
			INSERT INTO dbo.sj_pic_group (picId, groupPicId, doManId) VALUES (@groupPicId, @picId, @doManId)
			SET @addOk = SCOPE_IDENTITY()  
				IF (@@error <> 0)
				BEGIN
					SET @addOk = -1
				END
		END	
	END
	ELSE
	BEGIN
		SET @addOk = -2
	END	
	
	commit tran

	SELECT @addOk 
	RETURN @addOk
