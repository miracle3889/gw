create procedure [dbo].[p_LockGoodsShelfOrder] @id int ,@userId int ,@lockType int
as 
	if(@lockType=0)
		update  tb_goodsShelf  set isLock=0,lockMan=0 where id=@id
	else
		update  tb_goodsShelf  set isLock=1,lockMan=@userId,lockTime=getDate() where id=@id
