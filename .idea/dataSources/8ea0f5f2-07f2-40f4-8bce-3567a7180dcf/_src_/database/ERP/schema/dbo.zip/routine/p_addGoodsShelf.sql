CREATE      procedure [dbo].[p_addGoodsShelf] @regionCode char(1),@row int,@cell int
as 
	declare @rowChar varchar(10)
	declare @cellChar varchar(10)

	
	if not EXISTS (select 1 from tb_goodsShelf where regionCode=@regionCode and row=@row and cell=@cell)
	begin
		set @rowChar=cast(@row as  varchar(10))
		set @cellChar=cast(@cell as  varchar(10))
		while(len(@rowChar)<2)
		begin
			set @rowChar='0'+@rowChar
		end
		while(len(@cellChar)<2)
		begin
			set @cellChar='0'+@cellChar
		end
		-- M区和E区的货架区分层， M区分5层 E区分4层
		if (@regionCode = 'M' or @regionCode = 'E')
		begin
			declare @i int
			declare @t int
			declare @ichar varchar(10)
			set @i=1
			if @regionCode = 'M'
				set @t = 5
			if @regionCode = 'E'
				set @t = 4

			while(@i<=@t)
			begin
				set @ichar=cast(@i as  varchar(10))
				while(len(@ichar)<2)
				begin
					set @ichar='0'+@ichar
				end
				insert into tb_goodsShelf(code,regionCode,row,cell) values(@regionCode+@rowChar+@cellChar+@ichar,@regionCode,@row,@cell)
				set @i=@i+1
			end
		end
		
		--  其他区货架不分层，只有行、列
		else
		begin
			insert into tb_goodsShelf(code,regionCode,row,cell) values(@regionCode+@rowChar+@cellChar,@regionCode,@row,@cell)
		end

		select SCOPE_IDENTITY( )
	end
	else
	begin
		select 0
	end
