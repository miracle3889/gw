-- =============================================
-- Author:		<runbin>
-- Create date: <2015-08-16>
-- Description:	<插入店铺圈发布信息>
-- =============================================
CREATE PROCEDURE [dbo].[p_insertMsg] 
	@msgContent varchar(1000),	--消息内容
	@timeDif int,	--预期完成时间和发布时间差
	@picId int	--图片id
AS
declare @msgId int
BEGIN
	insert into ERP..tb_msg(msgContent,releaseTime,exceptTime,picId) values(@msgContent,GETDATE(),GETDATE()+@timeDif,@picId);
	set @msgId = SCOPE_IDENTITY();
	select @msgId
END
