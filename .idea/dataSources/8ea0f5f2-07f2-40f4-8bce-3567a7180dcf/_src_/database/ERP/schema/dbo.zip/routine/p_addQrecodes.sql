CREATE PROCEDURE [dbo].[p_addQrecodes]
	 @count int, --条数
	 @type int --类型
   AS
   BEGIN
		declare @basecount int --初始条数
			set @basecount=0;
		declare @i int 
			set @i=0
		declare @id int --二维码ID
		declare @wearMediaId int --试穿多媒体id
		declare @checkMediaId int --检验单id
		declare @designMediaId int --设计稿id
		declare @designQrecodes varchar(500) --二维码ID集合
			set @designQrecodes=''
		declare @url varchar(200) --跳转地址
		if(@type=1)
			begin
				set @url='http://www.liblin.com.cn/layercake/original'
			end
		if(@type=2)
			begin
				set @url='http://www.liblin.com.cn/layercake/fabriMsg'
			end
		if(@type=3)
			begin
				set @url='http://www.layercake.com.cn/designCenter/materials/fabricRecode/showDetailFabricRecodeByQr'
		--		set @url='http://www.liblin.com.cn/layercake/fabricRecode/showDetailFabricRecodeByQr'
			end
		if(@count>0)
			begin
				set @basecount=@count
				while @i<@basecount
					begin
						insert into ERP..mf_suppliderCardCodeQrcode (type,url) values (@type,@url); 
						set @id=SCOPE_IDENTITY()
						if(@designQrecodes='')
							begin
								set @designQrecodes=cast(@id as varchar(20))
							end
						else
							begin
								set @designQrecodes=@designQrecodes+','+cast(@id as varchar(20))
							end
						set @i+=1
					end
			end
		select @designQrecodes
    END
