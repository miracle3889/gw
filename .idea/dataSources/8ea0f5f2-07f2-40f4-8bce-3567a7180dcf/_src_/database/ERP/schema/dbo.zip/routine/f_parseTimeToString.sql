CREATE function [dbo].[f_parseTimeToString]( 
	@releaseTime datetime,
	@exceptTime	date )
RETURNS VARCHAR(25)
as 
begin
	declare @exceptTimeStr varchar(20)
	declare @dayInt int 
	set @dayInt = DateDiff(day,@releaseTime,@exceptTime)
	
	if(@dayInt=0)
		set @exceptTimeStr='希望尽快完成'
	
	if(@dayInt>0 and @dayInt<=3)
		set @exceptTimeStr='希望三天内完成'
	
	if(@dayInt>3 and @dayInt<=7)
		set @exceptTimeStr='希望一周之内完成'
	
	if(@dayInt>7 and @dayInt<=15)
		set @exceptTimeStr='希望半个月之内完成'
	
	if(@dayInt>7)
		set @exceptTimeStr='希望一个月之内完成'
	
	return @exceptTimeStr
end
