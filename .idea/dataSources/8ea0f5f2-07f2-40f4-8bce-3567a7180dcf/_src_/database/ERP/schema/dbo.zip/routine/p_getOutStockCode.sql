/*---------------------------------------------得到出库编号-----------------------------------------*/
CREATE   PROCEDURE [dbo].[p_getOutStockCode] @code VARCHAR(20) OUTPUT
AS	
	DECLARE @maxInt INT
	SET @maxInt=0

	SELECT @maxInt=MAX(intcode) FROM tb_outStockCodeTemp WHERE CONVERT(VARCHAR(10),GETDATE(),120)=CONVERT(VARCHAR(10),addDate,120) 
	IF(@maxInt=0 OR @maxInt IS NULL)
	BEGIN
		INSERT INTO tb_outStockCodeTemp(intcode,addDate) VALUES (1,getDATE())
		EXEC p_getNowDate @code OUTPUT
		SET @code='C'+@code+'0001'
	END
	ELSE
	BEGIN
		DECLARE @codeTemp VARCHAR(10)
		SET @maxInt=@maxInt+1
		SET @codeTemp=CAST(@maxInt AS VARCHAR(10))
		WHILE(LEN(@codeTemp)<4)
		BEGIN
			SET @codeTemp='0'+@codeTemp
		END
		EXEC p_getNowDate @code OUTPUT
		SET @code='C'+@code+@codeTemp
		INSERT INTO tb_outStockCodeTemp(intcode,addDate) VALUES (@maxInt,getDATE())
	END
