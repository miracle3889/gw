/*  增加面辅料和服装款号的对应  */

CREATE PROCEDURE [dbo].[mf_addMFfabricPcode] @mfFabricId INT, @pCode VARCHAR(32), @userId int
AS	
	DECLARE @returnValue INT
	SET @returnValue=0	

	IF (@mfFabricId<>0 and @pCode is not null and @pCode!='')
	BEGIN
		set @pCode= dbo.F_Ctofchar(@pCode,0)
		set @pCode=ltrim(rtrim(@pCode))
		set @pCode=UPPER(@pCode)

		IF NOT EXISTS ( select * from erp..mf_pCodeFabric where  pCode = @pCode and fabricId=@mfFabricId)
		BEGIN
			INSERT INTO ERP..mf_pCodeFabric (pCode, fabricId, userId) VALUES (@pCode, @mfFabricId, @userId)
			SET @returnValue=SCOPE_IDENTITY()
		END
		
		exec mf_setMFfabricPcodeCode @pCode

		
	END

	SELECT @returnValue
