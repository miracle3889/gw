-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE  [dbo].[p_designOrder]
	@codeFabriMsg int,
	@userId int
AS
   declare @num int
   declare @retur int
   declare @userName varchar(100)
   set @retur = 0
	 begin try
	 
	 if exists (select 1 from erp..mf_pCodeFabricMsg a inner join ERP..tb_product b on a.pCode=b.Pcode
		where a.id = @codeFabriMsg and b.stockStatus=0)
		begin
				set @retur = 11
				RAISERROR ('Error raised in make cloth.', -- Message text.
								16, -- Severity.
								1 -- State.
								)
			end
	 
	     select @userName = name from ERP..tb_user where id = @userId
		 --检查外协项
		 --todo
		 
		 
		 --检查制衣要求 
		 select @num = count(id)  from designCenter.fabric.tb_makeClothesRequireRecord where isCompareCell is not null  and lineProperty is not null and colorProperty is not null and fabricId=@codeFabriMsg
		 
		 --select @num = count(id) from designCenter.fabric.tb_makeClothesRequireRecord where isCompareCell is not null  and lineProperty is not null and colorProperty is not null and fabricId=102322
		 
		 if(@num=0)
			begin
				set @retur = 2
				RAISERROR ('Error raised in make cloth.', -- Message text.
								16, -- Severity.
								1 -- State.
								)
			end
		 --检查样衣说明
		 select @num = COUNT(id) from designCenter.fabric.tb_templetClothesState where fabricId = @codeFabriMsg
		  if(@num=0)
			begin
				set @retur = 3
				RAISERROR ('Error raised in yangyi shuoming.', -- Message text.
								16, -- Severity.
								1 -- State.
								)
			end 
		 
		 --检查颜色
		 --select @num = COUNT(id)  from designCenter.fabric.tb_colorPlanAmountRecord where fabricId = @codeFabriMsg
		 
		 
		 --if(@num=0)
		--	begin
		--		set @retur = 4
		--		RAISERROR ('Error raised in colornum .', -- Message text.
		--						16, -- Severity.
		--						1 -- State.
		--						)
		--	end 
		 
		 --检查规格 
		-- select @num = COUNT(id) from designCenter.fabric.tb_fabricAmountRecord where fabricId = @codeFabriMsg
		-- if(@num=0)
		--	begin
		--		set @retur = 5
		--		RAISERROR ('Error raised in guige .', -- Message text.
		--						16, -- Severity.
		--						1 -- State.
		--						)
		--	end 
		 --计划数
		 select  @num = isnull(SUM(amount),0) from designCenter.fabric.tb_colorPlanAmountRecord where fabricId = @codeFabriMsg
		  if(@num=0)
			begin
				set @retur = 6
				RAISERROR ('Error raised in jihuashu .', -- Message text.
								16, -- Severity.
								1 -- State.
								)
			end 
		 --尺码比例
		 select @num = isnull(SUM(amount),0) from designCenter.fabric.tb_fabricAmountRecord where fabricId = @codeFabriMsg
		  if(@num=0)
			begin
				set @retur = 7
				RAISERROR ('Error raised in chimabile .', -- Message text.
								16, -- Severity.
								1 -- State.
								)
			end 
			
		 select @num = COUNT(id) from ERP..mf_pCodeFabricMsg where exceptArriveTime is not null and id = @codeFabriMsg
		 if(@num=0)
			begin
				set @retur = 10
				RAISERROR ('Error raised in chimabile .', -- Message text.
								16, -- Severity.
								1 -- State.
								)
			end 
		 
			
			update mf_pCodeFabricMsg set statusid=10 , purchaseUserId=@userId where id=@codeFabriMsg and statusId=9
			if(@@ROWCOUNT=0)
			  begin
				set @retur = 8
				RAISERROR ('Error raised in chimabile .', -- Message text.
								16, -- Severity.
								1 -- State.
								)
			--插入款式历史表
			insert into erp..tb_status_history(styleid,statusId,userid,date,bz) values(@codeFabriMsg,10,@userId,getDate(),'设计师'+@userName+'已确认下单')
			  end
     end try
	 begin catch  
				select @retur as ret
				
	 end catch 
	 if(@retur=0) select @retur as ret 
	
   
   
	
	 
	 
	  
	    
		
		
	   

