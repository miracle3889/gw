-- =============================================
-- Author:		<runbin>
-- Create date: <2015-8-4>
-- Description:	<回复信息插入>
-- =============================================
CREATE PROCEDURE [dbo].[p_insertMsgReply]
	@userId int,	--回复人id	
	@msgId int,	--信息id
	@replyContent varchar(1000),	--回复内容	
	@replyUserId int,	--被回复人id
	@picId int	--图片pid
AS
declare @infoId int	--回复id
declare @status int --信息状态 0-跟踪 1-不再跟踪 2-已完成
BEGIN
	begin tran
		--插入回复信息表
		insert into ERP..tb_msgInfo (userId,msgId,replyContent,time,replyUserId,picId)
			values(@userId,@msgId,@replyContent,GETDATE(),@replyUserId,@picId)
		set @infoId = SCOPE_IDENTITY();
		--插入成功并且正在跟踪
		if(@infoId<>0 and 
		exists(select 1 from  ERP..tb_msgUserInfo where msgId = @msgId and infoType = 0 and status<>1))
			begin
				--插入未查看信息表(默认所有相关人员未查看)
				insert into ERP..tb_msgUser_viewHis(infoId,userId,time) 
					select @infoId,userId, GETDATE() from (
							select userId from (
								--其他相关人员有回复此消息或有人@他
								select msgid,userid,infotype,status,ROW_NUMBER() 
										over(partition by msgid,userid order by infotype) as row_num
											 from ERP..tb_msgUserInfo
							) i where i.row_num=1 
									and msgId=@msgId and userId<>@userId and infoType<>0
									and exists (select 1 from ERP..tb_msgInfo where userId = i.userId or replyUserId = i.userId)
							union 
							--发布者
							select userId from ERP..tb_msgUserInfo where msgId = @msgId and infoType=0 and status = 0 and userId<>@userId
						) a
			end
	commit tran
	select @infoId
END
