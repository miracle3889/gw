-- 修改物料采购单数量
CREATE PROCEDURE [dbo].[mf_updateMFpurchaseNewCount] @id int, @updateArrivalCount int, @arrivalAddrsId int, @arrivalDate varchar(32), @userId int, @shelfCode varchar(32), @doManId int 
AS

	DECLARE @returnValue INT	
	SET @returnValue=0
	
	begin tran

	IF (@id != 0)
	BEGIN
		

		UPDATE ERP..mf_purchaseNewCount SET arrivalCount=arrivalCount+@updateArrivalCount, 
				arrivalAddrsId=@arrivalAddrsId, arrivalDate=@arrivalDate, userId=@userId, shelfCode=@shelfCode 
			WHERE id=@id

		if (@@error<>0)
		begin
			ROLLBACK tran
		end
		set @returnValue=1
		
		--设置 是否到货
		exec mf_updateMFpurchaseNewCountSystem @id, 0
		
		--修改物料库存
		DECLARE @isUpdate INT
		DECLARE @mfpCodeFabricProtityId INT
		DECLARE @pCodeFabricFormId INT
		DECLARE @mfProductionPlanId INT
		select @mfpCodeFabricProtityId=a.mfpCodeFabricProtityId, @pCodeFabricFormId=b.pCodeFabricFormId,@mfProductionPlanId=a.mfProductionPlanId  
			from mf_purchaseNew a, mf_pCodeFabricProtity b, mf_purchaseNewCount c where a.mfpCodeFabricProtityId=b.id and c.purchaseNewId=a.id and c.id=@id
			
		exec mf_updateFabricNewStock @mfpCodeFabricProtityId, @pCodeFabricFormId, @mfProductionPlanId, @updateArrivalCount, @shelfCode, @doManId ,1
		
		
		if (@isUpdate=0)
		begin
			ROLLBACK tran
		end
	END
	commit tran

	SELECT @returnValue
