-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
create procedure [dbo].[ChangeUserBrandsToNotify]
	@brands varchar(500),
	@userId int
as
    declare @pointerPrev int
	declare @pointerCurr int
	declare @TRole int
	DECLARE @returnValue int
  	set @pointerPrev=1
  	set @returnValue=1
Begin
set nocount on;
update ERP..tb_userBrand set isNotify = 0 where userId=@userId
if @brands <>'-1'
Begin
 while (@PointerPrev < LEN(@brands)) 
    Begin 
        Set @PointerCurr=CharIndex(',',@brands,@PointerPrev) 
        if(@PointerCurr>0) 
        Begin 
            set @TRole=cast(SUBSTRING(@brands,@PointerPrev,@PointerCurr-@PointerPrev) as int) 
			
			update ERP..tb_userBrand set isNotify = 1 where userId=@userId and brandId = @TRole
            
            SET @PointerPrev = @PointerCurr+1 
        End 
        else 
            Break 
    End
End 

end
select @returnvalue
