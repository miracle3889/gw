/****发货***/
CREATE procedure [dbo].[updatePhManByDistibute]  @doManId int, @distributeId int
as
	declare @code varchar(20)
	declare @insertId int
	set @insertId=0
	if EXISTS  (select 1  from erp.dbo.tb_Distribute WHERE id=@distributeId and isPh=0 and isPirnt=1)
	begin
	begin tran 
		
		UPDATE erp.dbo.tb_Distribute SET isPh=1,phManId=@doManId,phTime=getDate() where  id=@distributeId
		
		UPDATE erp.dbo.tb_orderDistribute SET phManId=@doManId,phDate=getDate() where  distributeId=@distributeId
		
	--	UPDATE Supermarket.dbo.tb_order  SET orderStatus=2,setTime=getDate() 
	--	WHERE id in(select orderId from erp.dbo.tb_orderDistribute where distributeId=@distributeId) and isdelete<>1
		
		
		insert into supermarket..tb_orderstatusHis(orderId,orderstatus,doMan,remark) 
		select id,13,@doManId,'仓库打包完成发货' from  Supermarket.dbo.tb_order  
		where id  in(select orderId from erp.dbo.tb_orderDistribute  where distributeId=@distributeId) 
		commit tran 
	
	end 
	select @insertId
