CREATE VIEW dbo.v_weixindownload_first
AS
SELECT     id, weixinid, 'image' sign, 'erp..tb_image' tablename, 0 type
FROM         erp..tb_image
WHERE     url = '2'
UNION
SELECT     id, weixinid, 'multimedia' sign, 'erp..tb_multimedia' tablename, 1 type
FROM         erp..tb_multimedia
WHERE     weixinId <> '0' AND url = '2'
UNION
SELECT     id, mediaId weixinid, 'suppliderCardCodeMedia' sign, 'erp..Mf_suppliderCardCodeMedia' tablename, 0 type
FROM         erp..Mf_suppliderCardCodeMedia
WHERE     mediaurl = '2'
