/*------------------------- 查询裁片是否完成 ---------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[p_yiCaiPianIsOK] @yiCaiPianId INT
AS
	DECLARE @returnValue INT
	SET @returnValue=0
	
	DECLARE @caiPianCount INT
	SET @caiPianCount=0
	DECLARE @caiChuCount INT
	SET @caiChuCount=0
	DECLARE @caiPianSize INT
	SET @caiPianSize=0

	select @caiPianCount=caiPianCount from tb_yiCaiPian where id=@yiCaiPianId

	select @caiChuCount=sum(caiChuCount) from tb_yiCaiPianSize where yiCaiPianId=@yiCaiPianId

	
	IF (@caiPianCount=@caiChuCount)
	BEGIN
		SET @returnValue=1
	END
	ELSE
	BEGIN
		SET @returnValue=-1
	END
	
/*
	IF (@caiPianCount=@caiChuCount)
	BEGIN
		select @caiPianSize=count(id) from tb_yiCaiPianSize where yiCaiPianId=@yiCaiPianId and caiChuCount-yiChuCount!=0
		IF (@caiPianSize<>0)
		BEGIN
			SET @returnValue=-2
		END
		ELSE
		BEGIN
			SET @returnValue=1
		END
	END
	ELSE
	BEGIN
		SET @returnValue=-1
	END
*/
	SELECT @returnValue
