--查询多张发票编号,以','分隔
CREATE function [dbo].[sc_getInvoiceCode](@contractId int)
RETURNS VARCHAR(500)
as 
begin
declare @invoiceCode varchar(500)
SET @invoiceCode = ''
    SELECT @invoiceCode = @invoiceCode+invoiceCode+' ' FROM  supplyCenter.materie.tb_invoice_main where contractId = @contractId
	set @invoiceCode = stuff(@invoiceCode, 1, 0, '')
	
	RETURN @invoiceCode
 END
