CREATE PROCEDURE [dbo].[p_addInvoiceOrder] @title VARCHAR(200),@invoicePrice INT 
AS 
	DECLARE @precent INT
	DECLARE @orderId INT
	SET @precent=140 --税点

	DECLARE @invoicePriceLeft INT
	
	DECLARE @unitPrice INT
	DECLARE @productCount INT
	
	DECLARE @id INT
	
		
	INSERT INTO tb_invoiceOrder(title) VALUES(@title)
	SET @orderId=SCOPE_IDENTITY( )
	
	
	SET  @invoicePrice=@invoicePrice*100/@precent
	SET @invoicePriceLeft=@invoicePrice
	
	DECLARE authors_cursor0 CURSOR FOR
	select id,unitPrice,productCount-surplusCount from   tb_invoicePriceProduct where productCount>surplusCount and id<>10    order by newId() desc  
	OPEN authors_cursor0
	FETCH NEXT FROM authors_cursor0 
	INTO @id,@unitPrice,@productCount
	WHILE @@FETCH_STATUS = 0
	BEGIN		
		DECLARE @i INT
		SET @i=0
		WHILE(@unitPrice<=@invoicePriceLeft) --如果商品单价小于等于
		BEGIN
			SET @invoicePriceLeft=@invoicePriceLeft-@unitPrice
			SET @i=@i+1
		END
		PRINT cast(@id as varchar(10))+':'+cast(@i as varchar(10))
		if(@i>0)
		begin
		INSERT INTO tb_voiceOrderProduct(orderId,invoiceProductId,productCount) VALUES(@orderId,@id,@i)		
		UPDATE  tb_invoicePriceProduct SET surplusCount=surplusCount+@i WHERE id=@id
		end
		FETCH NEXT FROM authors_cursor0 
			INTO @id,@unitPrice,@productCount
	END
	
	CLOSE authors_cursor0
	DEALLOCATE authors_cursor0	
	
	IF(@invoicePriceLeft>0)
	BEGIN
		PRINT  '10:'+cast(@invoicePriceLeft/100 as varchar(10))
		INSERT INTO tb_voiceOrderProduct(orderId,invoiceProductId,productCount) VALUES(@orderId,10,@invoicePriceLeft/100)
		UPDATE  tb_invoicePriceProduct SET surplusCount=surplusCount+@invoicePriceLeft/100 WHERE id=10
	END
