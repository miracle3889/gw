--[dbo].p_distributeTeeOrder 1,'lp0F7kGQ6kdLGmP2PXaa-_V6pstH',1


create    procedure [dbo].[p_distributeTeeOrder] @doManId int,@imageKey varchar(50),@orderCount int
as
			--exec supermarket..p_setCanOrdernew 0
			declare @insertId int
			declare @code varchar(50)
			declare @sql varchar(2000)
			declare @count int
			set @insertId=0
			exec p_getDistributOrder @code OUTPUT
			declare @brandId int 
			
			select @brandId=brandId from SuperMarket..tb_brandNick where nickName='teegether'
			
			insert into tb_Distribute(pCode,doManId,brandId,userId) values(@code,@doManId,@brandId,0)
			
			
			set @insertId=SCOPE_IDENTITY( ) --批号的id
	
		
			set rowcount @orderCount 
			begin tran 
			---缓存订单信息
			insert into tb_orderDistribute(distributeId,orderId,orderCode,payType,deliverType,
			deliverPrice,memberId,orderStatus,doMan,reMark,receviceMan,post,receviceAddr1,regionalId1,
			receviceAddr2,regionalId2,receviceMobile,addrId,useGift,useAccount,getScore,proCode,oldOrderCode,
			backCode,otherOrder,provinceId,cityId,productPrice,needGetPrice,transport,proxy)
			
			select   @insertId,a.id,a.orderCode,payType,deliverType,
			deliverPrice,memberId,orderStatus,doMan,reMark,receviceMan,post,receviceAddr1,regionalId1,
			receviceAddr2,regionalId2,receviceMobile,addrId,useGift,useAccount,getScore,proCode,oldOrderCode,
			backCode,otherOrder,provinceId,cityId,productPrice,needGetPrice,transport,proxy 
			from SuperMarket..tb_order a
			inner join SuperMarket..tb_orderSaleProduct b on a.id=b.orderId 
			inner join SuperMarket..tb_orderNickName c on c.orderCode=a.orderCode and a.isDelete=0 
			inner join ERP..tb_Tshirt_sku d on d.id=b.outOCode 
			where c.nickName='teegether' and a.orderStatus=1 and d.imageKey=@imageKey
			group by a.id,a.orderCode,payType,deliverType,
			deliverPrice,memberId,orderStatus,doMan,reMark,receviceMan,post,receviceAddr1,regionalId1,
			receviceAddr2,regionalId2,receviceMobile,addrId,useGift,useAccount,getScore,proCode,oldOrderCode,
			backCode,otherOrder,provinceId,cityId,productPrice,needGetPrice,transport,proxy 
			
			set rowcount 0
			
			insert into ERP..tb_distributeImage(distributeId,imagekey,thumbUrl)
			select top 1 @insertId,@imageKey,thumbUrl from ERP..tb_Tshirt_sku where imageKey=@imageKey 
			
			
			/*---快照所有待配货订单商品信息*/
			insert into dbo.tb_orderSaleProductDistribute(distributeId,orderProductId,orderId,colorId,
			metricsId,saleProductCode,saleProductId,buyCount,groupPh)

			select @insertId,id,orderId,colorId,
			metricsId,saleProductCode,saleProductId,buyCount,groupPh from Supermarket.dbo.tb_orderSaleProduct where orderId in
		    (select orderId from tb_orderDistribute where distributeId=@insertId)
			
			--删除待配货
			delete from  erp..tb_canDistributeOrder where orderId  in(select orderId from tb_orderDistribute where distributeId=@insertId)
			
			delete from supermarket..tb_ordersaleOutOfStock where orderId in(select orderId from tb_orderDistribute where distributeId=@insertId)
			--更新订单状态
			update Supermarket.dbo.tb_order set orderstatus=20,isDelete=0 where id 
			in(select orderId from tb_orderDistribute where distributeId=@insertId)
			
			insert into supermarket..tb_orderstatusHis(orderId,orderstatus,doMan,remark) 
			select orderId,20,@doManId,'配货' from tb_orderDistribute 
			 where distributeId=@insertId
			
			update tb_Distribute set orderCount=@orderCount where id=@insertId
			
			--设置未发货已经配货状态
		--	update reportruhnn.dbo.tb_orderNoDelivered  set status=1 where orderId in(
		---		select orderId from tb_orderDistribute where distributeId=@insertId
		--	)
			--select orderId from tb_orderDistribute where distributeId=@insertId
			
			commit tran 
			exec p_addDistributeProductShelf  @insertId

		select @insertId
