-- 增加采购单
CREATE PROCEDURE [dbo].[mf_addMFpurchaseNew]  @mfProductionPlanId int, @mfpCodeFabricProtityId int, @purchaseUnit int, @unitPrice int, 
			@onSalePrice int, @price int, @arrivalDate varchar(32), @doManId int, @fabricCount int, @fabricCountList varchar(320), @userId int, @remark varchar(320)
AS

	DECLARE @returnValue INT	
	SET @returnValue=0
	
	begin tran

	IF (@mfpCodeFabricProtityId<>0 and @mfProductionPlanId<>0)
	BEGIN

	--IF NOT EXISTS ( select * from mf_purchaseNew where mfFabricId=@mfFabricId and purchaseUnit<>@purchaseUnit )
	--BEGIN
		INSERT INTO ERP..mf_purchaseNew (mfProductionPlanId, mfpCodeFabricProtityId,
				purchaseUnit, unitPrice, onSalePrice, price, arrivalDate, doManId, userId, remark) 
		VALUES (@mfProductionPlanId, @mfpCodeFabricProtityId, 
				@purchaseUnit, @unitPrice, @onSalePrice, @price, @arrivalDate, @doManId, @userId, @remark)
		SET @returnValue=SCOPE_IDENTITY()
		if (@@error<>0)
		begin
			ROLLBACK tran
		end

		/*****如果增加采购单的面料采购匹数****/
		DECLARE @i INT
		SET @i=1
		while @i<=@fabricCount
		begin
			if (SUBSTRING(@fabricCountList, 0,CHARINDEX(',',@fabricCountList)) <> 0)
			begin
				INSERT INTO ERP..mf_purchaseNewCount (doManId, purchaseNewId, purchaseCount)
				VALUES (@doManId, @returnValue, SUBSTRING(@fabricCountList, 0,CHARINDEX(',',@fabricCountList)))
				if (@@error<>0)
				begin
					ROLLBACK tran
				end
			end
			SET @fabricCountList= SUBSTRING(@fabricCountList, CHARINDEX(',',@fabricCountList)+1,len(@fabricCountList))
			SET @i=@i+1
		end
		
		exec mf_updateMFpurchaseNewCountSystem 0, @returnValue
		
		
		DECLARE @pCodeFabricFormId INT
		select @pCodeFabricFormId=b.pCodeFabricFormId  
			from mf_purchaseNew a, mf_pCodeFabricProtity b where a.mfpCodeFabricProtityId=b.id and a.id=@returnValue
			
		--如果有采购单到货 并且生产计划任务的到货状态为未采购，则设定生产计划任务的status 为采购中
		UPDATE mf_productionPlanTask SET status=1 WHERE mfProductionPlanId=@mfProductionPlanId and mfpCodeFabricFormId=@pCodeFabricFormId and status=0
	--END	

	END
	commit tran

	SELECT @returnValue
