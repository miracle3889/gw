-- =============================================
-- Author:		<runbin>
-- Create date: <2018-08-31>
-- Description:	<验证快递包裹是否已拆过或是否处理完成并且已入库>
-- =============================================
CREATE PROCEDURE [dbo].[p_checkHasPutInStorage] 
	@sid varchar(20)	--快递单号 
AS
declare @ret int	-- 返回值
declare @num int	--处理商品数
BEGIN
	select @ret = count(1) from SuperMarket..Tb_salePackageDeal where sid = @sid
	--判断是否处理过商品或只拍照未处理
	select @num = COUNT(a.id) from SuperMarket..Tb_saleProductDeal a join SuperMarket..Tb_salePackageDeal b 
							on a.packageId = b.id where b.sid = @sid 
	if(@ret>0 and @num>0)	--快递已处理且有处理商品 验证是否全部处理且已入库
		begin
			select @ret = COUNT(a.id) from SuperMarket..Tb_saleProductDeal a join SuperMarket..Tb_salePackageDeal b
				on a.packageId = b.id where b.sid = @sid and a.storageStatus = 0 and b.status <> 3
		end
	else
		set @ret = -1	--快递未处理
END
select @ret