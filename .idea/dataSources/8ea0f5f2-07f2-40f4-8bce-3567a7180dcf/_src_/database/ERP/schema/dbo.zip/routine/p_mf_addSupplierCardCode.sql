CREATE procedure [dbo].[p_mf_addSupplierCardCode] 
@suppliderId int ,
@cardCodeClassOneId int,
@cardCodeClassTwoId int,
@cardCode varchar(50),
@name varchar(50),
@price varchar(50),
@componets varchar(50),
@width varchar(50),
@remark varchar(200),
@qrCodeId int,
@mainMedia varchar(200),
@userId int 
as
declare @suppliderCardCodeId int     
begin
	--验证是否重复提交	
	if not exists (select 1 from erp.dbo.mf_suppliderCardCode where qrCodeId = @qrCodeId)
	begin
     begin tran 
		insert into erp.dbo.mf_suppliderCardCode(suppliderId,cardCodeClassOneId
		,cardCodeClassTwoId,cardCode,name,price,componets,width,remark,qrCodeId,mainMedia,userId) 
		values(@suppliderId,@cardCodeClassOneId,@cardCodeClassTwoId,
		 @cardCode,@name,@price,@componets,@width,@remark,@qrCodeId,@mainMedia,@userId)
  --    declare @scopId int 
  --    set @scopId=  SCOPE_IDENTITY()
		set @suppliderCardCodeId=  SCOPE_IDENTITY()
		
	--  update erp.dbo.mf_suppliderCardCodeMedia set suppliderCardCodeId=@scopId
		update erp.dbo.mf_suppliderCardCodeMedia set suppliderCardCodeId=@suppliderCardCodeId where qrCodeId=@qrCodeId
	  
	--  select @scopId
	commit tran 
   end
   else
	begin
		set @suppliderCardCodeId = 0
	end
    select @suppliderCardCodeId
end
