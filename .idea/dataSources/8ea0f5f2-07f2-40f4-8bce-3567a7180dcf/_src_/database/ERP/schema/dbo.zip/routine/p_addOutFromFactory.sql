/*----------------添加定单--------*/
CREATE    PROCEDURE [dbo].[p_addOutFromFactory]  
				     @doMan INT,
				     @outMan VARCHAR(50),
				     @outRemark VARCHAR(50),
				     @mfAddrId int 
AS

	DECLARE @code VARCHAR(50)	
	BEGIN TRAN 
		--set @mfAddrId=2
		EXEC p_getOutFromFactoryCode 1,@code OUTPUT --得到订单号
		insert into tb_outFromFactory(outman,doManId,remark,pCode,mfAddrId)
		values(@outMan,@doMan,@outRemark,@code,@mfAddrId )
		select SCOPE_IDENTITY() 
	commit tran
