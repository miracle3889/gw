/*********		替换图文编辑的图片		***********/
CREATE PROCEDURE [dbo].[p_moveItemPicWords]
 @id	int,
 @moveType	int
AS

DECLARE @orderById	INT  --图文位置
set @orderById=0
DECLARE @orderByIdNext	INT  --关联图文位置
set @orderByIdNext=0
DECLARE @salaId	INT  --销售号
set @salaId=0
DECLARE @return	INT  --返回值
set @return=0
if exists (select 1 from ERP..tb_itemPicWords where id=@id)
BEGIN
	 begin tran 
		 select @orderById=orderBy,@salaId=saleId from ERP..tb_itemPicWords where id=@id
		 if(@moveType=0)--下移
			begin
				if exists (select 1 from ERP..tb_itemPicWords where saleId=@salaId and orderBy>@orderById)
					begin
						select @orderByIdNext=orderBy from ERP..tb_itemPicWords where id=(select top 1 id from ERP..tb_itemPicWords where saleId=@salaId and orderBy>@orderById and isDel=0 order by orderBy)
						print @orderByIdNext;
						update ERP..tb_itemPicWords set orderBy=@orderById where saleId=@salaId and orderBy=@orderByIdNext
						update ERP..tb_itemPicWords set orderBy=@orderByIdNext where id=@id
						set @return=1
					end
			end
		 if(@moveType=1)--上移
			begin
				if exists (select 1 from ERP..tb_itemPicWords where saleId=@salaId and orderBy<@orderById)
					begin
						select @orderByIdNext=orderBy from ERP..tb_itemPicWords where id=(select top 1 id from ERP..tb_itemPicWords where saleId=@salaId and orderBy<@orderById and isDel=0 order by orderBy desc)
						print @orderByIdNext;
						update ERP..tb_itemPicWords set orderBy=@orderById where saleId=@salaId and orderBy=@orderByIdNext
						update ERP..tb_itemPicWords set orderBy=@orderByIdNext where id=@id
						set @return=1
					end
			end
		 
		 if @@ERROR<>0
			begin
				set @return=0
				rollback tran
			end
	 commit tran
END
select @return
