/******  更新试穿结果 ******/
CREATE PROCEDURE [dbo].[p_updateWearResult]
	 @userId int,
	 @styleId int,
	 @needDesign int,
	 @wearResult varchar(200),
	 @status int
   AS
   BEGIN
		declare @qcrode int
		declare @pattternId int
		declare @designId int
		declare @patternUserId int
		declare @userName varchar(100)
		declare @countMaking int
		declare @rowcount int
		DECLARE @bz	varchar(500)
		
		  select @pattternId = mainPatternId,@patternUserId = banShiId from ERP..mf_pCodeFabricMsg where id = @styleId
		  select @designId = currentPattern from ERP..tb_pattern_making where id = @pattternId
		  select @qcrode = qrcode from ERP..tb_design where id =@designId	
		
		begin tran	
			if(@wearResult is null) set @wearResult = 0
			update ERP..tb_design_qrcode set wearResult = @wearResult where id = @qcrode and wearResult is null
			set @rowcount = @@ROWCOUNT
			select @userName=name from ERP..tb_user where id=@userId
			select top 1 @countMaking=number from ERP..tb_pattern_making where styleId=@styleId order by date desc
		  
			if(@status=2 and @needDesign=0)
			begin
				set @bz=@userName+'组织试穿不改版重做'
				if(@countMaking<>1)
					set @bz=@bz+' /第'+cast(@countMaking as varchar(20))+'版'
				update ERP..mf_pCodeFabricMsg set statusId = @status where id = @styleId 
			end
			
			if(@status=2 and @needDesign=1)
			begin
				set @bz=@userName+'组织试穿需改版不重做'
				if(@countMaking<>1)
					set @bz=@bz+' /第'+cast(@countMaking as varchar(20))+'版'
				--update ERP..mf_pCodeFabricMsg set statusId = @status where id = @styleId
			end
		  
			if(@status=7 and @needDesign=2)
			begin
				set @bz=@userName+'组织试穿通过'
				if(@countMaking<>1)
				begin
					set @bz=@bz+'第'+cast(@countMaking as varchar(20))+'版'
				end
				
				
				select top 1  @status = a.statusid 
					from ERP..tb_roleStatus a
					inner join ERP..mf_pCodeFabricMsg b on a.statusId>b.statusId 
						and a.type = b.developMode and a.roleId=8
				where b.id=@styleId order by a.statusId
				
			 if(@status is null) set @status=7
			 update ERP..mf_pCodeFabricMsg set statusId = @status where id = @styleId 
			end
			
		 if(@rowcount>0)
			insert into ERP..tb_status_history (styleId,statusId,userId,date,bz) values (@styleId,@status,@userId,getDate(),@bz)
		commit tran
		 -- if(@needDesign <> 2)
		 -- begin
			--exec p_updatePatternMaking @styleId,@patternUserId,@needDesign
		 -- end
    END



