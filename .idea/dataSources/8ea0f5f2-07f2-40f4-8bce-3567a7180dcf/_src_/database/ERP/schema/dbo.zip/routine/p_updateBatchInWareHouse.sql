-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[p_updateBatchInWareHouse]
@batchId varchar(50),
@userId int
as
declare @id int,@colorId int ,@metricsId int ,@productId int ,@productCode varchar(50),@shelfCode varchar(50),@inCount int
declare @return int
set @return=1;
if exists (select	1  from SuperMarket..Tb_saleStorageBatch where batchId=@batchId and status=1)
begin
update SuperMarket..Tb_saleStorageBatch set status=2,userId=@userId where batchId=@batchId and status=1

begin tran
DECLARE  cs CURSOR FOR 
	
	
	select b.productId,b.colorId,b.metricsId,a.amount,skuCode,a.shelfCode 
	 
	from SuperMarket..Tb_saleStorageBatchChild a 
	inner join erp..tb_productStock b on a.skuCode=b.productShelfCode  
	inner join SuperMarket..Tb_saleStorageBatch c on c.id=a.batchId
	where  c.batchId=@batchId

	
	OPEN cs
	FETCH NEXT FROM cs
	INTO @productId,@colorId,@metricsId,@inCount,@productCode,@shelfCode
	WHILE @@fetch_status =0
	BEGIN		
		
		exec p_addProductStockCount  @productId,@colorId,@metricsId,@inCount,4,@userId,'退货入库'
		--SKU编号不存在
		if(@productCode is null  or @productCode='') 
		
		begin
			exec p_getShelfProductCode @productId,@colorId,@metricsId,@productCode output
			
			if(@productCode is null) 
			begin
				set @productCode=''
			end
			update tb_productStock set productShelfCode =@productCode
			 where productId=@productId and colorId=@colorId and metricsId=@metricsId
			
			if not exists (select 1 from erp..tb_productSkuCode 
			where productId=@productId and colorId=@colorId and metricsId=@metricsId )
			begin
				insert into tb_productSkuCode(productShelfCode,productId,colorId,metricsId)
				 values(@productCode,@productId,@colorId,@metricsId)
			end
		end	
		
		exec [dbo].[p_addShelfStockBySystem] @shelfCode,@productCode,@inCount,@userId,2,''
		
		FETCH NEXT FROM cs
		INTO @productId,@colorId,@metricsId,@inCount,@productCode,@shelfCode
	END
	
	CLOSE cs
DEALLOCATE cs


if @@ERROR<>0
	begin
		set @return=0;
		update SuperMarket..Tb_saleStorageBatch set status=0 where batchId=@batchId
	    rollback tran
	end
commit tran
end
select @return;
