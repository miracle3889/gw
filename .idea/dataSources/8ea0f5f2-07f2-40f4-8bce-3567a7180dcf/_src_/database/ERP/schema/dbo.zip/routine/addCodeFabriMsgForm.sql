CREATE PROCEDURE [dbo].[addCodeFabriMsgForm]
	@codeFabriMsgId int, --款式id
	@userId int,
	@fabricNewId int, ---调料记录色卡号id
	@codeFomrId int output,  --调料主表id 
	@type int --类型 1，面料 2，辅料 3，里料
AS
declare @count int
declare @fabricId int   --新增物料主表id   
declare @formName varchar(50) ---新增面料，辅料，里料名字
	BEGIN
		if(@fabricNewId>0 and @codeFomrId>0)
			begin
				update ERP..mf_pCodeFabricProtity set fabricNewId = @fabricNewId where pCodeFabricFormId=@codeFomrId
			end	
		if((@fabricNewId>0 and @codeFomrId=0 and @type>0)or(@fabricNewId=-1 and @codeFomrId=0 and @type>0))
			
			begin
				select @count= COUNT(*) from ERP..mf_pCodeFabricForm where mfTypeId=@type and pCodeFabricMsgId=@codeFabriMsgId
				if(@type=1)
					begin
						set @formName = '面料-'+cast((@count+1) as varchar(20))
					end 
				if(@type=3)
					begin
						set @formName = '里料-'+cast((@count+1) as varchar(20))
					end
				insert into ERP..mf_pCodeFabricForm(pCodeFabricMsgId,formName,mfTypeId,oneCount,mfUnitId,doManId,addDate)values(@codeFabriMsgId,@formName,@type,0,1,@userId,GETDATE())
				
				set @fabricId=SCOPE_IDENTITY()
				set @codeFomrId=@fabricId
				insert into ERP..mf_pCodeFabricProtity(pCodeFabricFormId,fabricNewId,doManId,addDate)values(@fabricId,@fabricNewId,@userId,GETDATE())
			end		
	END
select @codeFomrId as 'ret';
