CREATE PROCEDURE [dbo].[p_updateCodeTpye]
		@id int,
        @name varchar(200),
        @bz varchar(200)
    AS
    BEGIN
       if @id <> 0
		begin
			update ERP..tb_code_type set name=@name,bz=@bz where id=@id		       
        end 
        ELSE 
            BEGIN
                insert into ERP..tb_code_type(name,bz,isdelete)values(@name,@bz,0)
             END

    END
