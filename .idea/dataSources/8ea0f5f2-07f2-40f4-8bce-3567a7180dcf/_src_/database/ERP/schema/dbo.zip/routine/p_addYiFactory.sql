/*------------------------- 增加生产工单 ---------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[p_addYiFactory] @yiDaYangId INT, @userId INT, @orderDate varchar(28)
AS
	DECLARE @returnValue INT

	SET @returnValue=0
	INSERT INTO tb_yiFactory (yiDaYangId, mfUserId, orderDate, isFactory, type) VALUES (@yiDaYangId, @userId, @orderDate, 1, 1)
	SET @returnValue=SCOPE_IDENTITY()

	SELECT @returnValue
