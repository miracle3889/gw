CREATE procedure [dbo].[p_addUserAccount] @accountUserId int,@inPrice int, @nagative int, @inUserId  int,@remark varchar(200)
as
	if(@nagative=1)
		set @inPrice=@inPrice*-1
	insert into dbo.tb_userAccountAdd(accountUserId,inPrice,inUserId,remark) values(@accountUserId,@inPrice,@inUserId,@remark)
	update dbo.tb_userAccount set account=account+@inPrice where userId=@accountUserId
