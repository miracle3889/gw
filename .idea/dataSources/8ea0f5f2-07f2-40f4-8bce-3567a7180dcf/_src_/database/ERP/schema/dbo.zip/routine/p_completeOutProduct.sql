CREATE procedure [dbo].[p_completeOutProduct] @outId int
as 
	declare @productCount int
	declare @doMan int
	
	if exists(select 1 from tb_outFromFactory where status=1 and  id=@outId  )
	begin
		--不能超出裁床数
		 if not exists (
			select b.id,b.clippingCount,b.outCount,SUM(a.outCount) 
			 from erp..tb_outFromFactoryProduct a
			 inner join erp..tb_clippingProtity b on a.clippingProtityId=b.id 
			 where factoryId=@outId 
			 group by b.id,b.clippingCount,b.outCount 
			 having b.clippingCount-b.outCount-SUM(a.outCount)<0
		)
		begin 
			select @productCount=sum(outCount) from tb_outFromFactoryProduct where factoryId=@outId
		
			if(@productCount is null) set @productCount=0
			begin 
					begin tran 
					update tb_outFromFactory set outCount=@productCount,status=2 where id=@outId and status =1 
					if(@@rowcount>0)
					begin
						update tb_clipping set status=2 where id in(
						select clippingId  from tb_clippingProtity  where 
						id in(select clippingProtityId from tb_outFromFactoryProduct where factoryId=@outId))
					
						select @doMan=doManId from tb_outFromFactory where id=@outId
							
						update tb_outFromFactory set getManId=@doMan,getTime=getDate() where id=@outId
						
						update   tb_outFromFactoryProduct set inCount=outCount where factoryId=@outId			
						
						
						---设置商品状态变更
						insert into erp..tb_jstatusHis(pcode,jstatus)
						select pcode,6 from  erp..mf_pCodeFabricMsg  
						where pCode  in(
						select pCode from erp..tb_product where id in(
									
									select  c.productId  from tb_outFromFactoryProduct  a
									inner join erp..tb_clippingProtity b on a.clippingProtityId=b.id 
									inner join erp..tb_clipping c on c.id=b.clippingId
									 where factoryId=@outId
									
								)
							
							)  and jstatus<6
						
							UPDATE erp..mf_pCodeFabricMsg set jstatus=6 where pCode in(
								select pCode from erp..tb_product where id in(
									
									select  c.productId  from tb_outFromFactoryProduct  a
									inner join erp..tb_clippingProtity b on a.clippingProtityId=b.id 
									inner join erp..tb_clipping c on c.id=b.clippingId
									 where factoryId=@outId
									
								)
					) and jstatus <6
					
					
					DECLARE @tb_outShelf Table--记录商品货架信息
					(
					 Id int,
					 productCount int,
					 shelfCode varchar(50)
					)
					
					insert into @tb_outShelf(Id,shelfCode,productCount)
					 select a.id,e.shelfCode,e.productCount from tb_outFromFactoryProduct a
					inner join erp..tb_clippingProtity b on a.clippingProtityId=b.id 
					inner join erp..tb_clipping c on c.id=b.clippingId
					inner join erp..tb_productStock  d on d.productId=c.productId and d.colorId=b.colorId and d.metricsId=b.metricsId
					inner join erp..tb_shelfProductCount e on e.productCode=d.productShelfCode
					inner join erp..[tb_goodsShelf ] f on f.code=e.shelfCode and f.isStock=1
					 where factoryId=@outId 
					 group by a.id,e.shelfCode,e.productCount order by a.id 
					 
					 
					 
					  update tb_outFromFactoryProduct set shelfCode=b.shelfCode 
					  from tb_outFromFactoryProduct a,(
					 select a.Id,a.shelfCode from @tb_outShelf a
					 inner join (
					 select ID,MAX(productCount) as productCount from @tb_outShelf group by id 
					 ) b on a.productCount=b.productCount and a.Id=b.Id ) b where a.id=b.id and factoryId= @outId
 
 

					
					
					--自动入库
					--exec p_updateOutProductIn @outId  ,@doMan
				end
				commit tran 
			end
		end
	end
