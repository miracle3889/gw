/*********	获取试穿样衣图片	***********/
CREATE PROCEDURE [dbo].[p_getYangYiImage]
 @styId int,
 @token varchar(100)	
AS
	declare @url varchar(300) --图片
	declare @weixinId varchar(100) ---微信id
	declare @pId int --主图id
	declare @codeUrl varchar(300) ---款式图片
	declare @originalId int ---原样id
	declare @orginUrl varchar(300) --原样图片
	declare @orginPicId int
	
begin
	select top 1 @url =imgUrl,@pId=picId,@originalId=originalId from 
	(select 
	case when cast(i.url as varchar(300)) is null or cast(i.url as varchar(300))='2' then 'aaa'+'&media_id='+i.weixinId else cast(i.url as varchar(300)) end imgUrl,
	b.picId,b.originalId,b.id,i.mainPic,i.updateTime from
	ERP..tb_design_qrcode q 
	left join ERP..tb_design a on q.id=a.qrcode
	left join ERP..tb_pattern_making m on a.patternId=m.id 
	left join ERP..tb_image i on i.pid=q.wearMediaId 
	inner join ERP..mf_pCodeFabricMsg b on m.styleId = b.id where b.id=@styId) t order by mainPic,updateTime desc
	
	if(@url is null)
	begin
		select @codeUrl = imgurl from (select case when cast(url as varchar(300)) is null or cast(url as varchar(300))='2' then @token+'&media_id='+weixinId else cast(url as varchar(300)) end imgUrl from ERP..tb_image where pid = @pId) b
		 if(@codeUrl is null)
			 begin
				select @orginPicId = picId from  erp..v_original where id = @originalId
				select @orginUrl = imgurl from (select case when cast(url as varchar(300)) is null or cast(url as varchar(300))='2' then @token+'&media_id='+weixinId else cast(url as varchar(300)) end imgUrl from ERP..tb_image where pid = @orginPicId) c
				set @url = @orginUrl
			 end
		 else       
		   begin
				set @url = @codeUrl
		   end	 
	end
end
select @url as ret
