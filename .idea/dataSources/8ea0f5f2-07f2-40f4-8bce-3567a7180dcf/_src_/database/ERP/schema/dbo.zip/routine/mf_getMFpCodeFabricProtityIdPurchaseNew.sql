-- 得到LIBLIN的色卡
CREATE PROCEDURE [dbo].[mf_getMFpCodeFabricProtityIdPurchaseNew] @pCodeFabricProtityId int
AS

	DECLARE @returnId INT
	SET @returnId=0
	
	begin tran
		
	IF (@pCodeFabricProtityId <> 0)
	BEGIN
		
		DECLARE @fabricNewId INT
		set @fabricNewId=0
		DECLARE @doManId INT
		set @doManId=0
		select @fabricNewId=fabricNewId,@doManId=doManId from mf_pCodeFabricProtity where id=@pCodeFabricProtityId
		
		IF (@fabricNewId<>0)
		BEGIN
			
			select @returnId=id from mf_pCodeFabricProtity where fabricNewId=@fabricNewId and pCodeFabricFormId=1094 and isDelete=0
			if(@returnId=0)
			begin
				INSERT INTO mf_pCodeFabricProtity (pCodeFabricFormId, fabricNewId, doManId) 
				values (1094, @fabricNewId, @doManId)
					SET @returnId=SCOPE_IDENTITY()
			end
		END
	
	END
	commit tran

	SELECT @returnId
