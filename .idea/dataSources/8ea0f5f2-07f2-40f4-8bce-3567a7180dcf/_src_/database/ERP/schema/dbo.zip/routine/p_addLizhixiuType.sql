/*  增加荔枝秀 批次  */

CREATE PROCEDURE [dbo].[p_addLizhixiuType] @typeName varchar(32)
AS

	DECLARE @returnValue INT
	SET @returnValue=0
	
	IF NOT EXISTS ( select * from erp..tb_lizhixiuType where  typeName = @typeName)
	begin
		insert into ERP..tb_lizhixiuType (typeName) VALUES (@typeName)
		SET @returnValue=SCOPE_IDENTITY()
	END

	SELECT @returnValue
