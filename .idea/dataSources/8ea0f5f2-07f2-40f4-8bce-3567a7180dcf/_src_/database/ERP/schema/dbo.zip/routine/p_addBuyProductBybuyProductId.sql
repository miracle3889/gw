/*----------------添加采购单(最新)--------------------------------*/
CREATE PROCEDURE  [dbo].[p_addBuyProductBybuyProductId] @buyProductId int ,@buyCount int

 
AS	
	begin tran 
	
	update 	dbo.tb_buyProductList set buyCount=buyCount-@buyCount where id=@buyProductId

	update dbo.tb_buyProductList set transportPrice=0 ,remittancesPice=buyPrice*buyCount,invoicesPrice=buyPrice*buyCount where id=@buyProductId

	INSERT INTO dbo.tb_buyProductList(billType,productId,supplyId,buyPrice,
				     buyCount,transportTypeId,remittancesPice,
				     invoicesType,invoicesPrice,buyRemark,remittancesTime,
					buyUserId,transportPrice,expectedInTime,mfAddrId)
	select billType,productId,supplyId,buyPrice,
				     @buyCount,transportTypeId,buyPrice*@buyCount,
				     invoicesType,buyPrice*@buyCount+transportPrice,buyRemark,remittancesTime,
					buyUserId,transportPrice,expectedInTime,mfAddrId  from tb_buyProductList where id=@buyProductId
	
	
	SELECT SCOPE_IDENTITY()
	commit tran
