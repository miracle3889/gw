CREATE procedure [dbo].[p_getCountByPid]
 @pid int,
 @returnValue int output
as
	DECLARE @mediaCount INT --多媒体条数
	DECLARE @imageCount INT --图片条数
	DECLARE @count INT --总条数
	set @returnValue=1;
  begin try
	if @pid<>0
		begin
		  select @mediaCount=COUNT(*) from ERP..tb_multimedia  where pid=@pid
		  if @mediaCount is null set @mediaCount = 0
		  select @imageCount=COUNT(*) from ERP..tb_image  where pid=@pid
		  if @imageCount is null set @imageCount = 0
		  set @count=@mediaCount+@imageCount
		  update ERP..tb_multimedia_pid set count=@count where id=@pid
		end
	else
	begin
		set @returnValue=0
	end
  end try
BEGIN CATCH------------有异常被捕获
        IF @@TRANCOUNT > 0---------------判断有没有事务
        BEGIN
            ROLLBACK TRAN----------回滚事务
           set @returnValue=0
        END 
END CATCH