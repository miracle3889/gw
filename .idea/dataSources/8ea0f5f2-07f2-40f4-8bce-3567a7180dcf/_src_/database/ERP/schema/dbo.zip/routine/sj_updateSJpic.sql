/*  修改设计师选款图片  */

CREATE PROCEDURE [dbo].[sj_updateSJpic] @gradeId INT, @status INT, @pCode varchar(32), @remark varchar(128), @voteRemark varchar(128),
									@productProtityId INT, @seasonId INT, @id INT, @updateManId INT, @userId INT   
AS

	DECLARE @picIdValue INT
	SET @picIdValue=0

	BEGIN tran	
	
	DECLARE @picCode VARCHAR(64)
	DECLARE @seasonName VARCHAR(16)
	DECLARE @protityName VARCHAR(32)
	DECLARE @picCount INT
	SET @picCount = 0
	
	SELECT @picCount = codeInt FROM sj_pic WHERE id=@id
	
	IF NOT EXISTS (SELECT * FROM sj_pic WHERE id=@id and productProtityId=@productProtityId and seasonId=@seasonId)
	BEGIN
		SET @picCount = 0
	-- 设定图片编号
		SELECT @seasonName = seasonName FROM sj_pic_season WHERE id=@seasonId
		SELECT @protityName = protityName FROM sj_pic_productProtity WHERE id=@productProtityId
		SELECT @picCount = ISNULL(MAX(intV),0) FROM dbo.sj_pic_intV WHERE productProtityId=@productProtityId
		SET @picCount = @picCount + 1
		SET @picCode = @seasonName+'_' + @protityName+'_' + CONVERT(VARCHAR(8),@picCount)
		
		--  增加指定图片属性的最大编号
		INSERT INTO dbo.sj_pic_intV	(productProtityId, intV) VALUES (@productProtityId, @picCount)
	END
	ELSE
	BEGIN
		SELECT @picCode=picCode FROM sj_pic WHERE id=@id
	END	
	
		DECLARE @gradeName VARCHAR(32)
		SELECT @gradeName = gradeName FROM sj_pic_grade WHERE id=@gradeId
		DECLARE @userName VARCHAR(16)
		SELECT @userName = name FROM tb_user WHERE id=@userId
	
		-- 取出修改前信息
		DECLARE @oldPicCode VARCHAR(64)
		DECLARE @oldProductProtityId INT
		DECLARE @oldProtityName VARCHAR(32)
		DECLARE @oldGradeId INT
		DECLARE @oldGradeName VARCHAR(32)
		DECLARE @oldSeasonId INT
		DECLARE @oldSeasonName VARCHAR(16)
		DECLARE @oldUserId INT
		DECLARE @oldUserName VARCHAR(16)
		DECLARE @oldStatus INT
		DECLARE @oldPcode VARCHAR(32)
		DECLARE @oldRemark VARCHAR(128)
		DECLARE @oldVoteRemark VARCHAR(128)
		
		select @oldPicCode=a.picCode, @oldProductProtityId=a.productProtityId, @oldProtityName=b.protityName, @oldGradeId=a.gradeId, 
		@oldGradeName=(CASE WHEN a.gradeId=0 THEN '未选择' ELSE c.gradeName END) , @oldSeasonId=a.seasonId, @oldSeasonName=d.seasonName,  
		@oldStatus=a.status, @oldPcode=a.pCode, @oldRemark=a.remark, @oldVoteRemark=a.voteRemark, @oldUserId=userId, @oldUserName=e.name 
		from sj_pic a inner join sj_pic_productProtity b on a.productProtityId=b.id left join sj_pic_grade c on a.gradeId=c.id 
		inner join sj_pic_season d on a.seasonId = d.id inner join tb_user e on e.id=a.userId WHERE a.id=@id
		
		--修改前信息与修改后信息进行比较，如果修改，记录下来
		DECLARE @updateString VARCHAR(800)
		SET @updateString = ''
		IF (@picCode <> @oldPicCode)
		BEGIN
			SET @updateString = @updateString + ' ' + @oldPicCode + ' 改为 ' + @picCode + '，'
		END
		IF (@productProtityId <> @oldProductProtityId)
		BEGIN
			SET @updateString = @updateString + ' ' + @oldProtityName + ' 改为 ' + @protityName + '，'
		END
		IF (@gradeId <> @oldGradeId)
		BEGIN
			SET @updateString = @updateString + ' ' + @oldGradeName + ' 改为 ' + @gradeName + '，'
		END
		IF (@seasonId <> @oldSeasonId)
		BEGIN
			SET @updateString = @updateString + ' ' + @oldSeasonName + ' 改为 ' + @seasonName + '，'
		END
		IF (@userId <> @oldUserId)
		BEGIN
			SET @updateString = @updateString + ' ' + @oldUserName + ' 改为 ' + @userName + '，'
		END
		IF (@status <> @oldStatus)
		BEGIN
			SET @updateString = @updateString + ' ' + (CASE WHEN @oldStatus=0 THEN '未使用' ELSE '使用' END) + ' 改为 ' + (CASE WHEN @status=0 THEN '未使用' ELSE '使用' END) + '，'
		END
		IF (@pCode <> @oldPcode)
		BEGIN
			SET @updateString = @updateString + ' 服装款号：' + @oldPcode + ' 改为 ' + @pCode + '，'
		END
		IF (@remark <> @oldRemark)
		BEGIN
			SET @updateString = @updateString + ' 备注：' + @oldRemark + ' 改为 ' + @remark + '，'
		END
		IF (@voteRemark <> @oldVoteRemark)
		BEGIN
			SET @updateString = @updateString + ' 投票备注：' + @oldVoteRemark + ' 改为 ' + @voteRemark + '，'
		END
		
		
		-- 修改选款图片记录
			update sj_pic set picCode=@picCode, codeInt=@picCount, userId=@userId, gradeId=@gradeId, status=@status, pCode=@pCode, remark=@remark, 
				voteRemark=@voteRemark, productProtityId=@productProtityId, seasonId=@seasonId, updateManId=@updateManId, updateDate=GETDATE()  
					where id=@id  
			IF (@@error<>0)
			BEGIN
				SET @picIdValue=-1
			END
			ELSE
			BEGIN
				SET @picIdValue = 1
				
				IF (@updateString<>'')
				BEGIN
					DECLARE @updateManName VARCHAR(32)
					SELECT @updateManName = name FROM tb_user where id=@updateManId
					SET @updateString =  @updateManName  + ' 于 ' + CONVERT(varchar(19), GETDATE(), 120) + '修改：' + @updateString
					
					INSERT INTO sj_pic_updateInfo (sjPicId, updateInfo) VALUES (@id, @updateString)
				END
			END
			
		

	commit tran

	SELECT @picIdValue 
	RETURN @picIdValue
