-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE procedure [dbo].[ChangeUserRoles]
	@roles varchar(500),
	@userId int
as
    declare @pointerPrev int
	declare @pointerCurr int
	declare @TRole int
	DECLARE @returnValue int
  	set @pointerPrev=1
  	set @returnValue=0
Begin
set nocount on;

delete from tb_userrole where userid=@userId
if @roles <>'-1'
Begin
 while (@PointerPrev < LEN(@roles)) 
    Begin 
        Set @PointerCurr=CharIndex(',',@roles,@PointerPrev) 
        if(@PointerCurr>0) 
        Begin 
            set @TRole=cast(SUBSTRING(@roles,@PointerPrev,@PointerCurr-@PointerPrev) as int) 
		
            insert into tb_userrole(userId,roleId) values(@userId,@TRole)
            SET @PointerPrev = @PointerCurr+1 
        End 
        else 
            Break 
    End
End 

end
select @returnvalue
