CREATE procedure [dbo].[p_getNeedAddStockProduct] 
as 
delete from tb_needAddStockProduct
declare @productId int,@colorId int,@metricsId int,@productCount int
DECLARE authors_cursor CURSOR FOR
select productId,colorId,metricsId,productCount  from  tb_productStock where id in(select productId from SuperMarket.dbo.tb_saleProduct  )
OPEN authors_cursor
FETCH NEXT FROM authors_cursor 
INTO @productId,@colorId,@metricsId,@productCount
WHILE @@FETCH_STATUS = 0
BEGIN
	declare @buyCount int 
	declare @buyCountchat int 
	select @buyCount=buyCount from  SuperMarket.dbo.v_allBuyProductNew where saleProductId=@productId and colorId=@colorId and metricsId=@metricsId and type=1
	select @buyCountchat=buyCount from   SuperMarket.dbo.v_allBuyProductNew where saleProductId=@productId and colorId=@colorId and metricsId=@metricsId and type=2
	if((@productCount-@buyCount-@buyCountchat)<=0)
	begin
		insert into  tb_needAddStockProduct(productId,colorId,metricsId,productCount,buyCount,buyCountchat) values(@productId,@colorId,@metricsId,@productCount,@buyCount,@buyCountchat)
	end
	FETCH NEXT FROM authors_cursor 
	INTO @productId,@colorId,@metricsId,@productCount
END

CLOSE authors_cursor
DEALLOCATE authors_cursor
