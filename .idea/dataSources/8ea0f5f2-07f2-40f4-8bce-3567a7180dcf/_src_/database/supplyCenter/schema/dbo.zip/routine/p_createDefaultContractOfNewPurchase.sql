-- =============================================
-- Author:		<runbin>
-- Create date: <2015-10-23>
-- Description:	<生成虚拟合同>
-- =============================================

CREATE PROCEDURE [dbo].[p_createDefaultContractOfNewPurchase]
as
begin
	--生成新采购单默认合同
	declare @suppliderId varchar(20)	--供应商id
	declare @contractCode varchar(30)	--合同号
	declare @contractId int	--合同id
	
	declare p_cursor CURSOR FOR	
		select suppliderId from supplycenter..pro_purchase group by suppliderId
	
	open p_cursor
		FETCH NEXT FROM p_cursor INTO @suppliderId	
		WHILE @@FETCH_STATUS = 0
			begin
				exec  ERP..p_getProCode 1,@contractCode output
				--print 'contractCode='+@contractCode
				if exists (select 1 from supplyCenter..pro_contract where supliderId = @suppliderId)	--有合同则使用
					select  top 1 @contractId=id from supplyCenter..pro_contract where supliderId = @suppliderId
				else
					INSERT  into supplyCenter..pro_contract (contractCode,picId,supliderId)	--无合同则生成
					VALUES (@contractCode,0,@suppliderId)
					set @contractId = @@IDENTITY
					
				update supplycenter..pro_purchase set contractId = @contractId where suppliderId = @suppliderId	--更新采购单合同id
				
				FETCH NEXT FROM p_cursor INTO @suppliderId
			end
	CLOSE p_cursor--关闭游标
	DEALLOCATE p_cursor--释放游标
end
