-- =============================================
-- Author:		<runbin>
-- Create date: <2015-10-23>
-- Description:	<辅料颜色插入(所有编号都有的颜色)>
-- =============================================
CREATE PROCEDURE [dbo].[p_insertComponentChild]
@materialsId varchar(20),
@typeId int,
@componentId int
as

begin		
	
	declare @identifierId int	--编号id
	declare @sizeId int	--尺寸id
	declare @colorId int	--颜色id
	
	--编号游标
	declare p_cursor_identifier CURSOR FOR	
		select id from designCenter.materials.tb_materials_identifier where materialsId=@materialsId
	
	open p_cursor_identifier
		FETCH NEXT FROM p_cursor_identifier INTO @identifierId
		WHILE @@FETCH_STATUS = 0
			begin
				--尺寸游标	
				declare p_cursor_size CURSOR FOR	
					select a.id from designCenter.materials.tb_materials_size a 
						join designCenter.materials.tb_materials_identifier b on a.identifierId = b.id
						where b.materialsId=@materialsId and b.id = @identifierId
			
				open p_cursor_size 
				FETCH NEXT FROM p_cursor_size INTO @sizeId
				WHILE @@FETCH_STATUS = 0
					begin
					
						--颜色游标	
						declare p_cursor_color CURSOR FOR	
							select a.id from designCenter.materials.tb_materials_color a 
								join designCenter.materials.tb_materials_identifier b on a.identifierId = b.id
								where b.materialsId=@materialsId and b.id = @identifierId
					
						open p_cursor_color 
						FETCH NEXT FROM p_cursor_color INTO @colorId
						WHILE @@FETCH_STATUS = 0
							begin
								--是否重复
								if not exists (
								select 1 from designCenter.materials.tb_materials_component_child
								where typeId=@typeId and identifierId = @identifierId and componentId=@componentId
								and sizeId = @sizeId and colorId = @colorId)
								
								insert into designCenter.materials.tb_materials_component_child
								(typeId,identifierId,componentId,sizeId,colorId)
								values(@typeId,@identifierId,@componentId,@sizeId,@colorId)
								FETCH NEXT FROM p_cursor_color INTO @colorId
							end
							CLOSE p_cursor_color
							DEALLOCATE p_cursor_color
						FETCH NEXT FROM p_cursor_size INTO @sizeId
					end
					CLOSE p_cursor_size
					DEALLOCATE p_cursor_size
				FETCH NEXT FROM p_cursor_identifier INTO @identifierId
			end
	CLOSE p_cursor_identifier
	DEALLOCATE p_cursor_identifier	
		
end			

