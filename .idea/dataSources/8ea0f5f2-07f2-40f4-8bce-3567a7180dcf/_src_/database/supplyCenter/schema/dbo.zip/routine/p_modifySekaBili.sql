-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
create PROCEDURE [dbo].[p_modifySekaBili] 
	
AS
BEGIN
	declare cursor_modifySekaBili cursor for 
	select ID from designcenter.materials.tb_materials  where priceUnit=1
	open cursor_modifySekaBili
	declare @materialsId int ,@bili decimal(18,2),@storageAmount int,@storageKGAmount int
	FETCH NEXT FROM cursor_modifySekaBili into @materialsId
    WHILE @@FETCH_STATUS = 0
    begin
		select @storageAmount = SUM(storageAmount),@storageKGAmount = SUM(storageKGAmount) from supplycenter.materie.tb_materiePurchase where materielId = @materialsId 
		
		if(@storageAmount <> 0 and @storageKGAmount <> 0) 
		begin
			set @bili = cast(@storageKGAmount as decimal(18,8))/cast(@storageAmount as decimal(18,8))
			update designcenter.materials.tb_materials set bili = @bili where id = @materialsId
		end  
		
		FETCH NEXT FROM cursor_modifySekaBili into @materialsId
    end
END
