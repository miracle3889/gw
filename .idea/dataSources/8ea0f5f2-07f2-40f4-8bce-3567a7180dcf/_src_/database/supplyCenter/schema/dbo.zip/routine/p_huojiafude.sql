-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE p_huojiafude 
	
AS
BEGIN
begin tran 
begin try
	declare cursor_p_huojiafude cursor for 
	select materialsSkuId,SUM(storageAmount) storageAmount from supplycenter.materie.tb_shelfStorage where storageAmount < 0 group by materialsSkuId having count(id) = 1
	open cursor_p_huojiafude
	declare @materialsSkuId int,@storageAmount int,@storageAmount_cut int,@id int
	fetch next from cursor_p_huojiafude into @materialsSkuId,@storageAmount
	while @@FETCH_STATUS=0
	begin
		select top 1 @id = id,@storageAmount_cut = storageAmount from supplycenter.materie.tb_shelfStorage where materialsSkuId = @materialsSkuId  order by storageAmount desc
		if(@storageAmount_cut<-@storageAmount) set   @storageAmount = - @storageAmount_cut
		update supplycenter.materie.tb_shelfStorage set storageAmount = storageAmount - @storageAmount where materialsSkuId = @materialsSkuId and  storageAmount < 0
		update supplycenter.materie.tb_shelfStorage set storageAmount = storageAmount +@storageAmount where id = @id
		fetch next from cursor_p_huojiafude into @materialsSkuId,@storageAmount
	end
	CLOSE cursor_p_huojiafude
	DEALLOCATE cursor_p_huojiafude
	commit tran 
end try 
begin catch 
	 rollback tran 
	 declare @msg varchar(2000)
	 set @msg=error_message()
	 print @msg
	 --exec  ruhnnsystem.[dbo].[p_sendWeiXinMsg_title] '执行出错，回滚',@msg,829
	 insert into supplyCenter..tb_logs (msg)values(@msg)
	 select 0 as ret
end catch	
END
