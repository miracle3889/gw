-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[P_supplierContactMonth]
	
AS
BEGIN
	--TODO  -- select convert(varchar(7),dateadd(mm,-2,getdate()),120)
	--获得上个月的时间
	--获得上上个月的期末数
	--获得上个月的开票额，付款额
	--获得上上个月的期末数
	--获得上个月的到货额
	
	declare @startDate varchar(20) = '2016-08-01 00:00:00'
	declare @endDate varchar(20) = '2016-08-31 23:59:59'
	declare @date_lastMonth varchar(20)='2016-09',@date_lastTwoMonth varchar(20)='2016-08'
	
	
	
	
	--declare @date_lastMonth varchar(20),@date_lastTwoMonth varchar(20)
	--declare @startDate varchar(20),@endDate varchar(20)
	--select @date_lastMonth = convert(varchar(7),dateadd(mm,-1,getdate()),120)
	--select @date_lastTwoMonth = convert(varchar(7),dateadd(mm,-2,getdate()),120)
	-- select @startDate = convert(varchar(8),dateadd(mm,-1,getdate()),120) + '01'+' 00:00:00',
 --   @endDate = convert(varchar(10),cast(convert(varchar(8),getdate(),120) + '01' as datetime) - 1,120)+' 23:59:59' 
	
	declare cursor_supplider cursor for 
	select id,type from supermarket..pro_supliders where approvalStatus = 3
	open cursor_supplider
	declare @type int,@supliderId int,@earlyAccountsPayable bigint,@invoinceAmount bigint,@payAmount bigint
			,@endAccountPayable bigint,@earlyNotInvoinceAmount bigint,@instorageAmount bigint,@endInvoincePayable bigint
	fetch next from cursor_supplider into @supliderId,@type
	while @@FETCH_STATUS = 0
	begin
		--上上个月的期末数,期末应开票额
			select @earlyAccountsPayable = endAccountPayable,@earlyNotInvoinceAmount = endInvoincePayable from finance.store.tb_supplierContact_month where suppliderId = @supliderId and date = @date_lastTwoMonth
		if(@type = 2) 
		begin
			--物料供应商
			
			--上个月的开票额
			select @invoinceAmount = sum(a.priceMoney) from supplycenter.materie.tb_invoice_main a 
			   inner join (select documentId,MAX(approvalTime) approvalTime from supermarket..pro_approval group by documentId ) c on c.documentId = a.invoiceCode
			   where c.approvalTime>=@startDate and c.approvalTime<=@endDate  and a.approvalStatus = 1 and a.suppliderId = @supliderId
			
			--上个月的付款额
			select  @payAmount = SUM(cast(a.totalAmount as bigint))*1000000 from supplycenter.materie.tb_payment a
				inner join  (select documentId,MAX(approvalTime) approvalTime from supermarket..pro_approval group by documentId) b on a.payBatchId = b.documentId
				where a.approvalStatus = 3 and suppliderId =@supliderId  and b.approvalTime >=@startDate and b.approvalTime<=@endDate
			
			if(@earlyAccountsPayable is null ) set @earlyAccountsPayable = 0
			if(@invoinceAmount is null ) set @invoinceAmount = 0
			if(@payAmount is null ) set @payAmount = 0
			if(@earlyNotInvoinceAmount is null ) set @earlyNotInvoinceAmount = 0
			
			
			--算上个月期末应付账款
			set @endAccountPayable = @earlyAccountsPayable+@invoinceAmount-@payAmount
			
			--本期到货额
			select @instorageAmount = sum(cast(case when f.priceunit=0 then a.usefulNumber else a.usefullkgNumber end as bigint)*cast(d.taxPrice as bigint)*10000) from supplycenter.materie.tb_reciveRecord a
					inner join supplycenter.materie.tb_materiePurchase_child_pi b on a.materialPiId = b.id 
					inner join supplycenter.materie.tb_materiePurchase_child c on b.materielId = c.id 
					inner join supplycenter.materie.tb_materiePurchase d on d.id = c.purchaseId
					inner join designCenter.materials.tb_materials_sku e on e.id = c.materieChildId
					inner join designCenter.materials.tb_materials f on f.id = e.materialsId
			where a.status = 2 and a.storageTime>=@startDate and a.storageTime<=@endDate and d.suppliderId = @supliderId
			
			
		end
		else
		begin
		
			--成品供应商
		
			--上个月的开票额
			select @invoinceAmount = sum(a.priceMoney) from supplycenter..pro_invoice_main a 
			   inner join (select documentId,MAX(approvalTime) approvalTime from supplycenter..pro_approval group by documentId ) c on c.documentId = a.invoiceCode
			   where c.approvalTime>=@startDate and c.approvalTime<=@endDate  and a.approvalStatus = 1 and a.suppliderId = @supliderId
			
			--上个月的付款额
			select  @payAmount = SUM(cast(a.totalAmount as bigint))*1000000 from supplycenter..pro_payment a
				inner join  (select documentId,MAX(approvalTime) approvalTime from supplycenter..pro_approval group by documentId) b on a.payBatchId = b.documentId
				where a.approvalStatus = 3 and suppliderId = @supliderId  and b.approvalTime >=@startDate and b.approvalTime<=@endDate
			
			if(@earlyAccountsPayable is null ) set @earlyAccountsPayable = 0
			if(@invoinceAmount is null ) set @invoinceAmount = 0
			if(@payAmount is null ) set @payAmount = 0
			if(@earlyNotInvoinceAmount is null ) set @earlyNotInvoinceAmount = 0
			
			
			--算上个月期末应付账款
			set @endAccountPayable = @earlyAccountsPayable+@invoinceAmount-@payAmount
			
			--本期到货额 
			select  @instorageAmount = SUM(cast(a.storageAmount as bigint)*cast(b.taxPrice as bigint)*1000000) from supplycenter..pro_storage_child  a 
				inner join supplycenter..pro_purchase b on b.id = a.purchaseId
				inner join supplycenter..pro_storage c on a.factoryCode = c.factoryCode
			where b.suppliderId=@supliderId and c.inStorageTime >=@startDate and c.inStorageTime<=@endDate and a.storageAmount>0
			
			--本期退货额
			declare @refundAmount bigint
			select @refundAmount = SUM(cast(b.outAmount as bigint)*cast(d.taxPrice as bigint)*1000000) from supplycenter.product_refund.tb_outStorage a 
				inner join supplycenter.product_refund.tb_outStorage_child b on a.outCode = b.outCode
				inner join supplycenter.product_refund.tb_product_refund c on c.id = b.refundId
				inner join supplycenter.dbo.pro_purchase d on d.id = c.purchaseId
			where d.suppliderId = @supliderId and a.outStorageTime>=@startDate and a.outStorageTime<=@endDate
			
			if(@refundAmount is null ) set @refundAmount = 0
			
			--本期到货额 - 本期退货额	
			set @instorageAmount = @instorageAmount - @refundAmount
		end
		
		if(@instorageAmount is null ) set @instorageAmount = 0
		--期末应开发票
		set @endInvoincePayable =   @earlyNotInvoinceAmount+@instorageAmount-@invoinceAmount
		insert into finance.store.tb_supplierContact_month(date,suppliderId,earlyAccountsPayable,invoinceAmount,payAmount,endAccountPayable,earlyNotInvoinceAmount,instorageAmount,endInvoincePayable,type)
		values(@date_lastMonth,@supliderId,@earlyAccountsPayable,@invoinceAmount,@payAmount,@endAccountPayable,@earlyNotInvoinceAmount,@instorageAmount,@endInvoincePayable,@type)
		fetch next from cursor_supplider into @supliderId,@type
	end
	close cursor_supplider
	deallocate cursor_supplider
END
