
CREATE PROCEDURE [dbo].[deletePurchaseRecord] 
@id int
as

declare @childId int
declare @return int
set @return=1;
begin
begin tran

DECLARE  cs CURSOR FOR 
	
	SELECT id childId from supplyCenter.materie.tb_materiePurchase_child where purchaseId=@id
	
	OPEN cs
	FETCH NEXT FROM cs
	INTO @childId
	WHILE @@fetch_status =0
	BEGIN		

		delete from supplyCenter.materie.tb_materiePurchase_child_pi where materielId=@childId
	
		delete from supplyCenter.materie.tb_materiePurchase_child where id=@childId
		
		FETCH NEXT FROM cs
		INTO @childId
	END
	CLOSE cs
DEALLOCATE cs
delete from supplyCenter.materie.tb_materiePurchase where id=@id

if @@ERROR<>0
	begin
		set @return=0;
	    rollback tran
	end
commit tran
end
select @return as ret;
