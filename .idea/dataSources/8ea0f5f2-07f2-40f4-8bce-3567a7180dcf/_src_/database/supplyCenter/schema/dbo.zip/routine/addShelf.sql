-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
create PROCEDURE [dbo].[addShelf]
	 @area varchar(2),@begin int,@end int,@storeHouse int
AS
BEGIN
	declare @shelfCount int
	while @begin<=@end
	 begin
		select @shelfCount = COUNT(1) from supplycenter.materie.tb_shelf where shelfCode = @area+cast(@begin as varchar)
		if @shelfCount = 0 
		begin
			insert into supplycenter.materie.tb_shelf (area,row,col,layer,materialsStorehouseId,shelfCode)
					values(@area,1,1,1,@storeHouse,@area+cast(@begin as varchar))
			
		end
		set @begin = @begin+1
	 end
END