-- =============================================
-- Author:		taojun
-- Create date: 2016-08-10
-- Description:	<Description,,>
-- =============================================
create PROCEDURE [dbo].[P_MonthFirstStorage_sjw] 
	
AS
BEGIN
	declare @materialsId varchar(10),@storageAmount int,@purchaseInStorage int,@factoryOutStorage int,
	@noTaxInvoinceMoneyLastMonth bigint,@allNotGetInvoinceButInstorage bigint,
	@lastMonthZanGuInstorage bigint,@lastMonthCost bigint,@cost bigint,@localFirstStorageAmount int,
	@assistFirstStorageAmount int,@localInStorageAmount int ,@localOutStorageAmount int
	,@assistInstorageAmount int ,@assistOutStorageAmount int,@zanguRuku int,@zanguChuku int
	
	declare @startDate varchar(20) = '2017-06-01 00:00:00', @endDate varchar(20) = '2017-06-30 23:59:59'
	declare @thisMonthStartDate varchar(20) = '2017-07-01 00:00:00',@thisMonthEndDate varchar(20) = '2017-07-31 23:59:59'
	
	
	--更新 发票子表的不含税价 price
	update supplyCenter.materie.tb_invoice_next set price=b.price 
		 from  supplyCenter.materie.tb_invoice_next  a
				,(
				select b.id,b.unitPrice*100/(cast(replace(x.name,'%','') as int)+100) as price 
				from supplyCenter.materie.tb_invoice_main a 
				inner join supplyCenter.materie.tb_invoice_next b on a.invoiceCode = b.invoiceCode
				inner join (

				select * from erp..tb_code_base  where pid=41
				) x on x.id=a.taxId
		where b.price is null
	) b where a.id=b.id  and a.price is null
	
	
	declare cursor_materials cursor for 
		select id from designcenter.materials.tb_materials  order by id
	open cursor_materials
	FETCH NEXT FROM cursor_materials into @materialsId
    WHILE @@FETCH_STATUS = 0
    begin
		set @storageAmount =0
		set @purchaseInStorage = 0
		set @factoryOutStorage = 0
		set @noTaxInvoinceMoneyLastMonth =0
		set @allNotGetInvoinceButInstorage =0 
		set @lastMonthZanGuInstorage = 0
		set @lastMonthCost = 0 
		set @cost =0
		set @localFirstStorageAmount = 0 
		set @assistFirstStorageAmount = 0
		set @localInStorageAmount = 0 
		set @localOutStorageAmount = 0 
		set @assistInstorageAmount = 0
		set @assistOutStorageAmount = 0 
		set @zanguRuku = 0 
		set @zanguChuku = 0 
    
    
		--获取上个月的月初库存
		select 
			@storageAmount =  cast(  a.storageAmount  as bigint),--上月月底库存
			 @lastMonthZanGuInstorage = ISNULL(invoiceNotGetMoeny,0)--上月暂估金额
			,@lastMonthCost = ISNULL(   cost ,0)--上月成本
			,@localFirstStorageAmount = localFirstStorageAmount 
			,@assistFirstStorageAmount = assistFirstStorageAmount
		from finance.store.tb_materialsMonthCost a inner join 
		designcenter.materials.tb_materials b on a.materials = b.id
		 where a.MONTH>=@startDate and a.MONTH<=@endDate and a.materials = @materialsId
 
		--获取上个月的采购入库
		select @purchaseInStorage = isnull(SUM(amount),0)  from 	
		finance.store.tb_inStoreDocuments_child   
		where  instoreDate >=@startDate and instoreDate<=@endDate and code = @materialsId 
		and instorebatchId in (
			select instorebatchId from finance.store.tb_inStoreDocuments where  productType = 3
		)
		
		--获取上个月的工厂出库
		select @factoryOutStorage = isnull(SUM(amount),0) from finance.store.tb_outStoreDocuments_child  a
		   inner join finance.store.tb_outStoreDocuments b on a.outStoreBatchId = b.outStoreBatchId 
			where a.outStoreDate  >=@startDate and a.outStoreDate<@endDate and a.code = @materialsId and b.productType = 4 and b.documentsType<>17
	
		--获取原料仓的上个月入库数
		select @localInStorageAmount=SUM(b.amount) from finance.store.tb_inStoreDocuments a
			inner join finance.store.tb_inStoreDocuments_child b on a.inStoreBatchId = b.inStoreBatchId
		where b.code = @materialsId and a.inStoreDate>=@startDate and a.inStoreDate<=@endDate and a.productType=3
		
		--获取原料仓上个月出库数
		select @localOutStorageAmount=SUM(b.amount) from finance.store.tb_outStoreDocuments a
		inner join finance.store.tb_outStoreDocuments_child b on a.outStoreBatchId = b.outStoreBatchId
		where b.code = @materialsId and a.outStoreDate>=@startDate and a.outStoreDate<=@endDate and a.productType = 3
		
		--获取委外加工物资上个月的入库数
		select @assistInstorageAmount=SUM(b.amount) from finance.store.tb_inStoreDocuments a
			inner join finance.store.tb_inStoreDocuments_child b on a.inStoreBatchId = b.inStoreBatchId
		where b.code = @materialsId and a.inStoreDate>=@startDate and a.inStoreDate<=@endDate and a.productType=4
		
		--获取委外加工物资上个月的出库数
		select @assistOutStorageAmount=SUM(b.amount) from finance.store.tb_outStoreDocuments a
		inner join finance.store.tb_outStoreDocuments_child b on a.outStoreBatchId = b.outStoreBatchId
		where b.code = @materialsId and a.outStoreDate>=@startDate and a.outStoreDate<=@endDate and a.productType = 4 and a.documentsType<>17
	
		--获取委外加工物资上个月的暂估出库数
		--select @zanguChuku=SUM(b.amount) from finance.store.tb_outStoreDocuments a
		--inner join finance.store.tb_outStoreDocuments_child b on a.outStoreBatchId = b.outStoreBatchId
		--where b.code = @materialsId and a.outStoreDate>=@startDate and a.outStoreDate<=@endDate and a.productType = 4 and a.documentsType=17
		
		
		--获取委外加工物资上个月的暂估入库数
		--select @zanguRuku=SUM(-b.amount) from finance.store.tb_outStoreDocuments a
		--inner join finance.store.tb_outStoreDocuments_child b on a.outStoreBatchId = b.outStoreBatchId
		--where b.code = @materialsId and a.outStoreDate>=@startDate and a.outStoreDate<=@endDate and a.productType = 4 and a.documentsType=18
		
		
		if @storageAmount is null set @storageAmount = 0
		if @lastMonthZanGuInstorage is null set @lastMonthZanGuInstorage = 0
		if @lastMonthCost is null set @lastMonthCost = 0
		if @purchaseInStorage is null set @purchaseInStorage = 0
		if @factoryOutStorage is null set @factoryOutStorage = 0
		
		if @localFirstStorageAmount is null set @localFirstStorageAmount = 0
		if @assistFirstStorageAmount is null set @assistFirstStorageAmount = 0
		if @localInStorageAmount is null set @localInStorageAmount =0
		if @localOutStorageAmount is null set @localOutStorageAmount = 0
		if @assistInstorageAmount is null set @assistInstorageAmount = 0
		if @assistOutStorageAmount is null set @assistOutStorageAmount = 0
		if @zanguChuku is null set @zanguChuku = 0
		if @zanguRuku is null set @zanguRuku = 0
		set @zanguRuku = 0
		set @zanguChuku = 0
		--插入这个月的月初库存
		insert into finance.store.tb_materialsMonthCost(month,materials,purchaseInStorage,factoryOutStorage,storageAmount,localFirstStorageAmount,assistFirstStorageAmount,localInAmount,localOutAmount,assistInAmount,assistOutAmount,zanguChuku,zanguRuku)
		values(@thisMonthStartDate,@materialsId,@purchaseInStorage,@factoryOutStorage,@storageAmount+@localInStorageAmount-@localOutStorageAmount+@assistInstorageAmount-@assistOutStorageAmount,@localFirstStorageAmount+@localInStorageAmount-@localOutStorageAmount,@assistFirstStorageAmount+@assistInstorageAmount-@assistOutStorageAmount,
		@localInStorageAmount,@localOutStorageAmount,@assistInstorageAmount,@assistOutStorageAmount,@zanguChuku,@zanguRuku)
		
		declare @tolastMonthInvoinceReal bigint 
		declare @lastMonthInvoinceJInxiaocun bigint
		
		declare @invoinceCha bigint
		
		---计算上个月之前拿到的发票数真实
		select 
			@tolastMonthInvoinceReal = isnull(sum(price*cast(b.amount as bigint)/100),0) 
		from supplyCenter.materie.tb_invoice_main a
			inner join supplyCenter.materie.tb_invoice_next b on a.invoiceCode = b.invoiceCode 
			inner join supplyCenter.materie.tb_materiePurchase c on b.purchaseId = c.id and c.materielId = @materialsId
			inner join (select documentId,MAX(approvalTime) approvalTime from supermarket..pro_approval group by documentId)d on d.documentId = a.invoiceCode 
		where d.approvalTime < @startDate  and a.approvalStatus=1
		
		--计算进销存中发票数
		select @lastMonthInvoinceJInxiaocun = SUM(invoiceGetMoney) from finance.store.tb_materialsMonthCost where materials = @materialsId
		
		if @tolastMonthInvoinceReal is null set @tolastMonthInvoinceReal = 0
		if @lastMonthInvoinceJInxiaocun is null set @lastMonthInvoinceJInxiaocun = 0
		
		set @invoinceCha = @tolastMonthInvoinceReal - @lastMonthInvoinceJInxiaocun
		
		--计算上个月拿到发票的总数
		select 
			@noTaxInvoinceMoneyLastMonth = isnull(sum(price*cast(b.amount as bigint)/100),0) 
		from supplyCenter.materie.tb_invoice_main a
			inner join supplyCenter.materie.tb_invoice_next b on a.invoiceCode = b.invoiceCode 
			inner join supplyCenter.materie.tb_materiePurchase c on b.purchaseId = c.id and c.materielId = @materialsId
			inner join (select documentId,MAX(approvalTime) approvalTime from supermarket..pro_approval group by documentId)d on d.documentId = a.invoiceCode 
		where d.approvalTime >= @startDate and d.approvalTime < @endDate and a.approvalStatus=1
	  	
	  	
	  	
	  	
	  	
	  	
	  	--计算所有已入库，但是没拿到发票的金额
		--select	@allNotGetInvoinceButInstorage = SUM(cast(c.unitPrice as bigint)*(x.instorageAmount-isnull(d.invoinceAmount,0)))*10000 
		--from (
		--	select a.documentsBatchId,SUM(a.amount) instorageAmount from finance.store.tb_inStoreDocuments_child a 
		--		inner join finance.store.tb_inStoreDocuments b on a.inStoreBatchId = b.inStoreBatchId
		--	where b.documentsType = 12 and a.code = @materialsId and a.inStoreDate<@thisMonthStartDate group by a.documentsBatchId
		--) x 
		--inner join supplycenter.materie.tb_materiePurchase c on c.purchaseCode = x.documentsBatchId
		--left join (
		--	select purchaseId,SUM(a.amount) as  invoinceAmount
		--	from  supplyCenter.materie.tb_invoice_next a 
		--	  inner join supplyCenter.materie.tb_invoice_main b on a.invoiceCode = b.invoiceCode 
		--	  inner join (select documentId,MAX(approvalTime) approvalTime from supermarket..pro_approval group by documentId)d on d.documentId = a.invoiceCode 
		--	  where b.approvalStatus=1   	and d.approvalTime < @endDate  group by purchaseId
		-- ) d on d.purchaseId = c.id 
		
		
		select @allNotGetInvoinceButInstorage = sum((x.storageAmount-isnull(z.outAmount,0)-ISNULL(y.amount,0))*10000.0*x.unitPrice)  
			
			 from (
				select a.id,a.unitPrice,
				case when e.priceUnit = 0   then SUM(d.usefulNumber) else SUM(d.usefullKGNumber)  end storageAmount
				 from supplycenter.materie.tb_materiePurchase a
				inner join supplycenter.materie.tb_materiePurchase_child b on a.id = b.purchaseId
				inner join supplycenter.materie.tb_materiePurchase_child_pi c on c.materielId = b.id
				inner join supplycenter.materie.tb_reciveRecord d on d.materialPiId = c.id
				inner join designcenter.materials.tb_materials e on e.id = a.materielId
				where d.status =2  and d.storageTime<@thisMonthStartDate
				group by a.id,a.unitPrice,e.priceUnit
			)x 
			left join (
				
			select   a.id as purchaseId,  sum(b.amount)  as  amount
				from supplycenter.materie.tb_materiePurchase a
				inner join supplycenter.materie.tb_invoice_next b  on a.id=b.purchaseId
				inner join supplycenter.materie.tb_invoice_main c on c.invoiceCode=b.invoiceCode 
				and c.approvalStatus = 1   
				inner join (
				select documentId,MAX(approvalTime) approvalTime from supermarket..pro_approval 
				group by documentId ) d  on d.documentId=c.invoiceCode
				and   d.approvalTime<@thisMonthStartDate
				 group by  a.id 
			)y on x.id = y.purchaseId
			left join (
				select c.purchaseId,SUM(case when e.priceUnit = 0 then b.outStorageAmount else b.outStorageKgAmount end) outAmount from supplycenter.material_refund.tb_material_refund_outStorage a
					inner join supplycenter.material_refund.tb_material_refund_outStorage_child b on a.id = b.outStorageId
					inner join supplycenter.material_refund.tb_material_refund c on c.id = a.materialRefundId
					inner join supplycenter.materie.tb_materiePurchase d on d.id = c.purchaseId
					inner join designcenter.materials.tb_materials e on e.id = d.materielId
				where a.outStorageTime<@thisMonthStartDate
				group by c.purchaseId
			)z on z.purchaseId = x.id
			inner join supplycenter.materie.tb_materiePurchase zz on zz.id = x.id
			where zz.materielId = @materialsId
			
			
			
		
		
		
		if @allNotGetInvoinceButInstorage is null or @allNotGetInvoinceButInstorage<0 set @allNotGetInvoinceButInstorage = 0
		if @noTaxInvoinceMoneyLastMonth is null set @noTaxInvoinceMoneyLastMonth = 0
		
		
		if(@localInStorageAmount+@storageAmount+@zanguRuku)=0 set @cost = @lastMonthCost
		else
		 set @cost  = (@noTaxInvoinceMoneyLastMonth + @allNotGetInvoinceButInstorage +@invoinceCha - @lastMonthZanGuInstorage +cast(@storageAmount+@zanguRuku as float)/100*@lastMonthCost)/(cast (@localInStorageAmount as float)+cast (@zanguRuku as float)+ cast (@storageAmount as float))*100
		
		update finance.store.tb_materialsMonthCost 
			set invoiceGetMoney = @noTaxInvoinceMoneyLastMonth,
			invoiceNotGetMoeny = @allNotGetInvoinceButInstorage,
			cost = @cost,costkg = @cost,
			invoinceCha = @invoinceCha,
			yuechukucun = @storageAmount
		where materials = @materialsId and month>=@thisMonthStartDate and month<=@thisMonthEndDate
		FETCH NEXT FROM cursor_materials into @materialsId
	end
	--关闭游标
	CLOSE cursor_materials
	--释放资源
	DEALLOCATE cursor_materials	
	
	--更新公斤价格
--	update finance.store.tb_materialsMonthCost set cost = costkg *x.bili
--from finance.store.tb_materialsMonthCost a inner join (
--	select a.month,a.materials,b.bili from  finance.store.tb_materialsMonthCost a 
--	inner join designcenter.materials.tb_materials b on a.materials = b.id and b.priceUnit = 1
--)x on x.materials = a.materials and x.month = a.month
 end
