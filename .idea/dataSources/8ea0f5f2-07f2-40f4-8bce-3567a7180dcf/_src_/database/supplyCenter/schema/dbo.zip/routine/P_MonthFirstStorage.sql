-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[P_MonthFirstStorage] 
	
AS
BEGIN
	-- select * from finance.store.tb_materialsMonthCost where storageAmount<0 order by materials
	-- delete from finance.store.tb_materialsMonthCost
	
	
	
	declare @startDate varchar(20) = '2016-06-01 00:00:00', @endDate varchar(20) = '2016-06-30 23:59:59'
	declare @thisMonthStartDate varchar(20) = '2016-07-01 00:00:00',@thisMonthEndDate varchar(20) = '2016-07-31 23:59:59'
	
	--select convert(varchar(8),dateadd(mm,0,getdate()),120) + '01'+' 00:00:00',convert(varchar(10),cast(convert(varchar(8),getdate(),120) + '01' as datetime) - 2,120)+' 23:59:59'
	
	--declare @startDate varchar(20),@endDate varchar(20)
	--declare @thisMonthStartDate varchar(20),@thisMonthEndDate varchar(20)
	--select @startDate = convert(varchar(8),dateadd(mm,-1,getdate()),120) + '01'+' 00:00:00',
 --      @endDate = convert(varchar(10),cast(convert(varchar(8),getdate(),120) + '01' as datetime) - 1,120)+' 23:59:59' 
  
 --   select @thisMonthStartDate =  convert(varchar(8),dateadd(mm,0,getdate()),120) + '01'+' 00:00:00',
	--	@thisMonthEndDate = convert(varchar(8),dateadd(mm,0,getdate()),120) + '01'+' 23:59:59'
	declare cursor_materials cursor for 
	select id from designcenter.materials.tb_materials
	open cursor_materials
	declare @materialsId varchar(10),@storageAmount int,@purchaseInStorage int,@factoryOutStorage int,
	@noTaxInvoinceMoneyLastMonth bigint,@allNotGetInvoinceButInstorage bigint,
	@lastMonthZanGuInstorage bigint,@lastMonthCost bigint,@cost bigint,@localFirstStorageAmount int,
	@assistFirstStorageAmount int,@localInStorageAmount int ,@localOutStorageAmount int
	,@assistInstorageAmount int ,@assistOutStorageAmount int,@zanguRuku int,@zanguChuku int
	FETCH NEXT FROM cursor_materials into @materialsId
    WHILE @@FETCH_STATUS = 0
    begin
		--获取上个月的月初库存
		
		
		select 
			@storageAmount = isnull(storageAmount,0),@lastMonthZanGuInstorage = ISNULL(invoiceNotGetMoeny,0)
			,@lastMonthCost = ISNULL(cost,0)
			,@localFirstStorageAmount = localFirstStorageAmount
			,@assistFirstStorageAmount = assistFirstStorageAmount
		from finance.store.tb_materialsMonthCost where MONTH>=@startDate and MONTH<=@endDate and materials = @materialsId
 
		--获取上个月的采购入库
		select @purchaseInStorage = isnull(SUM(amount),0)  from 	finance.store.tb_inStoreDocuments_child   
		where  instoreDate >=@startDate and instoreDate<=@endDate and code = @materialsId 
		and instorebatchId in (
			select instorebatchId from finance.store.tb_inStoreDocuments where documentstype = 12 and productType = 3
		) 
		--获取上个月的工厂出库
		select @factoryOutStorage = isnull(SUM(amount),0) from finance.store.tb_outStoreDocuments_child  a
		   inner join finance.store.tb_outStoreDocuments b on a.outStoreBatchId = b.outStoreBatchId 
			where a.outStoreDate  >=@startDate and a.outStoreDate<@endDate and a.code = @materialsId and b.productType = 4
	
		--获取原料仓的上个月入库数
		select @localInStorageAmount=SUM(b.amount) from finance.store.tb_inStoreDocuments a
			inner join finance.store.tb_inStoreDocuments_child b on a.inStoreBatchId = b.inStoreBatchId
		where b.code = @materialsId and a.inStoreDate>=@startDate and a.inStoreDate<=@endDate and a.productType=3
		
		--获取原料仓上个月出库数
		select @localOutStorageAmount=SUM(b.amount) from finance.store.tb_outStoreDocuments a
		inner join finance.store.tb_outStoreDocuments_child b on a.outStoreBatchId = b.outStoreBatchId
		where b.code = @materialsId and a.outStoreDate>=@startDate and a.outStoreDate<=@endDate and a.productType = 3
		
		--获取委外加工物资上个月的入库数
		select @assistInstorageAmount=SUM(b.amount) from finance.store.tb_inStoreDocuments a
			inner join finance.store.tb_inStoreDocuments_child b on a.inStoreBatchId = b.inStoreBatchId
		where b.code = @materialsId and a.inStoreDate>=@startDate and a.inStoreDate<=@endDate and a.productType=4
		
		--获取委外加工物资上个月的出库数
		select @assistOutStorageAmount=SUM(b.amount) from finance.store.tb_outStoreDocuments a
		inner join finance.store.tb_outStoreDocuments_child b on a.outStoreBatchId = b.outStoreBatchId
		where b.code = @materialsId and a.outStoreDate>=@startDate and a.outStoreDate<=@endDate and a.productType = 4
	
		--获取委外加工物资上个月的暂估出库数
		select @zanguChuku=SUM(b.amount) from finance.store.tb_outStoreDocuments a
		inner join finance.store.tb_outStoreDocuments_child b on a.outStoreBatchId = b.outStoreBatchId
		where b.code = @materialsId and a.outStoreDate>=@startDate and a.outStoreDate<=@endDate and a.productType = 4 and a.documentsType=17
		
		--获取委外加工物资上个月的暂估入库数
		select @zanguRuku=SUM(-b.amount) from finance.store.tb_outStoreDocuments a
		inner join finance.store.tb_outStoreDocuments_child b on a.outStoreBatchId = b.outStoreBatchId
		where b.code = @materialsId and a.outStoreDate>=@startDate and a.outStoreDate<=@endDate and a.productType = 4 and a.documentsType=18
		
		if @storageAmount is null set @storageAmount = 0
		if @lastMonthZanGuInstorage is null set @lastMonthZanGuInstorage = 0
		if @lastMonthCost is null set @lastMonthCost = 0
		if @purchaseInStorage is null set @purchaseInStorage = 0
		if @factoryOutStorage is null set @factoryOutStorage = 0
		
		if @localFirstStorageAmount is null set @localFirstStorageAmount = 0
		if @assistFirstStorageAmount is null set @assistFirstStorageAmount = 0
		if @localInStorageAmount is null set @localInStorageAmount =0
		if @localOutStorageAmount is null set @localOutStorageAmount = 0
		if @assistInstorageAmount is null set @assistInstorageAmount = 0
		if @assistOutStorageAmount is null set @assistOutStorageAmount = 0
		--插入这个月的月初库存
		insert into finance.store.tb_materialsMonthCost(month,materials,purchaseInStorage,factoryOutStorage,storageAmount,localFirstStorageAmount,assistFirstStorageAmount,localInAmount,localOutAmount,assistInAmount,assistOutAmount,zanguChuku,zanguRuku)
		values(@thisMonthStartDate,@materialsId,@purchaseInStorage,@factoryOutStorage,@storageAmount+@purchaseInStorage-@factoryOutStorage,@localFirstStorageAmount+@localInStorageAmount-@localOutStorageAmount,@assistFirstStorageAmount+@assistInstorageAmount-@assistOutStorageAmount,
		@localInStorageAmount,@localOutStorageAmount,@assistInstorageAmount,@assistOutStorageAmount,@zanguChuku,@zanguRuku)
		
		
		--计算上个月拿到发票的总数
		select 
			@noTaxInvoinceMoneyLastMonth = isnull(sum(cast(b.unitPrice/(cast(replace(e.name,'%','') as decimal(18,2))/100) as bigint)*cast(b.amount as bigint)*10000),0) 
		from supplyCenter.materie.tb_invoice_main a
			inner join supplyCenter.materie.tb_invoice_next b on a.invoiceCode = b.invoiceCode 
			inner join supplyCenter.materie.tb_materiePurchase c on b.purchaseId = c.id and c.materielId = @materialsId
			inner join (select documentId,MAX(approvalTime) approvalTime from supermarket..pro_approval group by documentId)d on d.documentId = a.invoiceCode
			inner join erp..tb_code_base e on e.id = a.taxId and e.pid = 41
		where d.approvalTime >= @startDate
	  	and d.approvalTime < @startDate and a.approvalStatus=1
	  	
	  	--计算所有已入库，但是没拿到发票的金额
	  	 
		select	@allNotGetInvoinceButInstorage = SUM(cast(c.unitPrice as bigint)*CAST(x.instorageAmount as bigint)*10000-isnull(d.invoincePrice,0)) 
		from (
			select a.documentsBatchId,SUM(a.amount) instorageAmount from finance.store.tb_inStoreDocuments_child a 
				inner join finance.store.tb_inStoreDocuments b on a.inStoreBatchId = b.inStoreBatchId
			where b.documentsType = 12 and a.code = @materialsId  group by a.documentsBatchId
		) x 
		inner join supplycenter.materie.tb_materiePurchase c on c.purchaseCode = x.documentsBatchId
		left join (
			select purchaseId,SUM(cast(a.unitPrice/(cast(replace(e.name,'%','') as decimal(18,2))/100) as bigint)*cast(a.amount as bigint)/100) invoincePrice 
			from  supplyCenter.materie.tb_invoice_next a 
			  inner join supplyCenter.materie.tb_invoice_main b on a.invoiceCode = b.invoiceCode 
			  inner join erp..tb_code_base e on e.id = b.taxId and e.pid = 41
			  where b.approvalStatus=1  group by purchaseId
		 ) d on d.purchaseId = c.id 
		
		if @allNotGetInvoinceButInstorage is null set @allNotGetInvoinceButInstorage = 0
		if @noTaxInvoinceMoneyLastMonth is null set @noTaxInvoinceMoneyLastMonth = 0
		
		if(@purchaseInStorage+@storageAmount+@zanguRuku)=0 set @cost = 0
		else set @cost  = (@noTaxInvoinceMoneyLastMonth + @allNotGetInvoinceButInstorage - @lastMonthZanGuInstorage +cast(@storageAmount as float)/100*@lastMonthCost)/(cast (@purchaseInStorage as float)+cast (@zanguRuku as float)+ cast (@storageAmount as float))*100
		
		update finance.store.tb_materialsMonthCost 
			set invoiceGetMoney = @noTaxInvoinceMoneyLastMonth,
			invoiceNotGetMoeny = @allNotGetInvoinceButInstorage,
			cost = @cost
		where materials = @materialsId and month>=@thisMonthStartDate and month<=@thisMonthEndDate
		FETCH NEXT FROM cursor_materials into @materialsId
	end
	--关闭游标
	CLOSE cursor_materials
	--释放资源
	DEALLOCATE cursor_materials	
 end
