-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[p_deletePurchase] 
	@id int,@userId int
AS
BEGIN
begin tran 
begin try

	declare @instorageAmount int,@oldStorageAmount int,@materieChildId int ,@isbig int ,@shelfCode varchar(20)
			,@taskId int,@groupId int
			
	select @groupId = groupId from ERP..tb_user where id = @userId 
	
	select @isbig = SUM(x.isbig) from (
		select b.materieChildId,case when SUM(d.usefulNumber)>MIN(y.storageAmount) then -1 else 0 end isbig  from supplycenter.materie.tb_materiePurchase a
				inner join supplycenter.materie.tb_materiePurchase_child b on b.purchaseId = a.id 
				inner join supplycenter.materie.tb_materiePurchase_child_pi c on c.materielId = b.id
				inner join supplycenter.materie.tb_reciveRecord d on d.materialPiId = c.id
				inner join designcenter.materials.tb_materials_sku y on y.id = b.materieChildId
			where a.id = @id and d.status=2 group by b.materieChildId
	)x
	
	--如果入库数大于现有库存  不能删
	if(@groupId<>1) select 3 as ret
	else if(@isbig <0 or @id is null) select 2 as ret
	else
	begin
		--查询色号已入库数量
		declare cursor_deletePurchase cursor for
		
		select b.materieChildId,d.shelfCode,SUM(d.usefulNumber) storageAmount,min(a.materiepurchase_task) taskId
		from supplycenter.materie.tb_materiePurchase a
			inner join supplycenter.materie.tb_materiePurchase_child b on b.purchaseId = a.id 
			inner join supplycenter.materie.tb_materiePurchase_child_pi c on c.materielId = b.id
			inner join supplycenter.materie.tb_reciveRecord d on d.materialPiId = c.id
		where a.id = @id and d.status=2 group by b.materieChildId,d.shelfCode
		declare @ocAmount int,@zhanyongAmount int,@releaseAmount int
		open cursor_deletePurchase
		fetch next from cursor_deletePurchase into @materieChildId,@shelfCode,@instorageAmount,@taskId
		while @@FETCH_STATUS=0
		begin
			if(@taskId<>0 and exists (select * from supplycenter.materie.tb_materie_OccupancyInventory where taskId = @taskId and materieSkuId = @materieChildId))
			begin
				 select @zhanyongAmount = isnull(SUM(b.count+b.releaseCount),0)   from supplycenter.materie.tb_materiePurchase_task a
					left  join supplycenter.materie.tb_materie_OccupancyInventory b on a.id = b.taskId
				 where a.id = @taskId and b.materieSkuId = @materieChildId
				 
				  select @releaseAmount = SUM(c.amount) from supplycenter.materie.tb_materiePurchase_task a
					   inner join supplycenter.production.tb_production_task b on a.id = b.purchaseTaskId
					   inner join supplycenter.materie.tb_material_pickupRecord c on c.produceTaskId = b.id
						where a.id = @taskId and c.materialSkuId = @materieChildId
						
				 if(@releaseAmount is null ) set @releaseAmount = 0
				 if(@zhanyongAmount-@releaseAmount<@instorageAmount)
				 begin
					select 2 as ret
					CLOSE cursor_deletePurchase
					DEALLOCATE cursor_deletePurchase
					RAISERROR ('采购单删除失败，采购单所对应的采购任务的可用数不够', -- Message text.
						16, -- Severity.
						1 -- State.
					)
			end
			end
			if(@taskId=0)  set @ocAmount = 0
			else
			begin
				set @ocAmount = @instorageAmount
			end
			
			--增加shelfstorage
			update supplycenter.materie.tb_shelfStorage set storageAmount=storageAmount-@instorageAmount 
				where shelfCode = @shelfCode and materialsSkuId = @materieChildId and storageAmount-@instorageAmount>=0
			if(@@ROWCOUNT<=0)
			begin
				select 2 as ret
				CLOSE cursor_deletePurchase
		DEALLOCATE cursor_deletePurchase
				RAISERROR ('采购单删除失败，入库的货架没有库存了', -- Message text.
				16, -- Severity.
				1 -- State.
				)
			end
			
			--更新占用记录(直接删记录)
			--update supplycenter.materie.tb_materie_OccupancyInventory set count = count-@ocAmount 
			--	where purchaseId = @purchaseId and materieSkuId = @materieChildId
				
			--更新色号表
			update designcenter.materials.tb_materials_sku set storageAmount = storageAmount-@instorageAmount,occupancyAmount = occupancyAmount-@ocAmount where id = @materieChildId and  occupancyAmount-@ocAmount>=0
			if(@@ROWCOUNT<=0)
			begin
				select 2 as ret
				CLOSE cursor_deletePurchase
		DEALLOCATE cursor_deletePurchase
				RAISERROR ('采购单删除失败，占用数不够', -- Message text.
				16, -- Severity.
				1 -- State.
				)
			end
			
			insert into supplyCenter.materie.tb_materialStorageRecord(amount,skuId,taskId,type,userId,price,oldAmount)
			values(-@instorageAmount,@materieChildId,-1,-1,@userId,-1,-1)
			fetch next from cursor_deletePurchase into @materieChildId,@shelfCode,@instorageAmount,@taskId
		end
		
		--删除入库记录
		delete from supplycenter.materie.tb_reciveRecord where id in (
		select a.id from supplycenter.materie.tb_reciveRecord a
			inner join supplycenter.materie.tb_materiePurchase_child_pi b on a.materialPiId = b.id
			inner join supplycenter.materie.tb_materiePurchase_child c on b.materielId = c.id 
		where c.purchaseId = @id)
		--删pi
		delete from supplycenter.materie.tb_materiePurchase_child_pi where id in (
			select a.id from supplycenter.materie.tb_materiePurchase_child_pi a
				inner join supplycenter.materie.tb_materiePurchase_child b on  a.materielId = b.id 
			where b.purchaseId = @id
		)
		
		--删child
		delete from supplycenter.materie.tb_materiePurchase_child where purchaseId = @id
		
		--删占用表
		delete from supplycenter.materie.tb_materie_OccupancyInventory where purchaseId = @id
		
		--删采购单
		delete from supplycenter.materie.tb_materiePurchase where id = @id
		
		
		select 1 as ret
		CLOSE cursor_deletePurchase
		DEALLOCATE cursor_deletePurchase
	end
	
	commit tran 
end try 
begin catch 
	 rollback tran 
	 declare @msg varchar(2000)
	 set @msg=error_message()+cast(@id as varchar(10))
	 print @msg
	 --exec  ruhnnsystem.[dbo].[p_sendWeiXinMsg_title] '执行出错，回滚',@msg,829
	 insert into supplyCenter..tb_logs (msg)values(@msg)
	 select 0 as ret
end catch
	
	
	
END
