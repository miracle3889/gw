CREATE PROCEDURE [dbo].[p_panku]
as
declare @intAmount int,@sku int ,@retPickupRecordId int,@retExportRecordId int,
@shelfStorageId int,@shelfStorageCode varchar(50),@shelfStorageAmount int
begin
		DECLARE  cs CURSOR FOR 
		--查询
		select cast(amount*100 as int) intAmount ,sku  from supplycenter..sp_export where done is null
		OPEN cs
		FETCH NEXT FROM cs
		INTO @intAmount,@sku
		WHILE @@fetch_status =0
		BEGIN		
			if((select SUM(storageAmount) sta from supplycenter.materie.tb_shelfStorage where materialsSkuId=@sku)>=@intAmount)
			begin
			--select * from supplycenter.materie.tb_material_pickupRecord
				insert into supplycenter.materie.tb_material_pickupRecord (produceTaskId,materialSkuId,pCodeFabricProtityId,amount,status,updateTime,remarkId,applyTime,isAdd,applyUserId,assistId,remark)
				values (0,@sku,0,@intAmount,5,GETDATE(),0,GETDATE(),0,355,0,'panku2');
				set @retPickupRecordId=SCOPE_IDENTITY();
				insert into supplyCenter.materie.tb_material_exportRecord (pickupRecordId,exportUserId,exportTime,signUserId,signTime,amount)
				values (@retPickupRecordId,355,GETDATE(),355,GETDATE(),@intAmount)
				set @retExportRecordId=SCOPE_IDENTITY();
				
				
				DECLARE  cs2 CURSOR FOR 
				select id,shelfCode,storageAmount from supplycenter.materie.tb_shelfStorage where materialsSkuId=@sku and storageAmount>0 order by storageAmount desc
				OPEN cs2
				FETCH NEXT FROM cs2
				INTO @shelfStorageId,@shelfStorageCode,@shelfStorageAmount
				WHILE @@FETCH_STATUS =0
				BEGIN
					begin
						if @intAmount = 0 break
						if @intAmount>=@shelfStorageAmount
						begin
							update supplycenter.materie.tb_shelfStorage set storageAmount = 0 where id = @shelfStorageId
							set @intAmount = @intAmount - @shelfStorageAmount
							--chu ku zi biao
							insert into supplycenter.materie.tb_material_exportRecord_child(exportRecordId,shelfCode,amount)
							values(@retExportRecordId,@shelfStorageCode,@shelfStorageAmount)
							
							--select * from supplycenter.materie.tb_material_exportRecord_child
							--todo
						end
						else if @intAmount<@shelfStorageAmount
						begin
							update supplycenter.materie.tb_shelfStorage set storageAmount = storageAmount - @intAmount where id = @shelfStorageId
							--todo
							--chu ku zi biao
							
							insert into supplycenter.materie.tb_material_exportRecord_child(exportRecordId,shelfCode,amount)
							values(@retExportRecordId,@shelfStorageCode,@intAmount)
							set @intAmount = 0
						end
					end
					FETCH NEXT FROM cs2 INTO @shelfStorageId,@shelfStorageCode,@shelfStorageAmount
				END
				CLOSE cs2
				DEALLOCATE cs2
			end
			update supplycenter..sp_export set done = 1 where sku = @sku
			FETCH NEXT FROM cs INTO @intAmount,@sku
		END
		CLOSE cs
		DEALLOCATE cs
end