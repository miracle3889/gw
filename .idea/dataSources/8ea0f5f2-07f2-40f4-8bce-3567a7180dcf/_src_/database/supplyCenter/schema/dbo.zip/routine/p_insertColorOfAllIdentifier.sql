-- =============================================
-- Author:		<runbin>
-- Create date: <2015-10-23>
-- Description:	<辅料颜色插入(所有编号都有的颜色)>
-- =============================================
CREATE PROCEDURE [dbo].[p_insertColorOfAllIdentifier]
@materialsId varchar(20),
@color varchar(20)
as

begin		
	
	declare @identifierId int	--编号id
	
	declare p_cursor CURSOR FOR	
		select id from designCenter.materials.tb_materials_identifier where materialsId=@materialsId
	
	open p_cursor
		FETCH NEXT FROM p_cursor INTO @identifierId
		WHILE @@FETCH_STATUS = 0
			begin
				insert into designCenter.materials.tb_materials_color(identifierId,colorCode,name)
					values(@identifierId,@color,@color)
				FETCH NEXT FROM p_cursor INTO @identifierId
			end
	CLOSE p_cursor--关闭游标
	DEALLOCATE p_cursor--释放游标			
end			

