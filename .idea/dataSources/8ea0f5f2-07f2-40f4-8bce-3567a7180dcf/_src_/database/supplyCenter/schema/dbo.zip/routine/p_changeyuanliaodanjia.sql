-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[p_changeyuanliaodanjia]
AS
BEGIN
	declare @price int
	declare @purchaseCode varchar(100)
	declare @contractCode varchar(100)
	declare @status int
	declare @unitPrice int
	declare @taxPrice int
	declare @totalMoney int 
	declare @totalPrice int
	declare @contractId int
	declare @amount int 

	DECLARE contact_cursor CURSOR FOR  
		select * from supplycenter.dbo.tb_tempPurchase where status = 0
	OPEN contact_cursor
	fetch next from contact_cursor into @purchaseCode,@price,@contractCode,@status
	while @@FETCH_STATUS=0
	begin
	   set @taxPrice = @price
	   set @unitPrice = @taxPrice/1.17
	   select @amount = amount/100 from supplycenter.materie.tb_materiePurchase where purchasecode = @purchaseCode
	   set @totalMoney  = @taxPrice*@amount
	   set @totalPrice = @totalMoney/1.17
	   update supplycenter.materie.tb_materiePurchase set 
		totalMoney = @totalMoney,totalPrice = @totalPrice,unitprice = @unitPrice,
		taxprice = @taxPrice
	   where purchasecode = @purchaseCode
	   update supplyCenter..tb_tempPurchase set status = 1 where purchaseCode = @purchaseCode and price = @price
	  fetch next from contact_cursor into @purchaseCode,@price,@contractCode,@status
	end
	close contact_cursor
	deallocate contact_cursor
END
