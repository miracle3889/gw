-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[p_addPi]
	@materialsChildId int,@needInstorage_str varchar(10),@needInstorageKG_str varchar(10),@userId int
AS
BEGIN
begin tran 
begin try
	declare @shelfCode varchar(50),@needInstorage int,@materialsId int,@taskId int,@purchaseId int,@needInstorageKG int
	,@piId int,@reciveId int,@ocAmount int,@batchId int
	
	set @needInstorage = cast(cast(@needInstorage_str as decimal(18,2))*100 as int)
	set @needInstorageKG = cast(cast(@needInstorageKG_str as decimal(18,2))*100 as int)
	
	--取采购表的taskId
	
	
	--增加recive
	select @reciveId = min(d.id),@purchaseId = min(a.id),@materialsId = MIN(b.materieChildId),@shelfCode = min(d.shelfCode),@taskId = min(a.materiepurchase_task) from supplycenter.materie.tb_materiePurchase a
			inner join supplycenter.materie.tb_materiePurchase_child b on b.purchaseId = a.id 
			inner join supplycenter.materie.tb_materiePurchase_child_pi c on c.materielId = b.id
			inner join supplycenter.materie.tb_reciveRecord d on d.materialPiId = c.id
		where b.id = @materialsChildId and d.status=2
	
	update supplycenter.materie.tb_materiePurchase set amount = amount+@needInstorage,kgamount = kgamount+@needInstorageKG where id = @purchaseId
	
	
	--child表增加amount
	update supplycenter.materie.tb_materiePurchase_child set amount = amount + @needInstorage,kgamount =kgamount+@needInstorageKG  where id = @materialsChildId
	
	select @batchId = MAX(batchId) from  supplycenter.materie.tb_materiePurchase_child_pi where materielId = @materialsChildId
	set @batchId = @batchId+1
	--增加pi表
	insert into supplycenter.materie.tb_materiePurchase_child_pi (batchId,count,materielId,kgamount)
	values(@batchId,@needInstorage,@materialsChildId,@needInstorageKG)
	set @piId = SCOPE_IDENTITY()
	--update supplycenter.materie.tb_materiePurchase_child_pi set batchId = @piId where id = @piId
	
	--增加recive
	insert into supplycenter.materie.tb_reciveRecord(applyTime,arrivalTime,materialPiId,outFactoryNum,settleMent,
										settlementNumber,shelfCode,status,usefulNumber,storageTime,storageUserId,outFactoryKGNum,usefullKGNumber)
	select GETDATE(),arrivalTime,@piId,@needInstorage,settleMent,@needInstorage,shelfCode,2,@needInstorage,GETDATE(),storageUserId,@needInstorageKG,@needInstorageKG
		from  supplycenter.materie.tb_reciveRecord where id = @reciveId
		
	if(@taskId=0)  set @ocAmount = 0
	else
	begin
		set @ocAmount = @needInstorage
	end
	
	--增加shelfstorage
	update supplycenter.materie.tb_shelfStorage set storageAmount=storageAmount+@needInstorage 
		where shelfCode = @shelfCode and materialsSkuId = @materialsId
	
	--更新占用记录
	update supplycenter.materie.tb_materie_OccupancyInventory set count = count+@needInstorage 
		where purchaseId = @purchaseId and materieSkuId = @materialsId
		
	--更新色号表
	update designcenter.materials.tb_materials_sku set storageAmount = storageAmount+@needInstorage,occupancyAmount = occupancyAmount+@ocAmount where id = @materialsId
	
	insert into supplycenter.materie.tb_addPiHistory(materialsChildId,needInstorage_str,userId)
	values(@materialsChildId,@needInstorage_str,@userId)
	commit tran 
	select 1 as ret
end try 
begin catch 
	 rollback tran 
	 declare @msg varchar(2000)
	 set @msg=error_message()
	 --exec  ruhnnsystem.[dbo].[p_sendWeiXinMsg_title] '执行出错，回滚',@msg,829
	 select 0 as ret
end catch
END
