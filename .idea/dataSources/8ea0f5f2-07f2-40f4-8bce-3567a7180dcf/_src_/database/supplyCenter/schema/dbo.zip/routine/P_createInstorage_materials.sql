-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[P_createInstorage_materials]
AS
BEGIN
    -- documentsType 1.采购单入库   2.剩料还回入库  3.工厂入库单,4.反冲工厂入库单           productType    2.原料入库单 3.工厂入库单
    -- documentsType 1.成品入库   2.剩料还回  3.原料仓出库单,4.暂估出库,5.全部出库   	  2.原料仓出库单 3.工厂出库单
    -- documentsType               
    
    --3.原料   4.发出物资
    
    --12.采购业务入库10000米
	--13.生成计划出库2000米
	--14.自助领料出库100米
	--15.生产计划完结，总计领用1500米
	--16.剩料还回500米
	--17.未完成生产计划，预计出库200米
	--18.次月初上月暂估出库200米
	--19, 退货出库
	--20,销售出库

    
	---------------------------------入库1.采购单入库
	--上个月1号到最后一天
	--declare @startDate varchar(20) = '2016-05-01 00:00:00'
	--declare @endDate varchar(20) = '2016-05-31 23:59:59'
	
	--更新公斤结算的入库米数/入库公斤数 到色卡表
	exec dbo.p_modifySekaBili
	
	declare @startDate varchar(20),@endDate varchar(20)
	select @startDate = convert(varchar(8),dateadd(mm,-1,getdate()),120) + '01'+' 00:00:00',
       @endDate = convert(varchar(10),cast(convert(varchar(8),getdate(),120) + '01' as datetime) - 1,120)+' 23:59:59' 


	--查到有几个入库批次 按天按供应商
	DECLARE cursor_dateSupplider CURSOR for
	select convert(varchar(20),a.storageTime,23 ),d.suppliderId from supplycenter.materie.tb_reciveRecord a
			inner join supplycenter.materie.tb_materiePurchase_child_pi b on b.id = a.materialPiId
			inner join supplycenter.materie.tb_materiePurchase_child c on c.id = b.materielId
			inner join supplycenter.materie.tb_materiePurchase d on c.purchaseId = d.id
	where a.status = 2 and a.storageTime>=@startDate and a.storageTime < @endDate 
	group by convert(varchar(20),a.storageTime,23 ),d.suppliderId
	
	open cursor_dateSupplider 
	declare @main_date varchar(20),@suppliderId int,@inStoreBatchId varchar(20),@outStoreBatchId varchar(20),@index_id int, @inStoreDocumentsId int, @outStoreDocumentsId int
	FETCH NEXT FROM  cursor_dateSupplider INTO @main_date,@suppliderId
	WHILE @@FETCH_STATUS = 0
	BEGIN
		--生成原料入库单号
		insert into finance.store.tb_inStoreDocuments(inStoreBatchId,supliderId,inStoreDate,documentsType,productType)
			values('',@suppliderId,@main_date,12,3)
		set @inStoreDocumentsId = SCOPE_IDENTITY()
		set @inStoreBatchId = cast(@suppliderId as varchar(10))+'12'
		while(LEN(@inStoreBatchId)<6) set @inStoreBatchId = '0'+@inStoreBatchId
		set @inStoreBatchId = 'YLRK'+SUBSTRING(replace(@main_date,'-',''),3,12)+@inStoreBatchId
		update finance.store.tb_inStoreDocuments set inStoreBatchId = @inStoreBatchId where ID = @inStoreDocumentsId
		
		insert into finance.store.tb_inStoreDocuments_child(inStoreBatchId,code,category,brandId,amount,documentsBatchId,documentsContractCode,inStoreUserId,purchaseId,inStoreDate)
		select 
			@inStoreBatchId,
			d.materielId,isnull(min(x.category),''),min(d.brandId) ,case when min(g.priceunit) = 0 then  sum(a.usefulNumber) else SUM(a.usefullkgNumber) end,d.purchaseCode,min(e.contractCode),min(a.storageUserId),min(d.applyUserId),min(a.storageTime)
			from supplycenter.materie.tb_reciveRecord a
		inner join supplycenter.materie.tb_materiePurchase_child_pi b on b.id = a.materialPiId
		inner join supplycenter.materie.tb_materiePurchase_child c on c.id = b.materielId
		inner join supplycenter.materie.tb_materiePurchase d on c.purchaseId = d.id
		inner join supplycenter.materie.tb_contract e on e.id = d.contractId
		inner join designcenter.materials.tb_materials g on g.id = d.materielId
		left join 
		(
			select a.id,b.name+','+c.name+case when d.name is null then '' else ','+d.name end category
			 from designcenter.materials.tb_materials a
			  inner join designcenter.materials.tb_materials_cardClassType b on b.id = a.lablePid 
			  inner join designcenter.materials.tb_materials_cardCodeClassOne c on c.id = a.lableId 
			  left join designcenter.materials.tb_materials_cardCodeClassTwo d on d.id = a.lableTwoId  
		) x on x.id = d.materielId
			where a.status = 2 and convert(varchar(20),a.storageTime,23 ) = @main_date and d.suppliderId = @suppliderId
		group by d.materielId,d.purchaseCode
		FETCH NEXT FROM  cursor_dateSupplider INTO @main_date,@suppliderId
	END	

	--关闭游标
	CLOSE cursor_dateSupplider
	--释放资源
	DEALLOCATE cursor_dateSupplider
	
	
	---------------------------------入库2.剩料还回入库
	declare cursor_remainingBack CURSOR for
	select convert(varchar(20),a.onshelftime,23 ),factoryId 
		from supplycenter.materie.tb_material_remainingBack a 
	where 
		onShelfTime is not null 
		and a.onshelftime>=@startDate and a.onshelftime < @endDate
		group by  convert(varchar(20),a.onshelftime,23 ),factoryId
    open cursor_remainingBack
    FETCH NEXT FROM cursor_remainingBack into @main_date,@suppliderId
    WHILE @@FETCH_STATUS = 0
    begin
		insert into finance.store.tb_inStoreDocuments(inStoreBatchId,factoryId,inStoreDate,documentsType,productType)
			values('',@suppliderId,@main_date,16,4)
		set @inStoreDocumentsId = SCOPE_IDENTITY()
		set @inStoreBatchId = cast(@suppliderId as varchar(10))+'16'
		while(LEN(@inStoreBatchId)<6) set @inStoreBatchId = '0'+@inStoreBatchId
		set @inStoreBatchId = 'YLRK'+SUBSTRING(replace(@main_date,'-',''),3,12)+@inStoreBatchId
		update finance.store.tb_inStoreDocuments set inStoreBatchId = @inStoreBatchId where ID = @inStoreDocumentsId
		
		insert into finance.store.tb_inStoreDocuments_child(inStoreBatchId,code,category,brandId,amount,documentsBatchId,documentsContractCode,inStoreUserId,purchaseId,inStoreDate)
    
		--剩料还回 工厂负的入库单
		select @inStoreBatchId,b.materialsId,min(isnull(x.category,'')),min(d.brandId)
			,case when min(e.priceunit)=0 then -sum(a.commitAmount) else CAST(-sum(a.commitAmount)*min(e.bili) as int) end
			,'','',min(a.onShelfUserId),min(a.backUserId),min(a.onShelfTime) 
		from  supplycenter.materie.tb_material_remainingBack a 
		   inner join designcenter.materials.tb_materials_sku b on a.materialSkuId = b.id
		   inner join supplycenter.production.tb_production_task c on c.id = a.produceTaskId
		   inner join supplycenter.materie.tb_materiePurchase_task d on d.id = c.purchaseTaskId
		   inner join designcenter.materials.tb_materials e on e.id =b.materialsId 
		   left join 
				(
					select a.id,b.name+','+c.name+case when d.name is null then '' else ','+d.name end category
					 from designcenter.materials.tb_materials a
					  inner join designcenter.materials.tb_materials_cardClassType b on b.id = a.lablePid 
					  inner join designcenter.materials.tb_materials_cardCodeClassOne c on c.id = a.lableId 
					  left join designcenter.materials.tb_materials_cardCodeClassTwo d on d.id = a.lableTwoId  
				) x on x.id = b.materialsId
		   where convert(varchar(20),a.onshelftime,23 ) = @main_date and a.factoryId = @suppliderId
		   group by b.materialsId
		--剩料还回 原料负的出库单
		insert into  finance.store.tb_outStoreDocuments(outStoreBatchId,outStoreDate,documentsType,productType,factoryId)
		            values('',@main_date,16,3,@suppliderId)
		set @outStoreDocumentsId = SCOPE_IDENTITY()
		set @outStoreBatchId = cast(@suppliderId as varchar(10))+'16'
		while(LEN(@outStoreBatchId)<6) set @outStoreBatchId = '0'+@outStoreBatchId
		set @outStoreBatchId = 'YLCK'+SUBSTRING(replace(@main_date,'-',''),3,12)+@outStoreBatchId
		update finance.store.tb_outStoreDocuments set outStoreBatchId = @outStoreBatchId where ID = @outStoreDocumentsId
		
		insert into finance.store.tb_outStoreDocuments_child (outStoreBatchId,code,category,amount,documentsBatchId,documentsContractCode,outStoreUserId,outStoreDate)
		select @inStoreBatchId,b.materialsId,min(isnull(x.category,''))
		,case when min(e.priceunit)=0 then -sum(a.commitAmount) else CAST(-sum(a.commitAmount)*min(e.bili) as int) end
		,'','',min(a.onShelfUserId),min(a.onShelfTime) 
		from  supplycenter.materie.tb_material_remainingBack a 
		   inner join designcenter.materials.tb_materials_sku b on a.materialSkuId = b.id
		   inner join designcenter.materials.tb_materials e on e.id = b.materialsId
		   --inner join supplycenter.production.tb_production_task c on c.id = a.produceTaskId
		   --inner join supplycenter.materie.tb_materiePurchase_task d on d.id = c.purchaseTaskId
		   left join 
				(
					select a.id,b.name+','+c.name+case when d.name is null then '' else ','+d.name end category
					 from designcenter.materials.tb_materials a
					  inner join designcenter.materials.tb_materials_cardClassType b on b.id = a.lablePid 
					  inner join designcenter.materials.tb_materials_cardCodeClassOne c on c.id = a.lableId 
					  left join designcenter.materials.tb_materials_cardCodeClassTwo d on d.id = a.lableTwoId  
				) x on x.id = b.materialsId
		   where convert(varchar(20),a.onshelftime,23 ) = @main_date and a.factoryId = @suppliderId
		   group by b.materialsId
		 FETCH NEXT FROM cursor_remainingBack into @main_date,@suppliderId
    end
    CLOSE cursor_remainingBack
	DEALLOCATE cursor_remainingBack
	
	
	
	----原料仓出库单  
	declare  cursor_pickupRecord CURSOR for
	 select convert(varchar(20),b.exportTime,23 ),d.factoryId from  supplycenter.materie.tb_material_pickupRecord a    
         inner join supplycenter.materie.tb_material_exportRecord b on a.id =b.pickupRecordId
         inner join supplycenter.production.tb_production_task d on d.id = a.produceTaskId
         and b.exportTime>=@startDate and b.exportTime < @endDate
        group by convert(varchar(20),b.exportTime,23 ),d.factoryId
	open cursor_pickupRecord
	FETCH NEXT FROM cursor_pickupRecord into @main_date,@suppliderId
    WHILE @@FETCH_STATUS = 0
    begin
		--生成原料仓出库单
		insert into  finance.store.tb_outStoreDocuments(outStoreBatchId,outStoreDate,documentsType,productType,factoryId)
		            values('',@main_date,13,3,@suppliderId)
		set @outStoreDocumentsId = SCOPE_IDENTITY()
		set @outStoreBatchId = cast(@suppliderId as varchar(10))+'13'
		while(LEN(@outStoreBatchId)<6) set @outStoreBatchId = '0'+@outStoreBatchId
		set @outStoreBatchId = 'YLCK'+SUBSTRING(replace(@main_date,'-',''),3,12)+@outStoreBatchId
		update finance.store.tb_outStoreDocuments set outStoreBatchId = @outStoreBatchId where ID = @outStoreDocumentsId
		
		insert into finance.store.tb_outStoreDocuments_child (outStoreBatchId,code,category,amount,documentsBatchId,documentsContractCode,outStoreUserId,outStoreDate)
		select @outStoreBatchId,c.materialsId,min(isnull(x.category,''))
		,case when min(e.priceunit)=0 then sum(b.amount) else CAST(sum(b.amount)*min(e.bili) as int) end
		,'','',min(b.exportUserId),min(b.exportTime)
			from supplycenter.materie.tb_material_pickupRecord a
         inner join supplycenter.materie.tb_material_exportRecord b on a.id =b.pickupRecordId
         inner join designcenter.materials.tb_materials_sku c on c.id = a.materialSkuId
         inner join supplycenter.production.tb_production_task d on d.id = a.produceTaskId
         inner join designcenter.materials.tb_materials e on e.id = c.materialsId
         left join 
				(
					select a.id,b.name+','+c.name+case when d.name is null then '' else ','+d.name end category
					 from designcenter.materials.tb_materials a
					  inner join designcenter.materials.tb_materials_cardClassType b on b.id = a.lablePid 
					  inner join designcenter.materials.tb_materials_cardCodeClassOne c on c.id = a.lableId 
					  left join designcenter.materials.tb_materials_cardCodeClassTwo d on d.id = a.lableTwoId  
				) x on x.id = c.materialsId
        where convert(varchar(20),b.exportTime,23 ) = @main_date and d.factoryId = @suppliderId
        group by c.materialsId
        
        --工厂入库
        insert into finance.store.tb_inStoreDocuments(inStoreBatchId,supliderId,inStoreDate,documentsType,productType)
			values('',@suppliderId,@main_date,13,4)
		set @inStoreDocumentsId = SCOPE_IDENTITY()
		set @inStoreBatchId = cast(@suppliderId as varchar(10))+'13'
		while(LEN(@inStoreBatchId)<6) set @inStoreBatchId = '0'+@inStoreBatchId
		set @inStoreBatchId = 'YLRK'+SUBSTRING(replace(@main_date,'-',''),3,12)+@inStoreBatchId
		update finance.store.tb_inStoreDocuments set inStoreBatchId = @inStoreBatchId where ID = @inStoreDocumentsId
		
		insert into finance.store.tb_inStoreDocuments_child(inStoreBatchId,code,category,brandId,amount,documentsBatchId,documentsContractCode,inStoreUserId,purchaseId,inStoreDate)
		select @inStoreBatchId,c.materialsId,min(isnull(x.category,'')),min(e.brandId)
		,case when min(f.priceunit)=0 then sum(b.amount) else CAST(sum(b.amount)*min(f.bili) as int) end
		,'','',min(b.exportUserId),min(b.exportUserId),min(b.exportTime)
			from supplycenter.materie.tb_material_pickupRecord a
         inner join supplycenter.materie.tb_material_exportRecord b on a.id =b.pickupRecordId
         inner join designcenter.materials.tb_materials_sku c on c.id = a.materialSkuId
         inner join supplycenter.production.tb_production_task d on d.id = a.produceTaskId
         inner join supplycenter.materie.tb_materiePurchase_task e on d.purchaseTaskId = e.id
         inner join designcenter.materials.tb_materials f on f.id= c.materialsId
         left join 
				(
					select a.id,b.name+','+c.name+case when d.name is null then '' else ','+d.name end category
					 from designcenter.materials.tb_materials a
					  inner join designcenter.materials.tb_materials_cardClassType b on b.id = a.lablePid 
					  inner join designcenter.materials.tb_materials_cardCodeClassOne c on c.id = a.lableId 
					  left join designcenter.materials.tb_materials_cardCodeClassTwo d on d.id = a.lableTwoId  
				) x on x.id = c.materialsId
        where convert(varchar(20),b.exportTime,23 ) = @main_date and d.factoryId = @suppliderId
        group by c.materialsId
        FETCH NEXT FROM cursor_pickupRecord into @main_date,@suppliderId
    end
    CLOSE cursor_pickupRecord
	DEALLOCATE cursor_pickupRecord
	
	
	----工厂入库单
	----declare  cursor_signRecord CURSOR for
	----select convert(varchar(20),b.signTime,23 ),d.factoryId from  supplycenter.materie.tb_material_pickupRecord a    
 ----        inner join supplycenter.materie.tb_material_exportRecord b on a.id =b.pickupRecordId
 ----        inner join supplycenter.production.tb_production_task d on d.id = a.produceTaskId
 ----      where b.signTime is not null 
 ----      and b.signTime>=@startDate and b.signTime < @endDate
 ----      group by convert(varchar(20),b.signTime,23 ),d.factoryId
 ----   open cursor_signRecord
 ----   FETCH NEXT FROM cursor_signRecord into @main_date,@suppliderId
 ----   WHILE @@FETCH_STATUS = 0
 ----   begin
		
        
 ----       FETCH NEXT FROM cursor_signRecord into @main_date,@suppliderId
 ----   end
 ----   CLOSE cursor_signRecord
	----DEALLOCATE cursor_signRecord
	
	
	----TODO 工厂出库    select convert(varchar(10),cast(convert(varchar(8),getdate(),120) + '01' as datetime) - 1,120)
	----2.查找上个月未完结的  查找已入库记录，做暂估出库
	----1.查找上个月是暂估出库的  反冲到这个月（入库）
	----3.查找上个月已完结的  做全部出库 
	declare @chengpin_taskId int,@chengpin_status int , @chengpin_storageAmount int ,@chengpin_planCount int ,@chengpin_factoryId int,@chengpin_outStorageUserId int
	declare @chengpin_mainDate varchar(20)= convert(varchar(10),cast(convert(varchar(8),getdate(),120) + '01' as datetime) - 1,120)
	declare @chengpin_mainDate_String varchar(20) = SUBSTRING(replace(@chengpin_mainDate,'-',''),3,12),@endPurchaseDate datetime
	declare  cursor_instorageChengpin CURSOR for 
	 select * from (
		select min(b.completeTime) completeTime,a.taskId,case when b.status<4 then 0 else 4 end status,case when SUM(a.storageAmount)>min(b.planCount) then min(b.planCount)else SUM(a.storageAmount) end  storageAmount,min(c.inStorageUserId) inStorageUserId,MIN(b.planCount) planCount,min(b.factoryId) factoryId  from supplyCenter.production.tb_outfactory_batch_child a
		inner join supplycenter.production.tb_production_task b on a.taskId=b.id 
		inner join supplyCenter.production.tb_outfactory_batch c on c.factoryCode = a.factoryCode
		where  b.status<4 or(b.status = 4 and b.completeTime>=@startDate and b.completeTime<@endDate) 
		   --and c.inStorageTime>=@startDate and c.inStorageTime<@endDate
		group by a.taskId,case when b.status<4 then 0 else 4 end 
	)x where x.storageAmount>0
	open cursor_instorageChengpin
	FETCH NEXT FROM cursor_instorageChengpin into @endPurchaseDate,@chengpin_taskId,@chengpin_status,@chengpin_storageAmount,@chengpin_outStorageUserId,@chengpin_planCount,@chengpin_factoryId
    WHILE @@FETCH_STATUS = 0
	begin
		if @chengpin_status = 0 set @chengpin_status = 17
		else set @chengpin_status = 15
		insert into  finance.store.tb_outStoreDocuments(outStoreBatchId,outStoreDate,documentsType,productType,factoryId,brandId)
		           -- values('',@chengpin_mainDate,@chengpin_status,4,@chengpin_factoryId,@chengpin_taskId)
		           values('',@endPurchaseDate,@chengpin_status,4,@chengpin_factoryId,@chengpin_taskId)
		set @outStoreDocumentsId = SCOPE_IDENTITY()
		set @outStoreBatchId = cast(@chengpin_taskId as varchar(10))+cast(@chengpin_status as varchar(10))
		while(LEN(@outStoreBatchId)<6) set @outStoreBatchId = '0'+@outStoreBatchId
		set @outStoreBatchId = 'YLCK'+@chengpin_mainDate_String+@outStoreBatchId
		update finance.store.tb_outStoreDocuments set outStoreBatchId = @outStoreBatchId where ID = @outStoreDocumentsId
		
		insert into finance.store.tb_outStoreDocuments_child (outStoreBatchId,code,category,amount,documentsBatchId,documentsContractCode,outStoreUserId,outStoreDate)
		select @outStoreBatchId,c.materialsId,isnull(MIN(x.category),''),
			case when 
				@chengpin_status=15 then  cast(SUM(case when e.priceunit=0 then b.amount else cast(b.amount*e.bili as bigint) end) as bigint) 
			else cast(SUM(case when e.priceunit=0 then b.amount else cast(b.amount*e.bili as bigint) end) as bigint)*@chengpin_storageAmount/@chengpin_planCount 
			end signAmount
			,'','',@chengpin_outStorageUserId,@endPurchaseDate from supplycenter.materie.tb_material_pickupRecord a
			inner join supplycenter.materie.tb_material_exportRecord b on a.id =b.pickupRecordId
			inner join supplycenter.production.tb_production_task d on d.id = a.produceTaskId
			inner join designcenter.materials.tb_materials_sku c on c.id = a.materialSkuId
			inner join designcenter.materials.tb_materials e on e.id = c.materialsId
			left join 
				(
					select a.id,b.name+','+c.name+case when d.name is null then '' else ','+d.name end category
					 from designcenter.materials.tb_materials a
					  inner join designcenter.materials.tb_materials_cardClassType b on b.id = a.lablePid 
					  inner join designcenter.materials.tb_materials_cardCodeClassOne c on c.id = a.lableId 
					  left join designcenter.materials.tb_materials_cardCodeClassTwo d on d.id = a.lableTwoId  
				) x on x.id = c.materialsId
			   where  a.produceTaskId = @chengpin_taskId
			group by a.produceTaskId,c.materialsId 
		FETCH NEXT FROM cursor_instorageChengpin into @endPurchaseDate,@chengpin_taskId,@chengpin_status,@chengpin_storageAmount,@chengpin_outStorageUserId,@chengpin_planCount,@chengpin_factoryId
	end
	CLOSE cursor_instorageChengpin
	DEALLOCATE cursor_instorageChengpin
	
	----反冲上个月的暂估出库记录
	declare @zangu_outStoreCode varchar(20),@zangu_brandId int ,@zangu_factoryId int,@zangu_mainDate varchar(20)= convert(varchar(20),getDate(),23 )
	declare cursor_chengpinZangu cursor for 
	select outStoreBatchId,brandId,factoryId from finance.store.tb_outStoreDocuments 
		where documentsType = 17 and productType = 4 
				and outStoreDate>=@startDate and outStoreDate<@endDate
	open cursor_chengpinZangu
	FETCH NEXT FROM cursor_chengpinZangu into @zangu_outStoreCode,@zangu_brandId,@zangu_factoryId
    WHILE @@FETCH_STATUS = 0
	begin
		insert into finance.store.tb_outStoreDocuments(outStoreBatchId,factoryId,outStoreDate,documentsType,productType)
			values('',@zangu_factoryId,@zangu_mainDate,18,4)
		set @inStoreDocumentsId = SCOPE_IDENTITY()
		set @inStoreBatchId = cast(@zangu_brandId as varchar(10))+'18'
		while(LEN(@inStoreBatchId)<6) set @inStoreBatchId = '0'+@inStoreBatchId
		set @inStoreBatchId = 'YLRK'+SUBSTRING(replace(@zangu_mainDate,'-',''),3,12)+@inStoreBatchId
		update finance.store.tb_outStoreDocuments set outStoreBatchId = @inStoreBatchId where ID = @inStoreDocumentsId
		
		insert into finance.store.tb_outStoreDocuments_child(outStoreBatchId,code,category,amount,documentsBatchId,documentsContractCode,outStoreUserId,outStoreDate)
		select @inStoreBatchId,code,category,-amount,documentsBatchId,documentsContractCode,outStoreUserId,@zangu_mainDate  from finance.store.tb_outStoreDocuments_child 
		where outStoreBatchId = @zangu_outStoreCode
		FETCH NEXT FROM cursor_chengpinZangu into @zangu_outStoreCode,@zangu_brandId,@zangu_factoryId
	end 
	CLOSE cursor_chengpinZangu
	DEALLOCATE cursor_chengpinZangu
END
